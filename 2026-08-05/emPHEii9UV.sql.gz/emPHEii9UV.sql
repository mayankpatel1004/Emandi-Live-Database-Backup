-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: emPHEii9UV
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `emPHEii9UV`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `emPHEii9UV` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `emPHEii9UV`;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AREA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
INSERT INTO `AREA` VALUES (1,'274',NULL,NULL,'4','OTHERS','4_OTHERS','450','450',NULL,450,0,'2026-08-05 10:18:00','2026-08-05 10:18:00'),(2,'274',NULL,NULL,'1','DEFAULT','1_DEFAULT','450','450',NULL,450,0,'2026-08-05 10:18:00','2026-08-05 10:18:00'),(3,'274',NULL,NULL,'3','DHARAVI','3_DHARAVI','450','450',NULL,450,0,'2026-08-05 10:18:00','2026-08-05 10:18:00');
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CONFIG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text,
  `MASTER` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'274','0','emPHEii9UV',274,'','','','2026-08-05 10:16:20','2026-08-05 10:16:20','','','','','','','','','2026-08-05 10:16:20','450','450','',0,'2026-08-05 10:16:20','2026-08-05 10:16:20');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` varchar(255) DEFAULT 'No',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=275 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (274,NULL,NULL,NULL,'P3 ENTERPRISE','2026-04-01','2027-03-31','E19/5, Shahu Nagar','Mahim East','Mumbai','21','9022596423','','','','','','','','','','','','','','11521015000268',NULL,'0',NULL,NULL,'27','27DOFPK4866A1ZY','','p3enterprise0208@gmail.com','','400017',NULL,'1',NULL,'No','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-08-05 10:16:20','2026-08-05 10:16:20',NULL,'','','p3','Yes');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `CREATED_TS` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `BATCH_ID` int DEFAULT '0',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DISP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `DELETED` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int DEFAULT '0',
  `TAX_ID` int DEFAULT '0',
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `CONFIG_UNIT` varchar(255) DEFAULT 'mm',
  `DISPLAY_STATUS` varchar(255) DEFAULT 'Y',
  `SELECT_OPTIONS` int NOT NULL DEFAULT '0',
  `GROUP_ID` int NOT NULL DEFAULT '0',
  `DISPLAY_ORDER` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'Printpage_size','255mm 100mm','mm','Y',0,1,0),(2,'Printpage_Left_Margin','16','mm','Y',0,1,0),(3,'Top_Left_Width','97','mm','Y',0,2,0),(4,'Padding_Top_Right','5','px','Y',0,2,0),(5,'Items_Height','45','mm','Y',0,3,0),(6,'List_2','20','mm','Y',0,3,0),(7,'List_4','94','mm','Y',0,3,0),(8,'List_6','5','mm','Y',0,3,0),(9,'List_8','25','mm','Y',0,3,0),(10,'List_10','15','mm','Y',0,3,0),(11,'List_12','25','mm','Y',0,3,0),(12,'Footer_Padding_Top','2','mm','Y',0,4,0),(13,'Footer_2','25','mm','Y',0,4,0),(14,'Footer_4','17','mm','Y',0,4,0),(15,'Footer_6','21','mm','Y',0,4,0),(16,'Footer_8','14','mm','Y',0,4,0),(17,'Footer_10','0','mm','Y',0,4,0);
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INV_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'274',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'274',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'274',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'274',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'274',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'274',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'274',NULL,NULL,'465','','P3/','2026-27','15','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LEDGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `MAC_ID` int DEFAULT '0',
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int DEFAULT '0',
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int DEFAULT '0',
  `ROOT_PARENT_ID` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(14,'1',NULL,'1','UPI','UPI','bank','1','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text,
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `SAC_ID` int NOT NULL DEFAULT '0',
  `REMOTE_ID` int NOT NULL DEFAULT '0',
  `PENDING_AMT` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `PROD_ID` int NOT NULL DEFAULT '0',
  `PACK` int NOT NULL DEFAULT '0',
  `PROD_BATCH_ID` int NOT NULL DEFAULT '0',
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int NOT NULL DEFAULT '0',
  `PUR_RET_QTY` int NOT NULL DEFAULT '0',
  `PUR_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `PUR_TOTAL` int NOT NULL DEFAULT '0',
  `SALE_QTY` int DEFAULT '0',
  `SALE_RET_QTY` int DEFAULT '0',
  `SALE_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `SALE_TOTAL` int NOT NULL DEFAULT '0',
  `OP_STOCK` int NOT NULL DEFAULT '0',
  `CLOSING_STOCK` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MINIMUM_STOCK_LEVEL` int NOT NULL DEFAULT '0',
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'274',NULL,NULL,'441',NULL,'','ThumpsUp/Cocacola1.00 LTR','ThumpsUp/Cocacola1.00 LTR','22021010','1','6',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(2,'274',NULL,NULL,'442',NULL,'','FANTA 1 LTR','FANTA 1 LTR','22021010','1','6',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(3,'274',NULL,NULL,'1000',NULL,'','TATA SALT 1 KG','TATA SALT 1 KG','25010010','1','3',NULL,'2','TATA SALT','7','10','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','TATA SALT',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(4,'274',NULL,NULL,'195',NULL,'','Frooti 1.2Ltr','Frooti 1.2Ltr','22029020','1.2','6',NULL,'3','PEPSI','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(5,'274',NULL,NULL,'102',NULL,'','BIG COLA 1.5 LTR','BIG COLA 1.5 LTR','22021010','1.5','6',NULL,'4','BIG COLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','BIG COLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(6,'274',NULL,NULL,'104',NULL,'','Big Cola Orange 1.5 Ltr','Big Cola Orange 1.5 Ltr','22021010','1.5','6',NULL,'4','BIG COLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','BIG COLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(7,'274',NULL,NULL,'194',NULL,'','Frooti 1.8 ltr','Frooti 1.8 ltr','22029020','1.8','6',NULL,'3','PEPSI','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(8,'274',NULL,NULL,'430',NULL,'','THUMSUP 2.2LT','THUMSUP 2.2LT','22021010','2.2','6',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(9,'274',NULL,NULL,'431',NULL,'','Limca 2.2 ltr','Limca 2.2 ltr','22021010','2.2','6',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(10,'274',NULL,NULL,'432',NULL,'','Fanta 2.2ltr','Fanta 2.2ltr','22021010','2.2','6',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(11,'274',NULL,NULL,'433',NULL,'','Cocacola 2.2 Ltr','Cocacola 2.2 Ltr','22021010','2.2','6',NULL,'5','Monster','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Monster',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(12,'274',NULL,NULL,'470',NULL,'','Sprite 150 Ml PET','Sprite 150 Ml PET','22021010','150','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(13,'274',NULL,NULL,'471',NULL,'','LIMCA 150ML PET','LIMCA 150ML PET','22021010','150','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(14,'274',NULL,NULL,'606',NULL,'','STING 180ML CAN','STING 180ML CAN','22021010','180','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(15,'274',NULL,NULL,'510',NULL,'','CAMPA ORANGE 185ML CAN','CAMPA ORANGE 185ML CAN','22021010','185','5',NULL,'6','CAMPLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CAMPLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(16,'274',NULL,NULL,'511',NULL,'','CAMPA LEMON 185ML CAN','CAMPA LEMON 185ML CAN','22021010','185','5',NULL,'6','CAMPLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CAMPLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(17,'274',NULL,NULL,'512',NULL,'','CAMPA COLA 185ML CAN','CAMPA COLA 185ML CAN','22021010','185','5',NULL,'6','CAMPLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CAMPLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(18,'274',NULL,NULL,'513',NULL,'','CAMPA COLA 200ML PET','CAMPA COLA 200ML PET','22021010','200','5',NULL,'6','CAMPLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CAMPLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(19,'274',NULL,NULL,'514',NULL,'','CAMPA LEMON 200ML PET','CAMPA LEMON 200ML PET','22021010','200','5',NULL,'6','CAMPLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CAMPLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(20,'274',NULL,NULL,'515',NULL,'','CAMPA ORANGE 200ML PET','CAMPA ORANGE 200ML PET','22021010','200','5',NULL,'6','CAMPLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CAMPLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(21,'274',NULL,NULL,'421',NULL,'','MAAZA 250 ML','MAAZA 250 ML','22029020','250','5',NULL,'7','Maaza','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Maaza',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(22,'274',NULL,NULL,'602',NULL,'','KINLEY SODA','KINLEY SODA','22029990','250','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(23,'274',NULL,NULL,'459',NULL,'','FANTA 250 ML','FANTA 250 ML','22021010','250','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(24,'274',NULL,NULL,'189',NULL,'','Appy Fizz 250 ml PET','Appy Fizz 250 ml PET','22021010','250','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(25,'274',NULL,NULL,'200',NULL,'','FROOTI 250ML CAN','FROOTI 250ML CAN','22029020','250','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(26,'274',NULL,NULL,'301',NULL,'','THUMSUP 300ml Can','THUMSUP 300ml Can','22021010','300','5',NULL,'8','COCACOLA CAN','7','10','24',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','COCACOLA CAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(27,'274',NULL,NULL,'401',NULL,'','LIMCA 300 ml Can','LIMCA 300 ml Can','22021010','300','5',NULL,'8','COCACOLA CAN','7','10','24',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','COCACOLA CAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(28,'274',NULL,NULL,'501',NULL,'','FANTA 300 ml Can','FANTA 300 ml Can','22021010','300','5',NULL,'8','COCACOLA CAN','7','10','24',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','COCACOLA CAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(29,'274',NULL,NULL,'601',NULL,'','MIX CAN 300 ML','MIX CAN 300 ML','22021010','300','5',NULL,'8','COCACOLA CAN','7','10','24',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','COCACOLA CAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(30,'274',NULL,NULL,'302',NULL,'','COCACOLA 300 ML CAN','COCACOLA 300 ML CAN','22021010','300','5',NULL,'8','COCACOLA CAN','7','10','24',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','COCACOLA CAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(31,'274',NULL,NULL,'303',NULL,'','Sprite 300 ML CAN','Sprite 300 ML CAN','22021010','300','5',NULL,'8','COCACOLA CAN','7','10','24',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','COCACOLA CAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(32,'274',NULL,NULL,'111',NULL,'','Schweppes Ginger Ale','Schweppes Ginger Ale','22021010','300','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(33,'274',NULL,NULL,'603',NULL,'','7UP FIZZ 300ML CAN','7UP FIZZ 300ML CAN','22021010','300','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(34,'274',NULL,NULL,'604',NULL,'','MOUNTAIN DEW 300ML CAN','MOUNTAIN DEW 300ML CAN','22021010','300','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(35,'274',NULL,NULL,'605',NULL,'','PEPSI COLA','PEPSI COLA','22021010','300','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(36,'274',NULL,NULL,'607',NULL,'','MIRINDA 300 ML CAN','MIRINDA 300 ML CAN','22021010','300','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(37,'274',NULL,NULL,'196',NULL,'','Frooti 330 ML','Frooti 330 ML','22029020','330','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(38,'274',NULL,NULL,'502',NULL,'','Monster 350ml Can','Monster 350ml Can','22021010','350','5',NULL,'5','Monster','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Monster',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(39,'274',NULL,NULL,'191',NULL,'','PEPSI NIMBUZ 350ML','PEPSI NIMBUZ 350ML','22029920','350','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(40,'274',NULL,NULL,'460',NULL,'','Cocacola 400ml','Cocacola 400ml','22021010','400','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(41,'274',NULL,NULL,'402',NULL,'','MAAZA 600ML','MAAZA 600ML','22029020','600','5',NULL,'7','Maaza','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','Maaza',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(42,'274',NULL,NULL,'197',NULL,'','Frooti 600ml','Frooti 600ml','22029020','600','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(43,'274',NULL,NULL,'103',NULL,'','Big Cola 600ml','Big Cola 600ml','22021010','600','5',NULL,'4','BIG COLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','BIG COLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(44,'274',NULL,NULL,'105',NULL,'','Big Cola Orange 600 Ml','Big Cola Orange 600 Ml','22021010','600','5',NULL,'4','BIG COLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','BIG COLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(45,'274',NULL,NULL,'450',NULL,'','THUMSUP 750ML','THUMSUP 750ML','22021010','750','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(46,'274',NULL,NULL,'455',NULL,'','Limca 750 Ml','Limca 750 Ml','22021010','750','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(47,'274',NULL,NULL,'456',NULL,'','Fanta 750ml','Fanta 750ml','22021010','750','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(48,'274',NULL,NULL,'457',NULL,'','Sprite 750ml','Sprite 750ml','22021010','750','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(49,'274',NULL,NULL,'458',NULL,'','Coca-Cola 750 Ml','Coca-Cola 750 Ml','22021010','750','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(50,'274',NULL,NULL,'201',NULL,'','Mountain Dew 750 Ml','Mountain Dew 750 Ml','22021010','750','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(51,'274',NULL,NULL,'608',NULL,'','Mirinda 750ml','Mirinda 750ml','22021010','750','5',NULL,'5','Monster','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Monster',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(52,'274',NULL,NULL,'101',NULL,'','MIX CAN 300ML','MIX CAN 300ML','22021010','300','3',NULL,'8','COCACOLA CAN','7','10','24',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','COCACOLA CAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(53,'274',NULL,NULL,'199',NULL,'','MAAZA /APPY Tetra Pack TP 160/135 ML','MAAZA /APPY Tetra Pack TP 160/135 ML','22029020','160','3',NULL,'7','Maaza','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Maaza',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(54,'274',NULL,NULL,'110',NULL,'','Schweppes Tonic water','Schweppes Tonic water','22021010','1','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(55,'274',NULL,NULL,'420',NULL,'','MAAZA 1.2 LT','MAAZA 1.2 LT','22029020','1.2','6',NULL,'7','Maaza','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Maaza',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(56,'274',NULL,NULL,'440',NULL,'','THUMSUP/LIMCA 1.25 LT','THUMSUP/LIMCA 1.25 LT','22021010','1.2','6',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(57,'274',NULL,NULL,'451',NULL,'','THUMSUP/LIMCA 600ML','THUMSUP/LIMCA 600ML','22021010','600','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(58,'274',NULL,NULL,'452',NULL,'','THUMPS UP 250ML','THUMPS UP 250ML','22021010','250','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(59,'274',NULL,NULL,'422',NULL,'','PULPY ORANGE 250 ML','PULPY ORANGE 250 ML','22021010','250','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(60,'274',NULL,NULL,'190',NULL,'','Red Bull/ Sting / Hell 250ml','Red Bull/ Sting / Hell 250ml','22021010','250','5',NULL,'5','Monster','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Monster',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(61,'274',NULL,NULL,'453',NULL,'','LIMCA 250 ML','LIMCA 250 ML','22021010','250','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(62,'274',NULL,NULL,'454',NULL,'','250ML SPRITE COCACOLA','250ML SPRITE COCACOLA','22021010','250','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(63,'274',NULL,NULL,'198',NULL,'','FROOTI 125ML TP','FROOTI 125ML TP','22029020','125','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(64,'274',NULL,NULL,'211',NULL,'','TESTY MANGO 200 ML','TESTY MANGO 200 ML','22021090','200','5',NULL,'9','OTHERS','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(65,'274',NULL,NULL,'212',NULL,'','RIM ZIM / TESTY MIX 250 ML','RIM ZIM / TESTY MIX 250 ML','22021010','250','5',NULL,'9','OTHERS','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(66,'274',NULL,NULL,'112',NULL,'','Schweppes Soda','Schweppes Soda','22029990','1','5',NULL,'1','COCACOLA PET','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','COCACOLA PET',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(67,'274',NULL,NULL,'192',NULL,'','APPY FIZZ 600ML','APPY FIZZ 600ML','22021010','600','5',NULL,'3','PEPSI','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(68,'274',NULL,NULL,'193',NULL,'','APPY FIZZ 1LTR','APPY FIZZ 1LTR','22021010','1','6',NULL,'3','PEPSI','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PEPSI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(69,'274',NULL,NULL,'188',NULL,'','Appy Fizz 250ml CAN','Appy Fizz 250ml CAN','22021010','250','5',NULL,'5','Monster','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Monster',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(70,'274',NULL,NULL,'503',NULL,'','GS BOTTLE MIX','GS BOTTLE MIX','22021010','1','5',NULL,'5','Monster','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','Monster',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(71,'274',NULL,NULL,'516',NULL,'','CAMPA ENERGY','CAMPA ENERGY','22021010','1','5',NULL,'6','CAMPLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CAMPLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(72,'274',NULL,NULL,'517',NULL,'','CAMPA JEERU','CAMPA JEERU','22021010','1','5',NULL,'6','CAMPLA','7','10','1',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','CAMPLA',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL);
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'274',NULL,NULL,'COCACOLA PET','1',NULL,NULL,NULL,450,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:18:36','2026-08-05 10:18:36'),(2,'274',NULL,NULL,'TATA SALT','1',NULL,NULL,NULL,450,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:18:36','2026-08-05 10:18:36'),(3,'274',NULL,NULL,'PEPSI','1',NULL,NULL,NULL,450,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:18:36','2026-08-05 10:18:36'),(4,'274',NULL,NULL,'BIG COLA','1',NULL,NULL,NULL,450,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:18:36','2026-08-05 10:18:36'),(5,'274',NULL,NULL,'Monster','1',NULL,NULL,NULL,450,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:18:36','2026-08-05 10:18:36'),(6,'274',NULL,NULL,'CAMPLA','1',NULL,NULL,NULL,450,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:18:36','2026-08-05 10:18:36'),(7,'274',NULL,NULL,'Maaza','1',NULL,NULL,NULL,450,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:18:36','2026-08-05 10:18:36'),(8,'274',NULL,NULL,'COCACOLA CAN','1',NULL,NULL,NULL,450,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:18:36','2026-08-05 10:18:36'),(9,'274',NULL,NULL,'OTHERS','1',NULL,NULL,NULL,450,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:18:36','2026-08-05 10:18:36');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MINIMUM_STOCK_LEVEL` int NOT NULL DEFAULT '0',
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'274',NULL,NULL,'1','230904170718','2026-08-05','2026-08-05','441','0','0','0','55','690','0','680','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(2,'274',NULL,NULL,'2','260616124305','2026-08-05','2026-08-05','442','0','0','0','0','0','0','442.86','0','-442.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(3,'274',NULL,NULL,'3','260708222328','2026-08-05','2026-08-05','1000','0','0','0','0','820','0','795','0','25','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(4,'274',NULL,NULL,'4','250226190505','2026-08-05','2026-08-05','195','0','0','0','0','705','0','705','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(5,'274',NULL,NULL,'5','251124120355','2026-08-05','2026-08-05','102','0','0','0','0','595','0','595','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(6,'274',NULL,NULL,'6','251127101558','2026-08-05','2026-08-05','104','0','0','0','0','595','0','595','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(7,'274',NULL,NULL,'7','250303081627','2026-08-05','2026-08-05','194','0','0','0','0','630','0','630','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(8,'274',NULL,NULL,'8','211019193521','2026-08-05','2026-08-05','430','0','0','0','0','690','0','640','0','50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(9,'274',NULL,NULL,'9','240218151948','2026-08-05','2026-08-05','431','0','0','0','0','680','0','680','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(10,'274',NULL,NULL,'10','240218152054','2026-08-05','2026-08-05','432','0','0','0','0','0','0','680','0','-680','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(11,'274',NULL,NULL,'11','260702181507','2026-08-05','2026-08-05','433','0','0','0','0','765','0','765','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(12,'274',NULL,NULL,'12','260527201404','2026-08-05','2026-08-05','470','0','0','0','10','280','0','280','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(13,'274',NULL,NULL,'13','260527201445','2026-08-05','2026-08-05','471','0','0','0','10','280','0','280','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:36',NULL),(14,'274',NULL,NULL,'14','251107204624','2026-08-05','2026-08-05','606','0','0','0','30','0','0','710','0','-710','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(15,'274',NULL,NULL,'15','251219220942','2026-08-05','2026-08-05','510','0','0','0','0','495','0','475','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(16,'274',NULL,NULL,'16','251219221159','2026-08-05','2026-08-05','511','0','0','0','0','495','0','475','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(17,'274',NULL,NULL,'17','251219221418','2026-08-05','2026-08-05','512','0','0','0','0','495','0','475','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(18,'274',NULL,NULL,'18','251219221527','2026-08-05','2026-08-05','513','0','0','0','0','245','0','225','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(19,'274',NULL,NULL,'19','251219221641','2026-08-05','2026-08-05','514','0','0','0','0','245','0','225','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(20,'274',NULL,NULL,'20','251219221715','2026-08-05','2026-08-05','515','0','0','0','0','245','0','225','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(21,'274',NULL,NULL,'21','211030095618','2026-08-05','2026-08-05','421','0','0','0','25','480','0','383.93','0','96.07','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(22,'274',NULL,NULL,'22','230203111459','2026-08-05','2026-08-05','602','0','0','0','0','505','0','500','0','5','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(23,'274',NULL,NULL,'23','250110131003','2026-08-05','2026-08-05','459','0','0','0','0','475','0','475','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(24,'274',NULL,NULL,'24','250303093950','2026-08-05','2026-08-05','189','0','0','0','20','475','0','475','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(25,'274',NULL,NULL,'25','250428205808','2026-08-05','2026-08-05','200','0','0','0','0','0','0','642.86','0','-642.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(26,'274',NULL,NULL,'26','210923172057','2026-08-05','2026-08-05','301','0','0','0','40','20.24','0','442.86','0','-422.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(27,'274',NULL,NULL,'27','210923172156','2026-08-05','2026-08-05','401','0','0','0','40','20.24','0','442.86','0','-422.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(28,'274',NULL,NULL,'28','210923172329','2026-08-05','2026-08-05','501','0','0','0','40','20.24','0','442.86','0','-422.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(29,'274',NULL,NULL,'29','210923172502','2026-08-05','2026-08-05','601','0','0','0','40','20.24','0','442.86','0','-422.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(30,'274',NULL,NULL,'30','230219221503','2026-08-05','2026-08-05','302','0','0','0','40','27.7084','0','665','0','-637.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(31,'274',NULL,NULL,'31','231030105145','2026-08-05','2026-08-05','303','0','0','0','40','675','0','660','0','15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(32,'274',NULL,NULL,'32','240706171818','2026-08-05','2026-08-05','111','0','0','0','0','990','0','975','0','15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(33,'274',NULL,NULL,'33','251107204351','2026-08-05','2026-08-05','603','0','0','0','40','0','0','820','0','-820','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(34,'274',NULL,NULL,'34','251107204500','2026-08-05','2026-08-05','604','0','0','0','40','0','0','820','0','-820','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(35,'274',NULL,NULL,'35','251107204542','2026-08-05','2026-08-05','605','0','0','0','40','0','0','820','0','-820','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(36,'274',NULL,NULL,'36','251107204709','2026-08-05','2026-08-05','607','0','0','0','40','0','0','820','0','-820','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(37,'274',NULL,NULL,'37','250226190555','2026-08-05','2026-08-05','196','0','0','0','0','475','0','475','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(38,'274',NULL,NULL,'38','230131224002','2026-08-05','2026-08-05','502','0','0','0','110','44.6667','0','1071.43','0','-1026.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(39,'274',NULL,NULL,'39','250212081014','2026-08-05','2026-08-05','191','0','0','0','0','510','0','350','0','160','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(40,'274',NULL,NULL,'40','250623095914','2026-08-05','2026-08-05','460','0','0','0','0','0','0','300','0','-300','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(41,'274',NULL,NULL,'41','210929120345','2026-08-05','2026-08-05','402','0','0','0','35','25.3','0','680','0','-654.7','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(42,'274',NULL,NULL,'42','241229142817','2026-08-05','2026-08-05','197','0','0','0','0','790','0','790','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(43,'274',NULL,NULL,'43','251127101502','2026-08-05','2026-08-05','103','0','0','0','0','475','0','475','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(44,'274',NULL,NULL,'44','251127101646','2026-08-05','2026-08-05','105','0','0','0','0','575','0','575','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(45,'274',NULL,NULL,'45','211019193855','2026-08-05','2026-08-05','450','0','0','0','40','760','0','730','0','30','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(46,'274',NULL,NULL,'46','240218152234','2026-08-05','2026-08-05','455','0','0','0','0','785','0','750','0','35','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(47,'274',NULL,NULL,'47','240218152318','2026-08-05','2026-08-05','456','0','0','0','0','785','0','750','0','35','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(48,'274',NULL,NULL,'48','240626110323','2026-08-05','2026-08-05','457','0','0','0','0','815','0','810','0','5','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(49,'274',NULL,NULL,'49','240626110423','2026-08-05','2026-08-05','458','0','0','0','0','815','0','810','0','5','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(50,'274',NULL,NULL,'50','250611211340','2026-08-05','2026-08-05','201','0','0','0','0','680','0','680','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(51,'274',NULL,NULL,'51','260106171031','2026-08-05','2026-08-05','608','0','0','0','0','785','0','765','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(52,'274',NULL,NULL,'52','210917125555','2026-08-05','2026-08-05','101','0','0','0','35','19.65','0','472.86','0','-453.21','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(53,'274',NULL,NULL,'53','210917130130','2026-08-05','2026-08-05','199','0','0','0','10','267.85','0','232.13','0','35.72','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(54,'274',NULL,NULL,'54','210917135433','2026-08-05','2026-08-05','110','0','0','0','0','642.86','0','571.43','0','71.43','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(55,'274',NULL,NULL,'55','211019193308','2026-08-05','2026-08-05','420','0','0','0','70','690','0','640','0','50','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(56,'274',NULL,NULL,'56','211019193653','2026-08-05','2026-08-05','440','0','0','0','0','630','0','610','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(57,'274',NULL,NULL,'57','211019194014','2026-08-05','2026-08-05','451','0','0','0','38','690','0','660','0','30','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(58,'274',NULL,NULL,'58','211019194213','2026-08-05','2026-08-05','452','0','0','0','20','450','0','430','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(59,'274',NULL,NULL,'59','211030095722','2026-08-05','2026-08-05','422','0','0','0','20','480','0','410.71','0','69.29','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(60,'274',NULL,NULL,'60','211031180146','2026-08-05','2026-08-05','198','0','0','0','20','340','0','332.14','0','7.86','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(61,'274',NULL,NULL,'61','211102125209','2026-08-05','2026-08-05','453','0','0','0','20','445','0','440','0','5','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(62,'274',NULL,NULL,'62','211102125254','2026-08-05','2026-08-05','454','0','0','0','20','445','0','440','0','5','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(63,'274',NULL,NULL,'63','211111195217','2026-08-05','2026-08-05','198','0','0','0','10','310','0','300','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(64,'274',NULL,NULL,'64','211130174820','2026-08-05','2026-08-05','501','0','0','0','10','165','0','138.39','0','26.61','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(65,'274',NULL,NULL,'65','211130175005','2026-08-05','2026-08-05','212','0','0','0','20','450','0','450','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(66,'274',NULL,NULL,'66','240706171940','2026-08-05','2026-08-05','112','0','0','0','0','990','0','975','0','15','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(67,'274',NULL,NULL,'67','250222220415','2026-08-05','2026-08-05','192','0','0','0','0','670','0','542.86','0','127.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(68,'274',NULL,NULL,'68','250222220616','2026-08-05','2026-08-05','193','0','0','0','0','680','0','464.29','0','215.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(69,'274',NULL,NULL,'69','250925120524','2026-08-05','2026-08-05','188','0','0','0','0','950','0','950','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(70,'274',NULL,NULL,'70','251222200702','2026-08-05','2026-08-05','0','0','0','0','0','0','0','192','0','-192','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(71,'274',NULL,NULL,'71','260107120847','2026-08-05','2026-08-05','516','0','0','0','0','600','0','580','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL),(72,'274',NULL,NULL,'72','260107120923','2026-08-05','2026-08-05','517','0','0','0','0','380','0','360','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,450,0,'2026-08-05 10:18:37',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MINIMUM_STOCK_LEVEL` int NOT NULL DEFAULT '0',
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
INSERT INTO `PROD_BATCH_IMPORT` VALUES (1,'274','441','ThumpsUp/Cocacola1.00 LTR','22021010','1','LTR','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','441','0','0','55','680','690','0','0','0','1','230904170718','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(2,'274','442','FANTA 1 LTR','22021010','1','LTR','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','442','0','0','0','442.86','0','0','0','0','1','260616124305','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(3,'274','1000','TATA SALT 1 KG','25010010','1','KG','TATA SALT','TATA SALT','BOX','PCS','1','GST-0','GST-0','1000','0','0','0','795','820','0','0','0','1','260708222328','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(4,'274','195','Frooti 1.2Ltr','22029020','1.2','LTR','PEPSI','PEPSI','BOX','PCS','1','GST-5','GST-5','195','0','0','0','705','705','0','0','0','1','250226190505','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(5,'274','102','BIG COLA 1.5 LTR','22021010','1.5','LTR','BIG COLA','BIG COLA','BOX','PCS','1','GST-40','GST-40','102','0','0','0','595','595','0','0','0','1','251124120355','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(6,'274','104','Big Cola Orange 1.5 Ltr','22021010','1.5','LTR','BIG COLA','BIG COLA','BOX','PCS','1','GST-40','GST-40','104','0','0','0','595','595','0','0','0','1','251127101558','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(7,'274','194','Frooti 1.8 ltr','22029020','1.8','LTR','PEPSI','PEPSI','BOX','PCS','1','GST-5','GST-5','194','0','0','0','630','630','0','0','0','1','250303081627','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(8,'274','430','THUMSUP 2.2LT','22021010','2.2','LTR','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','430','0','0','0','640','690','0','0','0','1','211019193521','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(9,'274','431','Limca 2.2 ltr','22021010','2.2','LTR','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','431','0','0','0','680','680','0','0','0','1','240218151948','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(10,'274','432','Fanta 2.2ltr','22021010','2.2','LTR','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','432','0','0','0','680','0','0','0','0','1','240218152054','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(11,'274','433','Cocacola 2.2 Ltr','22021010','2.2','LTR','Monster','Monster','BOX','PCS','1','GST-40','GST-40','433','0','0','0','765','765','0','0','0','1','260702181507','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(12,'274','470','Sprite 150 Ml PET','22021010','150','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','470','0','0','10','280','280','0','0','0','1','260527201404','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(13,'274','471','LIMCA 150ML PET','22021010','150','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','471','0','0','10','280','280','0','0','0','1','260527201445','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(14,'274','606','STING 180ML CAN','22021010','180','ML','PEPSI','PEPSI','BOX','PCS','1','GST-40','GST-40','606','0','0','30','710','0','0','0','0','1','251107204624','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(15,'274','510','CAMPA ORANGE 185ML CAN','22021010','185','ML','CAMPLA','CAMPLA','BOX','PCS','1','GST-40','GST-40','510','0','0','0','475','495','0','0','0','1','251219220942','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(16,'274','511','CAMPA LEMON 185ML CAN','22021010','185','ML','CAMPLA','CAMPLA','BOX','PCS','1','GST-40','GST-40','511','0','0','0','475','495','0','0','0','1','251219221159','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(17,'274','512','CAMPA COLA 185ML CAN','22021010','185','ML','CAMPLA','CAMPLA','BOX','PCS','1','GST-40','GST-40','512','0','0','0','475','495','0','0','0','1','251219221418','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(18,'274','513','CAMPA COLA 200ML PET','22021010','200','ML','CAMPLA','CAMPLA','BOX','PCS','1','GST-40','GST-40','513','0','0','0','225','245','0','0','0','1','251219221527','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(19,'274','514','CAMPA LEMON 200ML PET','22021010','200','ML','CAMPLA','CAMPLA','BOX','PCS','1','GST-40','GST-40','514','0','0','0','225','245','0','0','0','1','251219221641','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(20,'274','515','CAMPA ORANGE 200ML PET','22021010','200','ML','CAMPLA','CAMPLA','BOX','PCS','1','GST-40','GST-40','515','0','0','0','225','245','0','0','0','1','251219221715','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(21,'274','421','MAAZA 250 ML','22029020','250','ML','Maaza','Maaza','BOX','PCS','1','GST-5','GST-5','421','0','0','25','383.93','480','0','0','0','1','211030095618','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(22,'274','602','KINLEY SODA','22029990','250','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-5','GST-5','602','0','0','0','500','505','0','0','0','1','230203111459','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(23,'274','459','FANTA 250 ML','22021010','250','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','459','0','0','0','475','475','0','0','0','1','250110131003','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(24,'274','189','Appy Fizz 250 ml PET','22021010','250','ML','PEPSI','PEPSI','BOX','PCS','1','GST-40','GST-40','189','0','0','20','475','475','0','0','0','1','250303093950','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(25,'274','200','FROOTI 250ML CAN','22029020','250','ML','PEPSI','PEPSI','BOX','PCS','1','GST-40','GST-40','200','0','0','0','642.86','0','0','0','0','1','250428205808','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(26,'274','301','THUMSUP 300ml Can','22021010','300','ML','COCACOLA CAN','COCACOLA CAN','BOX','PCS','24','GST-40','GST-40','301','0','0','40','442.86','20.24','0','0','0','24','210923172057','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(27,'274','401','LIMCA 300 ml Can','22021010','300','ML','COCACOLA CAN','COCACOLA CAN','BOX','PCS','24','GST-40','GST-40','401','0','0','40','442.86','20.24','0','0','0','24','210923172156','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(28,'274','501','FANTA 300 ml Can','22021010','300','ML','COCACOLA CAN','COCACOLA CAN','BOX','PCS','24','GST-40','GST-40','501','0','0','40','442.86','20.24','0','0','0','24','210923172329','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(29,'274','601','MIX CAN 300 ML','22021010','300','ML','COCACOLA CAN','COCACOLA CAN','BOX','PCS','24','GST-40','GST-40','601','0','0','40','442.86','20.24','0','0','0','24','210923172502','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(30,'274','302','COCACOLA 300 ML CAN','22021010','300','ML','COCACOLA CAN','COCACOLA CAN','BOX','PCS','24','GST-40','GST-40','302','0','0','40','665','27.7084','0','0','0','24','230219221503','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(31,'274','303','Sprite 300 ML CAN','22021010','300','ML','COCACOLA CAN','COCACOLA CAN','BOX','PCS','24','GST-40','GST-40','303','0','0','40','660','675','0','0','0','24','231030105145','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(32,'274','111','Schweppes Ginger Ale','22021010','300','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','111','0','0','0','975','990','0','0','0','1','240706171818','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(33,'274','603','7UP FIZZ 300ML CAN','22021010','300','ML','PEPSI','PEPSI','BOX','PCS','1','GST-40','GST-40','603','0','0','40','820','0','0','0','0','1','251107204351','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(34,'274','604','MOUNTAIN DEW 300ML CAN','22021010','300','ML','PEPSI','PEPSI','BOX','PCS','1','GST-40','GST-40','604','0','0','40','820','0','0','0','0','1','251107204500','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(35,'274','605','PEPSI COLA','22021010','300','ML','PEPSI','PEPSI','BOX','PCS','1','GST-40','GST-40','605','0','0','40','820','0','0','0','0','1','251107204542','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(36,'274','607','MIRINDA 300 ML CAN','22021010','300','ML','PEPSI','PEPSI','BOX','PCS','1','GST-40','GST-40','607','0','0','40','820','0','0','0','0','1','251107204709','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(37,'274','196','Frooti 330 ML','22029020','330','ML','PEPSI','PEPSI','BOX','PCS','1','GST-5','GST-5','196','0','0','0','475','475','0','0','0','1','250226190555','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(38,'274','502','Monster 350ml Can','22021010','350','ML','Monster','Monster','BOX','PCS','1','GST-40','GST-40','502','0','0','110','1071.43','44.6667','0','0','0','1','230131224002','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(39,'274','191','PEPSI NIMBUZ 350ML','22029920','350','ML','PEPSI','PEPSI','BOX','PCS','1','GST-5','GST-5','191','0','0','0','350','510','0','0','0','1','250212081014','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(40,'274','460','Cocacola 400ml','22021010','400','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','460','0','0','0','300','0','0','0','0','1','250623095914','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(41,'274','402','MAAZA 600ML','22029020','600','ML','Maaza','Maaza','BOX','PCS','24','GST-5','GST-5','402','0','0','35','680','25.3','0','0','0','24','210929120345','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(42,'274','197','Frooti 600ml','22029020','600','ML','PEPSI','PEPSI','BOX','PCS','1','GST-5','GST-5','197','0','0','0','790','790','0','0','0','1','241229142817','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(43,'274','103','Big Cola 600ml','22021010','600','ML','BIG COLA','BIG COLA','BOX','PCS','1','GST-40','GST-40','103','0','0','0','475','475','0','0','0','1','251127101502','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(44,'274','105','Big Cola Orange 600 Ml','22021010','600','ML','BIG COLA','BIG COLA','BOX','PCS','1','GST-40','GST-40','105','0','0','0','575','575','0','0','0','1','251127101646','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(45,'274','450','THUMSUP 750ML','22021010','750','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','450','0','0','40','730','760','0','0','0','1','211019193855','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(46,'274','455','Limca 750 Ml','22021010','750','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','455','0','0','0','750','785','0','0','0','1','240218152234','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(47,'274','456','Fanta 750ml','22021010','750','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','456','0','0','0','750','785','0','0','0','1','240218152318','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(48,'274','457','Sprite 750ml','22021010','750','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','457','0','0','0','810','815','0','0','0','1','240626110323','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(49,'274','458','Coca-Cola 750 Ml','22021010','750','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','458','0','0','0','810','815','0','0','0','1','240626110423','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(50,'274','201','Mountain Dew 750 Ml','22021010','750','ML','PEPSI','PEPSI','BOX','PCS','1','GST-40','GST-40','201','0','0','0','680','680','0','0','0','1','250611211340','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(51,'274','608','Mirinda 750ml','22021010','750','ML','Monster','Monster','BOX','PCS','1','GST-40','GST-40','608','0','0','0','765','785','0','0','0','1','260106171031','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(52,'274','101','MIX CAN 300ML','22021010','300','KG','COCACOLA CAN','COCACOLA CAN','BOX','PCS','24','GST-40','GST-40','101','0','0','35','472.86','19.65','0','0','0','24','210917125555','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(53,'274','199','MAAZA /APPY Tetra Pack TP 160/135 ML','22029020','160','KG','Maaza','Maaza','BOX','PCS','1','GST-5','GST-5','199','0','0','10','232.13','267.85','0','0','0','1','210917130130','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(54,'274','110','Schweppes Tonic water','22021010','1','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','110','0','0','0','571.43','642.86','0','0','0','1','210917135433','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(55,'274','420','MAAZA 1.2 LT','22029020','1.2','LTR','Maaza','Maaza','BOX','PCS','1','GST-5','GST-5','420','0','0','70','640','690','0','0','0','1','211019193308','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(56,'274','440','THUMSUP/LIMCA 1.25 LT','22021010','1.2','LTR','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','440','0','0','0','610','630','0','0','0','1','211019193653','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(57,'274','451','THUMSUP/LIMCA 600ML','22021010','600','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','451','0','0','38','660','690','0','0','0','1','211019194014','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(58,'274','452','THUMPS UP 250ML','22021010','250','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','452','0','0','20','430','450','0','0','0','1','211019194213','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(59,'274','422','PULPY ORANGE 250 ML','22021010','250','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-5','GST-5','422','0','0','20','410.71','480','0','0','0','1','211030095722','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(60,'274','190','Red Bull/ Sting / Hell 250ml','22021010','250','ML','Monster','Monster','BOX','PCS','1','GST-40','GST-40','198','0','0','20','332.14','340','0','0','0','1','211031180146','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(61,'274','453','LIMCA 250 ML','22021010','250','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','453','0','0','20','440','445','0','0','0','1','211102125209','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(62,'274','454','250ML SPRITE COCACOLA','22021010','250','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-40','GST-40','454','0','0','20','440','445','0','0','0','1','211102125254','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(63,'274','198','FROOTI 125ML TP','22029020','125','ML','PEPSI','PEPSI','BOX','PCS','1','GST-5','GST-5','198','0','0','10','300','310','0','0','0','1','211111195217','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(64,'274','211','TESTY MANGO 200 ML','22021090','200','ML','OTHERS','OTHERS','BOX','PCS','1','GST-5','GST-5','501','0','0','10','138.39','165','0','0','0','1','211130174820','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(65,'274','212','RIM ZIM / TESTY MIX 250 ML','22021010','250','ML','OTHERS','OTHERS','BOX','PCS','1','GST-40','GST-40','212','0','0','20','450','450','0','0','0','1','211130175005','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(66,'274','112','Schweppes Soda','22029990','1','ML','COCACOLA PET','COCACOLA PET','BOX','PCS','1','GST-5','GST-5','112','0','0','0','975','990','0','0','0','1','240706171940','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(67,'274','192','APPY FIZZ 600ML','22021010','600','ML','PEPSI','PEPSI','BOX','PCS','1','GST-40','GST-40','192','0','0','0','542.86','670','0','0','0','1','250222220415','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(68,'274','193','APPY FIZZ 1LTR','22021010','1','LTR','PEPSI','PEPSI','BOX','PCS','1','GST-40','GST-40','193','0','0','0','464.29','680','0','0','0','1','250222220616','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(69,'274','188','Appy Fizz 250ml CAN','22021010','250','ML','Monster','Monster','BOX','PCS','1','GST-40','GST-40','188','0','0','0','950','950','0','0','0','1','250925120524','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(70,'274','503','GS BOTTLE MIX','22021010','1','ML','Monster','Monster','BOX','PCS','1','GST-40','GST-40','0','0','0','0','192','0','0','0','0','1','251222200702','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(71,'274','516','CAMPA ENERGY','22021010','1','ML','CAMPLA','CAMPLA','BOX','PCS','1','GST-40','GST-40','516','0','0','0','580','600','0','0','0','1','260107120847','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450),(72,'274','517','CAMPA JEERU','22021010','1','ML','CAMPLA','CAMPLA','BOX','PCS','1','GST-40','GST-40','517','0','0','0','360','380','0','0','0','1','260107120923','2026-08-05','2026-08-05','7',0.00,0.00,0.00,0.00,0,450);
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int DEFAULT '0',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int DEFAULT '0',
  `M_ROUND_OFF` int DEFAULT '0',
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUPPLIER_ID',
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'PUR_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text,
  `INV_NO` text,
  `LOGIN_ID` int DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT 'mrp_value',
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `PROD_ID` int NOT NULL,
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PACK` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BOX` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN_QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `FREE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `CESS_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT 'PUR_DATE',
  `WEIGHT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PRICE_PER` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SALE_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DMG_MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CLOUD_SYNC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `INV_ARR` text COLLATE utf8mb4_general_ci COMMENT 'add_amt',
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'less_amt',
  `LOGIN_ID` int DEFAULT '0',
  `CREATED_BY` int DEFAULT NULL,
  `UPDATED_BY` int DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_TS` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SUPPLIER_ID` int DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8mb4_general_ci,
  `GROUP_ID` int DEFAULT NULL,
  `FINAL_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BATCH_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TCS_TAX` varchar(100) COLLATE utf8mb4_general_ci DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `BROKER_ID` int DEFAULT '0',
  `LOGIN_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUPPLIER_ID',
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'PUR_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REGISTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Parent_Superstockist_Distributor',
  `PARENT_USER_NAME` varchar(255) DEFAULT NULL,
  `PARENT_PASSWORD` varchar(255) DEFAULT NULL,
  `IS_SUPERSTOCKIST` tinyint NOT NULL DEFAULT '0',
  `SUPERSTOCKIST_ID` int DEFAULT '0',
  `EXTRA_1` varchar(255) DEFAULT NULL,
  `EXTRA_2` varchar(255) DEFAULT NULL,
  `ADD1` text,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=451 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (450,'274','0','emPHEii9UV','p3','emPHEii9UV','p3enterprise0208@gmail.com',NULL,NULL,'Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'450','450','',0,'2026-08-05 10:16:20','2026-08-05 10:16:20');
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REMARKS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int DEFAULT '0',
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-08-05 10:16:15',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text,
  `MAC_ID` int DEFAULT '0',
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text,
  `S_ADD2` text,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `DISCOUNT2` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=238 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'274',NULL,NULL,'Cash',14,'19373179.61','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'-3226070',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(2,'274',NULL,NULL,'Additional Tax(GST)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(3,'274',NULL,NULL,'Advertisement & Publicity',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(4,'274',NULL,NULL,'Bad Debts Written Off',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(5,'274',NULL,NULL,'Bank Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(6,'274',NULL,NULL,'Bonus',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(7,'274',NULL,NULL,'Books & Periodicals',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(8,'274',NULL,NULL,'Brokerage',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(9,'274',NULL,NULL,'C Form Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(10,'274',NULL,NULL,'C Form Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(11,'274',NULL,NULL,'Capital Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(12,'274',NULL,NULL,'Central Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(13,'274',NULL,NULL,'CGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(14,'274',NULL,NULL,'Charity & Donations',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(15,'274',NULL,NULL,'Commissions on Sales',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(16,'274',NULL,NULL,'Computers',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(17,'274',NULL,NULL,'Conveyance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(18,'274',NULL,NULL,'CST Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(19,'274',NULL,NULL,'Development Taxes',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(20,'274',NULL,NULL,'Edu. Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(21,'274',NULL,NULL,'Edu. Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(22,'274',NULL,NULL,'Edu. Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(23,'274',NULL,NULL,'Edu. Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(24,'274',NULL,NULL,'Excise Duties',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(25,'274',NULL,NULL,'IGST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(26,'274',NULL,NULL,'SGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(27,'274',NULL,NULL,'Legal Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(28,'274',NULL,NULL,'Market Fees',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(29,'274',NULL,NULL,'National VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(30,'274',NULL,NULL,'RDF',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(31,'274',NULL,NULL,'Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(32,'274',NULL,NULL,'SHE Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(33,'274',NULL,NULL,'SHE Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(34,'274',NULL,NULL,'SHE Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(35,'274',NULL,NULL,'SHE Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(36,'274',NULL,NULL,'Surcharge On VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(37,'274',NULL,NULL,'TDS (Advertisment)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(38,'274',NULL,NULL,'TDS (Commission)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(39,'274',NULL,NULL,'TDS (Contractor)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(40,'274',NULL,NULL,'TDS (Interest)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(41,'274',NULL,NULL,'TDS (Rent)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(42,'274',NULL,NULL,'TDS (Salery)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(43,'274',NULL,NULL,'VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(44,'274',NULL,NULL,'Telephone Expenses',19,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(45,'274',NULL,NULL,'Customer Entertainment Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(46,'274',NULL,NULL,'Depriciation A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(47,'274',NULL,NULL,'Discount',20,'77329.8','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(48,'274',NULL,NULL,'Freight & Forwarding Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(49,'274',NULL,NULL,'Interest Payable A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(50,'274',NULL,NULL,'Job Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(51,'274',NULL,NULL,'Labour',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(52,'274',NULL,NULL,'Legal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(53,'274',NULL,NULL,'Misc. Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(54,'274',NULL,NULL,'Miscellaneous Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(55,'274',NULL,NULL,'Office Maintenance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(56,'274',NULL,NULL,'Office Rent',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0',NULL,'0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-12000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(57,'274',NULL,NULL,'Office Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(58,'274',NULL,NULL,'Postal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(59,'274',NULL,NULL,'Printing & Stationery',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0',NULL,'0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(60,'274',NULL,NULL,'Rounded Off - Sales',20,'0','CR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0',NULL,'0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(61,'274',NULL,NULL,'Salery',20,'20000','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0',NULL,'0','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-34000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(62,'274',NULL,NULL,'Sales Promotion Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(63,'274',NULL,NULL,'Sewing Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(64,'274',NULL,NULL,'Staff Welfare Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(65,'274',NULL,NULL,'Stitching',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(66,'274',NULL,NULL,'Travelling Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(67,'274',NULL,NULL,'Water & Electricity Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(68,'274',NULL,NULL,'Earnest Money',29,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(69,'274',NULL,NULL,'Furnituer & Fixture',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(70,'274',NULL,NULL,'Office Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(71,'274',NULL,NULL,'Plants & Machinery',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(72,'274',NULL,NULL,'CST Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(73,'274',NULL,NULL,'Interstate Retail Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(74,'274',NULL,NULL,'Local B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(75,'274',NULL,NULL,'Sales',27,'58302987.77','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(76,'274',NULL,NULL,'Sales Retail 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(77,'274',NULL,NULL,'Sales Retail 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(78,'274',NULL,NULL,'Sales VAT 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(79,'274',NULL,NULL,'Sales VAT 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(80,'274',NULL,NULL,'Dammi',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(81,'274',NULL,NULL,'Income From National VAT',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(82,'274',NULL,NULL,'Interest Receivable A/c',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(83,'274',NULL,NULL,'Rate Adjustment',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(84,'274',NULL,NULL,'Mall Khata A/c',30,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(85,'274',NULL,NULL,'Profit & Loss',9,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(86,'274',NULL,NULL,'Purchase',25,'53645913.6','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(87,'274',NULL,NULL,'Purchase Retail 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(88,'274',NULL,NULL,'Purchase Retail 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(89,'274',NULL,NULL,'Purchase VAT 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(90,'274',NULL,NULL,'Purchase VAT 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(91,'274',NULL,NULL,'Replacement',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(92,'274',NULL,NULL,'Stock',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(93,'274',NULL,NULL,'Salery & Bonus Payable',24,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(94,'274',NULL,NULL,'Interstate B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(95,'274',NULL,NULL,'CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(96,'274',NULL,NULL,'Additional CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(97,'274',NULL,NULL,'SCHEME-1',20,'35711.8406','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(98,'274',NULL,NULL,'SCHEME-2',20,'1324.16','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-05 10:16:17','2026-08-05 10:16:17'),(99,'274',NULL,NULL,'WALIA FASHIONS',5,'0','DR','E-44 Okhla phase 2 New Delhi -110020','New Delhi','Delhi','Delhi','110020',NULL,'9999999999','NULL',NULL,'0','07AAAPW3642E1ZT',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','239',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(100,'274',NULL,NULL,'Victory Agency',5,'0','DR','opp aher garden, Walhekwarwadi','chinchwadgoan','pune','21','411033',NULL,'0000000000','NULL',NULL,'27','27AADPB9244N1ZG',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','273',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(101,'274',NULL,NULL,'VIMAL OVERSEAS',5,'0','DR','3RD, 54TO63, 418TO424 CHOTALAL BHUWAN,JOSHIWADI','KALBADEVI ROAD','MUMBAI','21','400002',NULL,'02222000133','vimalsoverseas@gmail.com',NULL,'27','27AADFV1164B1ZJ',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','200',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(102,'274',NULL,NULL,'VIKASHINI AGENCY',5,'0','DR','PLOT NO.92,FLAT NO.301,SAI JAGANAT BUILDING,','SECTOR-31,VASHI VILLAGE,','NAVI MUMBAI','21','400703',NULL,'9100000000.0','NULL',NULL,'27','27AQVPT4329G1Z6',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11520016000022',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','199',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(103,'274',NULL,NULL,'VARUN BEVERAGES LTD.',11,'0','DR','F','DEFAULT','NULL','21',NULL,NULL,'9100000000.0','NULL',NULL,'27','27AAACV2678L1ZU',NULL,'NULL',NULL,NULL,'NULL','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','198',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(104,'274',NULL,NULL,'VAIVIN ENTERPRISES',5,'0','DR','FLAT B-701,Ashar-16,','Thane','THANE','21','400604',NULL,'0000000000','NULL',NULL,'27','27AAZFV1142K1ZK',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','260',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(105,'274',NULL,NULL,'Unique Fragrances',5,'0','DR','C 141, TTC Industrial Area MIDC','NAVI MUMBAI,','Pawane','21','400705',NULL,'0000000000','NULL',NULL,'27','27AAAFU1982B1ZD',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','235',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(106,'274',NULL,NULL,'Tulaja Trading Company',5,'0','DR','Plot No 48 & 49, Unit No M127 & M33, Next To Green Park Hotel','Vashi','Navi Mumbai','21','400705',NULL,'9594876777','tulajatradingcompany@gmail.com',NULL,'27','27BFVPK4517F1Z5',NULL,'NEFT',NULL,NULL,'NEFT','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','244',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(107,'274',NULL,NULL,'Tripin Traders',5,'0','DR','32, Nagdevi street,','NULL','mumbai','21','400003',NULL,'0000000000','NULL',NULL,'27','27AABFT9524D1Z7',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','221',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(108,'274',NULL,NULL,'TULSI AGRISCALE IMPEX LLP',5,'0','DR','805, SATARA PLAZA, PLOT NO.19, SECT 19D, PALM BEACH','VASHI,','NAVI MUMBAI','21','400703',NULL,'0000000000','NULL',NULL,'27','27AANFT7253R1Z4',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','262',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(109,'274',NULL,NULL,'TRANS GLOBAL TRADE',5,'0','DR','9, Bhoj Mahal, Plot No.545, Tejukaya Park,','Dr. B. A. Road, Matunga,','Mumbai','21','400019',NULL,'0000000000','NULL',NULL,'27','27ACAPJ5495L1Z6',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','231',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(110,'274',NULL,NULL,'Super Bazar',5,'0','DR','Gd Flr, Shop no 119, European','Wadala','Mumbai','21','400037',NULL,'0000000000','NULL',NULL,'27','27AMCPS7275F2ZO',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','222',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(111,'274',NULL,NULL,'Siddhi Enterprises',5,'0','DR','J 124, SECTOR 3, AIROLI,','NAVI MUMBAI','Mumbai','21','400708',NULL,'0000000000','NULL',NULL,'27','27AFYPV2478N1Z3',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','264',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:01','2026-08-05 10:18:01'),(112,'274',NULL,NULL,'Shalom Services',5,'0','DR','Second Floor A-204','Shree Dutta Krupa Apartment','Thane','21','400705',NULL,'0000000000','NULL',NULL,'27','27ATZPC5967A2ZA',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','232',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(113,'274',NULL,NULL,'SURYA ENTERPRISE',5,'0','DR','MUMBAI 400 001','EGG SECTION,INSIDE CRAWFORD MARKET,','MUMBAI','21','400002',NULL,'9100000000.0','NULL',NULL,'27','27BCSPS3665N1ZI',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11519001000696',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','196',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(114,'274',NULL,NULL,'SUPERMARKET GROCERY SUPPLIES PVT. LTD.',11,'0','DR','C-19,TTC INDUSTRIAL AREA,PAWNE,','THANE BELAPUR ROAD,','NAVI MUMBAI','21','400703',NULL,'9100000000.0','NULL',NULL,'27','27AAQCS4503H1Z6',NULL,'NULL',NULL,NULL,'NULL','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','195',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(115,'274',NULL,NULL,'SUNRISE CHEMICALS',5,'0','DR','207 2ND FLOOR, SAMUEL STREET','MASJID BUNDER WEST','MUMBAI','21','400003',NULL,'9100000000.0','NULL',NULL,'27','27AACFS3511N1Z3',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','194',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(116,'274',NULL,NULL,'SUDHIR SHETH',5,'0','DR','D-10/6,T.T.C.INDUSTRIAL AREA','M.I.D.C.TURBHE.JUINAGAR,','MUMBAI','21','400705',NULL,'9100000000','NULL',NULL,'27','27APRPS5762B1ZG',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','193',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(117,'274',NULL,NULL,'STARKING EXIM LLP',5,'0','DR','C-601, Mangeshi Dazzle 3, Dombivali','90 Feet Road','Kalyan','21','421201',NULL,'0000000000','NULL',NULL,'27','27AFHFS5470G1ZP',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','247',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(118,'274',NULL,NULL,'SPICE NEST IMPEX PRIVATE LIMITED',5,'0','DR','Balaji Hall, 3rd Floor, Office No. 309, RK Prime 2, 150 Feet Ring Road, Mahapuja Dham Chowk,','Rajkot','Gujarat','Gujarat','360004',NULL,'0000000000','NULL',NULL,'0','24ABGCS5965G1Z2',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','248',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(119,'274',NULL,NULL,'SPICE NEST',5,'0','DR','PLOT NO 6 RAMESHWAR IND.','Rajkot','Rajkot','Gujarat','360002',NULL,'0000000000','NULL',NULL,'0','24AAXPR2457H2Z5',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','230',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(120,'274',NULL,NULL,'SPAN IMPEX',5,'0','DR','NEVETIA BUNGLOW, NEVETIA ROAD','MALAD EAST','MUMBAI','21','400097',NULL,'9820571008','spanprem@yahoo.co.in',NULL,'27','27AQRPK6371K1Z4',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','266',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(121,'274',NULL,NULL,'SOHAM SALES',11,'0','CR','GALA NO 5/A, SHREE KRISHNA BHAJI PAPLA','SION PAVVEL HIGHWAY ROAD MANKHURD','MUMBAI','21','400021',NULL,'9867501201','NULL',NULL,'27','27EQHPS4644P1ZW',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','224',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(122,'274',NULL,NULL,'SHUV ENTERPRISE',5,'0','DR','1204,A-WING ANMOL HEIGHTS CO-OP HSG ,LTD,','KURAR VILLAGE, MALAD(E)','MUMBAI','21','400097',NULL,'0000000000','NULL',NULL,'27','27ARCPB7067M1ZJ',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','217',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(123,'274',NULL,NULL,'SHREE SAI ENTERPRISES',11,'0','DR','THANE','DEFAULT','NULL','21',NULL,NULL,'9769863675','mohmmadpatel@gmail.com',NULL,'27','27AVPPP5648D1Z4',NULL,'NULL',NULL,NULL,'NULL','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','192',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(124,'274',NULL,NULL,'SHREE SAI ENTERPRISE',5,'0','DR','SHOP NO.11 KRISHNA COMPLEX GANGA NAGAR','MIRA ROAD (E) THANE','NULL','21','401107',NULL,'0000000000','NULL',NULL,'27','27AVPPP5648D1Z4',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','210',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(125,'274',NULL,NULL,'SHREE BALASA INTERNATIONAL LLP',5,'0','DR','Plot No.22, Vrundavan Industrial Park','Palgham, Umbergaon','Gujarat','Gujarat','396170',NULL,'0000000000','NULL',NULL,'0','24AEEFS5003F1ZH',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','281',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(126,'274',NULL,NULL,'SELMAX EXPORTS PVT LTD',5,'0','DR','PLOT NO D10/5 TURBHE T.T.C','MIDC AREA NEAR SUDHIR SETH','REKUNDA GAON NEAR JAY MATA DI KATTA','21','400705',NULL,'9820655796','mail@selmax.co.in',NULL,'27','27AAFCS1760B1ZO',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10016022005569',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','191',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(127,'274',NULL,NULL,'SEALINK IMPEX',5,'0','DR','501,KAILASH BHUVAN NO.1, M.P, VAIDYA MARG','TILAK ROAD , GHATKOPAR (E)','MUMBAI','21','400077',NULL,'9821241567','NULL',NULL,'27','27AMIPM3282E1Z0',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','229',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(128,'274',NULL,NULL,'SARASWAT BANK',12,'0','DR','DEFAULT','NULL','NULL','21',NULL,NULL,'NULL','NULL',NULL,'27',NULL,NULL,'SARASWAT BANK',NULL,NULL,'NULL','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','202',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(129,'274',NULL,NULL,'SAMAYARAA SALES',11,'0','CR','171, SONALE VILLAGE,','BHIWANDI','','21',NULL,NULL,'0000000000','NULL',NULL,'27','27BEVPK3633P2ZM',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','269',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(130,'274',NULL,NULL,'SALES STOCK ADJ',5,'0','DR','MAHIM','NULL','NULL','21',NULL,NULL,'1234567890','NULL',NULL,'27',NULL,NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','201',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(131,'274',NULL,NULL,'SAI SHRADDHA COLD DRINKS',11,'0','CR','KALYAN','DEFAULT','Mumbai','21','400001',NULL,'9000000000','NULL',NULL,'27','27BEVPK3633P1ZN',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','190',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:02','2026-08-05 10:18:02'),(132,'274',NULL,NULL,'SAI SHRADDHA',5,'0','DR','SHOP NO.2, NIKKI NAGAR,','GANDHARE VILLAGE,KALYAN','THANE','21','421301',NULL,'0000000000','NULL',NULL,'27','27BEVPK3633P1ZN',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','216',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(133,'274',NULL,NULL,'SAI IMPEX',5,'0','DR','C-7, MASALA MARKET PHASE-2 ,APMC MARKET VASHI, NAVI MUMBAI','DEFAULT','NAVI MUMBAI','21','400705',NULL,'9100000000.0','NULL',NULL,'27','27AEOPA4963Q1ZS',NULL,'NEFT',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','189',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(134,'274',NULL,NULL,'SAI AGENCY',5,'0','DR','GODOWN NO. 16, 9 ACRE','MANPADA, THANE WEST','NULL','21','400607',NULL,'0000000000','NULL',NULL,'27','27AJMPK4385M1ZH',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','209',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(135,'274',NULL,NULL,'SAHU ENTERPRISES',5,'0','DR','GALA NO 9 PLOT NO A/3 BGTA GANGA PREMISES CO-OP SOC','WADALA TERMINAL TRUCK','WADALA','21','400037',NULL,'9100000000.0','sahuenterprises@gmail.com',NULL,'27','27AIQPG6919E1Z0',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','197',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(136,'274',NULL,NULL,'SADHNA ENTERPRISES',5,'0','DR','Evrest Infotech Park 2 Plot. No. C-30,31 Pawane Midc','Thane Belapur Road Navi Mumbai','Mumbai','21','400705',NULL,'0000000000','NULL',NULL,'27','27AFKFS5269Q1ZW',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','249',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(137,'274',NULL,NULL,'Rising International',5,'0','DR','501, 5th Floor Shapath 1, Suite # 1019','NULL','Ahmedabad','Gujarat','380054',NULL,'0000000000','NULL',NULL,'0','24ABJFR4468B1Z8',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','282',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(138,'274',NULL,NULL,'Riddhi Enterprise',5,'0','DR','Plot No 37, Sec-5, Nr Tilak School','Ghansoli, Navi Mumbai','Navi Mumbai','21','400704',NULL,'9702150004','NULL',NULL,'27','27AORPG0615A1ZE',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','237',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(139,'274',NULL,NULL,'Redex Global',5,'0','DR','C/o. Gohil Dye Chem D-8/1, TTC Industrial Area,Next To Modhera Chemicals Near Jai Matadi Kata,','Turbhe','Navi Mumbai','21','400705',NULL,'9999999999','NULL',NULL,'27','27ANIPS4006R1ZD',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','228',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(140,'274',NULL,NULL,'ROME TRADING CO',5,'0','DR','7, AHEMDABAD STREET','CARNAC BUNDER','MUMBAI','21','400009',NULL,'0000000000','NULL',NULL,'27','27ASUPG5076E1ZE',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','250',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(141,'274',NULL,NULL,'ROHIT STORES',5,'0','DR','E/19,7,SHAHU NAGAR','MAHIM(E)','MUMBAI','21','400017',NULL,'9100000000','NULL',NULL,'27',NULL,NULL,'NULL',NULL,NULL,'NULL','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','142',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(142,'274',NULL,NULL,'RAVAL TRADING EXPORTS PVT LTD',5,'0','DR','F P 66, T P 151, Survey no. 898','Gandhinagar','Gujarat','Gujarat','382721',NULL,'9979977080','NULL',NULL,'0','24AANCR0497E1Z9',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','255',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(143,'274',NULL,NULL,'RAVAL TRADING COMPANY',5,'0','DR','D-304,TTC INDUSTRIAL AREA,','TURBHE MIDC,','NAVI MUMBAI','21','400705',NULL,'9769904761','NULL',NULL,'27','27AABPR4334F1ZU',NULL,'NEFT',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','207',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(144,'274',NULL,NULL,'R.SHANTILAL & CO.',5,'0','DR','MUMBAI','DEFAULT','NULL','21','',NULL,'9100000000.0','NULL',NULL,'27','27AAAFR0546E1ZK',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','188',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(145,'274',NULL,NULL,'R.P.AGENCIES',5,'0','DR','REY ROAD','DEFAULT','NULL','21','',NULL,'9100000000.0','NULL',NULL,'27','27ACVPP1545J1Z0',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','187',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(146,'274',NULL,NULL,'Quality Spices & Food Exports Pvt Ltd.',11,'0','DR','Plot No. M-1, Ambernath MIDC','NULL','Thane','21','421506',NULL,'9126207000','NULL',NULL,'27','27AAACQ1796J1Z2',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','220',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(147,'274',NULL,NULL,'QUALITY SPICES & FOODS EXPORTS PVT LTD.',5,'0','DR','M-1, ADDITIONAL AMBERNATH MIDC','AMBERNATH EAST','THANE','21','421506',NULL,'9100000000.0','NULL',NULL,'27','27AAACQ1796J1Z2',NULL,'NEFT',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','186',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(148,'274',NULL,NULL,'Purchase Stk Adj.',11,'0','DR','Mahim','DEFAULT','NULL','21',NULL,NULL,'1234567890','NULL',NULL,'27',NULL,NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','154',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(149,'274',NULL,NULL,'Parul Exports',5,'0','DR','GD-6 KARMASTAMBH IND ESTATE LBS ROAD VIKHROLI W','MUMBAI','MUMBAI','21','400083',NULL,'9167424423','NULL',NULL,'27','27AABPT5648J1Z8',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','259',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(150,'274',NULL,NULL,'POPAT RAJA AND SONS',5,'0','DR','GALA NO 5 A DHANRAJ MILL COMPOUND','LOWER PAREL','MUMBAI','21','400013',NULL,'9100000000.0','NULL',NULL,'27','27AECPG4750P1Z7',NULL,'NEFT',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11518004000602',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','185',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(151,'274',NULL,NULL,'PLATINUM ENTERPRISES',5,'0','DR','5th Floor, 502, Chandini CHS Ltd, Garden Avenue RB Mehta Marg, Bank Of Maharashtra','Ghatkopar East, Mumbai','Mumbai Suburban,','21','400077',NULL,'0000000000','NULL',NULL,'27','27ABGFP0479F1Z4',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','225',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:03','2026-08-05 10:18:03'),(152,'274',NULL,NULL,'PHOENIX IMPEX',5,'0','DR','59, JUHU SUPREME SHOPPING CENTRE','GULMOHAR CROSS ROAD NO 9 JVPD','MUMBAI','21','400049',NULL,'9100000000.0','NULL',NULL,'27','27AHKPR6167J1ZN',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','183',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(153,'274',NULL,NULL,'PATEL RETAIL LTD.',5,'0','DR','M - 2,UDYOG BHAVAN NO.-5,','ANAND NAGAR - M.I.D.C. PO.EXP. DATE : 22.10.2021  AMBERNATH ( E )','AMBERNARH','21','421506',NULL,'0251262840','NULL',NULL,'27','27AAECP3782B1ZI',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','203',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(154,'274',NULL,NULL,'PATEL ENTERPRISE Jogeshwari',5,'0','DR','Shop No 20, Perriera Compound, Vaishali Nagar','Jogeshwari East','Mumbai','21','400102',NULL,'0000000000','NULL',NULL,'27','27AAGPP4895E1ZB',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','251',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(155,'274',NULL,NULL,'PANKAJ EXPORTS PRIVATE LIMITED',5,'0','DR','PLOT NO,C-419,MIDC INDUSTRIAL AREA, TURBHE,','INDIRA NAGAR,MAHAPE ROAD,TURBHE,','NAVIMUMBAI,THANE','21','400703',NULL,'9100000000.0','NULL',NULL,'27','27AABCP4533D1ZQ',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10019022009300',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','182',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(156,'274',NULL,NULL,'PANKAJ EXPORTS',5,'0','DR','PLOT NO.C.419,TTC MIDC INDUSTRIAL','AREA.OPP.LUBRIZOL,MAIN GATE NO.3,','NULL','21','400613',NULL,'9100000000.0','NULL',NULL,'27','27AACPN0092R1Z9',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','181',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(157,'274',NULL,NULL,'P.J.EXPORTS',5,'0','DR','PJ HOUSE,SHRI ARIHANT COMPOUND,','RETI BUNDER ROAD,KALHER VILLEGE,','THANE(MAHARASHTRA)','21','421302',NULL,'9100000000.0','NULL',NULL,'27','27AABFP1994K1ZU',NULL,'NEFT',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10016022005068',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','180',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(158,'274',NULL,NULL,'OSWAL TRADING & EXPORTERS',5,'0','DR','7 JB SHAH MARKET .OPP PRABHU HOTEL','NERA MASJID STATION,MASJID BUNDER','MUMBAI','21','400009',NULL,'9100000000.0','NULL',NULL,'27','27FBVPS5188A1ZY',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1151600100042',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','179',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(159,'274',NULL,NULL,'OMKAR LOGISTICS AND EXPORT',5,'0','DR','GALA NO.4,SHED NO.8,ARIHANT COMPOUND,','KOPAR VILLAGE,BHIWANDI,','BHIWANDI','21','421302',NULL,'9969684048','omkarlogisticsandexport@gmail.com',NULL,'27','27CBKPB8612A1Z2',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10019022009239',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','178',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(160,'274',NULL,NULL,'OBSON INTERNATIONAL PVT LTD',5,'0','DR','Decor Shashtri Nagar, Andheri W 400058','A-797, 3 TTC IND. AREA','KOPAR KHAIRNE','21','400705',NULL,'0000000000','NULL',NULL,'27','27AAACO9277C1ZB',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','236',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(161,'274',NULL,NULL,'Novas Impex',5,'0','DR','19, BODKE BUILDING, NS ROAD','NEAR STATION, MULUND, Mumbai City','Mumbai','21','400080',NULL,'0000000000','NULL',NULL,'27','27AADPT8979L1ZM',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','242',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(162,'274',NULL,NULL,'NISHIT COLDRINKS',11,'0','DR','MATUNGA','DEFAULT','NULL','21',NULL,NULL,'9100000000.0','NULL',NULL,'27','27AAHPP6026E1ZR',NULL,'NULL',NULL,NULL,'NULL','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','177',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(163,'274',NULL,NULL,'NISHIT COLD DRINKS',5,'0','DR','346,SADHANA BLDG,TELANG CROSS ROAD,','MATUNGA,MUMBAI-400019','MUMBAI','21','400019',NULL,'9100000000.0','NULL',NULL,'27','27AAHPP6026E1ZR',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','176',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(164,'274',NULL,NULL,'NET BENEFIT TECH PRIVATE LIMITED',5,'0','DR','1308, 13TH FLOOR, HUB TOWN SOLARIS','NEAR FLYOVER BRIDGE, ANDHERI (E),','MUMBAI','21','400019',NULL,'9000000000','support@netbenefitltd.com',NULL,'27','27AAICN0907C1ZT',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','278',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(165,'274',NULL,NULL,'NECENT GLOBAL',5,'0','DR','50, JUHU SUPREME SHOPPING CENTER 2 ND FLOOR,','GULMOHAR CROSS, JVPD SCHEME','MUMBAI','21','400049',NULL,'0000000000','NULL',NULL,'27','27AANFN9264A1Z2',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','227',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(166,'274',NULL,NULL,'NATURES CHOICE FOOD PVT LTD.',5,'0','DR','3rd Floor No. 1 Kishor Kunj, M. G Road,','Ghatkopar West','Mumbai','21','400086',NULL,'8016392399','NULL',NULL,'27','27AAHCN3791K1ZX',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11524998000385',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','272',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(167,'274',NULL,NULL,'NASCENT GLOBAL IMPEX LLP',5,'0','DR','50, Juhu Supreme Shopping Center','2nd Floor Gulmohar Cross Road, Juhu','Mumbai','21','400049',NULL,'0000000000','NULL',NULL,'27','27AANFN9264A1Z2',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','233',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(168,'274',NULL,NULL,'Maverick bakes',5,'0','DR','14/6, Hella compound, Mewla Maharajpur, Faridabad,','NULL','Haryana','Haryana','121003',NULL,'0000000000','NULL',NULL,'0','06BFMPA2042A1ZA',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','265',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(169,'274',NULL,NULL,'Mahalaxmi Enterprise',11,'0','DR','shop no.4, 5 kandivali east','NULL','mumbai','21','400101',NULL,'0000000000','NULL',NULL,'27','27AHQPC9763P1ZC',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','212',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(170,'274',NULL,NULL,'Madhav Exim',5,'0','DR','GROUND FLOOR, PLOT NO 102/1,','ABOVE JK CREDIT CO OPERATIVE SOC LTD','RAJKOT','Gujarat','360003',NULL,'0000000000','NULL',NULL,'0','24ACAFM2933N1Z5',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','270',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(171,'274',NULL,NULL,'MRUNAAL CORPORATION',11,'0','DR','GALA NO.11,ABBASAHEB SHINDE MARG,GROUND FLOOR,','SRA CHS SHASTRI NAGAR,BANDRAEAST,','MUMBAI','21','400051',NULL,'9100000000.0','NULL',NULL,'27','27ABJFM1781G1Z3',NULL,'NULL',NULL,NULL,'NULL','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','175',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:04','2026-08-05 10:18:04'),(172,'274',NULL,NULL,'MARUTI GLOBAL INDIA',5,'0','DR','KHASRA NO 816/534 KHATA NO. 273,','GOVIND PURA, JHALRAPATAN','Jhalawar','Rajasthan','326023',NULL,'0000000000','NULL',NULL,'0','08AFUPY9472P1ZS',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','243',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(173,'274',NULL,NULL,'MAMTA ENTERPRISES',11,'0','CR','GR FLR, SWASTIK CHAMBERS','CST ROAD, CHEMBUR','MUMBAI','21','400071',NULL,'0000000000','NULL',NULL,'27','27AKWPC7619K1ZI',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','274',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(174,'274',NULL,NULL,'MAHAVIR ENTERPRISE',11,'0','DR','IVP LIMITED, SHASHIKANT N REDDY MARG, GHODADEPEO','NULL','MUMBAI','21','400033',NULL,'0000000000','NULL',NULL,'27','27AHCPJ6121G1Z0',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','211',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(175,'274',NULL,NULL,'M/S Fabstor',5,'0','DR','PLOT NO D-10/2, Turbhe MIDC,','WASHI','Thane','21','400701',NULL,'0000000000','NULL',NULL,'27','27ANLPR7084B1ZO',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','279',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(176,'274',NULL,NULL,'Lunia Enterprises',5,'0','DR','Shop No. 1, Angre Niwas, K.A Subramanium Road','Matunga Road','Mumbai','21','400019',NULL,'9321385434','info@lunia.in',NULL,'27','27ADHPJ2266P1Z2',NULL,'NEFT',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','219',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(177,'274',NULL,NULL,'LIBERTY OIL MILLS LTD.',5,'0','DR','2,VILLEGE BAMNE,TAL-SHAHAPUR,','DIST-THANE','NULL','21','',NULL,'9100000000.0','NULL',NULL,'27','27AAACL0888N1Z0',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','174',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(178,'274',NULL,NULL,'KOMAL IMPEX',5,'0','DR','G-7,APMC MARKET,MASALA BAZAR,','VASHI,NAVI MUMBAI','NAVI MUMBAI','21','400703',NULL,'9100000000.0','NULL',NULL,'27','27AACFK0946K1Z8',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10019022008867',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','171',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(179,'274',NULL,NULL,'KOHLICO FOODS AND BEVERAGES PVT LTD',5,'0','DR','C/O, AVINASH TEXTILES PVT. LTD. Plot  No. A-146/9,','MIDC, TTC Industrial Area,  Pawane','Navi Mumbai','21','400705',NULL,'9892262602','NULL',NULL,'27','27AACCK0019J1ZS',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10018022007488',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','173',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(180,'274',NULL,NULL,'KHYATI INTERNATIONAL',5,'0','DR','C-160','TTC MIDC PAWANE VILLAGE','NAVI MUMBAI','21','400705',NULL,'9100000000.0','NULL',NULL,'27','27ACBPR7688E1Z5',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','172',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(181,'274',NULL,NULL,'KHYATI GLOBAL VENTURES LIMITED',5,'0','DR','KHYATI GROUP,C-160,TTC,MIDC,PAWANE VILLAGE,','OPP.SONY BUILDING,','NAVI MUMBAI','21','400705',NULL,'9987400494','NULL',NULL,'27','27AAACK1682P1Z3',NULL,'NEFT',NULL,NULL,'NEFT','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10018022007994',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','170',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(182,'274',NULL,NULL,'KHUSHI ENTERPRISES',11,'0','DR','192-12,GANESH NAGAR,','CHARKOP,KANDIVALI WEST,','MUMBAI','21','400067',NULL,'9100000000.0','NULL',NULL,'27','27EUDPS3641Q1ZV',NULL,'NULL',NULL,NULL,'NULL','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','169',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(183,'274',NULL,NULL,'KAIVAL CORPORATION',5,'0','DR','SOMIAYA CHAMBERS, 2ND FLOOR','NR MALAD SHOPPING CENTRE, MALAD WEST','MUMBAI','21','400064',NULL,'9100000000.0','kaivalcorp@gmail.com',NULL,'27','27AASFK6365Q1Z7',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','168',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(184,'274',NULL,NULL,'Jay Ambe Agencies',5,'0','DR','W-140 Kahirne Midc','Navi-Mumbai','Mumbai','21','400705',NULL,'0000000000','NULL',NULL,'27','27ABHPL9996J1ZP',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','246',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(185,'274',NULL,NULL,'JUSTI HOSPITALITY',5,'0','DR','SHOP NO.HEG201 1/1C,GROUND FLOOR,OPP BMC SCHOOL,','KHERWADI,BANDRA EAST,','MUMBAI','21','400051',NULL,'9100000000.0','NULL',NULL,'27','27AHOPJ9141L2ZQ',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11519005000499',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','167',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(186,'274',NULL,NULL,'JUPITER INTERNATIONAL',5,'0','DR','V 25,APMC 2,VASHI,','NAVI MUMBAI - 400703','NAVI MUMBAI','21','400703',NULL,'9004383941','NULL',NULL,'27','27AAMFJ9610P1ZM',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','166',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(187,'274',NULL,NULL,'JAYANTILAL AND SONS',5,'0','DR','32,NAGDEVI STREET,MUMBAI,','D36/2,TTC MIDC,NEAR ALLANA COLD STORAGE,TURBHE,','NAVI MUMBAI','21','400705',NULL,'9100000000.0','NULL',NULL,'27','27AAAFJ0620M1ZK',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','165',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(188,'274',NULL,NULL,'JAY COMPANY',5,'0','DR','32 NAGDEVI STREET BEHIND MOHD ALI RD.MASJID BANDAR','DEFAULT','MUMBAI','21','400003',NULL,'9820912009','NULL',NULL,'27','27AGVPP3702D1ZA',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11520001000166',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','164',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(189,'274',NULL,NULL,'JASH TRADING',5,'0','DR','402 Sai Astha, Ashok Nagar','Kandivali','Mumbai','21','400101',NULL,'0000000000','NULL',NULL,'27','27AGDPP2173N1Z0',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','240',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(190,'274',NULL,NULL,'JAFERBHOY SALEHBHOY & CO.',5,'0','DR','70,MOHAMMADI MANZIL,MOHAMMAD ALI RD','1ST FLOOR,ROOM NO.6,','NULL','21','',NULL,'9100000000.0','NULL',NULL,'27','27AAAFJ4732E1ZO',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','163',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:05','2026-08-05 10:18:05'),(191,'274',NULL,NULL,'J.R.INTERNATIONAL',5,'0','DR','BELL BUILDING NO.19,','SIR P.M.ROAD,FORT','MUMBAI','21','400001',NULL,'9100000000.0','NULL',NULL,'27','27AACFJ5788Q1ZE',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','162',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(192,'274',NULL,NULL,'J.D.CORPORATION',5,'0','DR','BLDG.21,GALA NO.5TO10,ARIHANT GODOWN COMPLEX,POORNA VILLAGE, BHIWANDI,','NEAR KOPAR BUS STOP,THANE BHIWANDI ROAD,','BHIWANDI','21','421302',NULL,'8097970031.0','NULL',NULL,'27','27AAAFJ0848D1ZP',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10015022004405',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','161',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(193,'274',NULL,NULL,'J. RUTTONSEY TRADING CO.',5,'0','DR','505A NEELKANTH BLDG','98 MARINE DRIVE','MUMBAI','21','400002',NULL,'02222815897/22810388','puja.export@gmail.com',NULL,'27','27AACFJ2797H1Z3',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','160',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(194,'274',NULL,NULL,'J P Corporation',5,'0','DR','A-12/ BHUMINAGAR SOCIETY,','opp Hira bag, Ghatlodia','Ahemdabad','Gujarat','380061',NULL,'0000000000','NULL',NULL,'0','24AARFJ2152P1ZW',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','254',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(195,'274',NULL,NULL,'J K ENTERPRISES',11,'0','CR','Ground Floor Shop No 9 BGTA Godavari','Wadala','Mumbai','21','400001',NULL,'0000000000','NULL',NULL,'27','27AEBPL5614A1Z1',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','253',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(196,'274',NULL,NULL,'Ishita Agency',5,'0','DR','Jai Mangal Oil Complex Plot No 48 & 49','Unit No M23 & M132, Near Green Park Hotel, Sector 19A, Vashi','Navi Mumbai','21','402107',NULL,'8452876777','NULL',NULL,'27','27ARIPD1247K1ZT',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'21521077000769',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','257',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(197,'274',NULL,NULL,'INDIRA SALES AGENCY',5,'0','DR','SHOP NO 1 HUJUMCHAND CHAWL','GTB NAGAR','SION EAST','21','400037',NULL,'9100000000.0','NULL',NULL,'27','27AAAPL4395H1ZK',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','159',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(198,'274',NULL,NULL,'HOAC EXPORTS PRIVATE LIMITED',5,'0','DR','RZ-F-1150 UG01, Rajnagar-Part-2, Palam, Delhi','NULL','New Delhi','Delhi','110077',NULL,'0000000000','NULL',NULL,'0','07AAHCH7038K1Z9',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','263',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(199,'274',NULL,NULL,'HINDUSTAN COCA-COLA BEV.PVT.LTD.',5,'0','DR','WADA PLANT,PLOT NO.284,POST-KUDUS,','TAL.WADA,DIST.PALGHAR','NULL','21','',NULL,'9100000000.0','NULL',NULL,'27','27AAACH3005M1ZR',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','158',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(200,'274',NULL,NULL,'HINAL ENTERPRISES',5,'0','DR','MUMBAI','DEFAULT','MUMBAI','21','400009',NULL,'9100000000.0','NULL',NULL,'27','27AMMPS6027P1Z6',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','157',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(201,'274',NULL,NULL,'Ganesh Impex',5,'0','DR','W-160, TTC, MIDC,','Near : Pawane Kata Pawane Village, Pawane Village,','Navi Mumbai,','21','400705',NULL,'00000000000','NULL',NULL,'27','24AAAFZ4253C2ZH',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','223',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(202,'274',NULL,NULL,'GRANARY WHOLESALE JOGESHWARI',5,'0','DR','Ground Floor, Railside Warehousing Complex, Rail Side Goods','Office,Ram Mandir Road, Goregaon East','Mumbai','21','400063',NULL,'9324410079','NULL',NULL,'27','27AAHCG7552R1ZR',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','205',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(203,'274',NULL,NULL,'GRANARY WHOLESALE Bhiwandi',5,'0','DR','Building 226233 S Y No. 48/01','Indian Corporation, Gundawali','Bhiwandi, Thane','21','421308',NULL,'9324410079','NULL',NULL,'27','27AAHCG7552R1ZR',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','206',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(204,'274',NULL,NULL,'GRANARY WHOLESALE',5,'0','DR','GATE NO 215, SANTOSH WAREHOUSE','Off Mumbra Panvel Road, Near  Toll Plaza','Kiravali Village Dhansar','21','410208',NULL,'9324410079','NULL',NULL,'27','27AAHCG7552R1ZR',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','204',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(205,'274',NULL,NULL,'GEATS FOOD',5,'0','DR','MUMBAI','DEFAULT','NULL','21',NULL,NULL,'9819533778','NULL',NULL,'27','27AADCG5073B1ZW',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','156',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(206,'274',NULL,NULL,'GALAXY INTERNATIONAL',5,'0','DR','OFFICE NO. 516, COMMODITY EXCHANGE BLDG.,','PLOT NO. 2/3/4, SECTOR 19, VASHI','NAVI MUMBAI','21','400705',NULL,'9869164660','NULL',NULL,'27','27AALFG1795R1ZG',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10016022004941',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','213',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(207,'274',NULL,NULL,'Finpro Capital Services',5,'0','DR','Bill To: Malad. Ship To: Ansh Enterprises, Plot No 30/31, TTC Ind Area, Turbhe','Navi Mumbai','Mumbai','21','400705',NULL,'9321860280','ansh.enterprises7546@gmail.com',NULL,'27','27AMRPK6660K1ZC',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','238',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(208,'274',NULL,NULL,'FABSTOR',5,'0','DR','284/2 PAHLA NO 13/1 RAKBA','SAREKHA, GONDIA ROAD','BALAGHAT','Madhya Pradesh','481001',NULL,'7987024898','fabstorexim@gmail.com',NULL,'0','23ANLPR7084B1ZW',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10020026001973',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','267',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(209,'274',NULL,NULL,'ESQUIRE EXPORTERS',5,'0','DR','Kaveri bldg., Ground floor, Narayan Guru Co-op - Society,','Opposite Narayan Guru College, P.L. Lokhande marg, Chembur west ,','Mumbai-','21','400089',NULL,'0000000000','NULL',NULL,'27','27AAAFE0388F1ZN',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','226',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(210,'274',NULL,NULL,'DURGA DISTRIBUTORS',11,'0','DR','Mahada Colony Ghodepdev','NULL','NULL','21','400033',NULL,'0000000000','NULL',NULL,'27','27AHCPJ6122F1ZP',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','208',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:06','2026-08-05 10:18:06'),(211,'274',NULL,NULL,'DHANI ENTERPRISES',5,'0','DR','ROOM NO.7 GR. FLR','MOHANLAL MANSION, MATUNGA','MUMBAI','21','400019',NULL,'9702228888','NULL',NULL,'27','27AARFD6285B1Z7',NULL,'NEFT',NULL,NULL,'ONLINE','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','155',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(212,'274',NULL,NULL,'DHANI ENTERPRISE',11,'0','CR','ROOM NO.7, FLOOR, MOHANLAL MANSION','KING CIRCLE','MUMBAI','21','400019',NULL,'0000000000','NULL',NULL,'27','27DDFPK4866AIZY',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','275',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(213,'274',NULL,NULL,'D & G MASALA KRAFT',5,'0','DR','75, ABDUL REHMAN STREET,  ALAHI BAUG, BLOCK E-1,','DADGAH PREMISES,  GR. FLOOR,','MUMBAI','21','400003',NULL,'0000000000','NULL',NULL,'27','27AAKFD9287C1Z4',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','215',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(214,'274',NULL,NULL,'Chomal Exports',5,'0','DR','SR 692/3/1 BHOSARI ADINATH NGR','NULL','PUNE','21','411039',NULL,'0000000000','NULL',NULL,'27','27AATPC2250M1ZH',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','256',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(215,'274',NULL,NULL,'CHALLAN',11,'0','DR','DEFAULT','NULL','MUMBAI','21','400001',NULL,'9100000000','NULL',NULL,'27',NULL,NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','143',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(216,'274',NULL,NULL,'CASH',5,'0','DR','MUMBAI','DEFAULT','NULL','21',NULL,NULL,'9100000000.0','NULL',NULL,'27',NULL,NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','153',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(217,'274',NULL,NULL,'Beyond India Exports',5,'0','DR','5th Floor, 21, Elephanta Co-op','Pandit Solicitor Road','Malad East','21','400097',NULL,'0000000000','NULL',NULL,'27','27AAXFB7693M1ZA',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','234',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(218,'274',NULL,NULL,'BLG International Hing Pvt. Ltd.',5,'0','DR','A-241 TTC Industrial Area','Thane Belapur Road','Navi Mumbai','21','400710',NULL,'0000000000','NULL',NULL,'27','27AAHCB6944L1Z6',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','241',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(219,'274',NULL,NULL,'BHARAT SALES',11,'0','DR','MAHIM','NULL','MUMBAI','21','400017',NULL,'00000000000','NULL',NULL,'27','27AIFPP7599A1ZW',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','218',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(220,'274',NULL,NULL,'BHARAT SALES',5,'0','DR','E19/5 SHAHUNAGAR','MAHIM','MUMBAI','21','400017',NULL,'8097900893','NULL',NULL,'27','27AIFPP7599A1ZW',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','261',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(221,'274',NULL,NULL,'BHARAT INTERNATIONAL PVT LTD',5,'0','DR','KH NO 33/9 & 33/12, MAIN BAWANA ROAD','SAMAIPUR(Opp. Rohini','DELHI','Delhi','110042',NULL,'7428180383','NULL',NULL,'0','07AAACB8002G2Z4',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','276',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(222,'274',NULL,NULL,'BENSUNG',5,'0','DR','Ground Floor, 01, KANTA KUNJ, TELLI GALLI','ANDHERI','MUMBAI','21','400069',NULL,'0000000000','NULL',NULL,'27','27BUYPR8797Q1ZN',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','280',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(223,'274',NULL,NULL,'BALAJI ENTERPRISES',11,'0','CR','GALA NO.6,SOLITERS COLONY,MALWANI,','MALAD WEST','MUMBAI','21','400053',NULL,'9100000000','NULL',NULL,'27','27LVNPS1597M1Z9',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','151',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(224,'274',NULL,NULL,'Angad Exports',5,'0','DR','303, Riddhi Siddhi Towers, Tilak Nagar','Opp Sahakar Cinemas Chembur, Mumbai City','Mumbai','21','400089',NULL,'0000000000','',NULL,'27','27ANLPR0499J1ZA',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','258',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(225,'274',NULL,NULL,'Agencies',5,'0','DR','W-140 Kahirne Midc','Navi-Mumbai','NULL','21',NULL,NULL,'0000000000','NULL',NULL,'27','27ABHPL9996J1ZP',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','245',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(226,'274',NULL,NULL,'AVAAP GLOBAL TRADE PRIVATE LIMITED',5,'0','DR','B/603,CRYSTAL PLAZA,OPP CITY MALL,','ANDHERI LINK ROAD,ANDHERI WEST','MUMBAI','21','400058',NULL,'9100000000.0','NULL',NULL,'27','27AATCA0834C1ZT',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','149',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(227,'274',NULL,NULL,'ATIYAH ENTERPRISES',11,'0','CR','B/208 WHITE HOUSE CHS','MIRA BHAYANDAR','THANE','21','401101',NULL,'0000000000','NULL',NULL,'27','27BTWPP2841L1ZU',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','252',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(228,'274',NULL,NULL,'ASTAVINAYAK',11,'0','CR','8,MMRDA, ANTOP HILL','NULL','MUMBAI','21','400037',NULL,'0000000000','NULL',NULL,'27','27ABTFA0874C1ZD',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','268',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(229,'274',NULL,NULL,'ARJUN WATER SUPPLIERS',5,'0','DR','MUMBAI','DEFAULT','NULL','21','',NULL,'9100000000.0','NULL',NULL,'27','27CFYPS9964J1ZZ',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'21518001000126',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','148',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(230,'274',NULL,NULL,'ANIL & COMPANY',5,'0','DR','D.199,TTC INDUSTRIAL AREA,MIDC','TURBHE,PIPELINE ROAD,TURBHE,','Navi Mumbai','21','400710',NULL,'9100000000','NULL',NULL,'27','27AAEFA6583G1ZC',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11516016000016',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','147',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:07','2026-08-05 10:18:07'),(231,'274',NULL,NULL,'ANIKA TRADEXIM PRIVATE LIMITED',5,'0','DR','F-610A, Khajuri Khas,','NULL','NEW DELHI','Delhi','110094',NULL,'0000000000','NULL',NULL,'0','07ABDCA1275C1Z4',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','277',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:08','2026-08-05 10:18:08'),(232,'274',NULL,NULL,'AGRAWAL IMPEX',5,'0','DR','16/PAUSHE SADAN, SHASTRI NAGAR','KOPAR RD, DOMBIVLI WEST','Mumbai','21','421202',NULL,'9100000000','NULL',NULL,'27','27ARPPB5951P1Z3',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','150',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:08','2026-08-05 10:18:08'),(233,'274',NULL,NULL,'ACE EXPORTS',5,'0','DR','GROUND AND 1ST FLOOR,PLOT NO D-123,','TTC ,MIDC.NODE NERUL,','NAVI MUMBAI','21','400706',NULL,'9619198998','NULL',NULL,'27','27ABVFA9948B1ZW',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11521998000838',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','214',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:08','2026-08-05 10:18:08'),(234,'274',NULL,NULL,'ABHAYA EXPORTS PVT. LTD',5,'0','DR','Survey No. 30A, Plot No 1 To 4, Village Paud, Taluka Khalapur','Dist Raigad, Maharashtra','RAIGAD','21','410202',NULL,'9191919191','NULL',NULL,'27','27AACCA5401A1ZH',NULL,'NEFT',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','146',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:08','2026-08-05 10:18:08'),(235,'274',NULL,NULL,'AAYU IMPEX',5,'0','DR','Shop No. 1, Pavapuri Apts., 9th Khetwadi Lane','Delivery: MIDC,TTC IND. Area,KHAIRANE','NAVI MUMBAI','21','400705',NULL,'9820281445','aayuimpex@gmail.com',NULL,'27','27AAEFA7914M1Z6',NULL,'NEFT',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'10017022006693',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','145',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:08','2026-08-05 10:18:08'),(236,'274',NULL,NULL,'AADVIK CORPORATION',5,'0','DR','ROOM NO 219 PLOT NO A 257 SHIV SHANKAR CO OP SOC','GHANSOLI','THANE','21','400701',NULL,'0000000000','NULL',NULL,'27','27AQHPN1683P1Z4',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NULL',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','271',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:08','2026-08-05 10:18:08'),(237,'274',NULL,NULL,'A B ENTERPRISES',5,'0','DR','7/51, MOTILAL NAGAR NO. 3','SANKALP SIDDHI CHSL, OFF M.G. ROAD, BEHIND MANTHAN HOTEL, GOREGAON (WEST)','MUMBAI','21','400104',NULL,'9821534190','1partnerabe@gmail.com',NULL,'27','27ABIFA9810F1ZG',NULL,'NULL',NULL,NULL,'NULL','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'11519009000310',NULL,'0','0',NULL,'NULL','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','144',NULL,'0','0',NULL,450,0,'2026-08-05 10:18:08','2026-08-05 10:18:08');
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int NOT NULL DEFAULT '0',
  `ADDRESS1` text,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
INSERT INTO `SAC_IMPORT` VALUES (1,'274','A B ENTERPRISES','5','DR','0','27ABIFA9810F1ZG',NULL,NULL,'1','4',0,'7/51, MOTILAL NAGAR NO. 3','SANKALP SIDDHI CHSL, OFF M.G. ROAD, BEHIND MANTHAN HOTEL, GOREGAON (WEST)','MUMBAI','Maharashtra','27','400104','1partnerabe@gmail.com','9821534190','NULL','NULL','0','0','0','NULL','11519009000310',NULL,450,'144'),(2,'274','AADVIK CORPORATION','5','DR','0','27AQHPN1683P1Z4',NULL,NULL,'1','4',0,'ROOM NO 219 PLOT NO A 257 SHIV SHANKAR CO OP SOC','GHANSOLI','THANE','Maharashtra','27','400701','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'271'),(3,'274','AAYU IMPEX','5','DR','0','27AAEFA7914M1Z6',NULL,NULL,'1','4',0,'Shop No. 1, Pavapuri Apts., 9th Khetwadi Lane','Delivery: MIDC,TTC IND. Area,KHAIRANE','NAVI MUMBAI','Maharashtra','27','400705','aayuimpex@gmail.com','9820281445','NEFT','NULL','0','0','0','NULL','10017022006693',NULL,450,'145'),(4,'274','ABHAYA EXPORTS PVT. LTD','5','DR','0','27AACCA5401A1ZH',NULL,NULL,'1','4',0,'Survey No. 30A, Plot No 1 To 4, Village Paud, Taluka Khalapur','Dist Raigad, Maharashtra','RAIGAD','Maharashtra','27','410202','NULL','9191919191','NEFT','NULL','0','0','0','NULL','',NULL,450,'146'),(5,'274','ACE EXPORTS','5','DR','0','27ABVFA9948B1ZW',NULL,NULL,'1','4',0,'GROUND AND 1ST FLOOR,PLOT NO D-123,','TTC ,MIDC.NODE NERUL,','NAVI MUMBAI','Maharashtra','27','400706','NULL','9619198998','NULL','NULL','0','0','0','NULL','11521998000838',NULL,450,'214'),(6,'274','AGRAWAL IMPEX','5','DR','0','27ARPPB5951P1Z3',NULL,NULL,'1','4',0,'16/PAUSHE SADAN, SHASTRI NAGAR','KOPAR RD, DOMBIVLI WEST','Mumbai','Maharashtra','27','421202','NULL','9100000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'150'),(7,'274','ANIKA TRADEXIM PRIVATE LIMITED','5','DR','0','07ABDCA1275C1Z4',NULL,NULL,'1','4',0,'F-610A, Khajuri Khas,','NULL','NEW DELHI','Delhi','0','110094','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'277'),(8,'274','ANIL & COMPANY','5','DR','0','27AAEFA6583G1ZC',NULL,NULL,'1','4',0,'D.199,TTC INDUSTRIAL AREA,MIDC','TURBHE,PIPELINE ROAD,TURBHE,','Navi Mumbai','Maharashtra','27','400710','NULL','9100000000','NULL','NULL','0','0','0','NULL','11516016000016',NULL,450,'147'),(9,'274','ARJUN WATER SUPPLIERS','5','DR','0','27CFYPS9964J1ZZ',NULL,NULL,'1','4',0,'MUMBAI','DEFAULT','NULL','Maharashtra','27','','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','21518001000126',NULL,450,'148'),(10,'274','ASTAVINAYAK','11','CR','0','27ABTFA0874C1ZD',NULL,NULL,'1','4',0,'8,MMRDA, ANTOP HILL','NULL','MUMBAI','Maharashtra','27','400037','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'268'),(11,'274','ATIYAH ENTERPRISES','11','CR','0','27BTWPP2841L1ZU',NULL,NULL,'1','4',0,'B/208 WHITE HOUSE CHS','MIRA BHAYANDAR','THANE','Maharashtra','27','401101','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'252'),(12,'274','AVAAP GLOBAL TRADE PRIVATE LIMITED','5','DR','0','27AATCA0834C1ZT',NULL,NULL,'1','4',0,'B/603,CRYSTAL PLAZA,OPP CITY MALL,','ANDHERI LINK ROAD,ANDHERI WEST','MUMBAI','Maharashtra','27','400058','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'149'),(13,'274','Agencies','5','DR','0','27ABHPL9996J1ZP',NULL,NULL,'1','4',0,'W-140 Kahirne Midc','Navi-Mumbai','NULL','Maharashtra','27',NULL,'NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'245'),(14,'274','Angad Exports','5','DR','0','27ANLPR0499J1ZA',NULL,NULL,'1','4',0,'303, Riddhi Siddhi Towers, Tilak Nagar','Opp Sahakar Cinemas Chembur, Mumbai City','Mumbai','Maharashtra','27','400089','','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'258'),(15,'274','BALAJI ENTERPRISES','11','CR','0','27LVNPS1597M1Z9',NULL,NULL,'1','4',0,'GALA NO.6,SOLITERS COLONY,MALWANI,','MALAD WEST','MUMBAI','Maharashtra','27','400053','NULL','9100000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'151'),(16,'274','BENSUNG','5','DR','0','27BUYPR8797Q1ZN',NULL,NULL,'1','4',0,'Ground Floor, 01, KANTA KUNJ, TELLI GALLI','ANDHERI','MUMBAI','Maharashtra','27','400069','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'280'),(17,'274','BHARAT INTERNATIONAL PVT LTD','5','DR','0','07AAACB8002G2Z4',NULL,NULL,'1','4',0,'KH NO 33/9 & 33/12, MAIN BAWANA ROAD','SAMAIPUR(Opp. Rohini','DELHI','Delhi','0','110042','NULL','7428180383','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'276'),(18,'274','BHARAT SALES','5','DR','0','27AIFPP7599A1ZW',NULL,NULL,'1','4',0,'E19/5 SHAHUNAGAR','MAHIM','MUMBAI','Maharashtra','27','400017','NULL','8097900893','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'261'),(19,'274','BHARAT SALES','11','DR','0','27AIFPP7599A1ZW',NULL,NULL,'1','4',0,'MAHIM','NULL','MUMBAI','Maharashtra','27','400017','NULL','00000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'218'),(20,'274','BLG International Hing Pvt. Ltd.','5','DR','0','27AAHCB6944L1Z6',NULL,NULL,'1','4',0,'A-241 TTC Industrial Area','Thane Belapur Road','Navi Mumbai','Maharashtra','27','400710','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'241'),(21,'274','Beyond India Exports','5','DR','0','27AAXFB7693M1ZA',NULL,NULL,'1','4',0,'5th Floor, 21, Elephanta Co-op','Pandit Solicitor Road','Malad East','Maharashtra','27','400097','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'234'),(22,'274','CASH','5','DR','0',NULL,NULL,NULL,'1','4',0,'MUMBAI','DEFAULT','NULL','Maharashtra','27',NULL,'NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'153'),(23,'274','CHALLAN','11','DR','0',NULL,NULL,NULL,'1','4',0,'DEFAULT','NULL','MUMBAI','Maharashtra','27','400001','NULL','9100000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'143'),(24,'274','Chomal Exports','5','DR','0','27AATPC2250M1ZH',NULL,NULL,'1','4',0,'SR 692/3/1 BHOSARI ADINATH NGR','NULL','PUNE','Maharashtra','27','411039','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'256'),(25,'274','D & G MASALA KRAFT','5','DR','0','27AAKFD9287C1Z4',NULL,NULL,'1','4',0,'75, ABDUL REHMAN STREET,  ALAHI BAUG, BLOCK E-1,','DADGAH PREMISES,  GR. FLOOR,','MUMBAI','Maharashtra','27','400003','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'215'),(26,'274','DHANI ENTERPRISE','11','CR','0','27DDFPK4866AIZY',NULL,NULL,'1','4',0,'ROOM NO.7, FLOOR, MOHANLAL MANSION','KING CIRCLE','MUMBAI','Maharashtra','27','400019','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'275'),(27,'274','DHANI ENTERPRISES','5','DR','0','27AARFD6285B1Z7',NULL,NULL,'1','4',0,'ROOM NO.7 GR. FLR','MOHANLAL MANSION, MATUNGA','MUMBAI','Maharashtra','27','400019','NULL','9702228888','NEFT','ONLINE','0','0','0','NULL','NULL',NULL,450,'155'),(28,'274','DURGA DISTRIBUTORS','11','DR','0','27AHCPJ6122F1ZP',NULL,NULL,'1','4',0,'Mahada Colony Ghodepdev','NULL','NULL','Maharashtra','27','400033','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'208'),(29,'274','ESQUIRE EXPORTERS','5','DR','0','27AAAFE0388F1ZN',NULL,NULL,'1','4',0,'Kaveri bldg., Ground floor, Narayan Guru Co-op - Society,','Opposite Narayan Guru College, P.L. Lokhande marg, Chembur west ,','Mumbai-','Maharashtra','27','400089','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'226'),(30,'274','FABSTOR','5','DR','0','23ANLPR7084B1ZW',NULL,NULL,'1','4',0,'284/2 PAHLA NO 13/1 RAKBA','SAREKHA, GONDIA ROAD','BALAGHAT','Madhya Pradesh','0','481001','fabstorexim@gmail.com','7987024898','NULL','NULL','0','0','0','NULL','10020026001973',NULL,450,'267'),(31,'274','Finpro Capital Services','5','DR','0','27AMRPK6660K1ZC',NULL,NULL,'1','4',0,'Bill To: Malad. Ship To: Ansh Enterprises, Plot No 30/31, TTC Ind Area, Turbhe','Navi Mumbai','Mumbai','Maharashtra','27','400705','ansh.enterprises7546@gmail.com','9321860280','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'238'),(32,'274','GALAXY INTERNATIONAL','5','DR','0','27AALFG1795R1ZG',NULL,NULL,'1','4',0,'OFFICE NO. 516, COMMODITY EXCHANGE BLDG.,','PLOT NO. 2/3/4, SECTOR 19, VASHI','NAVI MUMBAI','Maharashtra','27','400705','NULL','9869164660','NULL','NULL','0','0','0','NULL','10016022004941',NULL,450,'213'),(33,'274','GEATS FOOD','5','DR','0','27AADCG5073B1ZW',NULL,NULL,'1','4',0,'MUMBAI','DEFAULT','NULL','Maharashtra','27',NULL,'NULL','9819533778','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'156'),(34,'274','GRANARY WHOLESALE','5','DR','0','27AAHCG7552R1ZR',NULL,NULL,'1','4',0,'GATE NO 215, SANTOSH WAREHOUSE','Off Mumbra Panvel Road, Near  Toll Plaza','Kiravali Village Dhansar','Maharashtra','27','410208','NULL','9324410079','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'204'),(35,'274','GRANARY WHOLESALE Bhiwandi','5','DR','0','27AAHCG7552R1ZR',NULL,NULL,'1','4',0,'Building 226233 S Y No. 48/01','Indian Corporation, Gundawali','Bhiwandi, Thane','Maharashtra','27','421308','NULL','9324410079','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'206'),(36,'274','GRANARY WHOLESALE JOGESHWARI','5','DR','0','27AAHCG7552R1ZR',NULL,NULL,'1','4',0,'Ground Floor, Railside Warehousing Complex, Rail Side Goods','Office,Ram Mandir Road, Goregaon East','Mumbai','Maharashtra','27','400063','NULL','9324410079','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'205'),(37,'274','Ganesh Impex','5','DR','0','24AAAFZ4253C2ZH',NULL,NULL,'1','4',0,'W-160, TTC, MIDC,','Near : Pawane Kata Pawane Village, Pawane Village,','Navi Mumbai,','Maharashtra','27','400705','NULL','00000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'223'),(38,'274','HINAL ENTERPRISES','5','DR','0','27AMMPS6027P1Z6',NULL,NULL,'1','4',0,'MUMBAI','DEFAULT','MUMBAI','Maharashtra','27','400009','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'157'),(39,'274','HINDUSTAN COCA-COLA BEV.PVT.LTD.','5','DR','0','27AAACH3005M1ZR',NULL,NULL,'1','4',0,'WADA PLANT,PLOT NO.284,POST-KUDUS,','TAL.WADA,DIST.PALGHAR','NULL','Maharashtra','27','','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','',NULL,450,'158'),(40,'274','HOAC EXPORTS PRIVATE LIMITED','5','DR','0','07AAHCH7038K1Z9',NULL,NULL,'1','4',0,'RZ-F-1150 UG01, Rajnagar-Part-2, Palam, Delhi','NULL','New Delhi','Delhi','0','110077','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'263'),(41,'274','INDIRA SALES AGENCY','5','DR','0','27AAAPL4395H1ZK',NULL,NULL,'1','4',0,'SHOP NO 1 HUJUMCHAND CHAWL','GTB NAGAR','SION EAST','Maharashtra','27','400037','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'159'),(42,'274','Ishita Agency','5','DR','0','27ARIPD1247K1ZT',NULL,NULL,'1','4',0,'Jai Mangal Oil Complex Plot No 48 & 49','Unit No M23 & M132, Near Green Park Hotel, Sector 19A, Vashi','Navi Mumbai','Maharashtra','27','402107','NULL','8452876777','NULL','NULL','0','0','0','NULL','21521077000769',NULL,450,'257'),(43,'274','J K ENTERPRISES','11','CR','0','27AEBPL5614A1Z1',NULL,NULL,'1','4',0,'Ground Floor Shop No 9 BGTA Godavari','Wadala','Mumbai','Maharashtra','27','400001','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'253'),(44,'274','J P Corporation','5','DR','0','24AARFJ2152P1ZW',NULL,NULL,'1','4',0,'A-12/ BHUMINAGAR SOCIETY,','opp Hira bag, Ghatlodia','Ahemdabad','Gujarat','0','380061','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'254'),(45,'274','J. RUTTONSEY TRADING CO.','5','DR','0','27AACFJ2797H1Z3',NULL,NULL,'1','4',0,'505A NEELKANTH BLDG','98 MARINE DRIVE','MUMBAI','Maharashtra','27','400002','puja.export@gmail.com','02222815897/22810388','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'160'),(46,'274','J.D.CORPORATION','5','DR','0','27AAAFJ0848D1ZP',NULL,NULL,'1','4',0,'BLDG.21,GALA NO.5TO10,ARIHANT GODOWN COMPLEX,POORNA VILLAGE, BHIWANDI,','NEAR KOPAR BUS STOP,THANE BHIWANDI ROAD,','BHIWANDI','Maharashtra','27','421302','NULL','8097970031.0','NULL','NULL','0','0','0','NULL','10015022004405',NULL,450,'161'),(47,'274','J.R.INTERNATIONAL','5','DR','0','27AACFJ5788Q1ZE',NULL,NULL,'1','4',0,'BELL BUILDING NO.19,','SIR P.M.ROAD,FORT','MUMBAI','Maharashtra','27','400001','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'162'),(48,'274','JAFERBHOY SALEHBHOY & CO.','5','DR','0','27AAAFJ4732E1ZO',NULL,NULL,'1','4',0,'70,MOHAMMADI MANZIL,MOHAMMAD ALI RD','1ST FLOOR,ROOM NO.6,','NULL','Maharashtra','27','','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','',NULL,450,'163'),(49,'274','JASH TRADING','5','DR','0','27AGDPP2173N1Z0',NULL,NULL,'1','4',0,'402 Sai Astha, Ashok Nagar','Kandivali','Mumbai','Maharashtra','27','400101','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'240'),(50,'274','JAY COMPANY','5','DR','0','27AGVPP3702D1ZA',NULL,NULL,'1','4',0,'32 NAGDEVI STREET BEHIND MOHD ALI RD.MASJID BANDAR','DEFAULT','MUMBAI','Maharashtra','27','400003','NULL','9820912009','NULL','NULL','0','0','0','NULL','11520001000166',NULL,450,'164'),(51,'274','JAYANTILAL AND SONS','5','DR','0','27AAAFJ0620M1ZK',NULL,NULL,'1','4',0,'32,NAGDEVI STREET,MUMBAI,','D36/2,TTC MIDC,NEAR ALLANA COLD STORAGE,TURBHE,','NAVI MUMBAI','Maharashtra','27','400705','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'165'),(52,'274','JUPITER INTERNATIONAL','5','DR','0','27AAMFJ9610P1ZM',NULL,NULL,'1','4',0,'V 25,APMC 2,VASHI,','NAVI MUMBAI - 400703','NAVI MUMBAI','Maharashtra','27','400703','NULL','9004383941','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'166'),(53,'274','JUSTI HOSPITALITY','5','DR','0','27AHOPJ9141L2ZQ',NULL,NULL,'1','4',0,'SHOP NO.HEG201 1/1C,GROUND FLOOR,OPP BMC SCHOOL,','KHERWADI,BANDRA EAST,','MUMBAI','Maharashtra','27','400051','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','11519005000499',NULL,450,'167'),(54,'274','Jay Ambe Agencies','5','DR','0','27ABHPL9996J1ZP',NULL,NULL,'1','4',0,'W-140 Kahirne Midc','Navi-Mumbai','Mumbai','Maharashtra','27','400705','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'246'),(55,'274','KAIVAL CORPORATION','5','DR','0','27AASFK6365Q1Z7',NULL,NULL,'1','4',0,'SOMIAYA CHAMBERS, 2ND FLOOR','NR MALAD SHOPPING CENTRE, MALAD WEST','MUMBAI','Maharashtra','27','400064','kaivalcorp@gmail.com','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'168'),(56,'274','KHUSHI ENTERPRISES','11','DR','0','27EUDPS3641Q1ZV',NULL,NULL,'2','1',0,'192-12,GANESH NAGAR,','CHARKOP,KANDIVALI WEST,','MUMBAI','Maharashtra','27','400067','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'169'),(57,'274','KHYATI GLOBAL VENTURES LIMITED','5','DR','0','27AAACK1682P1Z3',NULL,NULL,'1','4',0,'KHYATI GROUP,C-160,TTC,MIDC,PAWANE VILLAGE,','OPP.SONY BUILDING,','NAVI MUMBAI','Maharashtra','27','400705','NULL','9987400494','NEFT','NEFT','0','0','0','NULL','10018022007994',NULL,450,'170'),(58,'274','KHYATI INTERNATIONAL','5','DR','0','27ACBPR7688E1Z5',NULL,NULL,'1','4',0,'C-160','TTC MIDC PAWANE VILLAGE','NAVI MUMBAI','Maharashtra','27','400705','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'172'),(59,'274','KOHLICO FOODS AND BEVERAGES PVT LTD','5','DR','0','27AACCK0019J1ZS',NULL,NULL,'1','4',0,'C/O, AVINASH TEXTILES PVT. LTD. Plot  No. A-146/9,','MIDC, TTC Industrial Area,  Pawane','Navi Mumbai','Maharashtra','27','400705','NULL','9892262602','NULL','NULL','0','0','0','NULL','10018022007488',NULL,450,'173'),(60,'274','KOMAL IMPEX','5','DR','0','27AACFK0946K1Z8',NULL,NULL,'1','4',0,'G-7,APMC MARKET,MASALA BAZAR,','VASHI,NAVI MUMBAI','NAVI MUMBAI','Maharashtra','27','400703','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','10019022008867',NULL,450,'171'),(61,'274','LIBERTY OIL MILLS LTD.','5','DR','0','27AAACL0888N1Z0',NULL,NULL,'1','4',0,'2,VILLEGE BAMNE,TAL-SHAHAPUR,','DIST-THANE','NULL','Maharashtra','27','','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','',NULL,450,'174'),(62,'274','Lunia Enterprises','5','DR','0','27ADHPJ2266P1Z2',NULL,NULL,'1','4',0,'Shop No. 1, Angre Niwas, K.A Subramanium Road','Matunga Road','Mumbai','Maharashtra','27','400019','info@lunia.in','9321385434','NEFT','NULL','0','0','0','NULL','NULL',NULL,450,'219'),(63,'274','M/S Fabstor','5','DR','0','27ANLPR7084B1ZO',NULL,NULL,'1','4',0,'PLOT NO D-10/2, Turbhe MIDC,','WASHI','Thane','Maharashtra','27','400701','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'279'),(64,'274','MAHAVIR ENTERPRISE','11','DR','0','27AHCPJ6121G1Z0',NULL,NULL,'1','4',0,'IVP LIMITED, SHASHIKANT N REDDY MARG, GHODADEPEO','NULL','MUMBAI','Maharashtra','27','400033','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'211'),(65,'274','MAMTA ENTERPRISES','11','CR','0','27AKWPC7619K1ZI',NULL,NULL,'1','4',0,'GR FLR, SWASTIK CHAMBERS','CST ROAD, CHEMBUR','MUMBAI','Maharashtra','27','400071','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'274'),(66,'274','MARUTI GLOBAL INDIA','5','DR','0','08AFUPY9472P1ZS',NULL,NULL,'1','4',0,'KHASRA NO 816/534 KHATA NO. 273,','GOVIND PURA, JHALRAPATAN','Jhalawar','Rajasthan','0','326023','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'243'),(67,'274','MRUNAAL CORPORATION','11','DR','0','27ABJFM1781G1Z3',NULL,NULL,'2','1',0,'GALA NO.11,ABBASAHEB SHINDE MARG,GROUND FLOOR,','SRA CHS SHASTRI NAGAR,BANDRAEAST,','MUMBAI','Maharashtra','27','400051','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'175'),(68,'274','Madhav Exim','5','DR','0','24ACAFM2933N1Z5',NULL,NULL,'1','4',0,'GROUND FLOOR, PLOT NO 102/1,','ABOVE JK CREDIT CO OPERATIVE SOC LTD','RAJKOT','Gujarat','0','360003','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'270'),(69,'274','Mahalaxmi Enterprise','11','DR','0','27AHQPC9763P1ZC',NULL,NULL,'1','4',0,'shop no.4, 5 kandivali east','NULL','mumbai','Maharashtra','27','400101','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'212'),(70,'274','Maverick bakes','5','DR','0','06BFMPA2042A1ZA',NULL,NULL,'1','4',0,'14/6, Hella compound, Mewla Maharajpur, Faridabad,','NULL','Haryana','Haryana','0','121003','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'265'),(71,'274','NASCENT GLOBAL IMPEX LLP','5','DR','0','27AANFN9264A1Z2',NULL,NULL,'1','4',0,'50, Juhu Supreme Shopping Center','2nd Floor Gulmohar Cross Road, Juhu','Mumbai','Maharashtra','27','400049','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'233'),(72,'274','NATURES CHOICE FOOD PVT LTD.','5','DR','0','27AAHCN3791K1ZX',NULL,NULL,'1','4',0,'3rd Floor No. 1 Kishor Kunj, M. G Road,','Ghatkopar West','Mumbai','Maharashtra','27','400086','NULL','8016392399','NULL','NULL','0','0','0','NULL','11524998000385',NULL,450,'272'),(73,'274','NECENT GLOBAL','5','DR','0','27AANFN9264A1Z2',NULL,NULL,'1','4',0,'50, JUHU SUPREME SHOPPING CENTER 2 ND FLOOR,','GULMOHAR CROSS, JVPD SCHEME','MUMBAI','Maharashtra','27','400049','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'227'),(74,'274','NET BENEFIT TECH PRIVATE LIMITED','5','DR','0','27AAICN0907C1ZT',NULL,NULL,'1','4',0,'1308, 13TH FLOOR, HUB TOWN SOLARIS','NEAR FLYOVER BRIDGE, ANDHERI (E),','MUMBAI','Maharashtra','27','400019','support@netbenefitltd.com','9000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'278'),(75,'274','NISHIT COLD DRINKS','5','DR','0','27AAHPP6026E1ZR',NULL,NULL,'1','4',0,'346,SADHANA BLDG,TELANG CROSS ROAD,','MATUNGA,MUMBAI-400019','MUMBAI','Maharashtra','27','400019','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','',NULL,450,'176'),(76,'274','NISHIT COLDRINKS','11','DR','0','27AAHPP6026E1ZR',NULL,NULL,'2','1',0,'MATUNGA','DEFAULT','NULL','Maharashtra','27',NULL,'NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'177'),(77,'274','Novas Impex','5','DR','0','27AADPT8979L1ZM',NULL,NULL,'1','4',0,'19, BODKE BUILDING, NS ROAD','NEAR STATION, MULUND, Mumbai City','Mumbai','Maharashtra','27','400080','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'242'),(78,'274','OBSON INTERNATIONAL PVT LTD','5','DR','0','27AAACO9277C1ZB',NULL,NULL,'1','4',0,'Decor Shashtri Nagar, Andheri W 400058','A-797, 3 TTC IND. AREA','KOPAR KHAIRNE','Maharashtra','27','400705','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'236'),(79,'274','OMKAR LOGISTICS AND EXPORT','5','DR','0','27CBKPB8612A1Z2',NULL,NULL,'1','4',0,'GALA NO.4,SHED NO.8,ARIHANT COMPOUND,','KOPAR VILLAGE,BHIWANDI,','BHIWANDI','Maharashtra','27','421302','omkarlogisticsandexport@gmail.com','9969684048','NULL','NULL','0','0','0','NULL','10019022009239',NULL,450,'178'),(80,'274','OSWAL TRADING & EXPORTERS','5','DR','0','27FBVPS5188A1ZY',NULL,NULL,'1','4',0,'7 JB SHAH MARKET .OPP PRABHU HOTEL','NERA MASJID STATION,MASJID BUNDER','MUMBAI','Maharashtra','27','400009','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','1151600100042',NULL,450,'179'),(81,'274','P.J.EXPORTS','5','DR','0','27AABFP1994K1ZU',NULL,NULL,'1','4',0,'PJ HOUSE,SHRI ARIHANT COMPOUND,','RETI BUNDER ROAD,KALHER VILLEGE,','THANE(MAHARASHTRA)','Maharashtra','27','421302','NULL','9100000000.0','NEFT','NULL','0','0','0','NULL','10016022005068',NULL,450,'180'),(82,'274','PANKAJ EXPORTS','5','DR','0','27AACPN0092R1Z9',NULL,NULL,'1','4',0,'PLOT NO.C.419,TTC MIDC INDUSTRIAL','AREA.OPP.LUBRIZOL,MAIN GATE NO.3,','NULL','Maharashtra','27','400613','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','',NULL,450,'181'),(83,'274','PANKAJ EXPORTS PRIVATE LIMITED','5','DR','0','27AABCP4533D1ZQ',NULL,NULL,'1','4',0,'PLOT NO,C-419,MIDC INDUSTRIAL AREA, TURBHE,','INDIRA NAGAR,MAHAPE ROAD,TURBHE,','NAVIMUMBAI,THANE','Maharashtra','27','400703','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','10019022009300',NULL,450,'182'),(84,'274','PATEL ENTERPRISE Jogeshwari','5','DR','0','27AAGPP4895E1ZB',NULL,NULL,'1','4',0,'Shop No 20, Perriera Compound, Vaishali Nagar','Jogeshwari East','Mumbai','Maharashtra','27','400102','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'251'),(85,'274','PATEL RETAIL LTD.','5','DR','0','27AAECP3782B1ZI',NULL,NULL,'1','4',0,'M - 2,UDYOG BHAVAN NO.-5,','ANAND NAGAR - M.I.D.C. PO.EXP. DATE : 22.10.2021  AMBERNATH ( E )','AMBERNARH','Maharashtra','27','421506','NULL','0251262840','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'203'),(86,'274','PHOENIX IMPEX','5','DR','0','27AHKPR6167J1ZN',NULL,NULL,'1','4',0,'59, JUHU SUPREME SHOPPING CENTRE','GULMOHAR CROSS ROAD NO 9 JVPD','MUMBAI','Maharashtra','27','400049','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'183'),(87,'274','PLATINUM ENTERPRISES','5','DR','0','27ABGFP0479F1Z4',NULL,NULL,'1','4',0,'5th Floor, 502, Chandini CHS Ltd, Garden Avenue RB Mehta Marg, Bank Of Maharashtra','Ghatkopar East, Mumbai','Mumbai Suburban,','Maharashtra','27','400077','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'225'),(88,'274','POPAT RAJA AND SONS','5','DR','0','27AECPG4750P1Z7',NULL,NULL,'1','4',0,'GALA NO 5 A DHANRAJ MILL COMPOUND','LOWER PAREL','MUMBAI','Maharashtra','27','400013','NULL','9100000000.0','NEFT','NULL','0','0','0','NULL','11518004000602',NULL,450,'185'),(89,'274','Parul Exports','5','DR','0','27AABPT5648J1Z8',NULL,NULL,'1','4',0,'GD-6 KARMASTAMBH IND ESTATE LBS ROAD VIKHROLI W','MUMBAI','MUMBAI','Maharashtra','27','400083','NULL','9167424423','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'259'),(90,'274','Purchase Stk Adj.','11','DR','0',NULL,NULL,NULL,'1','4',0,'Mahim','DEFAULT','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'154'),(91,'274','QUALITY SPICES & FOODS EXPORTS PVT LTD.','5','DR','0','27AAACQ1796J1Z2',NULL,NULL,'1','4',0,'M-1, ADDITIONAL AMBERNATH MIDC','AMBERNATH EAST','THANE','Maharashtra','27','421506','NULL','9100000000.0','NEFT','NULL','0','0','0','NULL','NULL',NULL,450,'186'),(92,'274','Quality Spices & Food Exports Pvt Ltd.','11','DR','0','27AAACQ1796J1Z2',NULL,NULL,'1','4',0,'Plot No. M-1, Ambernath MIDC','NULL','Thane','Maharashtra','27','421506','NULL','9126207000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'220'),(93,'274','R.P.AGENCIES','5','DR','0','27ACVPP1545J1Z0',NULL,NULL,'1','4',0,'REY ROAD','DEFAULT','NULL','Maharashtra','27','','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','',NULL,450,'187'),(94,'274','R.SHANTILAL & CO.','5','DR','0','27AAAFR0546E1ZK',NULL,NULL,'1','4',0,'MUMBAI','DEFAULT','NULL','Maharashtra','27','','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','',NULL,450,'188'),(95,'274','RAVAL TRADING COMPANY','5','DR','0','27AABPR4334F1ZU',NULL,NULL,'1','4',0,'D-304,TTC INDUSTRIAL AREA,','TURBHE MIDC,','NAVI MUMBAI','Maharashtra','27','400705','NULL','9769904761','NEFT','NULL','0','0','0','NULL','NULL',NULL,450,'207'),(96,'274','RAVAL TRADING EXPORTS PVT LTD','5','DR','0','24AANCR0497E1Z9',NULL,NULL,'1','4',0,'F P 66, T P 151, Survey no. 898','Gandhinagar','Gujarat','Gujarat','0','382721','NULL','9979977080','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'255'),(97,'274','ROHIT STORES','5','DR','0',NULL,NULL,NULL,'3','3',0,'E/19,7,SHAHU NAGAR','MAHIM(E)','MUMBAI','Maharashtra','27','400017','NULL','9100000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'142'),(98,'274','ROME TRADING CO','5','DR','0','27ASUPG5076E1ZE',NULL,NULL,'1','4',0,'7, AHEMDABAD STREET','CARNAC BUNDER','MUMBAI','Maharashtra','27','400009','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'250'),(99,'274','Redex Global','5','DR','0','27ANIPS4006R1ZD',NULL,NULL,'1','4',0,'C/o. Gohil Dye Chem D-8/1, TTC Industrial Area,Next To Modhera Chemicals Near Jai Matadi Kata,','Turbhe','Navi Mumbai','Maharashtra','27','400705','NULL','9999999999','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'228'),(100,'274','Riddhi Enterprise','5','DR','0','27AORPG0615A1ZE',NULL,NULL,'1','4',0,'Plot No 37, Sec-5, Nr Tilak School','Ghansoli, Navi Mumbai','Navi Mumbai','Maharashtra','27','400704','NULL','9702150004','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'237'),(101,'274','Rising International','5','DR','0','24ABJFR4468B1Z8',NULL,NULL,'1','4',0,'501, 5th Floor Shapath 1, Suite # 1019','NULL','Ahmedabad','Gujarat','0','380054','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'282'),(102,'274','SADHNA ENTERPRISES','5','DR','0','27AFKFS5269Q1ZW',NULL,NULL,'1','4',0,'Evrest Infotech Park 2 Plot. No. C-30,31 Pawane Midc','Thane Belapur Road Navi Mumbai','Mumbai','Maharashtra','27','400705','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'249'),(103,'274','SAHU ENTERPRISES','5','DR','0','27AIQPG6919E1Z0',NULL,NULL,'1','4',0,'GALA NO 9 PLOT NO A/3 BGTA GANGA PREMISES CO-OP SOC','WADALA TERMINAL TRUCK','WADALA','Maharashtra','27','400037','sahuenterprises@gmail.com','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'197'),(104,'274','SAI AGENCY','5','DR','0','27AJMPK4385M1ZH',NULL,NULL,'1','4',0,'GODOWN NO. 16, 9 ACRE','MANPADA, THANE WEST','NULL','Maharashtra','27','400607','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'209'),(105,'274','SAI IMPEX','5','DR','0','27AEOPA4963Q1ZS',NULL,NULL,'1','4',0,'C-7, MASALA MARKET PHASE-2 ,APMC MARKET VASHI, NAVI MUMBAI','DEFAULT','NAVI MUMBAI','Maharashtra','27','400705','NULL','9100000000.0','NEFT','NULL','0','0','0','NULL','NULL',NULL,450,'189'),(106,'274','SAI SHRADDHA','5','DR','0','27BEVPK3633P1ZN',NULL,NULL,'1','4',0,'SHOP NO.2, NIKKI NAGAR,','GANDHARE VILLAGE,KALYAN','THANE','Maharashtra','27','421301','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'216'),(107,'274','SAI SHRADDHA COLD DRINKS','11','CR','0','27BEVPK3633P1ZN',NULL,NULL,'1','4',0,'KALYAN','DEFAULT','Mumbai','Maharashtra','27','400001','NULL','9000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'190'),(108,'274','SALES STOCK ADJ','5','DR','0',NULL,NULL,NULL,'1','4',0,'MAHIM','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'201'),(109,'274','SAMAYARAA SALES','11','CR','0','27BEVPK3633P2ZM',NULL,NULL,'1','4',0,'171, SONALE VILLAGE,','BHIWANDI','','Maharashtra','27',NULL,'NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'269'),(110,'274','SARASWAT BANK','12','DR','0',NULL,NULL,NULL,'2','1',0,'DEFAULT','NULL','NULL','Maharashtra','27',NULL,'NULL','NULL','SARASWAT BANK','NULL','0','0','0','NULL','NULL',NULL,450,'202'),(111,'274','SEALINK IMPEX','5','DR','0','27AMIPM3282E1Z0',NULL,NULL,'1','4',0,'501,KAILASH BHUVAN NO.1, M.P, VAIDYA MARG','TILAK ROAD , GHATKOPAR (E)','MUMBAI','Maharashtra','27','400077','NULL','9821241567','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'229'),(112,'274','SELMAX EXPORTS PVT LTD','5','DR','0','27AAFCS1760B1ZO',NULL,NULL,'1','4',0,'PLOT NO D10/5 TURBHE T.T.C','MIDC AREA NEAR SUDHIR SETH','REKUNDA GAON NEAR JAY MATA DI KATTA','Maharashtra','27','400705','mail@selmax.co.in','9820655796','NULL','NULL','0','0','0','NULL','10016022005569',NULL,450,'191'),(113,'274','SHREE BALASA INTERNATIONAL LLP','5','DR','0','24AEEFS5003F1ZH',NULL,NULL,'1','4',0,'Plot No.22, Vrundavan Industrial Park','Palgham, Umbergaon','Gujarat','Gujarat','0','396170','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'281'),(114,'274','SHREE SAI ENTERPRISE','5','DR','0','27AVPPP5648D1Z4',NULL,NULL,'1','4',0,'SHOP NO.11 KRISHNA COMPLEX GANGA NAGAR','MIRA ROAD (E) THANE','NULL','Maharashtra','27','401107','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'210'),(115,'274','SHREE SAI ENTERPRISES','11','DR','0','27AVPPP5648D1Z4',NULL,NULL,'2','1',0,'THANE','DEFAULT','NULL','Maharashtra','27',NULL,'mohmmadpatel@gmail.com','9769863675','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'192'),(116,'274','SHUV ENTERPRISE','5','DR','0','27ARCPB7067M1ZJ',NULL,NULL,'1','4',0,'1204,A-WING ANMOL HEIGHTS CO-OP HSG ,LTD,','KURAR VILLAGE, MALAD(E)','MUMBAI','Maharashtra','27','400097','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'217'),(117,'274','SOHAM SALES','11','CR','0','27EQHPS4644P1ZW',NULL,NULL,'1','4',0,'GALA NO 5/A, SHREE KRISHNA BHAJI PAPLA','SION PAVVEL HIGHWAY ROAD MANKHURD','MUMBAI','Maharashtra','27','400021','NULL','9867501201','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'224'),(118,'274','SPAN IMPEX','5','DR','0','27AQRPK6371K1Z4',NULL,NULL,'1','4',0,'NEVETIA BUNGLOW, NEVETIA ROAD','MALAD EAST','MUMBAI','Maharashtra','27','400097','spanprem@yahoo.co.in','9820571008','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'266'),(119,'274','SPICE NEST','5','DR','0','24AAXPR2457H2Z5',NULL,NULL,'1','4',0,'PLOT NO 6 RAMESHWAR IND.','Rajkot','Rajkot','Gujarat','0','360002','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'230'),(120,'274','SPICE NEST IMPEX PRIVATE LIMITED','5','DR','0','24ABGCS5965G1Z2',NULL,NULL,'1','4',0,'Balaji Hall, 3rd Floor, Office No. 309, RK Prime 2, 150 Feet Ring Road, Mahapuja Dham Chowk,','Rajkot','Gujarat','Gujarat','0','360004','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'248'),(121,'274','STARKING EXIM LLP','5','DR','0','27AFHFS5470G1ZP',NULL,NULL,'1','4',0,'C-601, Mangeshi Dazzle 3, Dombivali','90 Feet Road','Kalyan','Maharashtra','27','421201','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'247'),(122,'274','SUDHIR SHETH','5','DR','0','27APRPS5762B1ZG',NULL,NULL,'1','4',0,'D-10/6,T.T.C.INDUSTRIAL AREA','M.I.D.C.TURBHE.JUINAGAR,','MUMBAI','Maharashtra','27','400705','NULL','9100000000','NULL','NULL','0','0','0','NULL','',NULL,450,'193'),(123,'274','SUNRISE CHEMICALS','5','DR','0','27AACFS3511N1Z3',NULL,NULL,'1','4',0,'207 2ND FLOOR, SAMUEL STREET','MASJID BUNDER WEST','MUMBAI','Maharashtra','27','400003','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'194'),(124,'274','SUPERMARKET GROCERY SUPPLIES PVT. LTD.','11','DR','0','27AAQCS4503H1Z6',NULL,NULL,'2','1',0,'C-19,TTC INDUSTRIAL AREA,PAWNE,','THANE BELAPUR ROAD,','NAVI MUMBAI','Maharashtra','27','400703','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'195'),(125,'274','SURYA ENTERPRISE','5','DR','0','27BCSPS3665N1ZI',NULL,NULL,'1','4',0,'MUMBAI 400 001','EGG SECTION,INSIDE CRAWFORD MARKET,','MUMBAI','Maharashtra','27','400002','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','11519001000696',NULL,450,'196'),(126,'274','Shalom Services','5','DR','0','27ATZPC5967A2ZA',NULL,NULL,'1','4',0,'Second Floor A-204','Shree Dutta Krupa Apartment','Thane','Maharashtra','27','400705','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'232'),(127,'274','Siddhi Enterprises','5','DR','0','27AFYPV2478N1Z3',NULL,NULL,'1','4',0,'J 124, SECTOR 3, AIROLI,','NAVI MUMBAI','Mumbai','Maharashtra','27','400708','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'264'),(128,'274','Super Bazar','5','DR','0','27AMCPS7275F2ZO',NULL,NULL,'1','4',0,'Gd Flr, Shop no 119, European','Wadala','Mumbai','Maharashtra','27','400037','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'222'),(129,'274','TRANS GLOBAL TRADE','5','DR','0','27ACAPJ5495L1Z6',NULL,NULL,'1','4',0,'9, Bhoj Mahal, Plot No.545, Tejukaya Park,','Dr. B. A. Road, Matunga,','Mumbai','Maharashtra','27','400019','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'231'),(130,'274','TULSI AGRISCALE IMPEX LLP','5','DR','0','27AANFT7253R1Z4',NULL,NULL,'1','4',0,'805, SATARA PLAZA, PLOT NO.19, SECT 19D, PALM BEACH','VASHI,','NAVI MUMBAI','Maharashtra','27','400703','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'262'),(131,'274','Tripin Traders','5','DR','0','27AABFT9524D1Z7',NULL,NULL,'1','4',0,'32, Nagdevi street,','NULL','mumbai','Maharashtra','27','400003','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'221'),(132,'274','Tulaja Trading Company','5','DR','0','27BFVPK4517F1Z5',NULL,NULL,'1','4',0,'Plot No 48 & 49, Unit No M127 & M33, Next To Green Park Hotel','Vashi','Navi Mumbai','Maharashtra','27','400705','tulajatradingcompany@gmail.com','9594876777','NEFT','NEFT','0','0','0','NULL','NULL',NULL,450,'244'),(133,'274','Unique Fragrances','5','DR','0','27AAAFU1982B1ZD',NULL,NULL,'1','4',0,'C 141, TTC Industrial Area MIDC','NAVI MUMBAI,','Pawane','Maharashtra','27','400705','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'235'),(134,'274','VAIVIN ENTERPRISES','5','DR','0','27AAZFV1142K1ZK',NULL,NULL,'1','4',0,'FLAT B-701,Ashar-16,','Thane','THANE','Maharashtra','27','400604','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'260'),(135,'274','VARUN BEVERAGES LTD.','11','DR','0','27AAACV2678L1ZU',NULL,NULL,'2','1',0,'F','DEFAULT','NULL','Maharashtra','27',NULL,'NULL','9100000000.0','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'198'),(136,'274','VIKASHINI AGENCY','5','DR','0','27AQVPT4329G1Z6',NULL,NULL,'1','4',0,'PLOT NO.92,FLAT NO.301,SAI JAGANAT BUILDING,','SECTOR-31,VASHI VILLAGE,','NAVI MUMBAI','Maharashtra','27','400703','NULL','9100000000.0','NULL','NULL','0','0','0','NULL','11520016000022',NULL,450,'199'),(137,'274','VIMAL OVERSEAS','5','DR','0','27AADFV1164B1ZJ',NULL,NULL,'1','4',0,'3RD, 54TO63, 418TO424 CHOTALAL BHUWAN,JOSHIWADI','KALBADEVI ROAD','MUMBAI','Maharashtra','27','400002','vimalsoverseas@gmail.com','02222000133','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'200'),(138,'274','Victory Agency','5','DR','0','27AADPB9244N1ZG',NULL,NULL,'1','4',0,'opp aher garden, Walhekwarwadi','chinchwadgoan','pune','Maharashtra','27','411033','NULL','0000000000','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'273'),(139,'274','WALIA FASHIONS','5','DR','0','07AAAPW3642E1ZT',NULL,NULL,'1','4',0,'E-44 Okhla phase 2 New Delhi -110020','New Delhi','Delhi','Delhi','0','110020','NULL','9999999999','NULL','NULL','0','0','0','NULL','NULL',NULL,450,'239');
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `PG_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` int DEFAULT '0',
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUB_AC_DEBTORS',
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'SALES_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `INV_ARR` text,
  `INV_NO` text,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'tax_against',
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'van',
  `PROD_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN_QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FREE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROFIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'SALES_DATE',
  `WEIGHT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PRICE_PER` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DMG_MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REMARK` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_ARR` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'add_amt',
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'less_amt',
  `CREATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UPDATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SECURITY_KEY` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AREA` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_MAN` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GROUP_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PARTY_CODE` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FINAL_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BATCH_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `MFG_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `EXP_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int DEFAULT '0',
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int DEFAULT '0',
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUB_AC_DEBTORS',
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'SALES_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int DEFAULT '0',
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SMAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYNC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text,
  `UPDATED_VALUE` text,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text,
  `DIACM` text,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int DEFAULT '0',
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int DEFAULT '0',
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-08-05 10:16:15','2026-08-05 10:16:15');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UOM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int DEFAULT '0',
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
INSERT INTO `USER_PREF` VALUES (1,'274',NULL,NULL,'SalesReverseCalculation','1',450,NULL,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:20:10','2026-08-05 10:20:10'),(2,'274',NULL,NULL,'SalesZeroStock','1',450,NULL,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:20:10','2026-08-05 10:20:10'),(3,'274',NULL,NULL,'salesTemplateName','print-A4 Paper.hbs',450,NULL,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:20:10','2026-08-05 10:20:10'),(4,'274',NULL,NULL,'SalesPurchaseDecimal4','1',450,NULL,NULL,NULL,'450','450',NULL,0,'2026-08-05 10:20:10','2026-08-05 10:20:10');
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `WEB_ID` int NOT NULL DEFAULT '0',
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-08-05 10:16:20');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-05 21:00:06
