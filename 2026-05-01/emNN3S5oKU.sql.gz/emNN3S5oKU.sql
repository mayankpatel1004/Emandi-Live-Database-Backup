-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: emNN3S5oKU
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `emNN3S5oKU`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `emNN3S5oKU` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `emNN3S5oKU`;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AREA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
INSERT INTO `AREA` VALUES (1,'165',NULL,NULL,'1','MULUND',NULL,'282','282',NULL,0,'2026-02-17 10:58:40','2026-02-17 10:58:40');
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CONFIG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text,
  `MASTER` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'165','0','emNN3S5oKU',165,'','','','2026-02-17 10:32:46','2026-02-17 10:32:46','','','','','','','','','2026-02-17 10:32:46','282','282','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` varchar(25) NOT NULL DEFAULT 'Yes',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=166 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (165,NULL,NULL,NULL,'C Company','2025-04-01','2026-03-31','Shop No.2 Nr. Hanuman Temple','Gavdevi Rd Bhandup (W) Mumbai-400078','Mumbai','21','8082391869','','','','','','','','','','','','','','',NULL,'0',NULL,NULL,'27','','','s2@yopmail.com','','400078',NULL,'1',NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-02-17 10:32:46','2026-02-17 10:32:46',NULL,'','','C COMPANY','Yes');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `CREATED_TS` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `BATCH_ID` int DEFAULT '0',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DISP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-02-17 10:32:45','2026-02-17 10:32:45');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `DELETED` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int DEFAULT '0',
  `TAX_ID` int DEFAULT '0',
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INV_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'165',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'165',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'165',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'165',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'165',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'165',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'165',NULL,NULL,'1','','S','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(8,'165',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(9,'165',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(10,'165',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(11,'165',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(12,'165',NULL,NULL,'1','','','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(13,'165',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(14,'165',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LEDGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `MAC_ID` int DEFAULT '0',
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int DEFAULT '0',
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int DEFAULT '0',
  `ROOT_PARENT_ID` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(2,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text,
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `SAC_ID` int NOT NULL DEFAULT '0',
  `REMOTE_ID` int NOT NULL DEFAULT '0',
  `PENDING_AMT` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `PROD_ID` int NOT NULL DEFAULT '0',
  `PACK` int NOT NULL DEFAULT '0',
  `PROD_BATCH_ID` int NOT NULL DEFAULT '0',
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int NOT NULL DEFAULT '0',
  `PUR_RET_QTY` int NOT NULL DEFAULT '0',
  `PUR_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `PUR_TOTAL` int NOT NULL DEFAULT '0',
  `SALE_QTY` int DEFAULT '0',
  `SALE_RET_QTY` int DEFAULT '0',
  `SALE_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `SALE_TOTAL` int NOT NULL DEFAULT '0',
  `OP_STOCK` int NOT NULL DEFAULT '0',
  `CLOSING_STOCK` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
INSERT INTO `OP_CL_STOCK` VALUES (1,165,1,0,1,'2026-02-17',100,0,0,0,20000,0,0,20000,0,-20000),(2,165,2,0,2,'2026-02-17',200,0,0,0,0,0,0,0,0,0),(3,165,3,0,3,'2026-02-17',300,0,0,0,0,0,0,0,0,0),(4,165,4,0,4,'2026-02-17',400,0,0,0,0,0,0,0,0,0),(5,165,4,0,4,'2026-02-18',0,0,0,0,2200,0,0,2200,0,-2200),(6,165,3,0,3,'2026-02-18',600,0,0,0,0,0,0,0,0,0),(7,165,2,0,2,'2026-02-18',400,0,0,0,0,0,0,0,0,0),(8,165,1,0,1,'2026-02-18',200,0,0,0,0,0,0,0,-20000,0),(9,165,1,0,1,'2026-02-19',0,0,0,0,1200,0,0,1200,0,-1200);
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-02-17 10:32:45','2026-02-17 10:32:45');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'165',NULL,NULL,'001',NULL,'','SNAC LLITE PASTAMASALA MRP 5|25GM*2.7KG','SNAC LLITE PASTAMASALA MRP 5|25GM*2.7KG','21069099','25','2',NULL,'1','HALDIRAM B DIVISION','7','7','108',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(2,'165',NULL,NULL,'002',NULL,'','SNAC LITE PLAIN PONGA 30 GM*3.24 KG','SNAC LITE PLAIN PONGA 30 GM*3.24 KG','21069099','30','2',NULL,'1','HALDIRAM B DIVISION','7','7','108',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(3,'165',NULL,NULL,'003',NULL,'','SNAC LITE MASALA CHOWKADI 25 GM*2.7 KG','SNAC LITE MASALA CHOWKADI 25 GM*2.7 KG','21069099','25','2',NULL,'1','HALDIRAM B DIVISION','7','7','108',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(4,'165',NULL,NULL,'004',NULL,'','POPCORN SALTED MRP 5|11GM*1.716KG','POPCORN SALTED MRP 5|11GM*1.716KG','21069099','11','2',NULL,'1','HALDIRAM B DIVISION','7','7','156',NULL,NULL,'6','6','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','156','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(5,'165',NULL,NULL,'005',NULL,'','POTATO LITE MRP 5|15 GM*3.6 KG','POTATO LITE MRP 5|15 GM*3.6 KG','21069099','15','2',NULL,'1','HALDIRAM B DIVISION','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(6,'165',NULL,NULL,'006',NULL,'','SNAC LITE NOODLE STICKS 25 GM*2.7 KG','SNAC LITE NOODLE STICKS 25 GM*2.7 KG','21069099','25','2',NULL,'1','HALDIRAM B DIVISION','7','7','108',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(7,'165',NULL,NULL,'007',NULL,'','POPCORN SALTED MRP 5|12 GM*1.872 KG','POPCORN SALTED MRP 5|12 GM*1.872 KG','21069099','12','2',NULL,'1','HALDIRAM B DIVISION','7','7','156',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','156','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(8,'165',NULL,NULL,'008',NULL,'','FALAHARI CHIWDA MRP 5|18GM*5.4KG','FALAHARI CHIWDA MRP 5|18GM*5.4KG','21069099','18','2',NULL,'1','HALDIRAM B DIVISION','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(9,'165',NULL,NULL,'009',NULL,'','MOONG DAL MRP 5|17 GM*9.792 KG','MOONG DAL MRP 5|17 GM*9.792 KG','21069099','17','2',NULL,'1','HALDIRAM B DIVISION','7','7','576',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','576','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(10,'165',NULL,NULL,'010',NULL,'','MIXTURE MRP 5|22 GM*9.504 KG NGP','MIXTURE MRP 5|22 GM*9.504 KG NGP','21069099','22','2',NULL,'1','HALDIRAM B DIVISION','7','7','432',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','432','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(11,'165',NULL,NULL,'011',NULL,'','SOYA CHIPS MRP 5|20 GM*4.8 KG NGP','SOYA CHIPS MRP 5|20 GM*4.8 KG NGP','21069099','20','2',NULL,'1','HALDIRAM B DIVISION','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(12,'165',NULL,NULL,'012',NULL,'','SOYA STICKS MRP 5|20 GM*4.8 KG NGP','SOYA STICKS MRP 5|20 GM*4.8 KG NGP','21069099','20','2',NULL,'1','HALDIRAM B DIVISION','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(13,'165',NULL,NULL,'013',NULL,'','ALOO BHUJIA MRP 5|20 GM*7.68 KG','ALOO BHUJIA MRP 5|20 GM*7.68 KG','21069099','20','2',NULL,'1','HALDIRAM B DIVISION','7','7','384',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','384','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(14,'165',NULL,NULL,'014',NULL,'','ALL IN ONE MRP 5|17GM*7.344KG NGP','ALL IN ONE MRP 5|17GM*7.344KG NGP','21069099','17','2',NULL,'1','HALDIRAM B DIVISION','7','7','432',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','432','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(15,'165',NULL,NULL,'015',NULL,'','BHUJIA MRP 5| 17 GM*8.16 KG','BHUJIA MRP 5| 17 GM*8.16 KG','21069099','17','2',NULL,'1','HALDIRAM B DIVISION','7','7','480',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','480','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(16,'165',NULL,NULL,'016',NULL,'','CHATPATA MATAR MRP5|18.55GM*10.685KG NGP','CHATPATA MATAR MRP5|18.55GM*10.685KG NGP','21069099','55','2',NULL,'1','HALDIRAM B DIVISION','7','7','576',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','576','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(17,'165',NULL,NULL,'017',NULL,'','CHANA JOR GARAM MRP 5|25 GM*7.2 KG NGP','CHANA JOR GARAM MRP 5|25 GM*7.2 KG NGP','21069099','25','2',NULL,'1','HALDIRAM B DIVISION','7','7','288',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(18,'165',NULL,NULL,'018',NULL,'','KHATTA MEETHA MRP 5|27.5GM*9.24KG NGP','KHATTA MEETHA MRP 5|27.5GM*9.24KG NGP','21069099','27.5','2',NULL,'1','HALDIRAM B DIVISION','7','7','336',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','336','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(19,'165',NULL,NULL,'019',NULL,'','LITE CHIWDA MRP 5|22GM*7.92KG NGP','LITE CHIWDA MRP 5|22GM*7.92KG NGP','21069099','22','2',NULL,'1','HALDIRAM B DIVISION','7','7','360',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','360','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(20,'165',NULL,NULL,'020',NULL,'','LEMON BHEL MRP 5|22 GM*6.6 KG NGP','LEMON BHEL MRP 5|22 GM*6.6 KG NGP','21069099','22','2',NULL,'1','HALDIRAM B DIVISION','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(21,'165',NULL,NULL,'021',NULL,'','CHIKKI PEANUT MRP 10| 30 GM*9.6 KG NGP','CHIKKI PEANUT MRP 10| 30 GM*9.6 KG NGP','17049090','30','2',NULL,'1','HALDIRAM B DIVISION','7','7','320',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','320','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(22,'165',NULL,NULL,'022',NULL,'','POPCORN SALTED MRP 10|22GM*2.2KG','POPCORN SALTED MRP 10|22GM*2.2KG','21069099','22','2',NULL,'1','HALDIRAM B DIVISION','7','7','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(23,'165',NULL,NULL,'023',NULL,'','WOKA INSTANT NOODLES 52 GM*7.488KG','WOKA INSTANT NOODLES 52 GM*7.488KG','19021900','52','2',NULL,'1','HALDIRAM B DIVISION','7','7','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(24,'165',NULL,NULL,'024',NULL,'','ALL IN ONE 36 GM *8.6KG NGP','ALL IN ONE 36 GM *8.6KG NGP','21069099','36','2',NULL,'1','HALDIRAM B DIVISION','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(25,'165',NULL,NULL,'025',NULL,'','ALOO BHUJIA MRP 10|42 GM*10.584 KG','ALOO BHUJIA MRP 10|42 GM*10.584 KG','21069099','42','2',NULL,'1','HALDIRAM B DIVISION','7','7','252',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','252','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(26,'165',NULL,NULL,'026',NULL,'','BHUJIA 35 GM*9.24 KG NGP','BHUJIA 35 GM*9.24 KG NGP','21069099','35','2',NULL,'1','HALDIRAM B DIVISION','7','7','264',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','264','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(27,'165',NULL,NULL,'027',NULL,'','CHANA JOR GARAM MRP 10|50 GM*9 KG NGP','CHANA JOR GARAM MRP 10|50 GM*9 KG NGP','21069099','50','2',NULL,'1','HALDIRAM B DIVISION','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(28,'165',NULL,NULL,'028',NULL,'','ROASTED CRUSHED PEANUT 35GM*10.5KG','ROASTED CRUSHED PEANUT 35GM*10.5KG','20081100','35','2',NULL,'1','HALDIRAM B DIVISION','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(29,'165',NULL,NULL,'029',NULL,'','INSTANT BHEL MRP 10|44 GM*8.976 KG','INSTANT BHEL MRP 10|44 GM*8.976 KG','21069099','44','2',NULL,'1','HALDIRAM B DIVISION','7','7','204',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','204','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(30,'165',NULL,NULL,'030',NULL,'','FALAHARI CHIWDA  MRP 10|42 GM*10.08 KG','FALAHARI CHIWDA  MRP 10|42 GM*10.08 KG','21069099','42','2',NULL,'1','HALDIRAM B DIVISION','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(31,'165',NULL,NULL,'031',NULL,'','KHATTA MEETHA MRP 10|50 GM*12 KG NGP','KHATTA MEETHA MRP 10|50 GM*12 KG NGP','21069099','50','2',NULL,'1','HALDIRAM B DIVISION','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(32,'165',NULL,NULL,'032',NULL,'','LITE CHIWDA 45GM*8.64KG','LITE CHIWDA 45GM*8.64KG','21069099','45','2',NULL,'1','HALDIRAM B DIVISION','7','7','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(33,'165',NULL,NULL,'033',NULL,'','LEMON BHEL MRP 10|47 GM*8.460 KG NGP','LEMON BHEL MRP 10|47 GM*8.460 KG NGP','20052000','47','2',NULL,'1','HALDIRAM B DIVISION','7','7','180',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','180','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(34,'165',NULL,NULL,'034',NULL,'','MASALA PEANUT MRP 10|35 GM*10.5 KG NGP','MASALA PEANUT MRP 10|35 GM*10.5 KG NGP','20081100','35','2',NULL,'1','HALDIRAM B DIVISION','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(35,'165',NULL,NULL,'035',NULL,'','MIXTURE MRP 10|48 GM*11.52 KG NGP','MIXTURE MRP 10|48 GM*11.52 KG NGP','21069099','48','2',NULL,'1','HALDIRAM B DIVISION','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(36,'165',NULL,NULL,'036',NULL,'','MOONG DAL MRP 10|35 GM*11.76 KG NGP','MOONG DAL MRP 10|35 GM*11.76 KG NGP','21069099','35','2',NULL,'1','HALDIRAM B DIVISION','7','7','336',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','336','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(37,'165',NULL,NULL,'037',NULL,'','NAVRATAN MIX MRP 10|30GM*7.2KG NGP','NAVRATAN MIX MRP 10|30GM*7.2KG NGP','21069099','30','2',NULL,'1','HALDIRAM B DIVISION','7','7','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(38,'165',NULL,NULL,'038',NULL,'','PANCHRATTAN MRP 10|25 GM*7.5 KG NGP','PANCHRATTAN MRP 10|25 GM*7.5 KG NGP','21069099','25','2',NULL,'1','HALDIRAM B DIVISION','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(39,'165',NULL,NULL,'039',NULL,'','RATLAMI SEV MRP 10|45GM*10.26KG','RATLAMI SEV MRP 10|45GM*10.26KG','21069099','45','2',NULL,'1','HALDIRAM B DIVISION','7','7','228',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','228','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(40,'165',NULL,NULL,'040',NULL,'','SALTED PEANUT MRP 10|34GM*10.2KG NGP','SALTED PEANUT MRP 10|34GM*10.2KG NGP','20081100','34','2',NULL,'1','HALDIRAM B DIVISION','7','7','300',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','300','0','0','0','HALDIRAM B DIVISION',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL);
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-02-17 10:32:46','2026-02-17 10:32:46');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'165',NULL,NULL,'HALDIRAM B DIVISION','1',NULL,NULL,NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 10:58:54','2026-02-17 10:58:54');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'165',NULL,NULL,'1','1770962005877','2000-01-01','0108-01-01','001','0','0','700','5','4.0476','4.7619','3.0000','3.0000','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(2,'165',NULL,NULL,'2','1770962005887','2000-01-01','0108-01-01','002','0','0','1100','5','4.0476','8.9286','3.0000','3.0000','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(3,'165',NULL,NULL,'3','1770962005899','2000-01-01','0108-01-01','003','0','0','2400','5','4.0476','3.3898','3.0000','3.0000','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(4,'165',NULL,NULL,'4','1770962005907','2000-01-01','0156-01-01','004','0','0','3800','5','4.0476','2.8571','3.0000','3.0000','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(5,'165',NULL,NULL,'5','1770962005917','2000-01-01','0240-01-01','005','0','0','0.00','5','4.0476','0','3.5437','0','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(6,'165',NULL,NULL,'6','1770962005924','2000-01-01','0108-01-01','006','0','0','0.00','5','4.0476','0','3.5437','0','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(7,'165',NULL,NULL,'7','1770962005934','2000-01-01','0156-01-01','007','0','0','0.00','5','4.0476','0','3.5437','0','0.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(8,'165',NULL,NULL,'8','1770962005943','2000-01-01','0300-01-01','008','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(9,'165',NULL,NULL,'9','1770962005951','2000-01-01','0576-01-01','009','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(10,'165',NULL,NULL,'10','1770962005958','2000-01-01','0432-01-01','010','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(11,'165',NULL,NULL,'11','1770962005965','2000-01-01','0240-01-01','011','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(12,'165',NULL,NULL,'12','1770962005973','2000-01-01','0240-01-01','012','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(13,'165',NULL,NULL,'13','1770962005982','2000-01-01','0384-01-01','013','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(14,'165',NULL,NULL,'14','1770962005991','2000-01-01','0432-01-01','014','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:54',NULL),(15,'165',NULL,NULL,'15','1770962006001','2000-01-01','0480-01-01','015','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(16,'165',NULL,NULL,'16','1770962006009','2000-01-01','0576-01-01','016','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(17,'165',NULL,NULL,'17','1770962006017','2000-01-01','0288-01-01','017','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(18,'165',NULL,NULL,'18','1770962006024','2000-01-01','0336-01-01','018','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(19,'165',NULL,NULL,'19','1770962006034','2000-01-01','0360-01-01','019','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(20,'165',NULL,NULL,'20','1770962006041','2000-01-01','0300-01-01','020','0','0','0.00','5','4.0476','0','3.7651','0','0.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(21,'165',NULL,NULL,'21','1770962006050','2000-01-01','0320-01-01','021','0','0','0.00','10','8.1714','0','5.9898','0','2.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(22,'165',NULL,NULL,'22','1770962006059','2000-01-01','0100-01-01','022','0','0','0.00','10','8.1714','0','6.6292','0','1.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(23,'165',NULL,NULL,'23','1770962006067','2000-01-01','0144-01-01','023','0','0','0.00','10','8.1714','0','7.5661','0','0.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(24,'165',NULL,NULL,'24','1770962006074','2000-01-01','0240-01-01','024','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(25,'165',NULL,NULL,'25','1770962006083','2000-01-01','0252-01-01','025','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(26,'165',NULL,NULL,'26','1770962006092','2000-01-01','0264-01-01','026','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(27,'165',NULL,NULL,'27','1770962006100','2000-01-01','0180-01-01','027','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(28,'165',NULL,NULL,'28','1770962006108','2000-01-01','0300-01-01','028','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(29,'165',NULL,NULL,'29','1770962006116','2000-01-01','0204-01-01','029','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(30,'165',NULL,NULL,'30','1770962006123','2000-01-01','0240-01-01','030','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(31,'165',NULL,NULL,'31','1770962006130','2000-01-01','0240-01-01','031','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(32,'165',NULL,NULL,'32','1770962006137','2000-01-01','0192-01-01','032','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(33,'165',NULL,NULL,'33','1770962006143','2000-01-01','0180-01-01','033','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(34,'165',NULL,NULL,'34','1770962006151','2000-01-01','0300-01-01','034','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(35,'165',NULL,NULL,'35','1770962006158','2000-01-01','0240-01-01','035','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(36,'165',NULL,NULL,'36','1770962006167','2000-01-01','0336-01-01','036','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(37,'165',NULL,NULL,'37','1770962006174','2000-01-01','0240-01-01','037','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(38,'165',NULL,NULL,'38','1770962006181','2000-01-01','0300-01-01','038','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(39,'165',NULL,NULL,'39','1770962006188','2000-01-01','0228-01-01','039','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL),(40,'165',NULL,NULL,'40','1770962006196','2000-01-01','0300-01-01','040','0','0','0.00','10','8.1714','0','7.5545','0','0.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-02-17 10:58:55',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int DEFAULT '0',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int DEFAULT '0',
  `M_ROUND_OFF` int DEFAULT '0',
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
INSERT INTO `PURCHASE` VALUES (1,'165',NULL,NULL,'2026-02-17',123,'D001','0','30000','9720','0','0','0','0','0','2028','3993.3','998.325','998.325','0','0.00','0.00','+0.75','24273','24273.3','10000','0','14258.70',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'0','0',NULL,0,'0.00',0,NULL,NULL,0,0,'0',NULL,'0.00','Imported','282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(2,'165',NULL,NULL,'2026-02-17',123,'D002','0','75000','19800','0','0','0','0','0','11040','8071.2','2017.8','2017.8','0','0.00','0.00','+0.67','63271','63271.2','25000','0','36088.80',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'0','0',NULL,0,'0.00',0,NULL,NULL,0,0,'0',NULL,'0.00','Imported','282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(3,'165',NULL,NULL,'2026-02-17',123,'DB No.001',NULL,'3000.00','0','0','0.00','0.00','0','0','0','729.00','364.5','364.5','0.00','0','0','+0.96','3729.00','3729.00','5/364','20400.00','30000','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'1',NULL,NULL,'0.00','0','0',0,'0',0,'0','0',0,0,'0','0','0.00',NULL,'282','282',NULL,0,'2026-02-17 11:01:12','2026-02-17 11:01:12'),(4,'165',NULL,NULL,'2026-02-17',123,'DB No.002',NULL,'0','0','0','0.00','0.00','0','0','0','72.90','36.45','36.45','0.00','0','0','+0.98','373.00','372.90','0/0','0','00','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'1',NULL,NULL,'0.00','0','0',0,'0',0,'300.00','0',0,0,'0','0','0.00',NULL,'282','282',NULL,0,'2026-02-17 11:02:07','2026-02-17 11:02:07'),(5,'165',NULL,NULL,'2026-02-18',124,'H001',NULL,'30000.00','9000','720','0.00','0.00','0','10','2028.00','3993.30','1996.65','1996.65','0.00','5','250','+0.96','22000.00','22000.30','10000/0','204000.00','180025','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'0.00','0','0',0,'0',0,NULL,NULL,0,0,'0','0','0',NULL,'0','0',NULL,0,'2026-02-17 11:18:24','2026-02-17 11:41:30'),(6,'165',NULL,NULL,'2026-02-18',125,'DK001',NULL,'3000.00','90','11.52','0.00','0.00','0','10','289.85','628.87','314.435','314.435','0.00','0','0','+0.99','3270.00','3269.88','1000/0','20400.00','2608.630','',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'0.00','0','0',0,'0',0,NULL,NULL,0,0,'32.38','1','0',NULL,'0','0',NULL,0,'2026-02-17 11:23:22','2026-02-17 11:23:44'),(7,'165',NULL,NULL,'2026-02-18',124,'HDB001',NULL,'1800.00','0','0','0.00','0.00','0','0','0','729.00','364.5','364.5','0.00','11','740','-0.00','3000.00','1329.00','600/0','16000.00','106011','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'1',NULL,NULL,'0.00','0','0',0,'0',0,'1200.00','0',0,0,'0','0','0.00',NULL,'282','282',NULL,0,'2026-02-17 12:11:00','2026-02-17 12:51:17'),(8,'165',NULL,NULL,'2026-02-18',125,'DK002',NULL,'1800.00','0','0','0.00','0.00','0','0','0','309.00','154.5','154.5','0.00','0','0','-0.00','2259.00','1959.00','3/276','16000.00','18000','',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'1',NULL,NULL,'0.00','0','0',0,'0',0,'150.00','0',0,0,'0','1','0.00',NULL,'282','282',NULL,0,'2026-02-17 12:35:46','2026-02-17 12:51:30');
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text,
  `INV_NO` text,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
INSERT INTO `PURCHASE_ITEM` VALUES (1,'165','','',1,1,1,7,'3','5','2.5','2.5','0','0','0',108,NULL,'9.26','1000','','270','0',0,'0','300','0','0','3000','121.5','60.75','60.75','0','0','','0','0','','25','0','7','0','0','0','5','0','0','0','0','0','0','0','Imported','','','282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(2,'165','','',2,2,1,7,'3','12','6','6','0','0','0',108,NULL,'18.52','2000','','480','0',0,'0','1200','0','0','6000','518.4','259.2','259.2','0','0','','0','0','','30','0','7','0','0','0','5','0','0','0','0','0','0','0','Imported','','','282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(3,'165','','',3,3,1,7,'3','18','9','9','0','0','0',108,NULL,'27.78','3000','','630','0',0,'0','2700','0','0','9000','1020.6','510.3','510.3','0','0','','0','0','','25','0','7','0','0','0','5','0','0','0','0','0','0','0','Imported','','','282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(4,'165','','',4,4,1,7,'3','40','20','20','0','0','0',156,NULL,'25.64','4000','','648','0',0,'0','5520','0','0','12000','2332.8','1166.4','1166.4','0','0','','0','0','','11','0','7','0','0','0','5','0','0','0','0','0','0','0','Imported','','','282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(8,'165','','',1,1,2,7,'3','5','2.5','2.5','0','0','0',108,NULL,'46.3','5000','','2700','0',0,'0','1500','0','0','15000','540','270','270','0','0','','0','0','','25','0','7','0','0','0','5','0','0','0','0','0','0','0','Imported','','','282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(9,'165','','',2,2,2,7,'3','12','6','6','0','0','0',108,NULL,'55.56','6000','','2880','0',0,'0','3600','0','0','18000','1382.4','691.2','691.2','0','0','','0','0','','30','0','7','0','0','0','5','0','0','0','0','0','0','0','Imported','','','282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(10,'165','','',3,3,2,7,'3','18','9','9','0','0','0',108,NULL,'64.81','7000','','2940','0',0,'0','6300','0','0','21000','2116.8','1058.4','1058.4','0','0','','0','0','','25','0','7','0','0','0','5','0','0','0','0','0','0','0','Imported','','','282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(11,'165','','',4,4,2,7,'3','40','20','20','0','0','0',156,NULL,'44.87','7000','','2520','0',0,'0','8400','0','0','21000','4032','2016','2016','0','0','','0','0','','11','0','7','0','0','0','5','0','0','0','0','0','0','0','Imported','','','282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(15,'165',NULL,NULL,4,4,3,7,'3','40.00','20','20','0','0','0',1,NULL,'2.56','400','0','0','400',0,'0','0','0','0','1200.00','480.00','240','240','','1',NULL,'','',NULL,'11','7','7','0','0','0','1200.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:01:12','2026-02-17 11:01:12'),(16,'165',NULL,NULL,3,3,3,7,'3','18.00','9','9','0','0','0',1,NULL,'2.78','300','0','0','300',0,'0','0','0','0','900.00','162.00','81','81','','1',NULL,'','',NULL,'25','7','7','0','0','0','900.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:01:12','2026-02-17 11:01:12'),(17,'165',NULL,NULL,2,2,3,7,'3','12.00','6','6','0','0','0',1,NULL,'1.85','200','0','0','200',0,'0','0','0','0','600.00','72.00','36','36','','1',NULL,'','',NULL,'30','7','7','0','0','0','600.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:01:12','2026-02-17 11:01:12'),(18,'165',NULL,NULL,1,1,3,7,'3','5.00','2.5','2.5','0','0','0',1,NULL,'0.93','100','0','0','100',0,'0','0','0','0','300.00','15.00','7.5','7.5','','1',NULL,'','',NULL,'25','7','7','0','0','0','300.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:01:12','2026-02-17 11:01:12'),(19,'165',NULL,NULL,3,3,4,7,'3.0000','18.00','9','9','0','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','16.20','8.1','8.1','','1',NULL,'','',NULL,'25','7','7','0','0','0','90.00','30','90','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:02:07','2026-02-17 11:02:07'),(20,'165',NULL,NULL,4,4,4,7,'3.0000','40.00','20','20','0','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','48.00','24','24','','1',NULL,'','',NULL,'11','7','7','0','0','0','5','40','120','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:02:07','2026-02-17 11:02:07'),(21,'165',NULL,NULL,2,2,4,7,'3.0000','12.00','6','6','0','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','7.20','3.6','3.6','','1',NULL,'','',NULL,'30','7','7','0','0','0','60.00','20','60','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:02:07','2026-02-17 11:02:07'),(22,'165',NULL,NULL,1,1,4,7,'3.0000','5.00','2.5','2.5','0','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','1.50','0.75','0.75','','1',NULL,'','',NULL,'25','7','7','0','0','0','30.00','10','30','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:02:07','2026-02-17 11:02:07'),(23,'165',NULL,NULL,3,3,5,7,'3.0000','18.00','9','9','0','0','0',1,NULL,'27.78','03000','10','630',NULL,0,'30','2700.00','0','0','9000.0000','1020.60','510.3','510.3','',NULL,NULL,'','',NULL,'25','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 11:18:24','2026-02-17 11:18:24'),(24,'165',NULL,NULL,4,4,5,7,'3.0000','40.00','20','20','0','0','0',1,NULL,'25.64','04000','10','648',NULL,0,'40','4800.00','10','720.00','12000.0000','2332.80','1166.4','1166.4','',NULL,NULL,'','',NULL,'11','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 11:18:24','2026-02-17 11:18:24'),(25,'165',NULL,NULL,2,2,5,7,'3.0000','12.00','6','6','0','0','0',1,NULL,'18.52','02000','10','480',NULL,0,'20','1200.00','0','0','6000.0000','518.40','259.2','259.2','',NULL,NULL,'','',NULL,'30','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 11:18:24','2026-02-17 11:18:24'),(26,'165',NULL,NULL,1,1,5,7,'3.0000','5.00','2.5','2.5','0','0','0',1,NULL,'9.26','1000','10','270',NULL,0,'10','300.00','0','0','3000.0000','121.50','60.75','60.75','',NULL,NULL,'','',NULL,'25','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 11:18:24','2026-02-17 11:18:24'),(27,'165',NULL,NULL,4,4,6,7,'3.0000','40.00','20','20','0','0','0',1,NULL,'2.56','400','10','114.048',NULL,0,'4','48.00','1','11.52','1200.0000','410.57','205.285','205.285','',NULL,NULL,'','',NULL,'11','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 11:23:22','2026-02-17 11:23:22'),(28,'165',NULL,NULL,3,3,6,7,'3.0000','18.00','9','9','0','0','0',1,NULL,'2.78','0300','10','87.30000000000001',NULL,0,'3','27.00','0','0','900.0000','141.43','70.715','70.715','',NULL,NULL,'','',NULL,'25','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 11:23:22','2026-02-17 11:23:22'),(29,'165',NULL,NULL,2,2,6,7,'3.0000','12.00','6','6','0','0','0',1,NULL,'1.85','200','10','58.800000000000004',NULL,0,'2','12.00','0','0','600.0000','63.50','31.75','31.75','',NULL,NULL,'','',NULL,'30','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 11:23:22','2026-02-17 11:23:22'),(30,'165',NULL,NULL,1,1,6,7,'3.0000','5.00','2.5','2.5','0','0','0',1,NULL,'0.93','0100','10','29.700000000000003',NULL,0,'1','3.00','0','0','300.0000','13.37','6.685','6.685','',NULL,NULL,'','',NULL,'25','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 11:23:22','2026-02-17 11:23:22'),(31,'165',NULL,NULL,3,3,6,7,'3.0000','18.00','0','0','18.00','0','0',1,NULL,'2.78','0300','10','87.30000000000001',NULL,0,'3','27.00','0','0','900.0000','141.43','0','0','141.43',NULL,NULL,'','0',NULL,'25','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:23:44','2026-02-17 11:23:44'),(32,'165',NULL,NULL,4,4,6,7,'3.0000','40.00','0','0','40.00','0','0',1,NULL,'2.56','400','10','114.048',NULL,0,'4','48.00','1','11.52','1200.0000','410.57','0','0','410.57',NULL,NULL,'','0',NULL,'11','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:23:44','2026-02-17 11:23:44'),(33,'165',NULL,NULL,2,2,6,7,'3.0000','12.00','0','0','12.00','0','0',1,NULL,'1.85','200','10','58.800000000000004',NULL,0,'2','12.00','0','0','600.0000','63.50','0','0','63.50',NULL,NULL,'','0',NULL,'30','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:23:44','2026-02-17 11:23:44'),(34,'165',NULL,NULL,1,1,6,7,'3.0000','5.00','0','0','5.00','0','0',1,NULL,'0.93','0100','10','29.700000000000003',NULL,0,'1','3.00','0','0','300.0000','13.37','0','0','13.37',NULL,NULL,'','0',NULL,'25','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:23:44','2026-02-17 11:23:44'),(35,'165',NULL,NULL,3,3,5,7,'3.0000','18.00','9','9','0','0','0',1,NULL,'27.78','03000','10','630',NULL,0,'30','2700.00','0','0','9000.0000','1020.60','510.3','510.3','',NULL,NULL,'','0',NULL,'25','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:41:30','2026-02-17 11:41:30'),(36,'165',NULL,NULL,4,4,5,7,'3.0000','40.00','20','20','0','0','0',1,NULL,'25.64','04000','10','648',NULL,0,'40','4800.00','10','720.00','12000.0000','2332.80','1166.4','1166.4','',NULL,NULL,'','0',NULL,'11','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:41:30','2026-02-17 11:41:30'),(37,'165',NULL,NULL,1,1,5,7,'3.0000','5.00','2.5','2.5','0','0','0',1,NULL,'9.26','1000','10','270',NULL,0,'10','300.00','0','0','3000.0000','121.50','60.75','60.75','',NULL,NULL,'','0',NULL,'25','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:41:30','2026-02-17 11:41:30'),(38,'165',NULL,NULL,2,2,5,7,'3.0000','12.00','6','6','0','0','0',1,NULL,'18.52','02000','10','480',NULL,0,'20','1200.00','0','0','6000.0000','518.40','259.2','259.2','',NULL,NULL,'','0',NULL,'30','7','7','0','0','0','5',NULL,NULL,NULL,NULL,'0.00','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:41:30','2026-02-17 11:41:30'),(39,'165',NULL,NULL,2,2,7,7,'3.0000','12.00','6','6','0','0','0',1,NULL,'1.85','200','0','0','200',0,'0','0','0','0','600.00','72.00','36','36','','1',NULL,'','',NULL,'30','7','7','0','0','0','600.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:11:00','2026-02-17 12:11:00'),(40,'165',NULL,NULL,4,4,7,7,'3.0000','40.00','20','20','0','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','480.00','240','240','','1',NULL,'','',NULL,'11','7','7','0','0','0','5','400','1200','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:11:00','2026-02-17 12:11:00'),(41,'165',NULL,NULL,3,3,7,7,'3.0000','18.00','9','9','0','0','0',1,NULL,'2.78','0300','0','0','0300',0,'0','0','0','0','900.00','162.00','81','81','','1',NULL,'','',NULL,'25','7','7','0','0','0','900.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:11:00','2026-02-17 12:11:00'),(42,'165',NULL,NULL,1,1,7,7,'3.0000','5.00','2.5','2.5','0','0','0',1,NULL,'0.93','100','0','0','100',0,'0','0','0','0','300.00','15.00','7.5','7.5','','1',NULL,'','',NULL,'25','7','7','0','0','0','300.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:11:00','2026-02-17 12:11:00'),(43,'165',NULL,NULL,2,2,7,7,'3.0000','12.00','6','6','0','0','0',1,NULL,'1.85','200','0','0','200',0,'0','0','0','0','600.00','72.00','36','36','','1',NULL,'','0',NULL,'30','7','7','0','0','0','600.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:15:43','2026-02-17 12:15:43'),(44,'165',NULL,NULL,4,4,7,7,'3.0000','40.00','20','20','0','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','480.00','240','240','','1',NULL,'','0',NULL,'11','7','7','0','0','0','5','400','1200','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:15:43','2026-02-17 12:15:43'),(45,'165',NULL,NULL,1,1,7,7,'3.0000','5.00','2.5','2.5','0','0','0',1,NULL,'0.93','100','0','0','100',0,'0','0','0','0','300.00','15.00','7.5','7.5','','1',NULL,'','0',NULL,'25','7','7','0','0','0','300.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:15:43','2026-02-17 12:15:43'),(46,'165',NULL,NULL,3,3,7,7,'3.0000','18.00','9','9','0','0','0',1,NULL,'2.78','0300','0','0','0300',0,'0','0','0','0','900.00','162.00','81','81','','1',NULL,'','0',NULL,'25','7','7','0','0','0','900.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:15:43','2026-02-17 12:15:43'),(47,'165',NULL,NULL,4,4,8,7,'3.0000','40.00','0','0','40.00','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','60.00','0','0','60.00','1',NULL,'','',NULL,'11','7','7','0','0','0','5','50','150','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:35:46','2026-02-17 12:35:46'),(48,'165',NULL,NULL,3,3,8,7,'3.0000','18.00','0','0','18.00','0','0',1,NULL,'2.78','0300','0','0','0300',0,'0','0','0','0','900.00','162.00','0','0','162.00','1',NULL,'','',NULL,'25','7','7','0','0','0','900.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:35:46','2026-02-17 12:35:46'),(49,'165',NULL,NULL,2,2,8,7,'3.0000','12.00','0','0','12.00','0','0',1,NULL,'1.85','200','0','0','200',0,'0','0','0','0','600.00','72.00','0','0','72.00','1',NULL,'','',NULL,'30','7','7','0','0','0','600.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:35:46','2026-02-17 12:35:46'),(50,'165',NULL,NULL,1,1,8,7,'3.0000','5.00','0','0','5.00','0','0',1,NULL,'0.93','100','0','0','100',0,'0','0','0','0','300.00','15.00','0','0','15.00','1',NULL,'','',NULL,'25','7','7','0','0','0','300.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:35:46','2026-02-17 12:35:46'),(51,'165',NULL,NULL,4,4,7,7,'3.0000','40.00','20','20','0','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','480.00','240','240','','1',NULL,'','0',NULL,'11','7','7','0','0','0','5','400','1200','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:48:30','2026-02-17 12:48:30'),(52,'165',NULL,NULL,2,2,7,7,'3.0000','12.00','6','6','0','0','0',1,NULL,'1.85','200','0','0','200',0,'0','0','0','0','600.00','72.00','36','36','','1',NULL,'','0',NULL,'30','7','7','0','0','0','600.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:48:30','2026-02-17 12:48:30'),(53,'165',NULL,NULL,1,1,7,7,'3.0000','5.00','2.5','2.5','0','0','0',1,NULL,'0.93','100','0','0','100',0,'0','0','0','0','300.00','15.00','7.5','7.5','','1',NULL,'','0',NULL,'25','7','7','0','0','0','300.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:48:30','2026-02-17 12:48:30'),(54,'165',NULL,NULL,3,3,7,7,'3.0000','18.00','9','9','0','0','0',1,NULL,'2.78','0300','0','0','0300',0,'0','0','0','0','900.00','162.00','81','81','','1',NULL,'','0',NULL,'25','7','7','0','0','0','900.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:48:30','2026-02-17 12:48:30'),(55,'165',NULL,NULL,4,4,7,7,'3.0000','40.00','20','20','0','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','480.00','240','240','','1',NULL,'','0',NULL,'11','7','7','0','0','0','5','400','1200','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:49:19','2026-02-17 12:49:19'),(56,'165',NULL,NULL,1,1,7,7,'3.0000','5.00','2.5','2.5','0','0','0',1,NULL,'0.93','100','0','0','100',0,'0','0','0','0','300.00','15.00','7.5','7.5','','1',NULL,'','0',NULL,'25','7','7','0','0','0','300.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:49:19','2026-02-17 12:49:19'),(57,'165',NULL,NULL,2,2,7,7,'3.0000','12.00','6','6','0','0','0',1,NULL,'1.85','200','0','0','200',0,'0','0','0','0','600.00','72.00','36','36','','1',NULL,'','0',NULL,'30','7','7','0','0','0','600.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:49:19','2026-02-17 12:49:19'),(58,'165',NULL,NULL,3,3,7,7,'3.0000','18.00','9','9','0','0','0',1,NULL,'2.78','0300','0','0','0300',0,'0','0','0','0','900.00','162.00','81','81','','1',NULL,'','0',NULL,'25','7','7','0','0','0','900.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,1,'2026-02-17 12:49:19','2026-02-17 12:49:19'),(59,'165',NULL,NULL,1,1,7,7,'3.0000','5.00','2.5','2.5','0','0','0',1,NULL,'0.93','100','0','0','100',0,'0','0','0','0','300.00','15.00','7.5','7.5','','1',NULL,'','0',NULL,'25','7','7','0','0','0','300.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 12:51:17','2026-02-17 12:51:17'),(60,'165',NULL,NULL,4,4,7,7,'3.0000','40.00','20','20','0','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','480.00','240','240','','1',NULL,'','0',NULL,'11','7','7','0','0','0','5','400','1200','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 12:51:17','2026-02-17 12:51:17'),(61,'165',NULL,NULL,2,2,7,7,'3.0000','12.00','6','6','0','0','0',1,NULL,'1.85','200','0','0','200',0,'0','0','0','0','600.00','72.00','36','36','','1',NULL,'','0',NULL,'30','7','7','0','0','0','600.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 12:51:17','2026-02-17 12:51:17'),(62,'165',NULL,NULL,3,3,7,7,'3.0000','18.00','9','9','0','0','0',1,NULL,'2.78','0300','0','0','0300',0,'0','0','0','0','900.00','162.00','81','81','','1',NULL,'','0',NULL,'25','7','7','0','0','0','900.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 12:51:17','2026-02-17 12:51:17'),(63,'165',NULL,NULL,4,4,8,7,'3.0000','40.00','0','0','40.00','0','0',1,NULL,'0','0','0','0.00','0',0,'0','0','0','0','0','60.00','0','0','60.00','1',NULL,'','0',NULL,'11','7','7','0','0','0','5','50','150','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 12:51:30','2026-02-17 12:51:30'),(64,'165',NULL,NULL,3,3,8,7,'3.0000','18.00','0','0','18.00','0','0',1,NULL,'2.78','0300','0','0','0300',0,'0','0','0','0','900.00','162.00','0','0','162.00','1',NULL,'','0',NULL,'25','7','7','0','0','0','900.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 12:51:30','2026-02-17 12:51:30'),(65,'165',NULL,NULL,2,2,8,7,'3.0000','12.00','0','0','12.00','0','0',1,NULL,'1.85','200','0','0','200',0,'0','0','0','0','600.00','72.00','0','0','72.00','1',NULL,'','0',NULL,'30','7','7','0','0','0','600.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 12:51:30','2026-02-17 12:51:30'),(66,'165',NULL,NULL,1,1,8,7,'3.0000','5.00','0','0','5.00','0','0',1,NULL,'0.93','100','0','0','100',0,'0','0','0','0','300.00','15.00','0','0','15.00','1',NULL,'','0',NULL,'25','7','7','0','0','0','300.00','0','0','0','0','0','0','0',NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 12:51:30','2026-02-17 12:51:30');
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL,
  `LITE_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `WEB_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `PROD_ID` int NOT NULL,
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `PACK` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `BOX` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `QTY` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_PERCENT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_AMOUNT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN_QTY` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `FREE` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `AMT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `SR_NO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `CESS_AMT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `UI_DISP_BAG` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '',
  `WEIGHT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `PRICE_PER` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `SALE_UNIT` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `MRP` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE_AMT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `REPLACE` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `DMG_MRP` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_INSURANCE` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `CLOUD_SYNC` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `INV_ARR` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `INV_NO` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_BY` int DEFAULT NULL,
  `UPDATED_BY` int DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_TS` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SUPPLIER_ID` int DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `GROUP_ID` int DEFAULT NULL,
  `FINAL_AMT` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  `BATCH_NO` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TCS_TAX` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `BROKER_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
INSERT INTO `PUR_SALE_RET_MAPPING` VALUES (3,'165',NULL,NULL,'3','1','S','4000',NULL,'282','282','SalesReturn',0,'2026-02-17 11:04:23','2026-02-17 11:04:23'),(4,'165',NULL,NULL,'4','2','S','400',NULL,'282','282','SalesReturn',0,'2026-02-17 11:06:14','2026-02-17 11:06:14'),(5,'165',NULL,NULL,'7','6','P','3270',NULL,'282','282','PurchaseReturn',1,'2026-02-17 12:11:00','2026-02-17 12:11:00'),(6,'165',NULL,NULL,'7','6','P','3000',NULL,'282','282','PurchaseReturn',1,'2026-02-17 12:15:43','2026-02-17 12:15:43'),(8,'165',NULL,NULL,'7','5','P','3000',NULL,'282','282','PurchaseReturn',1,'2026-02-17 12:49:19','2026-02-17 12:49:19'),(9,'165',NULL,NULL,'7','5','P','3000',NULL,'282','282','PurchaseReturn',0,'2026-02-17 12:51:17','2026-02-17 12:51:17'),(11,'165',NULL,NULL,'8','7','S','500',NULL,'282','282','SalesReturn',0,'2026-02-18 06:02:12','2026-02-18 06:02:12'),(12,'165',NULL,NULL,'10','9','S','5000',NULL,'282','282','SalesReturn',0,'2026-02-18 06:08:43','2026-02-18 06:08:43');
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REGISTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REMARKS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int DEFAULT '0',
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-02-17 10:32:45',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text,
  `MAC_ID` int DEFAULT '0',
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text,
  `S_ADD2` text,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'165',NULL,NULL,'p_Service_Tax',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:41','2026-02-17 10:58:41'),(2,'165',NULL,NULL,'p_SHE_Cess_On_GST',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:41','2026-02-17 10:58:41'),(3,'165',NULL,NULL,'p_SHE_Cess_On_Excise',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'3',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:41','2026-02-17 10:58:41'),(4,'165',NULL,NULL,'Water & Electricity Expenses',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'4',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:41','2026-02-17 10:58:41'),(5,'165',NULL,NULL,'Travelling Expenses',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:41','2026-02-17 10:58:41'),(6,'165',NULL,NULL,'Telephone Expenses',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'6',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:41','2026-02-17 10:58:41'),(7,'165',NULL,NULL,'Stock',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:41','2026-02-17 10:58:41'),(8,'165',NULL,NULL,'Sales Promotion Expenses',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'8',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:41','2026-02-17 10:58:41'),(9,'165',NULL,NULL,'Sales',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'9',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:41','2026-02-17 10:58:41'),(10,'165',NULL,NULL,'Salery & Bonus Payable',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'10',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:41','2026-02-17 10:58:41'),(11,'165',NULL,NULL,'Salery',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'11',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:42','2026-02-17 10:58:42'),(12,'165',NULL,NULL,'S_VAT',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'12',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:42','2026-02-17 10:58:42'),(13,'165',NULL,NULL,'S_Surcharge_On_VAT',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'13',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:42','2026-02-17 10:58:42'),(14,'165',NULL,NULL,'S_Service_Tax',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'14',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:42','2026-02-17 10:58:42'),(15,'165',NULL,NULL,'S_SHE_Cess_On_Service_Tax',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:42','2026-02-17 10:58:42'),(16,'165',NULL,NULL,'S_SHE_Cess_On_GST',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'16',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:42','2026-02-17 10:58:42'),(17,'165',NULL,NULL,'S_SHE_Cess_On_Excise',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'17',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:42','2026-02-17 10:58:42'),(18,'165',NULL,NULL,'S_SGST',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'18',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:42','2026-02-17 10:58:42'),(19,'165',NULL,NULL,'S_ROUND_OFF',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'19',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:42','2026-02-17 10:58:42'),(20,'165',NULL,NULL,'S_National_VAT',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'20',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:42','2026-02-17 10:58:42'),(21,'165',NULL,NULL,'S_LESS_AMT',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:43','2026-02-17 10:58:43'),(22,'165',NULL,NULL,'S_IGST',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'22',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:43','2026-02-17 10:58:43'),(23,'165',NULL,NULL,'S_Edu_Cess_On_Service_Tax',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'23',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:43','2026-02-17 10:58:43'),(24,'165',NULL,NULL,'S_Edu_Cess_On_GST',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'24',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:43','2026-02-17 10:58:43'),(25,'165',NULL,NULL,'S_Edu_Cess_On_Excise',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'25',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:43','2026-02-17 10:58:43'),(26,'165',NULL,NULL,'S_DISPLAY_AMT',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'26',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:43','2026-02-17 10:58:43'),(27,'165',NULL,NULL,'S_Central_Sales_Tax',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:43','2026-02-17 10:58:43'),(28,'165',NULL,NULL,'S_CGST',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'28',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:43','2026-02-17 10:58:43'),(29,'165',NULL,NULL,'S_CESS',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'29',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:43','2026-02-17 10:58:43'),(30,'165',NULL,NULL,'S_Additional_Tax(GST)',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'30',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:43','2026-02-17 10:58:43'),(31,'165',NULL,NULL,'S_Additional_CESS',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'31',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:44','2026-02-17 10:58:44'),(32,'165',NULL,NULL,'S_ADD_AMT',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'32',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:44','2026-02-17 10:58:44'),(33,'165',NULL,NULL,'SGST',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'33',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:44','2026-02-17 10:58:44'),(34,'165',NULL,NULL,'SCHEME-2',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'34',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:44','2026-02-17 10:58:44'),(35,'165',NULL,NULL,'SCHEME-1',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'35',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:44','2026-02-17 10:58:44'),(36,'165',NULL,NULL,'Rounded Off',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'36',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:44','2026-02-17 10:58:44'),(37,'165',NULL,NULL,'Replacement',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'37',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:44','2026-02-17 10:58:44'),(38,'165',NULL,NULL,'Rate Adjustment',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'38',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:44','2026-02-17 10:58:44'),(39,'165',NULL,NULL,'Purchase',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'39',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:44','2026-02-17 10:58:44'),(40,'165',NULL,NULL,'Profit & Loss',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'40',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:44','2026-02-17 10:58:44'),(41,'165',NULL,NULL,'Printing & Stationery',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'41',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:45','2026-02-17 10:58:45'),(42,'165',NULL,NULL,'Postal Expenses',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'42',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:45','2026-02-17 10:58:45'),(43,'165',NULL,NULL,'Plants & Machinery',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'43',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:45','2026-02-17 10:58:45'),(44,'165',NULL,NULL,'P_VAT',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'44',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:45','2026-02-17 10:58:45'),(45,'165',NULL,NULL,'P_Surcharge_On_VAT',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'45',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:45','2026-02-17 10:58:45'),(46,'165',NULL,NULL,'P_SHE_Cess_On_Service_Tax',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'46',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:45','2026-02-17 10:58:45'),(47,'165',NULL,NULL,'P_SGST',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'47',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:45','2026-02-17 10:58:45'),(48,'165',NULL,NULL,'P_ROUND_OFF',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'48',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:45','2026-02-17 10:58:45'),(49,'165',NULL,NULL,'P_National_VAT',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'49',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:45','2026-02-17 10:58:45'),(50,'165',NULL,NULL,'P_LESS_AMT',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'50',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:45','2026-02-17 10:58:45'),(51,'165',NULL,NULL,'P_IGST',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'51',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:46','2026-02-17 10:58:46'),(52,'165',NULL,NULL,'P_Edu_Cess_On_Service_Tax',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'52',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:46','2026-02-17 10:58:46'),(53,'165',NULL,NULL,'P_Edu_Cess_On_GST',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:46','2026-02-17 10:58:46'),(54,'165',NULL,NULL,'P_Edu_Cess_On_Excise',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'54',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:46','2026-02-17 10:58:46'),(55,'165',NULL,NULL,'P_Central_Sales_Tax',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'55',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:46','2026-02-17 10:58:46'),(56,'165',NULL,NULL,'P_CGST',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'56',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:46','2026-02-17 10:58:46'),(57,'165',NULL,NULL,'P_CESS',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'57',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:46','2026-02-17 10:58:46'),(58,'165',NULL,NULL,'P_Additional_Tax(GST)',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'58',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:46','2026-02-17 10:58:46'),(59,'165',NULL,NULL,'P_Additional_CESS',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'59',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:46','2026-02-17 10:58:46'),(60,'165',NULL,NULL,'P_ADD_AMT',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'60',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:46','2026-02-17 10:58:46'),(61,'165',NULL,NULL,'Office Rent',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'61',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:47','2026-02-17 10:58:47'),(62,'165',NULL,NULL,'Office Maintenance Expenses',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'62',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:47','2026-02-17 10:58:47'),(63,'165',NULL,NULL,'Office Equipments',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'63',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:47','2026-02-17 10:58:47'),(64,'165',NULL,NULL,'Office Charges',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'64',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:47','2026-02-17 10:58:47'),(65,'165',NULL,NULL,'Miscellaneous Expenses',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'65',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:47','2026-02-17 10:58:47'),(66,'165',NULL,NULL,'Misc. Charges',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'66',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:47','2026-02-17 10:58:47'),(67,'165',NULL,NULL,'Mall Khata A/c',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'67',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:47','2026-02-17 10:58:47'),(68,'165',NULL,NULL,'Legal Expenses',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'68',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:47','2026-02-17 10:58:47'),(69,'165',NULL,NULL,'Interstate B2b Sales',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'69',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:47','2026-02-17 10:58:47'),(70,'165',NULL,NULL,'Interest Payable A/c',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'70',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:47','2026-02-17 10:58:47'),(71,'165',NULL,NULL,'IGST',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'71',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:48','2026-02-17 10:58:48'),(72,'165',NULL,NULL,'Furnituer & Fixture',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'72',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:48','2026-02-17 10:58:48'),(73,'165',NULL,NULL,'Freight & Forwarding Charges',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'73',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:48','2026-02-17 10:58:48'),(74,'165',NULL,NULL,'Discount',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'74',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:48','2026-02-17 10:58:48'),(75,'165',NULL,NULL,'Development Taxes',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'75',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:48','2026-02-17 10:58:48'),(76,'165',NULL,NULL,'Depriciation A/c',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'76',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:48','2026-02-17 10:58:48'),(77,'165',NULL,NULL,'Conveyance Expenses',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'77',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:48','2026-02-17 10:58:48'),(78,'165',NULL,NULL,'Computers',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'78',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:48','2026-02-17 10:58:48'),(79,'165',NULL,NULL,'Commissions on Sales',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'79',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:48','2026-02-17 10:58:48'),(80,'165',NULL,NULL,'Charity & Donations',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'80',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:48','2026-02-17 10:58:48'),(81,'165',NULL,NULL,'Cash',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'81',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:49','2026-02-17 10:58:49'),(82,'165',NULL,NULL,'Capital Equipments',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'82',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:49','2026-02-17 10:58:49'),(83,'165',NULL,NULL,'CGST',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'83',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:49','2026-02-17 10:58:49'),(84,'165',NULL,NULL,'CESS',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'84',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:49','2026-02-17 10:58:49'),(85,'165',NULL,NULL,'C Form Sales',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'85',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:49','2026-02-17 10:58:49'),(86,'165',NULL,NULL,'C Form Purchase',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'86',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:49','2026-02-17 10:58:49'),(87,'165',NULL,NULL,'Brokerage',11,'0','DR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'87',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:49','2026-02-17 10:58:49'),(88,'165',NULL,NULL,'Bonus',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'88',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:49','2026-02-17 10:58:49'),(89,'165',NULL,NULL,'Bank Charges',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'89',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:49','2026-02-17 10:58:49'),(90,'165',NULL,NULL,'Bad Debts Written Off',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'90',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:49','2026-02-17 10:58:49'),(91,'165',NULL,NULL,'Additional Tax(GST)',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'91',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:50','2026-02-17 10:58:50'),(92,'165',NULL,NULL,'Additional CESS',11,'0','CR','DEFAULT','','','','',NULL,'','',NULL,'0','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'92',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:50','2026-02-17 10:58:50'),(93,'165',NULL,NULL,'AAREY 2161',5,'0','DR','MAHADA COLONY NEAR VAISHALI G STORE','DEFAULT','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'93',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:50','2026-02-17 10:58:50'),(94,'165',NULL,NULL,'AAREY 2065',5,'0','DR','NEAR RISHAB GENERAL STORE DEVIDAYAL GARDEN MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'94',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:50','2026-02-17 10:58:50'),(95,'165',NULL,NULL,'AAREY 166',5,'0','DR','NEAR M.G.RAD STATION','DEFAULT','MUMBAI','21','',NULL,'9137679306.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'95',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:50','2026-02-17 10:58:50'),(96,'165',NULL,NULL,'AAREY 1609',5,'0','DR','NEAR A H SUPARIWALA MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'8879172392.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'96',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:50','2026-02-17 10:58:50'),(97,'165',NULL,NULL,'AAREY 01',5,'0','DR','NEAR MULUND RAILWAY STATION','DEFAULT','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'97',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:50','2026-02-17 10:58:50'),(98,'165',NULL,NULL,'AARE 2505',5,'0','DR','NEAR B M C OFFICE','DEFAULT','MUMBAI','21','',NULL,'9137784338.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'98',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:50','2026-02-17 10:58:50'),(99,'165',NULL,NULL,'AARE 2339',5,'0','DR','S L ROAD MULUND NEAR JAI AMBE SNACKS','DEFAULT','MUMBAI','21','',NULL,'8356961186.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'99',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:50','2026-02-17 10:58:50'),(100,'165',NULL,NULL,'AARE 2337',5,'0','DR','L B S ROAD , DAGNGAR PADA','CNG PETROLPUMP','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'100',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:50','2026-02-17 10:58:50'),(101,'165',NULL,NULL,'AARE 2221',5,'0','DR','P K RAOD OPP ARIHANT STORE 5 RASTA','DEFAULT','MUMBAI','21','',NULL,'9076727975.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'101',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:51','2026-02-17 10:58:51'),(102,'165',NULL,NULL,'AARE 167',5,'0','DR','5 RASTA , OPP AUTAL ELECTRONIC','DEFAULT','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'102',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:51','2026-02-17 10:58:51'),(103,'165',NULL,NULL,'AAKASH KIRANA STORE',5,'0','DR','MHADA COLONY, PLOT NO.30, MULUND EAST','DEFAULT','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'103',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:51','2026-02-17 10:58:51'),(104,'165',NULL,NULL,'AAI RAMDHANI STORE',5,'0','DR','MULUND EAST 90FEET ROAD','DEFAULT','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'104',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:51','2026-02-17 10:58:51'),(105,'165',NULL,NULL,'AADHI GANESH STORES',5,'0','DR','J N ROAD, MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'9820374775.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'105',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:51','2026-02-17 10:58:51'),(106,'165',NULL,NULL,'AADHAR MART',5,'0','DR','VAISHALI NAGAR MULUND W','DEFAULT','MUMBAI','21','',NULL,'9876543210.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'106',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:51','2026-02-17 10:58:51'),(107,'165',NULL,NULL,'AADHAR FOOD',5,'0','DR','VAISHALI NAGAR, MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'9321668830.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'107',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:51','2026-02-17 10:58:51'),(108,'165',NULL,NULL,'A1 SUPERSTORE',5,'0','DR','VEENA NAGAR, NEAR HARIYA SUPERMARKET, MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'9517378745.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'108',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:51','2026-02-17 10:58:51'),(109,'165',NULL,NULL,'A1 STORE',5,'0','DR','MULUND EAST','DEFAULT','MUMBAI','21','',NULL,'9876543201.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'109',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:51','2026-02-17 10:58:51'),(110,'165',NULL,NULL,'A-1 SUPERMARKET',5,'0','DR','MHADA COLONY, MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'110',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:51','2026-02-17 10:58:51'),(111,'165',NULL,NULL,'A-1 GENERAL STORE',5,'0','DR','KHINDIPADA NEAR SUNANDA G STORE','MULUN COLONY W','MUMBAI','21','',NULL,'9876543210.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'111',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:52','2026-02-17 10:58:52'),(112,'165',NULL,NULL,'A V STORE',5,'0','DR','NEAR RUPMANE CLASSES, OPPOSITE PADVATI STORE, KHINDIPADA, MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'112',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:52','2026-02-17 10:58:52'),(113,'165',NULL,NULL,'A V GENERAL STORE',5,'0','DR','KHINDI PADA','DEFAULT','MUMBAI','21','',NULL,'8356961186.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'113',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:52','2026-02-17 10:58:52'),(114,'165',NULL,NULL,'A TO Z STORE',5,'0','DR','NEELAM NAGAR, NEAR SHATAYU MEDICAL, MULUND EAST','DEFAULT','MUMBAI','21','',NULL,'8850516138.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'114',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:52','2026-02-17 10:58:52'),(115,'165',NULL,NULL,'A ONE SUPER STORE',5,'0','DR','VEENA NAGAR','DEFAULT','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'115',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:52','2026-02-17 10:58:52'),(116,'165',NULL,NULL,'A ONE KIRANA STORE',5,'0','DR','SONAPUR','DEFAULT','MUMBAI','21','',NULL,'9930160805.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'116',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:52','2026-02-17 10:58:52'),(117,'165',NULL,NULL,'A ONE ENTERPRISES',5,'0','DR','MAHAGIRI MARTET THANE(W)','DEFAULT','MUMBAI','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'117',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:52','2026-02-17 10:58:52'),(118,'165',NULL,NULL,'A M SOAP CENTRE',5,'0','DR','MULUND COLONY, MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'9372085600.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'118',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:52','2026-02-17 10:58:52'),(119,'165',NULL,NULL,'A H SUPARIWALA',5,'0','DR','GANESH GAWDE ROAD, MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'9892462800.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'119',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:52','2026-02-17 10:58:52'),(120,'165',NULL,NULL,'A C GUPTA STORE',5,'0','DR','DUMPING ROAD, NEAR SIGNAL, MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'9876543210.0','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'120',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:52','2026-02-17 10:58:52'),(121,'165',NULL,NULL,'A B KIRANA STORES',5,'0','DR','NEXT TO EKVIRA GENERAL STORE, GANESH MANDIR, KHINDIPADA, MULUND WEST','DEFAULT','MUMBAI','21','',NULL,'9876543210.0','',NULL,'27','27DCPPS2397Q1ZA','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'121',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:53','2026-02-17 10:58:53'),(122,'165',NULL,NULL,'A 1 STORE',5,'0','DR','GAWANPADA, MULUND EAST','DEFAULT','MUMBAI','21','',NULL,'9726019722.0','',NULL,'27','27AKXPM1033A1ZC','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'122',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'0','0',NULL,0,'2026-02-17 10:58:53','2026-02-17 10:58:53'),(123,'165',NULL,NULL,'DEEPAK ENTERPRISES',11,'0.00','CR',NULL,NULL,NULL,NULL,NULL,NULL,'9898989898',NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,'123',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'282','282',NULL,0,'2026-02-17 10:59:11','2026-02-17 10:59:11'),(124,'165',NULL,NULL,'HALDIRAM FOODS PVT LTD.',11,'0','CR','MULUND','','','21','','','0000000000','','','27','27DHWPG7105L1ZR','','','','','','1','','0','1',NULL,'124',NULL,'','','','','','','','','1','','',0,NULL,0,NULL,NULL,'0','','0','','0.00','GST','0','0','','0','0',NULL,'282','282',NULL,0,'2026-02-17 12:45:02','2026-02-17 12:45:02'),(125,'165',NULL,NULL,'DK ENTERPRISES',11,'0','CR','MULUND','','','12','','','0000000000','','','24','','','','','','','1','','0','1',NULL,'125',NULL,'','','','','','','','','1','','',0,NULL,0,NULL,NULL,'0','','0','','0.00','GST','0','0','1','1','0',NULL,'282','282',NULL,0,'2026-02-17 11:19:51','2026-02-17 11:19:51');
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int NOT NULL DEFAULT '0',
  `ADDRESS1` text,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `REMOTE_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `PG_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` int DEFAULT '0',
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
INSERT INTO `SALES` VALUES (1,'165',NULL,NULL,'2026-02-17',3,1,'1','',122,NULL,'Imported','00001',0,'','0','',0,'0','0','32550.1','10117.394','0','0.00','2243.271','4146.31','1036.58','1036.58','0','0.00','0.00','0.00','24336','24335.75','10000','0','16043.13',NULL,'0.00','0','0.00',NULL,'0.00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0.00','0','0',NULL,'Y','282','282',NULL,0,0,'2026-02-17 10:59:25','2026-02-17 10:59:25'),(2,'165',NULL,NULL,'2026-02-17',3,1,'','',121,NULL,'Imported','00002',0,'','0','',0,'0','0','32550.1','6003.17','0','0.00','2654.693','5627.43','1406.86','1406.86','0','0.00','0.00','0.00','29520','29519.67','10000','0','18264.81',NULL,'0.00','0','0.00',NULL,'0.00',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0.00','0','0',NULL,'Y','282','282',NULL,0,0,'2026-02-17 10:59:25','2026-02-17 10:59:25'),(3,'165',NULL,NULL,'2026-02-17',3,1,'','',122,'GAWANPADA, MULUND EAST DEFAULT MUMBAI 27AKXPM1033A1ZC ',NULL,'SR000001',0,'SR','000001','',0,'8','6','3255.01','0','0','0','0','744.95','372.475','372.475','0','0','0','+0.04','4000','3999.96','5/364','20400.00','3255.01','','0.00','0','0',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,0,'1',NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','0','0',NULL,0,0,'2026-02-17 11:04:23','2026-02-17 11:04:23'),(4,'165',NULL,NULL,'2026-02-17',3,1,'','',121,'NEXT TO EKVIRA GENERAL STORE, GANESH MANDIR, KHINDIPADA, MULUND WEST DEFAULT MUMBAI 27DCPPS2397Q1ZA ',NULL,'SR000002',0,'SR','000002','',0,'8','6','0','0','0','0','0','74.48','37.24','37.24','0','0','0','+0.02','400','399.98','0/0','0','325.5','','0.00','325.50','0',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,0,'1',NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','0','0',NULL,0,0,'2026-02-17 11:06:14','2026-02-17 11:06:14'),(5,'165',NULL,NULL,'2026-02-18',3,1,'','',122,'GAWANPADA, MULUND EAST DEFAULT MUMBAI 27AKXPM1033A1ZC ',NULL,'S0000001',1,'S','0000001','',0,'8','7','3255.01','0','0','0','0','744.95','372.475','372.475','0','0','0','+0.04','4000','3999.96','5/364','20400.00','3255.01','','0.00','0','0',NULL,'0',NULL,NULL,'',NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','282','282',NULL,0,0,'2026-02-17 12:42:36','2026-02-17 12:42:36'),(6,'165',NULL,NULL,'2026-02-18',3,1,'','',120,'DUMPING ROAD, NEAR SIGNAL, MULUND WEST DEFAULT MUMBAI  ',NULL,'S0000002',2,'S','0000002','',0,'8','7','571.42','0','0','0','0','228.57','114.285','114.285','0','0','0','+0.01','800','799.99','1/44','2200.00','571.42','','0.00','0','0',NULL,'0',NULL,NULL,'',NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','282','282',NULL,0,0,'2026-02-17 12:43:01','2026-02-17 12:43:01'),(7,'165',NULL,NULL,'2026-02-19',3,1,'','',119,'GANESH GAWDE ROAD, MULUND WEST DEFAULT MUMBAI  ',NULL,'S0000003',3,'S','0000003','',0,'8','7','952.38','0','0','0','0','47.62','23.81','23.81','0','0','0','0','1000','1000.00','200/0','5000.00','952.38','','0.00','0','0',NULL,'0',NULL,NULL,'',NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','282','282',NULL,0,0,'2026-02-18 06:01:36','2026-02-18 06:01:44'),(8,'165',NULL,NULL,'2026-02-19',3,1,'','',119,'GANESH GAWDE ROAD, MULUND WEST DEFAULT MUMBAI  ',NULL,'SR000003',0,'SR','000003','',0,'8','6','476.19','0','0','0','0','23.81','11.905','11.905','0','0','0','0','500','500.00','0/100','2500.00','476.19','','0.00','0','0',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,0,'1',NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','0','0',NULL,0,0,'2026-02-18 06:02:12','2026-02-18 06:02:12'),(9,'165',NULL,NULL,'2026-02-19',3,1,'','',122,'GAWANPADA, MULUND EAST DEFAULT MUMBAI 27AKXPM1033A1ZC ',NULL,'S0000004',4,'S','0000004','',0,'8','7','8928.6','0','0','0','0','1071.43','535.715','535.715','0','0','0','-0.03','10000','10000.03','1000/0','30000.00','8928.6','','0.00','0','0',NULL,'0',NULL,NULL,'',NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','282','282',NULL,0,0,'2026-02-18 06:06:55','2026-02-18 06:08:17'),(10,'165',NULL,NULL,'2026-02-19',3,1,'','',122,'GAWANPADA, MULUND EAST DEFAULT MUMBAI 27AKXPM1033A1ZC ',NULL,'SR000004',0,'SR','000004','',0,'8','6','4464.3','0','0','0','0','535.72','267.86','267.86','0','0','0','-0.02','5000','5000.02','4/68','15000.00','4464.3','','0.00','0','0',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',0,0,'1',NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','0','0',NULL,0,0,'2026-02-18 06:08:43','2026-02-18 06:08:43');
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `INV_ARR` text,
  `INV_NO` text,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
INSERT INTO `SALES_ITEM` VALUES (1,'165','',NULL,1,1,1,7,'3.8095',3.5437,0,'5','2.5','2.5','0.00','0','0',108,'Imported','9.2593','1000','0','342.855',NULL,NULL,'0',0,'10','380.95','0.00','0.00','3809.5',0.0000,0.0000,'154.28475','77.142375','77.142375','0.00',0,'0',0,'0.00','0',NULL,'0','0',0,'5',NULL,'25',7,'0','0','','0',0,'0.00',NULL,'0',NULL,'0.00','0.00',NULL,'Y',NULL,NULL,'282','282',NULL,0,'2026-02-17 10:59:25','2026-02-17 10:59:25'),(2,'165','',NULL,2,2,1,7,'3.5714',3.5437,0,'12','6','6','0.00','0','0',108,'Imported','18.5185','2000','0','571.424',NULL,NULL,'0',0,'20','1428.56','0.00','0.00','7142.8',0.0000,0.0000,'617.13792','308.56896','308.56896','0.00',0,'0',0,'0.00','0',NULL,'0','0',0,'5',NULL,'30',7,'0','0','','0',0,'0.00',NULL,'0',NULL,'0.00','0.00',NULL,'Y',NULL,NULL,'282','282',NULL,0,'2026-02-17 10:59:25','2026-02-17 10:59:25'),(3,'165','',NULL,3,3,1,7,'3.3898',3.5437,0,'18','9','9','0.00','0','0',108,'Imported','27.7778','3000','0','711.858',NULL,NULL,'0',0,'30','3050.82','0.00','0.00','10169.4',0.0000,0.0000,'1153.20996','576.60498','576.60498','0.00',0,'0',0,'0.00','0',NULL,'0','0',0,'5',NULL,'25',7,'0','0','','0',0,'0.00',NULL,'0',NULL,'0.00','0.00',NULL,'Y',NULL,NULL,'282','282',NULL,0,'2026-02-17 10:59:25','2026-02-17 10:59:25'),(4,'165','',NULL,4,4,1,7,'2.8571',3.5437,0,'40','20','20','0.00','0','0',156,'Imported','25.641','4000','0','617.1336',NULL,NULL,'0',0,'50','5257.064','0.00','0.00','11428.4',0.0000,0.0000,'2221.68096','1110.84048','1110.84048','0.00',0,'0',0,'0.00','0',NULL,'0','0',0,'5',NULL,'11',7,'0','0','','0',0,'0.00',NULL,'0',NULL,'0.00','0.00',NULL,'Y',NULL,NULL,'282','282',NULL,0,'2026-02-17 10:59:25','2026-02-17 10:59:25'),(8,'165','',NULL,1,1,2,7,'3.8095',3.5437,0,'5','2.5','2.5','0.00','0','0',108,'Imported','9.2593','1000','0','342.855',NULL,NULL,'0',0,'10','380.95','0.00','0.00','3809.5',0.0000,0.0000,'154.28475','77.142375','77.142375','0.00',0,'0',0,'0.00','0',NULL,'0','0',0,'5',NULL,'25',7,'0','0','','0',0,'0.00',NULL,'0',NULL,'0.00','0.00',NULL,'Y',NULL,NULL,'282','282',NULL,0,'2026-02-17 10:59:25','2026-02-17 10:59:25'),(9,'165','',NULL,2,2,2,7,'3.5714',3.5437,0,'12','6','6','0.00','0','0',108,'Imported','18.5185','2000','0','571.424',NULL,NULL,'0',0,'20','1428.56','0.00','0.00','7142.8',0.0000,0.0000,'617.13792','308.56896','308.56896','0.00',0,'0',0,'0.00','0',NULL,'0','0',0,'5',NULL,'30',7,'0','0','','0',0,'0.00',NULL,'0',NULL,'0.00','0.00',NULL,'Y',NULL,NULL,'282','282',NULL,0,'2026-02-17 10:59:25','2026-02-17 10:59:25'),(10,'165','',NULL,3,3,2,7,'3.3898',3.5437,0,'18','9','9','0.00','0','0',108,'Imported','27.7778','3000','0','711.858',NULL,NULL,'0',0,'30','3050.82','0.00','0.00','10169.4',0.0000,0.0000,'1153.20996','576.60498','576.60498','0.00',0,'0',0,'0.00','0',NULL,'0','0',0,'5',NULL,'25',7,'0','0','','0',0,'0.00',NULL,'0',NULL,'0.00','0.00',NULL,'Y',NULL,NULL,'282','282',NULL,0,'2026-02-17 10:59:25','2026-02-17 10:59:25'),(11,'165','',NULL,4,4,2,7,'2.8571',3.5437,0,'40','20','20','0.00','0','0',156,'Imported','25.641','4000','0','1028.556',NULL,NULL,'0',0,'10','1142.84','0.00','0.00','11428.4',0.0000,0.0000,'3702.8016','1851.4008','1851.4008','0.00',0,'0',0,'0.00','0',NULL,'0','0',0,'5',NULL,'11',7,'0','0','','0',0,'0.00',NULL,'0',NULL,'0.00','0.00',NULL,'Y',NULL,NULL,'282','282',NULL,0,'2026-02-17 10:59:25','2026-02-17 10:59:25'),(15,'165',NULL,NULL,3,3,3,7,'4',0.0000,0,'18.00','9','9','0','0','0',1,NULL,'2.78','300','0','0',NULL,NULL,'0',0,'0','0','0','0','1016.94',0.0000,0.0000,'183.05','91.525','91.525','0',0,'0',0,'0','1',NULL,'','',0,'5',NULL,'25',7,'7','3.3898','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 11:04:23','2026-02-17 11:04:23'),(16,'165',NULL,NULL,4,4,3,7,'4',0.0000,0,'40.00','20','20','0','0','0',1,NULL,'2.56','400','0','0',NULL,NULL,'0',0,'0','0','0','0','1142.84',0.0000,0.0000,'457.14','228.57','228.57','0',0,'0',0,'0','1',NULL,'','',0,'5',NULL,'11',7,'7','2.8571','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 11:04:23','2026-02-17 11:04:23'),(17,'165',NULL,NULL,1,1,3,7,'4',0.0000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'0.93','100','0','0',NULL,NULL,'0',0,'0','0','0','0','380.95',0.0000,0.0000,'19.05','9.525','9.525','0',0,'0',0,'0','1',NULL,'','',0,'5',NULL,'25',7,'7','3.8095','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 11:04:23','2026-02-17 11:04:23'),(18,'165',NULL,NULL,2,2,3,7,'4',0.0000,0,'12.00','6','6','0','0','0',1,NULL,'1.85','200','0','0',NULL,NULL,'0',0,'0','0','0','0','714.28',0.0000,0.0000,'85.71','42.855','42.855','0',0,'0',0,'0','1',NULL,'','',0,'5',NULL,'30',7,'7','3.5714','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 11:04:23','2026-02-17 11:04:23'),(19,'165',NULL,NULL,4,4,4,7,'4',0.0000,0,'40.00','20','20','0','0','0',1,NULL,'0','0','0','0.00',NULL,NULL,'0',0,'0','0','0','0','0',0.0000,0.0000,'45.71','22.855','22.855','0',40,'114.28399999999999',0,'0','1',NULL,'','',0,'5',NULL,'11',7,'7','2.8571','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 11:06:14','2026-02-17 11:06:14'),(20,'165',NULL,NULL,3,3,4,7,'4',0.0000,0,'18.00','9','9','0','0','0',1,NULL,'0','0','0','0.00',NULL,NULL,'0',0,'0','0','0','0','0',0.0000,0.0000,'18.30','9.15','9.15','0',30,'101.694',0,'0','1',NULL,'','',0,'5',NULL,'25',7,'7','3.3898','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 11:06:14','2026-02-17 11:06:14'),(21,'165',NULL,NULL,2,2,4,7,'4',0.0000,0,'12.00','6','6','0','0','0',1,NULL,'0','0','0','0.00',NULL,NULL,'0',0,'0','0','0','0','0',0.0000,0.0000,'8.57','4.285','4.285','0',20,'71.428',0,'0','1',NULL,'','',0,'5',NULL,'30',7,'7','3.5714','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 11:06:14','2026-02-17 11:06:14'),(22,'165',NULL,NULL,1,1,4,7,'4',0.0000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'0','0','0','0.00',NULL,NULL,'0',0,'0','0','0','0','0',0.0000,0.0000,'1.90','0.95','0.95','0',10,'38.095',0,'0','1',NULL,'','',0,'5',NULL,'25',7,'7','3.8095','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 11:06:14','2026-02-17 11:06:14'),(23,'165',NULL,NULL,4,4,5,7,'4',0.0000,0,'40.00','20','20','0','0','0',1,NULL,'2.56','400','0','0',NULL,NULL,'0',0,'0','0','0','0','1142.84',0.0000,0.0000,'457.14','228.57','228.57','0',0,'0',0,'0',NULL,NULL,'','',0,'5',NULL,'11',7,'7','2.8571','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 12:42:37','2026-02-17 12:42:37'),(24,'165',NULL,NULL,3,3,5,7,'4',0.0000,0,'18.00','9','9','0','0','0',1,NULL,'2.78','300','0','0',NULL,NULL,'0',0,'0','0','0','0','1016.94',0.0000,0.0000,'183.05','91.525','91.525','0',0,'0',0,'0',NULL,NULL,'','',0,'5',NULL,'25',7,'7','3.3898','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 12:42:37','2026-02-17 12:42:37'),(25,'165',NULL,NULL,1,1,5,7,'4',0.0000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'0.93','100','0','0',NULL,NULL,'0',0,'0','0','0','0','380.9524',0.0000,0.0000,'19.05','9.525','9.525','0',0,'0',0,'0',NULL,NULL,'','',0,'380.9500',NULL,'25',7,'7','3.8095','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 12:42:37','2026-02-17 12:42:37'),(26,'165',NULL,NULL,2,2,5,7,'4',0.0000,0,'12.00','6','6','0','0','0',1,NULL,'1.85','200','0','0',NULL,NULL,'0',0,'0','0','0','0','714.28',0.0000,0.0000,'85.71','42.855','42.855','0',0,'0',0,'0',NULL,NULL,'','',0,'5',NULL,'30',7,'7','3.5714','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 12:42:37','2026-02-17 12:42:37'),(27,'165',NULL,NULL,4,4,6,7,'4',0.0000,0,'40.00','20','20','0','0','0',1,NULL,'1.28','200','0','0',NULL,NULL,'0',0,'0','0','0','0','571.42',0.0000,0.0000,'228.57','114.285','114.285','0',0,'0',0,'0',NULL,NULL,'','',0,'5',NULL,'11',7,'7','2.8571','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-17 12:43:01','2026-02-17 12:43:01'),(28,'165',NULL,NULL,1,1,7,7,'5',0.0000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'1.85','200','0','0',NULL,NULL,'0',0,'0','0','0','0','952.38',0.0000,0.0000,'47.62','23.81','23.81','0',0,'0',0,'0',NULL,NULL,'','',0,'5',NULL,'25',7,'7','4.7619','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,1,'2026-02-18 06:01:36','2026-02-18 06:01:36'),(29,'165',NULL,NULL,1,1,7,7,'5',0.0000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'1.85','200','0','0',NULL,NULL,'0',0,'0','0','0','0','952.38',0.0000,0.0000,'47.62','23.81','23.81','0',0,'0',0,'0',NULL,NULL,'','',0,'5',NULL,'25',7,'7','4.7619','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-18 06:01:44','2026-02-18 06:01:44'),(30,'165',NULL,NULL,1,1,8,7,'5',0.0000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'0.93','100','0','0',NULL,NULL,'0',0,'0','0','0','0','476.19',0.0000,0.0000,'23.81','11.905','11.905','0',0,'0',0,'0','1',NULL,'','',0,'5',NULL,'25',7,'7','4.7619','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-18 06:02:12','2026-02-18 06:02:12'),(31,'165',NULL,NULL,2,2,9,7,'10',0.0000,0,'12.00','6','6','0','0','0',1,NULL,'9.26','1000','0','0',NULL,NULL,'0',0,'0','0','0','0','8928.60',0.0000,0.0000,'1071.43','535.715','535.715','0',0,'0',0,'0',NULL,NULL,'','',0,'5',NULL,'30',7,'7','8.9286','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,1,'2026-02-18 06:06:55','2026-02-18 06:06:55'),(32,'165',NULL,NULL,2,2,9,7,'10',0.0000,0,'12.00','6','6','0','0','0',1,NULL,'9.26','1000','0','0',NULL,NULL,'0',0,'0','0','0','0','8928.60',0.0000,0.0000,'1071.43','535.715','535.715','0',0,'0',0,'0',NULL,NULL,'','',0,'5',NULL,'30',7,'7','8.9286','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-18 06:08:17','2026-02-18 06:08:17'),(33,'165',NULL,NULL,2,2,10,7,'10',0.0000,0,'12.00','6','6','0','0','0',1,NULL,'4.63','500','0','0',NULL,NULL,'0',0,'0','0','0','0','4464.30',0.0000,0.0000,'535.72','267.86','267.86','0',0,'0',0,'0','1',NULL,'','',0,'5',NULL,'30',7,'7','8.9286','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'282','282',NULL,0,'2026-02-18 06:08:43','2026-02-18 06:08:43');
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LITE_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `WEB_ID` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_ID` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_ID` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_UNIT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_RATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_PACK` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PACK` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_PERCENT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN_QTY` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FREE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AMT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_AMT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROFIT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REPLACE` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SR_NO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `WEIGHT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_UNIT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PRICE_PER` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DMG_MRP` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REMARK` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_ARR` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_NO` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_BY` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UPDATED_BY` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SECURITY_KEY` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AREA` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_DATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_MAN` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_CODE` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GROUP_ID` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PARTY_CODE` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FINAL_AMT` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BATCH_NO` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `MFG_DATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `EXP_DATE` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int DEFAULT '0',
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int DEFAULT '0',
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int DEFAULT '0',
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SMAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
INSERT INTO `SMAN` VALUES (1,NULL,NULL,'Deepak-1234567890','Deepak-1234567890',NULL,NULL,'165',NULL,'282','282',NULL,0,'2026-02-17 10:59:25','2026-02-17 10:59:25');
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYNC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text,
  `UPDATED_VALUE` text,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text,
  `DIACM` text,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int DEFAULT '0',
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int DEFAULT '0',
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-02-17 10:32:45','2026-02-17 10:32:45');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UOM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int DEFAULT '0',
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
INSERT INTO `USER_PREF` VALUES (1,'165',NULL,NULL,'SalesZeroStock','1',282,NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:03:22','2026-02-17 11:03:22'),(2,'165',NULL,NULL,'SalesReverseCalculation','1',282,NULL,NULL,NULL,'282','282',NULL,0,'2026-02-17 11:03:22','2026-02-17 11:03:22');
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `WEB_ID` int NOT NULL DEFAULT '0',
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-02-17 10:32:46');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-01 21:00:06
