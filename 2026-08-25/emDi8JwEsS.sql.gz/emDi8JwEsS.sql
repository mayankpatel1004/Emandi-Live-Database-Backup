-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: emDi8JwEsS
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `emDi8JwEsS`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `emDi8JwEsS` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `emDi8JwEsS`;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AREA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
INSERT INTO `AREA` VALUES (1,'303',NULL,NULL,'4','NEW MUMBAI','4_NEW MUMBAI','484','484',NULL,484,0,'2026-08-25 12:15:05','2026-08-25 12:15:05'),(2,'303',NULL,NULL,'10','DOMBIVALI','10_DOMBIVALI','484','484',NULL,484,0,'2026-08-25 12:15:05','2026-08-25 12:15:05'),(3,'303',NULL,NULL,'9','VASIND','9_VASIND','484','484',NULL,484,0,'2026-08-25 12:15:05','2026-08-25 12:15:05'),(4,'303',NULL,NULL,'8','KASARA','8_KASARA','484','484',NULL,484,0,'2026-08-25 12:15:05','2026-08-25 12:15:05'),(5,'303',NULL,NULL,'5','SHAHAPUR','5_SHAHAPUR','484','484',NULL,484,0,'2026-08-25 12:15:05','2026-08-25 12:15:05'),(6,'303',NULL,NULL,'7','KINHVALI','7_KINHVALI','484','484',NULL,484,0,'2026-08-25 12:15:05','2026-08-25 12:15:05'),(7,'303',NULL,NULL,'3','1','3_1','484','484',NULL,484,0,'2026-08-25 12:15:05','2026-08-25 12:15:05'),(8,'303',NULL,NULL,'6','KALYAN','6_KALYAN','484','484',NULL,484,0,'2026-08-25 12:15:05','2026-08-25 12:15:05');
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CONFIG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text,
  `MASTER` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'303','0','emDi8JwEsS',303,'','','','2026-08-25 12:07:00','2026-08-25 12:07:00','','','','','','','','','2026-08-25 12:07:00','484','484','',0,'2026-08-25 12:07:00','2026-08-25 12:07:00');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` varchar(255) DEFAULT 'No',
  `REGION_NAME` varchar(255) DEFAULT '',
  `SITE_CODE` varchar(255) DEFAULT '',
  `SITE_NAME` varchar(255) DEFAULT '',
  `DISTRIBUTOR_TYPE` varchar(255) DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=304 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (303,NULL,NULL,NULL,'SAMARTH ENTERPRISES','2026-04-01','2027-03-31','SHOP NO-1, DATTA NIWAS CHAWAL,KUMBARKHAN','PADA OPP SAI AAI BANGLOW DOBIVALI WEST-421202','DOMBIVALI','21','7774854111','9168818910','','','','','','','','','','','','','',NULL,'0',NULL,NULL,'27','27BWPPD8234D2ZG','','samarth@yopmail.com','','ramesh',NULL,'1',NULL,'No','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-08-25 12:07:00','2026-08-25 12:07:00',NULL,'','','Samarth','Yes','','','','');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `CREATED_TS` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `BATCH_ID` int DEFAULT '0',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DISP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISTRIBUTORS_IMPORT`
--

DROP TABLE IF EXISTS `DISTRIBUTORS_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DISTRIBUTORS_IMPORT` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NEW_COMPANY_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DB_CREATED` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `NEW_DB_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `UNIT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `COMP_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `COMP_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EMAIL_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PASSWORD` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLONE_TYPE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `START_DATE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `END_DATE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SITE_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SITE_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISTRIBUTOR_TYPE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DEALS_WITH` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'No',
  `WEB_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `IS_ACTIVE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Yes',
  `ADD1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REGION_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CITY` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PINCODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `MOBILE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISTRIBUTOR_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AREA` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Default Area',
  `MAC_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '5',
  `CUSTOMER_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SAC_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `CUSTOMER_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AREA_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `GSTIN_NO` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PAN_NO` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SALON_GROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROSPECT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CUSTOMERCODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CHANNEL_TYPE_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TIER` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PSR_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `PSR_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PSR_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REPORTING_MNGR_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `REPORTING_MNGR_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REPORTING_MNGR_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TRAINER_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `TRAINER_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TRAINER_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TECH_LEAD` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROMOGROUPCODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROMOGROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `VENDOR` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SM_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SALES_MAN` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ACTIVE_STATUS` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Yes',
  `HSN_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PARENT_PRODUCT_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_DIVISION` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_GROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODM_GROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_CATEGORY` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_CATEGORY_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_BRAND` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_BRANDFORM` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_SUBBRANDFORM` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DFU` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RLP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `MRP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RETAILING` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REFERENCE_NO` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `INVOICE_DATE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Sales',
  `SALONGROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GROSS_TOTAL` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNTTOCLAIM` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNTGROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SEC_DISCOUNT_VALUE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SCHEME_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SCHEME_VALUE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAXABLE_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX1_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX1_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX2_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX2_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX3_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX3_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX4_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX4_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX5_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX5_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX6_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX6_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX1_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX2_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX3_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX4_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX5_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX6_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NET_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REMARKS` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `INVOICE_QTY` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GROSS_VALUE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNT_VALUE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNT_TO_CLAIM` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNT_GROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `MONTH` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `MONTH_YEAR` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROMO_GROUP_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROMO_GROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISTRIBUTORS_IMPORT`
--

LOCK TABLES `DISTRIBUTORS_IMPORT` WRITE;
/*!40000 ALTER TABLE `DISTRIBUTORS_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISTRIBUTORS_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `DELETED` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int DEFAULT '0',
  `TAX_ID` int DEFAULT '0',
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `CONFIG_UNIT` varchar(255) DEFAULT 'mm',
  `DISPLAY_STATUS` varchar(255) DEFAULT 'Y',
  `SELECT_OPTIONS` int NOT NULL DEFAULT '0',
  `GROUP_ID` int NOT NULL DEFAULT '0',
  `DISPLAY_ORDER` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'Printpage_Top_Margin','10','mm','Y',0,1,0),(2,'Printpage_Border','0','px','Y',0,1,0),(3,'Top_Center_Width','100','mm','Y',0,2,0),(4,'Item_Listing_Padding_Top','0','mm','Y',0,3,0),(5,'List_1','47','mm','Y',0,3,0),(6,'List_3','35','mm','Y',0,3,0),(7,'List_5','23','mm','Y',0,3,0),(8,'List_7','5','mm','Y',0,3,0),(9,'List_9','25','mm','Y',0,3,0),(10,'List_11','20','mm','Y',0,3,0),(11,'Blank_Space_Top_Padding','2','mm','Y',0,4,0),(12,'Footer_1','17','mm','Y',0,4,0),(13,'Footer_3','21','mm','Y',0,4,0),(14,'Footer_5','24','mm','Y',0,4,0),(15,'Footer_7','21','mm','Y',0,4,0),(16,'Footer_9','25','mm','Y',0,4,0);
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INV_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'303',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'303',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'303',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'303',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'303',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'303',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'303',NULL,NULL,'1','','S','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LEDGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `MAC_ID` int DEFAULT '0',
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int DEFAULT '0',
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int DEFAULT '0',
  `ROOT_PARENT_ID` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(14,'1',NULL,'1','UPI','UPI','bank','1','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text,
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `SAC_ID` int NOT NULL DEFAULT '0',
  `REMOTE_ID` int NOT NULL DEFAULT '0',
  `PENDING_AMT` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `PROD_ID` int NOT NULL DEFAULT '0',
  `PACK` int NOT NULL DEFAULT '0',
  `PROD_BATCH_ID` int NOT NULL DEFAULT '0',
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int NOT NULL DEFAULT '0',
  `PUR_RET_QTY` int NOT NULL DEFAULT '0',
  `PUR_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `PUR_TOTAL` int NOT NULL DEFAULT '0',
  `SALE_QTY` int DEFAULT '0',
  `SALE_RET_QTY` int DEFAULT '0',
  `SALE_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `SALE_TOTAL` int NOT NULL DEFAULT '0',
  `OP_STOCK` int NOT NULL DEFAULT '0',
  `CLOSING_STOCK` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
INSERT INTO `OP_CL_STOCK` VALUES (1,303,151,0,151,'2026-08-25',20,0,100,0,0,0,0,0,0,0),(2,303,151,0,151,'2026-08-01',20,0,0,0,0,0,0,0,100,0),(3,303,2,0,2,'2026-08-25',12,0,0,0,0,0,0,0,0,0),(4,303,4,0,4,'2026-08-25',0,0,12,0,0,0,0,0,0,0),(5,303,5,0,5,'2026-08-25',12,0,0,0,0,0,0,0,0,0),(6,303,1,0,1,'2026-08-25',0,0,12,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MINIMUM_STOCK_LEVEL` int NOT NULL DEFAULT '0',
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `PARENT_PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DIVISION` varchar(255) DEFAULT NULL,
  `DFU` varchar(255) DEFAULT NULL,
  `PRODUCT_BRANDFORM` varchar(255) DEFAULT NULL,
  `PRODUCT_SUBBRANDFORM` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'303',NULL,NULL,'1',NULL,'','HIM NEEM F/W 100ML','HIM NEEM F/W 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(2,'303',NULL,NULL,'2',NULL,'','HIM I/O L F/W 100ML','HIM I/O L F/W 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(3,'303',NULL,NULL,'20',NULL,'','GOW GHEE 100ML','GOW GHEE 100ML','04059020','1','2',NULL,'2','GOWARDHAN','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GOWARDHAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(4,'303',NULL,NULL,'21',NULL,'','GOW GHEE 200ML','GOW GHEE 200ML','04059020','1','2',NULL,'2','GOWARDHAN','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GOWARDHAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(5,'303',NULL,NULL,'22',NULL,'','GOW GHEE 500ML','GOW GHEE 500ML','04059020','1','2',NULL,'2','GOWARDHAN','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GOWARDHAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(6,'303',NULL,NULL,'23',NULL,'','GOW GHEE 1 LTR','GOW GHEE 1 LTR','04059020','1','2',NULL,'2','GOWARDHAN','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GOWARDHAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(7,'303',NULL,NULL,'3',NULL,'','HIM LEMON F/W 100ML','HIM LEMON F/W 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(8,'303',NULL,NULL,'4',NULL,'','HIM KESAR F/W 150ML','HIM KESAR F/W 150ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(9,'303',NULL,NULL,'5',NULL,'','HIM ALOE F/W 100ML','HIM ALOE F/W 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(10,'303',NULL,NULL,'6',NULL,'','HIM NEEM SCRUB 50GM','HIM NEEM SCRUB 50GM','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(11,'303',NULL,NULL,'7',NULL,'','HIM ALOE/F  F/W 50ML','HIM ALOE/F  F/W 50ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(12,'303',NULL,NULL,'9',NULL,'','HIM NEEM F/W 50 ML','HIM NEEM F/W 50 ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(13,'303',NULL,NULL,'10',NULL,'','HIM  PEEL OFF M 8 GM','HIM  PEEL OFF M 8 GM','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(14,'303',NULL,NULL,'11',NULL,'','HIM NEEM SCRUB 8 GM','HIM NEEM SCRUB 8 GM','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(15,'303',NULL,NULL,'12',NULL,'','HIM NEEM PACK 8 GM','HIM NEEM PACK 8 GM','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(16,'303',NULL,NULL,'13',NULL,'','HIM MENS P/G F/W 100ML','HIM MENS P/G F/W 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(17,'303',NULL,NULL,'14',NULL,'','HIM POWER G  F/W 100ML','HIM POWER G  F/W 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(18,'303',NULL,NULL,'15',NULL,'','HIM  INTE L F/W 100ML','HIM  INTE L F/W 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(19,'303',NULL,NULL,'16',NULL,'','HIM REF CLE MILK 100ML','HIM REF CLE MILK 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(20,'303',NULL,NULL,'17',NULL,'','HIM NEEM F/W 300ML','HIM NEEM F/W 300ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(21,'303',NULL,NULL,'25',NULL,'','HIM ANTI D SH 80ML','HIM ANTI D SH 80ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(22,'303',NULL,NULL,'26',NULL,'','HIM ANTI D SH 200ML','HIM ANTI D SH 200ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(23,'303',NULL,NULL,'27',NULL,'','HIM ANTI HF SH 80ML','HIM ANTI HF SH 80ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(24,'303',NULL,NULL,'28',NULL,'','HIM GDC SH 180ML','HIM GDC SH 180ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(25,'303',NULL,NULL,'29',NULL,'','HIM C/C PEST 80GM','HIM C/C PEST 80GM','33061020','1','2',NULL,'3','HIMALAYA DC','2','2','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(26,'303',NULL,NULL,'31',NULL,'','HIM C/C PEST 150GM','HIM C/C PEST 150GM','33061020','1','2',NULL,'3','HIMALAYA DC','2','2','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(27,'303',NULL,NULL,'32',NULL,'','HIM AYURVEDA  PEST 150GM','HIM AYURVEDA  PEST 150GM','33061020','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(28,'303',NULL,NULL,'33',NULL,'','HIM ACTIVE F PEST 80GM','HIM ACTIVE F PEST 80GM','33061020','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(29,'303',NULL,NULL,'34',NULL,'','HIM S/W PEST 80GM','HIM S/W PEST 80GM','33061020','1','2',NULL,'3','HIMALAYA DC','2','2','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(30,'303',NULL,NULL,'35',NULL,'','HIM  S/W PEST 150GM','HIM  S/W PEST 150GM','33061020','1','2',NULL,'3','HIMALAYA DC','2','2','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(31,'303',NULL,NULL,'36',NULL,'','HIM STR LIP 4.5GM','HIM STR LIP 4.5GM','33041000','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(32,'303',NULL,NULL,'38',NULL,'','HIM STR LIP 2 GM','HIM STR LIP 2 GM','33041000','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(33,'303',NULL,NULL,'18',NULL,'','HIM PRICKLY HEAT 100GM','HIM PRICKLY HEAT 100GM','NULL','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(34,'303',NULL,NULL,'37',NULL,'','HIM F/W 150 ML','HIM F/W 150 ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(35,'303',NULL,NULL,'39',NULL,'','HIM FAIRNESS CR 15GM','HIM FAIRNESS CR 15GM','33049910','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(36,'303',NULL,NULL,'40',NULL,'','HIM SUNSCREEN L 50ML','HIM SUNSCREEN L 50ML','33049910','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(37,'303',NULL,NULL,'41',NULL,'','HIM KAJAL 1 GM','HIM KAJAL 1 GM','33042000','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(38,'303',NULL,NULL,'42',NULL,'','HIM LIV 52 SYP 100ML','HIM LIV 52 SYP 100ML','30049011','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(39,'303',NULL,NULL,'43',NULL,'','HIM LIV 52 SYP 200ML','HIM LIV 52 SYP 200ML','30049011','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(40,'303',NULL,NULL,'44',NULL,'','HIM AHF SH 180ML','HIM AHF SH 180ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(41,'303',NULL,NULL,'45',NULL,'','HIM AHF SH 340ML','HIM AHF SH 340ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(42,'303',NULL,NULL,'46',NULL,'','HIM ANTI DAN  200ML','HIM ANTI DAN  200ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(43,'303',NULL,NULL,'47',NULL,'','HIM LIP B 10GM 24+2 JAR','HIM LIP B 10GM 24+2 JAR','33041000','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(44,'303',NULL,NULL,'48',NULL,'','HIM S/B LIP BLAM 10GM','HIM S/B LIP BLAM 10GM','33041000','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(45,'303',NULL,NULL,'49',NULL,'','HIM PUAR HANDS L 100ML','HIM PUAR HANDS L 100ML','34013090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(46,'303',NULL,NULL,'50',NULL,'','HIM AYURVEDA CLEAR SOAP 125GM','HIM AYURVEDA CLEAR SOAP 125GM','34011110','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(47,'303',NULL,NULL,'51',NULL,'','HIM NEEM SOAP 125GM','HIM NEEM SOAP 125GM','34011110','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(48,'303',NULL,NULL,'52',NULL,'','HIM NEEM PACK 100GM','HIM NEEM PACK 100GM','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(49,'303',NULL,NULL,'53',NULL,'','HIM NEEM SCRUB 100GM','HIM NEEM SCRUB 100GM','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(50,'303',NULL,NULL,'54',NULL,'','HIM BABY POW 50GM','HIM BABY POW 50GM','33049120','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(51,'303',NULL,NULL,'55',NULL,'','HIM G SOAP 125 GM','HIM G SOAP 125 GM','34011190','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(52,'303',NULL,NULL,'56',NULL,'','HIM DARK S T F W 100ML','HIM DARK S T F W 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(53,'303',NULL,NULL,'57',NULL,'','HIM GREEN TULSI TEA','HIM GREEN TULSI TEA','NULL','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(54,'303',NULL,NULL,'58',NULL,'','HIM TAN/O F/W 50ML','HIM TAN/O F/W 50ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(55,'303',NULL,NULL,'59',NULL,'','HIM WINTER CR 50ML','HIM WINTER CR 50ML','33049930','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(56,'303',NULL,NULL,'60',NULL,'','HIM A/R SOAP 125GM','HIM A/R SOAP 125GM','34011110','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(57,'303',NULL,NULL,'61',NULL,'','HIM A SOAP N & T 75GM','HIM A SOAP N & T 75GM','34011110','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(58,'303',NULL,NULL,'62',NULL,'','HIM BABY SOAP N 125M','HIM BABY SOAP N 125M','34011190','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(59,'303',NULL,NULL,'63',NULL,'','HIM BABY POW 100GM','HIM BABY POW 100GM','33049120','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(60,'303',NULL,NULL,'64',NULL,'','SHUBH MUHURAT BOX','SHUBH MUHURAT BOX','34011110','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(61,'303',NULL,NULL,'65',NULL,'','HIM DIAPERS 9S','HIM DIAPERS 9S','96190090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(62,'303',NULL,NULL,'66',NULL,'','HIM KEASR PACK 100GM','HIM KEASR PACK 100GM','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(63,'303',NULL,NULL,'67',NULL,'','HIM N SKIN C 200ML','HIM N SKIN C 200ML','33049910','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(64,'303',NULL,NULL,'68',NULL,'','HIM PDCF SCRUB 100GM','HIM PDCF SCRUB 100GM','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(65,'303',NULL,NULL,'69',NULL,'','HIM T R OR  F/W 100ML','HIM T R OR  F/W 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(66,'303',NULL,NULL,'70',NULL,'','HIM P/MART CAP 5\\\'S','HIM P/MART CAP 5\\\'S','30049011','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(67,'303',NULL,NULL,'71',NULL,'','HIM NEEM F/W 200ML','HIM NEEM F/W 200ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(68,'303',NULL,NULL,'72',NULL,'','HIM NEEM F/W 150 ML','HIM NEEM F/W 150 ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(69,'303',NULL,NULL,'73',NULL,'','HIM A/VERA G 100 ML','HIM A/VERA G 100 ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(70,'303',NULL,NULL,'74',NULL,'','HIM PANT X LARGE 54S','HIM PANT X LARGE 54S','9610','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(71,'303',NULL,NULL,'75',NULL,'','HIM PANT SMALL 54 S','HIM PANT SMALL 54 S','9610','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(72,'303',NULL,NULL,'76',NULL,'','HIM BABY WIP 12 PES','HIM BABY WIP 12 PES','3307','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(73,'303',NULL,NULL,'77',NULL,'','HIM BABY WIP 24 PES','HIM BABY WIP 24 PES','3307','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(74,'303',NULL,NULL,'78',NULL,'','HIM BABY WIP 72 PES','HIM BABY WIP 72 PES','3307','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(75,'303',NULL,NULL,'79',NULL,'','HIM BABY WIP COMBI 72*2','HIM BABY WIP COMBI 72*2','3307','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(76,'303',NULL,NULL,'80',NULL,'','HIM UNDER UYE C 15ML','HIM UNDER UYE C 15ML','33049990','1','2',NULL,'3','HIMALAYA DC','7','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(77,'303',NULL,NULL,'81',NULL,'','HIM BABY CR 50ML','HIM BABY CR 50ML','33049930','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(78,'303',NULL,NULL,'82',NULL,'','HIM  B LOTION 400ML','HIM  B LOTION 400ML','33049930','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(79,'303',NULL,NULL,'83',NULL,'','HIM BABY LOTION 200ML','HIM BABY LOTION 200ML','33049930','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(80,'303',NULL,NULL,'84',NULL,'','HIM BABY POW 200GM','HIM BABY POW 200GM','33049120','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(81,'303',NULL,NULL,'85',NULL,'','HIM BABY POW 700GM','HIM BABY POW 700GM','330491','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(82,'303',NULL,NULL,'86',NULL,'','HIM BABY M OIL 50ML','HIM BABY M OIL 50ML','33049990','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(83,'303',NULL,NULL,'87',NULL,'','HIM BABY M OIL 100ML','HIM BABY M OIL 100ML','330499','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(84,'303',NULL,NULL,'88',NULL,'','HIM BABY M OIL 200ML','HIM BABY M OIL 200ML','33049990','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(85,'303',NULL,NULL,'89',NULL,'','HIM AHF COND 80ML','HIM AHF COND 80ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(86,'303',NULL,NULL,'90',NULL,'','HIM BABY SHAMPOO 100ML','HIM BABY SHAMPOO 100ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(87,'303',NULL,NULL,'91',NULL,'','HIM BABY SHAMPOO 200ML','HIM BABY SHAMPOO 200ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(88,'303',NULL,NULL,'93',NULL,'','HIM BABY WASH 100ML','HIM BABY WASH 100ML','33051090','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(89,'303',NULL,NULL,'94',NULL,'','HIM GIFT PACK 285 RS','HIM GIFT PACK 285 RS','33049990','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(90,'303',NULL,NULL,'95',NULL,'','HIM GIFT PACK W 7S','HIM GIFT PACK W 7S','33049990','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(91,'303',NULL,NULL,'96',NULL,'','HIM RASH CREAM 100GM','HIM RASH CREAM 100GM','30049011','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(92,'303',NULL,NULL,'97',NULL,'','HIM AY C SKIN SOAP 75GM','HIM AY C SKIN SOAP 75GM','34011110','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(93,'303',NULL,NULL,'98',NULL,'','HIM G B S 75+30GM POW FREE','HIM G B S 75+30GM POW FREE','340111','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(94,'303',NULL,NULL,'99',NULL,'','HIM  APRICOT F/W 50ML','HIM  APRICOT F/W 50ML','3304','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(95,'303',NULL,NULL,'100',NULL,'','HIM CHAR  F/W 100ML','HIM CHAR  F/W 100ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(96,'303',NULL,NULL,'101',NULL,'','HIM  CCBMF SCRUB 100GM','HIM  CCBMF SCRUB 100GM','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(97,'303',NULL,NULL,'102',NULL,'','HIM HONEY S 125GM','HIM HONEY S 125GM','34011190','1','2',NULL,'1','HIMALAYA FC','2','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(98,'303',NULL,NULL,'103',NULL,'','HIM BABY WASH 400ML','HIM BABY WASH 400ML','33049990','1','2',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(99,'303',NULL,NULL,'104',NULL,'','XPERT 120GM(96) CAKES 10RS','XPERT 120GM(96) CAKES 10RS','34054000','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(100,'303',NULL,NULL,'107',NULL,'','HIM SHISHU A WIPES 99 RS','HIM SHISHU A WIPES 99 RS','3307','1','2',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(101,'303',NULL,NULL,'110',NULL,'','HIM DAY CREAM 50GM','HIM DAY CREAM 50GM','','1','3',NULL,'2','GOWARDHAN','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GOWARDHAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(102,'303',NULL,NULL,'111',NULL,'','HIM R BABY S 125GM','HIM R BABY S 125GM','3401119O','1','3',NULL,'3','HIMALAYA DC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA DC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(103,'303',NULL,NULL,'112',NULL,'','HIM OIL C/L FW 100ML','HIM OIL C/L FW 100ML','33049990','1','3',NULL,'2','GOWARDHAN','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GOWARDHAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(104,'303',NULL,NULL,'113',NULL,'','HIM REF BABY S 75GM','HIM REF BABY S 75GM','34011190','1','3',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(105,'303',NULL,NULL,'114',NULL,'','Uniwash 1kgx 12 packs M-140','Uniwash 1kgx 12 packs M-140','340290','1','3',NULL,'2','GOWARDHAN','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GOWARDHAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(106,'303',NULL,NULL,'116',NULL,'','HIM  G APRICOT S 100GM','HIM  G APRICOT S 100GM','33059090','1','3',NULL,'4','JAYESH ENTERPRISES KAVERI','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JAYESH ENTERPRISES KAVERI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(107,'303',NULL,NULL,'117',NULL,'','HIM V/C SB F/W 50ML','HIM V/C SB F/W 50ML','33049990','1','3',NULL,'4','JAYESH ENTERPRISES KAVERI','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JAYESH ENTERPRISES KAVERI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(108,'303',NULL,NULL,'118',NULL,'','HIM V/C BLUE B F/W 100ML','HIM V/C BLUE B F/W 100ML','34013090','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(109,'303',NULL,NULL,'119',NULL,'','HIM DARK SCTF SCRUB 100GM','HIM DARK SCTF SCRUB 100GM','33049990','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(110,'303',NULL,NULL,'120',NULL,'','HIM AHF CREAM 100MAL','HIM AHF CREAM 100MAL','33059030','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(111,'303',NULL,NULL,'121',NULL,'','HIM ANTI W CR 50GM','HIM ANTI W CR 50GM','33049910','1','3',NULL,'4','JAYESH ENTERPRISES KAVERI','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JAYESH ENTERPRISES KAVERI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(112,'303',NULL,NULL,'130',NULL,'','HIM C C PEST 80GM','HIM C C PEST 80GM','33061020','1','3',NULL,'2','GOWARDHAN','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','GOWARDHAN',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(113,'303',NULL,NULL,'132',NULL,'','HIM V/C B F/W 50ML','HIM V/C B F/W 50ML','33049990','1','3',NULL,'4','JAYESH ENTERPRISES KAVERI','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JAYESH ENTERPRISES KAVERI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(114,'303',NULL,NULL,'139',NULL,'','BABELOIS D PANTS L-30','BABELOIS D PANTS L-30','96190040','1','3',NULL,'4','JAYESH ENTERPRISES KAVERI','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JAYESH ENTERPRISES KAVERI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(115,'303',NULL,NULL,'140',NULL,'','HIM TAN O F/W 100ML','HIM TAN O F/W 100ML','33049990','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(116,'303',NULL,NULL,'135',NULL,'','KAVERI E FAST D BROWN RS-20','KAVERI E FAST D BROWN RS-20','33059030','1','3',NULL,'4','JAYESH ENTERPRISES KAVERI','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','JAYESH ENTERPRISES KAVERI',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(117,'303',NULL,NULL,'138',NULL,'','HIM KESAR F/W 100ML','HIM KESAR F/W 100ML','33049990','1','3',NULL,'1','HIMALAYA FC','7','7','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(118,'303',NULL,NULL,'162',NULL,'','HIM BRIGHTENING VCOSC 50GM','HIM BRIGHTENING VCOSC 50GM','33049990','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(119,'303',NULL,NULL,'400',NULL,'','HIM VITAMIN C/O 100ML','HIM VITAMIN C/O 100ML','33049990','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(120,'303',NULL,NULL,'401',NULL,'','HIM VIT C/O FW 50ML','HIM VIT C/O FW 50ML','33049990','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(121,'303',NULL,NULL,'402',NULL,'','HIM HEENA 120GM','HIM HEENA 120GM','33059040','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(122,'303',NULL,NULL,'403',NULL,'','HIM CUCUMBER  S 125GM','HIM CUCUMBER  S 125GM','34011110','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(123,'303',NULL,NULL,'404',NULL,'','HIM AYURVEDA S 125GM','HIM AYURVEDA S 125GM','3401110','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(124,'303',NULL,NULL,'405',NULL,'','HIM OIL C L/F  50ML','HIM OIL C L/F  50ML','33049990','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(125,'303',NULL,NULL,'406',NULL,'','HIM ALOE V F/W 200ML','HIM ALOE V F/W 200ML','33049990','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(126,'303',NULL,NULL,'407',NULL,'','HIM AHF SHAM 650ML','HIM AHF SHAM 650ML','33051090','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(127,'303',NULL,NULL,'601',NULL,'','HIM DARK SFP 100GM','HIM DARK SFP 100GM','33049990','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(128,'303',NULL,NULL,'701',NULL,'','YEZIGLOW H OIL 100ML','YEZIGLOW H OIL 100ML','39152000','1','3',NULL,'5','VIVE COSMATIC','5','5','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','VIVE COSMATIC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(129,'303',NULL,NULL,'702',NULL,'','P RELIF OIL 60ML','P RELIF OIL 60ML','33049011','1','3',NULL,'5','VIVE COSMATIC','5','5','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','VIVE COSMATIC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(130,'303',NULL,NULL,'703',NULL,'','P EXFOGLOW S 100GM','P EXFOGLOW S 100GM','33049910','1','3',NULL,'5','VIVE COSMATIC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','VIVE COSMATIC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(131,'303',NULL,NULL,'704',NULL,'','P HYDRCOIN F/W 100ML','P HYDRCOIN F/W 100ML','33049910','1','3',NULL,'5','VIVE COSMATIC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','VIVE COSMATIC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(132,'303',NULL,NULL,'705',NULL,'','P LUMI SHIELD 100ML','P LUMI SHIELD 100ML','33049910','1','3',NULL,'5','VIVE COSMATIC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','VIVE COSMATIC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(133,'303',NULL,NULL,'706',NULL,'','P SUGAR CC CAPSULE','P SUGAR CC CAPSULE','33049011','1','3',NULL,'5','VIVE COSMATIC','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','VIVE COSMATIC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(134,'303',NULL,NULL,'707',NULL,'','P VITAMIN C F/W 100ML','P VITAMIN C F/W 100ML','33049910','1','3',NULL,'5','VIVE COSMATIC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','VIVE COSMATIC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(135,'303',NULL,NULL,'122',NULL,'','HIM NEEM PACK 25GM','HIM NEEM PACK 25GM','33049990','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(136,'303',NULL,NULL,'123',NULL,'','HIM NEEM SCRUB 25GM','HIM NEEM SCRUB 25GM','33049990','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(137,'303',NULL,NULL,'124',NULL,'','HIM WALNET SCRUB 25GM','HIM WALNET SCRUB 25GM','33049990','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(138,'303',NULL,NULL,'125',NULL,'','HIM GB SOAP 5+1 50GM','HIM GB SOAP 5+1 50GM','34011190','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(139,'303',NULL,NULL,'126',NULL,'','HIM EMB SOAP 125GM','HIM EMB SOAP 125GM','34011190','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(140,'303',NULL,NULL,'127',NULL,'','HIM AD SH PATTI RS 2','HIM AD SH PATTI RS 2','33051090','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(141,'303',NULL,NULL,'128',NULL,'','HIM AHF SH PATTI RS 2','HIM AHF SH PATTI RS 2','33051090','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(142,'303',NULL,NULL,'129',NULL,'','HIM STRAB F/W 100ML','HIM STRAB F/W 100ML','34013090','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(143,'303',NULL,NULL,'712',NULL,'','HIM REF C TONER 100ML','HIM REF C TONER 100ML','33049990','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(144,'303',NULL,NULL,'720',NULL,'','HIM GDC SH 340ML','HIM GDC SH 340ML','33051090','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(145,'303',NULL,NULL,'721',NULL,'','HIM DR SH 340ML','HIM DR SH 340ML','33051090','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(146,'303',NULL,NULL,'723',NULL,'','HIM DARK SPOT F P 100GM','HIM DARK SPOT F P 100GM','33049990','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(147,'303',NULL,NULL,'724',NULL,'','HIM TOF SURUB 100GM','HIM TOF SURUB 100GM','33049990','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(148,'303',NULL,NULL,'725',NULL,'','HIM NEEM F/W 400ML','HIM NEEM F/W 400ML','33049990','1','3',NULL,'1','HIMALAYA FC','2','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(149,'303',NULL,NULL,'726',NULL,'','HIM LEMON F/W 200ML','HIM LEMON F/W 200ML','33049990','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(150,'303',NULL,NULL,'727',NULL,'','HIM NEEM F/W 100ML','HIM NEEM F/W 100ML','33039990','1','3',NULL,'1','HIMALAYA FC','5','5','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL),(151,'303',NULL,NULL,'728',NULL,'','HIM RICH CB LIP 4*5 GM','HIM RICH CB LIP 4*5 GM','NULL','1','3',NULL,'1','HIMALAYA FC','2','2','1',NULL,NULL,'4','4','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','HIMALAYA FC',0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'303',NULL,NULL,'HIMALAYA FC','1',NULL,NULL,NULL,484,NULL,NULL,'484','484',NULL,0,'2026-08-25 12:16:55','2026-08-25 12:16:55'),(2,'303',NULL,NULL,'GOWARDHAN','1',NULL,NULL,NULL,484,NULL,NULL,'484','484',NULL,0,'2026-08-25 12:16:55','2026-08-25 12:16:55'),(3,'303',NULL,NULL,'HIMALAYA DC','1',NULL,NULL,NULL,484,NULL,NULL,'484','484',NULL,0,'2026-08-25 12:16:55','2026-08-25 12:16:55'),(4,'303',NULL,NULL,'JAYESH ENTERPRISES KAVERI','1',NULL,NULL,NULL,484,NULL,NULL,'484','484',NULL,0,'2026-08-25 12:16:55','2026-08-25 12:16:55'),(5,'303',NULL,NULL,'VIVE COSMATIC','1',NULL,NULL,NULL,484,NULL,NULL,'484','484',NULL,0,'2026-08-25 12:16:55','2026-08-25 12:16:55');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MINIMUM_STOCK_LEVEL` int NOT NULL DEFAULT '0',
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'303',NULL,NULL,'1','1649077111510','05-04-2022','2026-08-25','1','0','0','12','189','100.15','0','93.61','0','6.54','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(2,'303',NULL,NULL,'2','1649077111527','05-04-2022','2026-08-25','2','0','0','-12','189','123.27','0','120.0000','120.0000','3.27','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(3,'303',NULL,NULL,'3','1649077111560','05-04-2022','2026-08-25','20','0','0','0','79','65.31','0','62.06','0','3.25','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(4,'303',NULL,NULL,'4','1649077111576','05-04-2022','2026-08-25','21','0','0','12','129','106.64','0','98.22','0','8.42','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(5,'303',NULL,NULL,'5','1649077111589','05-04-2022','2026-08-25','22','0','0','12','305','252.15','0','229.92','229.9200','22.23','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(6,'303',NULL,NULL,'6','1649077111604','05-04-2022','2026-08-25','23','0','0','0','579','478.67','0','450','0','28.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(7,'303',NULL,NULL,'7','1649077111617','05-04-2022','2026-08-25','3','0','0','0','189','189','0','170','0','19','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(8,'303',NULL,NULL,'8','1649077111639','05-04-2022','2026-08-25','4','0','0','0','279','156','0','142','0','14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(9,'303',NULL,NULL,'9','1649077111655','05-04-2022','2026-08-25','5','0','0','0','189','125','0','123','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(10,'303',NULL,NULL,'10','1649077111678','05-04-2022','2026-08-25','6','0','0','0','95','57.78','0','54','0','3.78','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(11,'303',NULL,NULL,'11','1649077111693','05-04-2022','2026-08-25','7','0','0','0','95','53.93','0','50.41','0','3.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(12,'303',NULL,NULL,'12','1649077111704','05-04-2022','2026-08-25','9','0','0','0','90','53.93','0','51','0','2.93','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(13,'303',NULL,NULL,'13','1649077111717','05-04-2022','2026-08-25','10','0','0','0','10','7.7','0','6.38','0','1.32','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(14,'303',NULL,NULL,'14','1649077111737','05-04-2022','2026-08-25','11','0','0','0','10','7.7','0','6.39','0','1.31','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(15,'303',NULL,NULL,'15','1649077111753','05-04-2022','2026-08-25','12','0','0','0','10','7.7','0','6.39','0','1.31','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(16,'303',NULL,NULL,'16','1649077111766','05-04-2022','2026-08-25','13','0','0','0','189','108','0','102','0','6','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(17,'303',NULL,NULL,'17','1649077111785','05-04-2022','2026-08-25','14','0','0','0','189','73.19','0','59.05','0','14.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(18,'303',NULL,NULL,'18','1649077111801','05-04-2022','2026-08-25','15','0','0','0','189','73.19','0','65.99','0','7.2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(19,'303',NULL,NULL,'19','1649077111821','05-04-2022','2026-08-25','16','0','0','0','95','73.18','0','68.39','0','4.79','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(20,'303',NULL,NULL,'20','1649077111843','05-04-2022','2026-08-25','17','0','0','0','549','11.56','0','10.8','0','0.76','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(21,'303',NULL,NULL,'21','1649077111859','05-04-2022','2026-08-25','25','0','0','0','66','50.08','0','44.64','0','5.44','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(22,'303',NULL,NULL,'22','1649077111871','05-04-2022','2026-08-25','26','0','0','0','140','107.85','0','90','0','17.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(23,'303',NULL,NULL,'23','1649077111884','05-04-2022','2026-08-25','27','0','0','0','61','47.76','0','46.79','0','0.97','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(24,'303',NULL,NULL,'24','1649077111904','05-04-2022','2026-08-25','28','0','0','0','159','47.76','0','44.64','0','3.12','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(25,'303',NULL,NULL,'25','1649077111920','05-04-2022','2026-08-25','29','0','0','0','52','38.52','0','35.99','0','2.53','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(26,'303',NULL,NULL,'26','1649077111943','05-04-2022','2026-08-25','31','0','0','0','99','65.49','0','57.6','0','7.89','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(27,'303',NULL,NULL,'27','1649077111959','05-04-2022','2026-08-25','32','0','0','0','130','115.4','0','110','0','5.4','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(28,'303',NULL,NULL,'28','1649077111971','05-04-2022','2026-08-25','33','0','0','0','56','43','0','35','0','8','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(29,'303',NULL,NULL,'29','1649077111984','05-04-2022','2026-08-25','34','0','0','0','57','46.22','0','46','0','0.22','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(30,'303',NULL,NULL,'30','1649077111994','05-04-2022','2026-08-25','35','0','0','0','115','73.19','0','64.8','0','8.39','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(31,'303',NULL,NULL,'31','1649077112006','05-04-2022','2026-08-25','36','0','0','0','150','115.56','0','108','0','7.56','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(32,'303',NULL,NULL,'32','1649077112019','05-04-2022','2026-08-25','38','0','0','0','45','34.66','0','30','0','4.66','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(33,'303',NULL,NULL,'33','1649077112041','05-04-2022','2026-08-25','18','0','0','0','90','65.33','0','50.41','0','14.92','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(34,'303',NULL,NULL,'34','1649077112056','05-04-2022','2026-08-25','37','0','0','0','155','119.41','0','100','0','19.41','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(35,'303',NULL,NULL,'35','1649077112069','05-04-2022','2026-08-25','39','0','0','0','48','37','0','34.56','0','2.44','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(36,'303',NULL,NULL,'36','1649077112080','05-04-2022','2026-08-25','40','0','0','0','125','97','0','94','0','3','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(37,'303',NULL,NULL,'37','1649077112091','05-04-2022','2026-08-25','41','0','0','0','550','405','0','400','0','5','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(38,'303',NULL,NULL,'38','1649077112104','05-04-2022','2026-08-25','42','70','0','0','120','72','0','70','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(39,'303',NULL,NULL,'39','1649077112116','05-04-2022','2026-08-25','43','120','0','0','195','125','0','123','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(40,'303',NULL,NULL,'40','1649077112127','05-04-2022','2026-08-25','44','0','0','0','159','123','0','134','0','-11','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(41,'303',NULL,NULL,'41','1649077112138','05-04-2022','2026-08-25','45','0','0','0','335','100.15','0','123','0','-22.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(42,'303',NULL,NULL,'42','1649077112151','05-04-2022','2026-08-25','46','0','0','0','140','107.85','0','100','0','7.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(43,'303',NULL,NULL,'43','1649077112160','05-04-2022','2026-08-25','47','0','0','0','960','727','0','678','0','49','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(44,'303',NULL,NULL,'44','1649077112171','05-04-2022','2026-08-25','48','0','0','0','40','34.66','0','33','0','1.66','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(45,'303',NULL,NULL,'45','1649077112201','05-04-2022','2026-08-25','49','0','0','0','50','38.52','0','32','0','6.52','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(46,'303',NULL,NULL,'46','1649077112220','05-04-2022','2026-08-25','50','0','0','0','78','52.36','0','45','0','7.36','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(47,'303',NULL,NULL,'47','1649077112236','05-04-2022','2026-08-25','51','0','0','0','60','52.36','0','68','0','-15.64','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(48,'303',NULL,NULL,'48','1649077112249','05-04-2022','2026-08-25','52','0','0','0','170','107','0','105','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(49,'303',NULL,NULL,'49','1649077112260','05-04-2022','2026-08-25','53','0','0','0','189','105','0','105','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(50,'303',NULL,NULL,'50','1649077112272','05-04-2022','2026-08-25','54','0','0','0','60','137.89','0','123','0','14.89','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(51,'303',NULL,NULL,'51','1649077112284','05-04-2022','2026-08-25','55','0','0','0','100','51.67','0','48','0','3.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(52,'303',NULL,NULL,'52','1649077112304','05-04-2022','2026-08-25','56','0','0','0','220','134','0','134','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(53,'303',NULL,NULL,'53','1649077112324','05-04-2022','2026-08-25','57','0','0','0','70','58.92','0','40','0','18.92','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(54,'303',NULL,NULL,'54','1649077112338','05-04-2022','2026-08-25','58','0','0','0','115','57.78','0','55','0','2.78','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(55,'303',NULL,NULL,'55','1649077112358','05-04-2022','2026-08-25','59','0','0','0','99','65.48','0','63','0','2.48','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(56,'303',NULL,NULL,'56','1649077112372','05-04-2022','2026-08-25','60','0','0','0','60','44','0','43','0','1','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(57,'303',NULL,NULL,'57','1649077112386','05-04-2022','2026-08-25','61','0','0','0','36','37.9','0','31.9','0','6','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(58,'303',NULL,NULL,'58','1649077112397','05-04-2022','2026-08-25','62','0','0','0','100','55.19','0','45.94','0','9.25','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(59,'303',NULL,NULL,'59','1649077112408','05-04-2022','2026-08-25','63','0','0','0','120','55.12','0','45.94','0','9.18','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(60,'303',NULL,NULL,'60','1649077112420','05-04-2022','2026-08-25','64','0','0','0','565','389.28','0','360.43','0','28.85','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(61,'303',NULL,NULL,'61','1649077112432','05-04-2022','2026-08-25','65','0','0','0','130','94.37','0','87.38','0','6.99','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(62,'303',NULL,NULL,'62','1649077112443','05-04-2022','2026-08-25','66','0','0','0','135','95','0','93.79','0','1.21','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(63,'303',NULL,NULL,'63','1649077112454','05-04-2022','2026-08-25','67','0','0','0','245','95','0','97.21','0','-2.21','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(64,'303',NULL,NULL,'64','1649077112468','05-04-2022','2026-08-25','68','0','0','0','230','103','0','97.21','0','5.79','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(65,'303',NULL,NULL,'65','1649077112477','05-04-2022','2026-08-25','69','0','0','0','220','103','0','100.79','0','2.21','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(66,'303',NULL,NULL,'66','1649077112489','05-04-2022','2026-08-25','70','0','0','0','112','51','0','60','0','-9','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(67,'303',NULL,NULL,'67','1649077112502','05-04-2022','2026-08-25','71','0','0','0','449','210','0','202','0','8','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(68,'303',NULL,NULL,'68','1649077112516','05-04-2022','2026-08-25','72','0','0','0','279','151','0','140','0','11','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(69,'303',NULL,NULL,'69','1649077112526','05-04-2022','2026-08-25','73','0','0','0','95','165','0','151.21','0','13.79','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(70,'303',NULL,NULL,'70','1649077112536','05-04-2022','2026-08-25','74','0','0','0','1249','456','0','487.5','0','-31.5','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(71,'303',NULL,NULL,'71','1649077112546','05-04-2022','2026-08-25','75','0','0','0','899','490.74','0','478.15','0','12.59','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(72,'303',NULL,NULL,'72','1649077112568','05-04-2022','2026-08-25','76','0','0','0','48','33.07','0','31','0','2.07','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(73,'303',NULL,NULL,'73','1649077112589','05-04-2022','2026-08-25','77','0','0','0','85','58.57','0','55','0','3.57','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(74,'303',NULL,NULL,'74','1649077112602','05-04-2022','2026-08-25','78','0','0','0','280','137.8','0','100','0','37.8','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(75,'303',NULL,NULL,'75','1649077112614','05-04-2022','2026-08-25','79','0','0','0','350','241.14','0','200','0','41.14','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(76,'303',NULL,NULL,'76','1649077112625','05-04-2022','2026-08-25','80','0','0','0','259','481.6','0','470','0','11.6','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(77,'303',NULL,NULL,'77','1649077112637','05-04-2022','2026-08-25','81','0','0','0','115','51.67','0','50','0','1.67','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(78,'303',NULL,NULL,'78','1649077112650','05-04-2022','2026-08-25','82','0','0','0','400','65.45','0','60','0','5.45','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(79,'303',NULL,NULL,'79','1649077112660','05-04-2022','2026-08-25','83','0','0','0','210','113.68','0','102','0','11.68','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(80,'303',NULL,NULL,'80','1649077112672','05-04-2022','2026-08-25','84','0','0','0','215','100','0','90','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(81,'303',NULL,NULL,'81','1649077112683','05-04-2022','2026-08-25','85','0','0','0','475','27.55','0','25','0','2.55','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(82,'303',NULL,NULL,'82','1649077112694','05-04-2022','2026-08-25','86','0','0','0','75','37.89','0','35','0','2.89','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(83,'303',NULL,NULL,'83','1649077112705','05-04-2022','2026-08-25','87','0','0','0','150','68.89','0','65','0','3.89','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(84,'303',NULL,NULL,'84','1649077112717','05-04-2022','2026-08-25','88','0','0','0','270','124.04','0','110','0','14.04','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(85,'303',NULL,NULL,'85','1649077112741','05-04-2022','2026-08-25','89','0','0','0','90','86.12','0','80','0','6.12','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(86,'303',NULL,NULL,'86','1649077112757','05-04-2022','2026-08-25','90','0','0','0','115','62','0','60','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(87,'303',NULL,NULL,'87','1649077112770','05-04-2022','2026-08-25','91','0','0','0','225','117.13','0','100','0','17.13','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(88,'303',NULL,NULL,'88','1649077112779','05-04-2022','2026-08-25','93','0','0','0','130','58.56','0','55','0','3.56','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(89,'303',NULL,NULL,'89','1649077112792','05-04-2022','2026-08-25','94','0','0','0','285','158.47','0','145','0','13.47','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(90,'303',NULL,NULL,'90','1649077112802','05-04-2022','2026-08-25','95','0','0','0','670','361.71','0','355','0','6.71','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(91,'303',NULL,NULL,'91','1649077112817','05-04-2022','2026-08-25','96','0','0','0','243','58.07','0','50','0','8.07','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(92,'303',NULL,NULL,'92','1649077112828','05-04-2022','2026-08-25','97','0','0','0','44','26.97','0','24','0','2.97','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(93,'303',NULL,NULL,'93','1649077112839','05-04-2022','2026-08-25','98','0','0','0','204','103.35','0','100','0','3.35','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(94,'303',NULL,NULL,'94','1649077112852','05-04-2022','2026-08-25','99','0','0','0','75','57.78','0','49','0','8.78','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(95,'303',NULL,NULL,'95','1649077112863','05-04-2022','2026-08-25','100','0','0','0','220','60','0','51','0','9','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(96,'303',NULL,NULL,'96','1649077112875','05-04-2022','2026-08-25','101','0','0','0','200','57.78','0','51','0','6.78','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(97,'303',NULL,NULL,'97','1649077112887','05-04-2022','2026-08-25','102','0','0','0','60','26.97','0','29','0','-2.03','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(98,'303',NULL,NULL,'98','1649077112909','05-04-2022','2026-08-25','103','0','0','0','350','50','0','45','0','5','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(99,'303',NULL,NULL,'99','1649077112925','05-04-2022','2026-08-25','104','0','0','0','10','648.54','0','648.54','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(100,'303',NULL,NULL,'100','1649077112938','05-04-2022','2026-08-25','107','0','0','0','99','68.21','0','66','0','2.21','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(101,'303',NULL,NULL,'101','240601171910','2026-08-25','2026-08-25','110','0','0','0','270','250','0','240','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(102,'303',NULL,NULL,'102','240601172143','2026-08-25','2026-08-25','111','0','0','0','100','33.5','0','33.5','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(103,'303',NULL,NULL,'103','240601172515','2026-08-25','2026-08-25','112','0','0','0','189','96.12','0','96.12','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(104,'303',NULL,NULL,'104','240601172728','2026-08-25','2026-08-25','113','0','0','0','65','70.58','0','70.58','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(105,'303',NULL,NULL,'105','240601173044','2026-08-25','2026-08-25','114','0','0','0','140','90.26','0','90.26','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(106,'303',NULL,NULL,'106','240626141330','2026-08-25','2026-08-25','116','0','0','0','189','23','0','12','0','11','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(107,'303',NULL,NULL,'107','240626141426','2026-08-25','2026-08-25','117','0','0','0','115','34','0','33','0','1','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(108,'303',NULL,NULL,'108','240626141644','2026-08-25','2026-08-25','118','0','0','0','219','112','0','110','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(109,'303',NULL,NULL,'109','240626141843','2026-08-25','2026-08-25','119','0','0','0','210','122','0','101','0','21','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(110,'303',NULL,NULL,'110','240626142017','2026-08-25','2026-08-25','120','0','0','0','100','68','0','67','0','1','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(111,'303',NULL,NULL,'111','240626142208','2026-08-25','2026-08-25','121','0','0','0','270','129','0','128','0','1','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(112,'303',NULL,NULL,'112','240710140627','2026-08-25','2026-08-25','130','34','0','0','59','45','0','43','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(113,'303',NULL,NULL,'113','240714200925','2026-08-25','2026-08-25','132','0','0','0','115','80','0','90','0','-10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(114,'303',NULL,NULL,'114','240714201042','2026-08-25','2026-08-25','139','0','0','0','399','210','0','142.93','0','67.07','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(115,'303',NULL,NULL,'115','240714201327','2026-08-25','2026-08-25','140','0','0','0','220','190','0','145','0','45','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(116,'303',NULL,NULL,'116','240714201639','2026-08-25','2026-08-25','135','0','0','0','20','11','0','8','0','3','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(117,'303',NULL,NULL,'117','240726195954','2026-08-25','2026-08-25','138','0','0','0','189','111','0','100','0','11','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(118,'303',NULL,NULL,'118','251202071503','2026-08-25','2026-08-25','162','0','0','0','275','192','0','190','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(119,'303',NULL,NULL,'119','260225204602','2026-08-25','2026-08-25','400','0','0','0','219','168','0','156','0','12','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(120,'303',NULL,NULL,'120','260225204704','2026-08-25','2026-08-25','401','0','0','0','115','158','0','156','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(121,'303',NULL,NULL,'121','260225204838','2026-08-25','2026-08-25','402','0','0','0','75','55','0','54','0','1','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(122,'303',NULL,NULL,'122','260225205049','2026-08-25','2026-08-25','403','0','0','0','60','46','0','44','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(123,'303',NULL,NULL,'123','260225205219','2026-08-25','2026-08-25','404','0','0','0','70','54','0','43','0','11','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(124,'303',NULL,NULL,'124','260225205419','2026-08-25','2026-08-25','405','0','0','0','95','321','0','65','0','256','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(125,'303',NULL,NULL,'125','260225205621','2026-08-25','2026-08-25','406','0','0','0','499','327','0','326','0','1','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(126,'303',NULL,NULL,'126','260225221522','2026-08-25','2026-08-25','407','0','0','0','755','567','0','566','0','1','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(127,'303',NULL,NULL,'127','260704181208','2026-08-25','2026-08-25','601','0','0','0','230','180','0','170','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(128,'303',NULL,NULL,'128','260722143531','2026-08-25','2026-08-25','701','0','0','0','349','290','0','226.01','0','63.99','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(129,'303',NULL,NULL,'129','260722144622','2026-08-25','2026-08-25','702','0','0','0','160','120','0','103.61','0','16.39','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(130,'303',NULL,NULL,'130','260722145003','2026-08-25','2026-08-25','703','0','0','0','169','110','0','97.38','0','12.62','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(131,'303',NULL,NULL,'131','260723152701','2026-08-25','2026-08-25','704','0','0','0','180','110','0','103.72','0','6.28','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(132,'303',NULL,NULL,'132','260723152904','2026-08-25','2026-08-25','705','0','0','0','190','112','0','109.49','0','2.51','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(133,'303',NULL,NULL,'133','260723153134','2026-08-25','2026-08-25','706','0','0','0','600','400','0','388.75','0','11.25','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(134,'303',NULL,NULL,'134','260723153250','2026-08-25','2026-08-25','707','0','0','0','179','110','0','103.18','0','6.82','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(135,'303',NULL,NULL,'135','260802095105','2026-08-25','2026-08-25','122','0','0','0','55','45','0','40','0','5','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(136,'303',NULL,NULL,'136','260802095216','2026-08-25','2026-08-25','123','0','0','0','55','46','0','40','0','6','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(137,'303',NULL,NULL,'137','260802095311','2026-08-25','2026-08-25','124','0','0','0','55','46','0','40','0','6','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(138,'303',NULL,NULL,'138','260802095928','2026-08-25','2026-08-25','125','0','0','0','230','205','0','200','0','5','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(139,'303',NULL,NULL,'139','260802101101','2026-08-25','2026-08-25','126','0','0','0','100','81','0','80','0','1','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(140,'303',NULL,NULL,'140','260802183753','2026-08-25','2026-08-25','127','0','0','0','32','22','0','20','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(141,'303',NULL,NULL,'141','260802183909','2026-08-25','2026-08-25','128','0','0','0','32','22','0','20','0','2','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(142,'303',NULL,NULL,'142','260803125621','2026-08-25','2026-08-25','129','0','0','0','219','160','0','150.49','0','9.51','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(143,'303',NULL,NULL,'143','260803131531','2026-08-25','2026-08-25','712','0','0','0','110','80','0','79.2','0','0.8','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(144,'303',NULL,NULL,'144','260804121124','2026-08-25','2026-08-25','720','0','0','0','335','220','0','200','0','20','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(145,'303',NULL,NULL,'145','260804121229','2026-08-25','2026-08-25','721','0','0','0','351','230','0','220','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(146,'303',NULL,NULL,'146','260804121851','2026-08-25','2026-08-25','723','0','0','0','230','200','0','190','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(147,'303',NULL,NULL,'147','260804122019','2026-08-25','2026-08-25','724','0','0','0','210','190','0','180','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(148,'303',NULL,NULL,'148','260824144456','2026-08-25','2026-08-25','725','0','0','0','599','410','0','400','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(149,'303',NULL,NULL,'149','260824144619','2026-08-25','2026-08-25','726','0','0','0','499','400','0','390','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(150,'303',NULL,NULL,'150','260824150249','2026-08-25','2026-08-25','727','0','0','0','189','130','0','120','0','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL),(151,'303',NULL,NULL,'151','260824151434','2026-08-25','2026-08-25','728','0','0100','365','210','190','0','180.0000','180.0000','10','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'0','0',NULL,484,0,'2026-08-25 12:16:56',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MINIMUM_STOCK_LEVEL` int NOT NULL DEFAULT '0',
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
INSERT INTO `PROD_BATCH_IMPORT` VALUES (1,'303','1','HIM NEEM F/W 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','1','0','0','189','93.61','100.15','0','0','0','1','1649077111510','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(2,'303','2','HIM I/O L F/W 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','2','0','0','189','120','123.27','0','0','0','1','1649077111527','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(3,'303','20','GOW GHEE 100ML','04059020','1','GM','GOWARDHAN','GOWARDHAN','PCS','PCS','1','GST-12','GST-12','20','0','0','79','62.06','65.31','0','0','0','1','1649077111560','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(4,'303','21','GOW GHEE 200ML','04059020','1','GM','GOWARDHAN','GOWARDHAN','PCS','PCS','1','GST-12','GST-12','21','0','0','129','98.22','106.64','0','0','0','1','1649077111576','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(5,'303','22','GOW GHEE 500ML','04059020','1','GM','GOWARDHAN','GOWARDHAN','PCS','PCS','1','GST-12','GST-12','22','0','0','305','229.92','252.15','0','0','0','1','1649077111589','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(6,'303','23','GOW GHEE 1 LTR','04059020','1','GM','GOWARDHAN','GOWARDHAN','PCS','PCS','1','GST-12','GST-12','23','0','0','579','450','478.67','0','0','0','1','1649077111604','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(7,'303','3','HIM LEMON F/W 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','3','0','0','189','170','189','0','0','0','1','1649077111617','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(8,'303','4','HIM KESAR F/W 150ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','4','0','0','279','142','156','0','0','0','1','1649077111639','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(9,'303','5','HIM ALOE F/W 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','5','0','0','189','123','125','0','0','0','1','1649077111655','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(10,'303','6','HIM NEEM SCRUB 50GM','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','6','0','0','95','54','57.78','0','0','0','1','1649077111678','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(11,'303','7','HIM ALOE/F  F/W 50ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','7','0','0','95','50.41','53.93','0','0','0','1','1649077111693','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(12,'303','9','HIM NEEM F/W 50 ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','9','0','0','90','51','53.93','0','0','0','1','1649077111704','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(13,'303','10','HIM  PEEL OFF M 8 GM','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','10','0','0','10','6.38','7.7','0','0','0','1','1649077111717','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(14,'303','11','HIM NEEM SCRUB 8 GM','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','11','0','0','10','6.39','7.7','0','0','0','1','1649077111737','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(15,'303','12','HIM NEEM PACK 8 GM','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','12','0','0','10','6.39','7.7','0','0','0','1','1649077111753','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(16,'303','13','HIM MENS P/G F/W 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','13','0','0','189','102','108','0','0','0','1','1649077111766','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(17,'303','14','HIM POWER G  F/W 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','14','0','0','189','59.05','73.19','0','0','0','1','1649077111785','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(18,'303','15','HIM  INTE L F/W 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','15','0','0','189','65.99','73.19','0','0','0','1','1649077111801','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(19,'303','16','HIM REF CLE MILK 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','16','0','0','95','68.39','73.18','0','0','0','1','1649077111821','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(20,'303','17','HIM NEEM F/W 300ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','17','0','0','549','10.8','11.56','0','0','0','1','1649077111843','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(21,'303','25','HIM ANTI D SH 80ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','25','0','0','66','44.64','50.08','0','0','0','1','1649077111859','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(22,'303','26','HIM ANTI D SH 200ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','26','0','0','140','90','107.85','0','0','0','1','1649077111871','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(23,'303','27','HIM ANTI HF SH 80ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','27','0','0','61','46.79','47.76','0','0','0','1','1649077111884','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(24,'303','28','HIM GDC SH 180ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','28','0','0','159','44.64','47.76','0','0','0','1','1649077111904','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(25,'303','29','HIM C/C PEST 80GM','33061020','1','GM','HIMALAYA DC','HIMALAYA DC','GM','GM','1','GST-5','GST-5','29','0','0','52','35.99','38.52','0','0','0','1','1649077111920','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(26,'303','31','HIM C/C PEST 150GM','33061020','1','GM','HIMALAYA DC','HIMALAYA DC','GM','GM','1','GST-5','GST-5','31','0','0','99','57.6','65.49','0','0','0','1','1649077111943','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(27,'303','32','HIM AYURVEDA  PEST 150GM','33061020','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','32','0','0','130','110','115.4','0','0','0','1','1649077111959','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(28,'303','33','HIM ACTIVE F PEST 80GM','33061020','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','33','0','0','56','35','43','0','0','0','1','1649077111971','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(29,'303','34','HIM S/W PEST 80GM','33061020','1','GM','HIMALAYA DC','HIMALAYA DC','GM','GM','1','GST-5','GST-5','34','0','0','57','46','46.22','0','0','0','1','1649077111984','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(30,'303','35','HIM  S/W PEST 150GM','33061020','1','GM','HIMALAYA DC','HIMALAYA DC','GM','GM','1','GST-5','GST-5','35','0','0','115','64.8','73.19','0','0','0','1','1649077111994','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(31,'303','36','HIM STR LIP 4.5GM','33041000','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','36','0','0','150','108','115.56','0','0','0','1','1649077112006','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(32,'303','38','HIM STR LIP 2 GM','33041000','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','38','0','0','45','30','34.66','0','0','0','1','1649077112019','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(33,'303','18','HIM PRICKLY HEAT 100GM','NULL','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-12','GST-12','18','0','0','90','50.41','65.33','0','0','0','1','1649077112041','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(34,'303','37','HIM F/W 150 ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','37','0','0','155','100','119.41','0','0','0','1','1649077112056','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(35,'303','39','HIM FAIRNESS CR 15GM','33049910','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','39','0','0','48','34.56','37','0','0','0','1','1649077112069','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(36,'303','40','HIM SUNSCREEN L 50ML','33049910','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','40','0','0','125','94','97','0','0','0','1','1649077112080','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(37,'303','41','HIM KAJAL 1 GM','33042000','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','41','0','0','550','400','405','0','0','0','1','1649077112091','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(38,'303','42','HIM LIV 52 SYP 100ML','30049011','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-12','GST-12','42','70','0','120','70','72','0','0','0','1','1649077112104','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(39,'303','43','HIM LIV 52 SYP 200ML','30049011','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-12','GST-12','43','120','0','195','123','125','0','0','0','1','1649077112116','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(40,'303','44','HIM AHF SH 180ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','44','0','0','159','134','123','0','0','0','1','1649077112127','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(41,'303','45','HIM AHF SH 340ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','45','0','0','335','123','100.15','0','0','0','1','1649077112138','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(42,'303','46','HIM ANTI DAN  200ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','46','0','0','140','100','107.85','0','0','0','1','1649077112151','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(43,'303','47','HIM LIP B 10GM 24+2 JAR','33041000','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','47','0','0','960','678','727','0','0','0','1','1649077112160','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(44,'303','48','HIM S/B LIP BLAM 10GM','33041000','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','48','0','0','40','33','34.66','0','0','0','1','1649077112171','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(45,'303','49','HIM PUAR HANDS L 100ML','34013090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','49','0','0','50','32','38.52','0','0','0','1','1649077112201','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(46,'303','50','HIM AYURVEDA CLEAR SOAP 125GM','34011110','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-5','GST-5','50','0','0','78','45','52.36','0','0','0','1','1649077112220','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(47,'303','51','HIM NEEM SOAP 125GM','34011110','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-5','GST-5','51','0','0','60','68','52.36','0','0','0','1','1649077112236','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(48,'303','52','HIM NEEM PACK 100GM','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','52','0','0','170','105','107','0','0','0','1','1649077112249','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(49,'303','53','HIM NEEM SCRUB 100GM','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','53','0','0','189','105','105','0','0','0','1','1649077112260','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(50,'303','54','HIM BABY POW 50GM','33049120','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','54','0','0','60','123','137.89','0','0','0','1','1649077112272','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(51,'303','55','HIM G SOAP 125 GM','34011190','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','55','0','0','100','48','51.67','0','0','0','1','1649077112284','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(52,'303','56','HIM DARK S T F W 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','56','0','0','220','134','134','0','0','0','1','1649077112304','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(53,'303','57','HIM GREEN TULSI TEA','NULL','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-5','GST-5','57','0','0','70','40','58.92','0','0','0','1','1649077112324','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(54,'303','58','HIM TAN/O F/W 50ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','58','0','0','115','55','57.78','0','0','0','1','1649077112338','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(55,'303','59','HIM WINTER CR 50ML','33049930','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','59','0','0','99','63','65.48','0','0','0','1','1649077112358','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(56,'303','60','HIM A/R SOAP 125GM','34011110','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-5','GST-5','60','0','0','60','43','44','0','0','0','1','1649077112372','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(57,'303','61','HIM A SOAP N & T 75GM','34011110','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','61','0','0','36','31.9','37.9','0','0','0','1','1649077112386','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(58,'303','62','HIM BABY SOAP N 125M','34011190','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','62','0','0','100','45.94','55.19','0','0','0','1','1649077112397','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(59,'303','63','HIM BABY POW 100GM','33049120','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','63','0','0','120','45.94','55.12','0','0','0','1','1649077112408','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(60,'303','64','SHUBH MUHURAT BOX','34011110','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','64','0','0','565','360.43','389.28','0','0','0','1','1649077112420','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(61,'303','65','HIM DIAPERS 9S','96190090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-12','GST-12','65','0','0','130','87.38','94.37','0','0','0','1','1649077112432','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(62,'303','66','HIM KEASR PACK 100GM','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','66','0','0','135','93.79','95','0','0','0','1','1649077112443','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(63,'303','67','HIM N SKIN C 200ML','33049910','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','67','0','0','245','97.21','95','0','0','0','1','1649077112454','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(64,'303','68','HIM PDCF SCRUB 100GM','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','68','0','0','230','97.21','103','0','0','0','1','1649077112468','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(65,'303','69','HIM T R OR  F/W 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','69','0','0','220','100.79','103','0','0','0','1','1649077112477','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(66,'303','70','HIM P/MART CAP 5\\\'S','30049011','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-5','GST-5','70','0','0','112','60','51','0','0','0','1','1649077112489','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(67,'303','71','HIM NEEM F/W 200ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','71','0','0','449','202','210','0','0','0','1','1649077112502','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(68,'303','72','HIM NEEM F/W 150 ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','72','0','0','279','140','151','0','0','0','1','1649077112516','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(69,'303','73','HIM A/VERA G 100 ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','73','0','0','95','151.21','165','0','0','0','1','1649077112526','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(70,'303','74','HIM PANT X LARGE 54S','9610','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-12','GST-12','74','0','0','1249','487.5','456','0','0','0','1','1649077112536','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(71,'303','75','HIM PANT SMALL 54 S','9610','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-12','GST-12','75','0','0','899','478.15','490.74','0','0','0','1','1649077112546','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(72,'303','76','HIM BABY WIP 12 PES','3307','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','76','0','0','48','31','33.07','0','0','0','1','1649077112568','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(73,'303','77','HIM BABY WIP 24 PES','3307','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','77','0','0','85','55','58.57','0','0','0','1','1649077112589','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(74,'303','78','HIM BABY WIP 72 PES','3307','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','78','0','0','280','100','137.8','0','0','0','1','1649077112602','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(75,'303','79','HIM BABY WIP COMBI 72*2','3307','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','79','0','0','350','200','241.14','0','0','0','1','1649077112614','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(76,'303','80','HIM UNDER UYE C 15ML','33049990','1','GM','HIMALAYA DC','HIMALAYA DC','ML','PCS','1','GST-18','GST-18','80','0','0','259','470','481.6','0','0','0','1','1649077112625','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(77,'303','81','HIM BABY CR 50ML','33049930','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','81','0','0','115','50','51.67','0','0','0','1','1649077112637','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(78,'303','82','HIM  B LOTION 400ML','33049930','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','82','0','0','400','60','65.45','0','0','0','1','1649077112650','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(79,'303','83','HIM BABY LOTION 200ML','33049930','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','83','0','0','210','102','113.68','0','0','0','1','1649077112660','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(80,'303','84','HIM BABY POW 200GM','33049120','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','84','0','0','215','90','100','0','0','0','1','1649077112672','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(81,'303','85','HIM BABY POW 700GM','330491','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','85','0','0','475','25','27.55','0','0','0','1','1649077112683','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(82,'303','86','HIM BABY M OIL 50ML','33049990','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','86','0','0','75','35','37.89','0','0','0','1','1649077112694','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(83,'303','87','HIM BABY M OIL 100ML','330499','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','87','0','0','150','65','68.89','0','0','0','1','1649077112705','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(84,'303','88','HIM BABY M OIL 200ML','33049990','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','88','0','0','270','110','124.04','0','0','0','1','1649077112717','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(85,'303','89','HIM AHF COND 80ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','89','0','0','90','80','86.12','0','0','0','1','1649077112741','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(86,'303','90','HIM BABY SHAMPOO 100ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','90','0','0','115','60','62','0','0','0','1','1649077112757','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(87,'303','91','HIM BABY SHAMPOO 200ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','91','0','0','225','100','117.13','0','0','0','1','1649077112770','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(88,'303','93','HIM BABY WASH 100ML','33051090','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','93','0','0','130','55','58.56','0','0','0','1','1649077112779','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(89,'303','94','HIM GIFT PACK 285 RS','33049990','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','94','0','0','285','145','158.47','0','0','0','1','1649077112792','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(90,'303','95','HIM GIFT PACK W 7S','33049990','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','95','0','0','670','355','361.71','0','0','0','1','1649077112802','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(91,'303','96','HIM RASH CREAM 100GM','30049011','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','96','0','0','243','50','58.07','0','0','0','1','1649077112817','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(92,'303','97','HIM AY C SKIN SOAP 75GM','34011110','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','97','0','0','44','24','26.97','0','0','0','1','1649077112828','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(93,'303','98','HIM G B S 75+30GM POW FREE','340111','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','98','0','0','204','100','103.35','0','0','0','1','1649077112839','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(94,'303','99','HIM  APRICOT F/W 50ML','3304','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','99','0','0','75','49','57.78','0','0','0','1','1649077112852','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(95,'303','100','HIM CHAR  F/W 100ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','100','0','0','220','51','60','0','0','0','1','1649077112863','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(96,'303','101','HIM  CCBMF SCRUB 100GM','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','101','0','0','200','51','57.78','0','0','0','1','1649077112875','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(97,'303','102','HIM HONEY S 125GM','34011190','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','GM','1','GST-5','GST-5','102','0','0','60','29','26.97','0','0','0','1','1649077112887','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(98,'303','103','HIM BABY WASH 400ML','33049990','1','GM','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','103','0','0','350','45','50','0','0','0','1','1649077112909','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(99,'303','104','XPERT 120GM(96) CAKES 10RS','34054000','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','104','0','0','10','648.54','648.54','0','0','0','1','1649077112925','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(100,'303','107','HIM SHISHU A WIPES 99 RS','3307','1','GM','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-18','GST-18','107','0','0','99','66','68.21','0','0','0','1','1649077112938','05-04-2022','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(101,'303','110','HIM DAY CREAM 50GM','','1','KG','GOWARDHAN','GOWARDHAN','GM','GM','1','GST-18','GST-18','110','0','0','270','240','250','0','0','0','1','240601171910','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(102,'303','111','HIM R BABY S 125GM','3401119O','1','KG','HIMALAYA DC','HIMALAYA DC','PCS','PCS','1','GST-5','GST-5','111','0','0','100','33.5','33.5','0','0','0','1','240601172143','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(103,'303','112','HIM OIL C/L FW 100ML','33049990','1','KG','GOWARDHAN','GOWARDHAN','PCS','PCS','1','GST-18','GST-18','112','0','0','189','96.12','96.12','0','0','0','1','240601172515','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(104,'303','113','HIM REF BABY S 75GM','34011190','1','KG','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-5','GST-5','113','0','0','65','70.58','70.58','0','0','0','1','240601172728','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(105,'303','114','Uniwash 1kgx 12 packs M-140','340290','1','KG','GOWARDHAN','GOWARDHAN','PCS','PCS','1','GST-18','GST-18','114','0','0','140','90.26','90.26','0','0','0','1','240601173044','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(106,'303','116','HIM  G APRICOT S 100GM','33059090','1','KG','JAYESH ENTERPRISES KAVERI','JAYESH ENTERPRISES KAVERI','GM','GM','1','GST-18','GST-18','116','0','0','189','12','23','0','0','0','1','240626141330','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(107,'303','117','HIM V/C SB F/W 50ML','33049990','1','KG','JAYESH ENTERPRISES KAVERI','JAYESH ENTERPRISES KAVERI','ML','ML','1','GST-18','GST-18','117','0','0','115','33','34','0','0','0','1','240626141426','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(108,'303','118','HIM V/C BLUE B F/W 100ML','34013090','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','118','0','0','219','110','112','0','0','0','1','240626141644','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(109,'303','119','HIM DARK SCTF SCRUB 100GM','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-18','GST-18','119','0','0','210','101','122','0','0','0','1','240626141843','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(110,'303','120','HIM AHF CREAM 100MAL','33059030','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','120','0','0','100','67','68','0','0','0','1','240626142017','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(111,'303','121','HIM ANTI W CR 50GM','33049910','1','KG','JAYESH ENTERPRISES KAVERI','JAYESH ENTERPRISES KAVERI','PCS','PCS','1','GST-18','GST-18','121','0','0','270','128','129','0','0','0','1','240626142208','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(112,'303','130','HIM C C PEST 80GM','33061020','1','KG','GOWARDHAN','GOWARDHAN','GM','GM','1','GST-18','GST-18','130','34','0','59','43','45','0','0','0','1','240710140627','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(113,'303','132','HIM V/C B F/W 50ML','33049990','1','KG','JAYESH ENTERPRISES KAVERI','JAYESH ENTERPRISES KAVERI','ML','ML','1','GST-18','GST-18','132','0','0','115','90','80','0','0','0','1','240714200925','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(114,'303','139','BABELOIS D PANTS L-30','96190040','1','KG','JAYESH ENTERPRISES KAVERI','JAYESH ENTERPRISES KAVERI','PCS','PCS','1','GST-12','GST-12','139','0','0','399','142.93','210','0','0','0','1','240714201042','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(115,'303','140','HIM TAN O F/W 100ML','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','140','0','0','220','145','190','0','0','0','1','240714201327','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(116,'303','135','KAVERI E FAST D BROWN RS-20','33059030','1','KG','JAYESH ENTERPRISES KAVERI','JAYESH ENTERPRISES KAVERI','PCS','PCS','1','GST-18','GST-18','135','0','0','20','8','11','0','0','0','1','240714201639','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(117,'303','138','HIM KESAR F/W 100ML','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','PCS','PCS','1','GST-18','GST-18','138','0','0','189','100','111','0','0','0','1','240726195954','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(118,'303','162','HIM BRIGHTENING VCOSC 50GM','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-18','GST-18','162','0','0','275','190','192','0','0','0','1','251202071503','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(119,'303','400','HIM VITAMIN C/O 100ML','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','400','0','0','219','156','168','0','0','0','1','260225204602','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(120,'303','401','HIM VIT C/O FW 50ML','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','401','0','0','115','156','158','0','0','0','1','260225204704','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(121,'303','402','HIM HEENA 120GM','33059040','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-18','GST-18','402','0','0','75','54','55','0','0','0','1','260225204838','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(122,'303','403','HIM CUCUMBER  S 125GM','34011110','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-5','GST-5','403','0','0','60','44','46','0','0','0','1','260225205049','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(123,'303','404','HIM AYURVEDA S 125GM','3401110','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-5','GST-5','404','0','0','70','43','54','0','0','0','1','260225205219','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(124,'303','405','HIM OIL C L/F  50ML','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','405','0','0','95','65','321','0','0','0','1','260225205419','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(125,'303','406','HIM ALOE V F/W 200ML','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','406','0','0','499','326','327','0','0','0','1','260225205621','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(126,'303','407','HIM AHF SHAM 650ML','33051090','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-5','GST-5','407','0','0','755','566','567','0','0','0','1','260225221522','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(127,'303','601','HIM DARK SFP 100GM','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-18','GST-18','601','0','0','230','170','180','0','0','0','1','260704181208','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(128,'303','701','YEZIGLOW H OIL 100ML','39152000','1','KG','VIVE COSMATIC','VIVE COSMATIC','ML','ML','1','GST-5','GST-5','701','0','0','349','226.01','290','0','0','0','1','260722143531','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(129,'303','702','P RELIF OIL 60ML','33049011','1','KG','VIVE COSMATIC','VIVE COSMATIC','ML','ML','1','GST-5','GST-5','702','0','0','160','103.61','120','0','0','0','1','260722144622','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(130,'303','703','P EXFOGLOW S 100GM','33049910','1','KG','VIVE COSMATIC','VIVE COSMATIC','GM','GM','1','GST-18','GST-18','703','0','0','169','97.38','110','0','0','0','1','260722145003','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(131,'303','704','P HYDRCOIN F/W 100ML','33049910','1','KG','VIVE COSMATIC','VIVE COSMATIC','ML','ML','1','GST-18','GST-18','704','0','0','180','103.72','110','0','0','0','1','260723152701','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(132,'303','705','P LUMI SHIELD 100ML','33049910','1','KG','VIVE COSMATIC','VIVE COSMATIC','ML','ML','1','GST-18','GST-18','705','0','0','190','109.49','112','0','0','0','1','260723152904','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(133,'303','706','P SUGAR CC CAPSULE','33049011','1','KG','VIVE COSMATIC','VIVE COSMATIC','PCS','PCS','1','GST-5','GST-5','706','0','0','600','388.75','400','0','0','0','1','260723153134','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(134,'303','707','P VITAMIN C F/W 100ML','33049910','1','KG','VIVE COSMATIC','VIVE COSMATIC','ML','ML','1','GST-18','GST-18','707','0','0','179','103.18','110','0','0','0','1','260723153250','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(135,'303','122','HIM NEEM PACK 25GM','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-18','GST-18','122','0','0','55','40','45','0','0','0','1','260802095105','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(136,'303','123','HIM NEEM SCRUB 25GM','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-18','GST-18','123','0','0','55','40','46','0','0','0','1','260802095216','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(137,'303','124','HIM WALNET SCRUB 25GM','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-18','GST-18','124','0','0','55','40','46','0','0','0','1','260802095311','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(138,'303','125','HIM GB SOAP 5+1 50GM','34011190','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-5','GST-5','125','0','0','230','200','205','0','0','0','1','260802095928','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(139,'303','126','HIM EMB SOAP 125GM','34011190','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-5','GST-5','126','0','0','100','80','81','0','0','0','1','260802101101','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(140,'303','127','HIM AD SH PATTI RS 2','33051090','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-5','GST-5','127','0','0','32','20','22','0','0','0','1','260802183753','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(141,'303','128','HIM AHF SH PATTI RS 2','33051090','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-5','GST-5','128','0','0','32','20','22','0','0','0','1','260802183909','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(142,'303','129','HIM STRAB F/W 100ML','34013090','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','129','0','0','219','150.49','160','0','0','0','1','260803125621','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(143,'303','712','HIM REF C TONER 100ML','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','712','0','0','110','79.2','80','0','0','0','1','260803131531','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(144,'303','720','HIM GDC SH 340ML','33051090','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-5','GST-5','720','0','0','335','200','220','0','0','0','1','260804121124','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(145,'303','721','HIM DR SH 340ML','33051090','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-5','GST-5','721','0','0','351','220','230','0','0','0','1','260804121229','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(146,'303','723','HIM DARK SPOT F P 100GM','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-18','GST-18','723','0','0','230','190','200','0','0','0','1','260804121851','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(147,'303','724','HIM TOF SURUB 100GM','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-18','GST-18','724','0','0','210','180','190','0','0','0','1','260804122019','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(148,'303','725','HIM NEEM F/W 400ML','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','ML','GM','1','GST-18','GST-18','725','0','0','599','400','410','0','0','0','1','260824144456','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(149,'303','726','HIM LEMON F/W 200ML','33049990','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','726','0','0','499','390','400','0','0','0','1','260824144619','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(150,'303','727','HIM NEEM F/W 100ML','33039990','1','KG','HIMALAYA FC','HIMALAYA FC','ML','ML','1','GST-18','GST-18','727','0','0','189','120','130','0','0','0','1','260824150249','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484),(151,'303','728','HIM RICH CB LIP 4*5 GM','NULL','1','KG','HIMALAYA FC','HIMALAYA FC','GM','GM','1','GST-18','GST-18','728','0','0','210','180','190','0','0','0','1','260824151434','2026-08-25','2026-08-25','7',0.00,0.00,0.00,0.00,0,484);
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_STOCK_REPORT`
--

DROP TABLE IF EXISTS `PROD_STOCK_REPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_STOCK_REPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) DEFAULT '0',
  `PROD_ID` varchar(50) DEFAULT '0',
  `PROD_BATCH_ID` varchar(50) DEFAULT '0',
  `PROD_CODE` varchar(100) DEFAULT NULL,
  `PROD_DESCRIPTION` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(100) DEFAULT NULL,
  `MFG_DATE` date DEFAULT NULL,
  `PACK` varchar(50) DEFAULT '0',
  `PROD_WEIGHT` int NOT NULL DEFAULT '0',
  `PROD_WEIGHT_UNIT` int NOT NULL DEFAULT '0',
  `MRP` decimal(18,2) DEFAULT '0.00',
  `PREV_OP_STOCK` decimal(18,2) DEFAULT '0.00',
  `OP_STOCK` decimal(18,2) DEFAULT '0.00',
  `OP_VALUE` decimal(18,2) DEFAULT '0.00',
  `TOTAL_PURCHASE` decimal(18,2) DEFAULT '0.00',
  `TOTAL_PURCHASE_RETURN` decimal(18,2) DEFAULT '0.00',
  `TOTAL_PURCHASE_CHALLAN` decimal(18,2) DEFAULT '0.00',
  `PURCHASE` decimal(18,2) DEFAULT '0.00',
  `PURCHASE_VALUE` decimal(18,2) DEFAULT '0.00',
  `TOTAL_SALES` decimal(18,2) DEFAULT '0.00',
  `TOTAL_SALES_RETURN` decimal(18,2) DEFAULT '0.00',
  `TOTAL_SALES_CHALLAN` decimal(18,2) DEFAULT '0.00',
  `SALES` decimal(18,2) DEFAULT '0.00',
  `SALES_VALUE` decimal(18,2) DEFAULT '0.00',
  `CLOSING_STOCK` decimal(18,2) DEFAULT '0.00',
  `PUR_AMT` decimal(18,2) DEFAULT '0.00',
  `PUR_TAX_AMT` decimal(18,2) DEFAULT '0.00',
  `PUR_AMT_WITH_GST` decimal(18,2) DEFAULT '0.00',
  `PUR_AMT_WITH_GST_CESS` decimal(18,2) DEFAULT '0.00',
  `SALE_AMT` decimal(18,2) DEFAULT '0.00',
  `SALE_TAX_AMT` decimal(18,2) DEFAULT '0.00',
  `SALE_AMT_WITH_GST` decimal(18,2) DEFAULT '0.00',
  `SALE_AMT_WITH_GST_CESS` decimal(18,2) DEFAULT '0.00',
  `PUR_SALE_DATE` date DEFAULT NULL,
  `INVOICE_NO` varchar(100) DEFAULT NULL,
  `PUR_RATE` decimal(18,2) DEFAULT '0.00',
  `SALE_RATE` decimal(18,2) DEFAULT '0.00',
  `PUR_VAT` decimal(10,2) DEFAULT '0.00',
  `SALES_VAT` decimal(10,2) DEFAULT '0.00',
  `PUR_UNIT` varchar(50) DEFAULT '0',
  `SALE_UNIT` varchar(50) DEFAULT '0',
  `TAX_AGAINST` varchar(50) DEFAULT '0',
  `CESS` decimal(10,2) DEFAULT '0.00',
  `CL_VALUE` decimal(18,2) DEFAULT '0.00',
  `PUR_WEIGHT` decimal(18,2) DEFAULT '0.00',
  `PUR_WEIGHT_UNIT` varchar(50) DEFAULT '0',
  `SALES_WEIGHT` decimal(18,2) DEFAULT '0.00',
  `SALES_WEIGHT_UNIT` varchar(50) DEFAULT '0',
  `HSN_SAC_CODE` varchar(50) DEFAULT '',
  `GROUP_NAME` varchar(100) DEFAULT '',
  `SALES_ITEM_ID` varchar(50) DEFAULT '0',
  `TABLE_NAME` varchar(100) DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `idx_prod` (`PROD_ID`),
  KEY `idx_company` (`COMPANY_ID`),
  KEY `idx_invoice` (`INVOICE_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_STOCK_REPORT`
--

LOCK TABLES `PROD_STOCK_REPORT` WRITE;
/*!40000 ALTER TABLE `PROD_STOCK_REPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_STOCK_REPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PSR_MANAGER`
--

DROP TABLE IF EXISTS `PSR_MANAGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PSR_MANAGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PSR_NAME` varchar(255) DEFAULT NULL,
  `PSR_CODE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PSR_MANAGER`
--

LOCK TABLES `PSR_MANAGER` WRITE;
/*!40000 ALTER TABLE `PSR_MANAGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PSR_MANAGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int DEFAULT '0',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int DEFAULT '0',
  `M_ROUND_OFF` int DEFAULT '0',
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
INSERT INTO `PURCHASE` VALUES (1,'303',NULL,NULL,'2026-08-25',236,'123',NULL,'9000.00','0','0','0.00','0.00','0','0','0','1620.00','810','810','0.00','0','0','0','10620.00','10620.00','50/0','50.00','90000','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'0.00','0','0',0,'0',0,NULL,NULL,0,0,'0','0','0',484,NULL,'484','484',NULL,0,'2026-08-25 13:03:33','2026-08-25 13:16:12',''),(2,'303',NULL,NULL,'2026-08-01',236,'13',NULL,'4500.00','0','0','0.00','0.00','0','0','0','810.00','405','405','0.00','0','0','0','5310.00','5310.00','25/0','25.00','45000','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'0.00','0','0',0,'0',0,NULL,NULL,0,0,'0','0','0',484,NULL,'484','484',NULL,0,'2026-08-25 13:10:47','2026-08-25 13:12:52',''),(3,'303',NULL,NULL,'2026-08-25',236,'123',NULL,'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','',3,'0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'1',NULL,NULL,'0','0','0',0,'0',0,'0','0',0,0,'0','0','0',484,NULL,'484','484',NULL,1,'2026-08-25 13:16:53','2026-08-25 13:16:53',''),(4,'303',NULL,NULL,'2026-08-25',236,'123',NULL,'1440.00','0','0','0.00','0.00','0','0','0','259.20','129.6','129.6','0.00','0','0','-0.20','1699.00','1699.20','12/0','12.00','14400','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'1',NULL,NULL,'0.00','0','0',0,'0',0,'0','0',0,0,'0','0','0.00',484,NULL,'484','484',NULL,0,'2026-08-25 13:17:31','2026-08-25 13:18:36',''),(5,'303',NULL,NULL,'2026-08-01',236,'123',NULL,'3600.00','0','0','0.00','0.00','0','0','0','648.00','324','324','0.00','0','0','0','4248.00','4248.00','20/0','20.00','36000','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'1',NULL,NULL,'0.00','0','0',0,'0',0,'0','0',0,0,'0','0','0.00',484,NULL,'484','484',NULL,0,'2026-08-25 13:19:29','2026-08-25 13:20:22',''),(6,'303',NULL,NULL,'2026-08-25',236,'123',NULL,'1800.00','0','0','0.00','0.00','0','0','0','648.00','324','324','0.00','0','0','0','4248.00','648.00','10/0','10.00','18000','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'1',NULL,NULL,'0.00','0','0',0,'0',0,'1800.00','0',0,0,'0','0','0.00',484,NULL,'484','484',NULL,0,'2026-08-25 13:21:14','2026-08-25 13:22:06',''),(7,'303',NULL,NULL,'2026-08-25',236,'989',NULL,'2759.04','0','0','0.00','0.00','0','0','0','331.08','165.54','165.54','0.00','0','0','0.12','3090.00','3090.12','12/0','12.00','2759.040','',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'0.00','0','0',0,'0',0,NULL,NULL,0,0,'0','0','0',484,NULL,'484','484',NULL,0,'2026-08-25 13:26:41','2026-08-25 13:26:41','');
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUPPLIER_ID',
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'PUR_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text,
  `INV_NO` text,
  `LOGIN_ID` int DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
INSERT INTO `PURCHASE_ITEM` VALUES (1,'303',NULL,NULL,151,151,1,2,'180.0000','18.00','9','9','0','0','0',1,'236','50.00','50','0','0',NULL,30,'0','0','0','0','9000.0000','1620.00','810','810','',NULL,NULL,'','0','2026-08-25','1','7','2','0','0','0','210',NULL,NULL,'0',NULL,'0.00','0','0',NULL,NULL,NULL,484,'484','484',NULL,0,'2026-08-25 13:03:33','2026-08-25 13:16:12',NULL),(2,'303',NULL,NULL,151,151,2,2,'180.0000','18.00','9','9','0','0','0',1,'236','25.00','25','0','0',NULL,0,'0','0','0','0','4500.0000','810.00','405','405','',NULL,NULL,'','0','2026-08-01','1','7','2','0','0','0','210',NULL,NULL,'0',NULL,'0.00','0','0',NULL,NULL,NULL,484,'484','484',NULL,0,'2026-08-25 13:10:47','2026-08-25 13:12:52',NULL),(6,'303',NULL,NULL,2,2,4,7,'120.0000','18.00','9','9','0','0','0',1,'236','12.00','012','0','0','012',0,'0','0','0','0','1440.00','259.20','129.6','129.6','','1',NULL,'','0','2026-08-25','1','7','7','0','0','0','1440.00','0','0','0','0','0','0','0',NULL,NULL,NULL,484,'484','484',NULL,0,'2026-08-25 13:17:31','2026-08-25 13:18:36',NULL),(8,'303',NULL,NULL,151,151,5,2,'180.0000','18.00','9','9','0','0','0',1,'236','20.00','20','0','0','20',0,'0','0','0','0','3600.00','648.00','324','324','','1',NULL,'','0','2026-08-01','1','7','2','0','0','0','3600.00','0','0','0','0','0','0','0',NULL,NULL,NULL,484,'484','484',NULL,0,'2026-08-25 13:19:29','2026-08-25 13:20:22',NULL),(9,'303',NULL,NULL,151,151,6,2,'180.0000','18.00','9','9','0','0','0',1,'236','10.00','010','0','0','010',10,'0','0','0','0','1800.00','324.00','162','162','','1',NULL,'','0','2026-08-25','1','7','2','0','0','0','1800.00','0','0','0','0','0','0','0',NULL,NULL,NULL,484,'484','484',NULL,0,'2026-08-25 13:21:14','2026-08-25 13:22:06',NULL),(11,'303',NULL,NULL,5,5,7,7,'229.9200','12.00','6','6','0','0','0',1,'236','12.00','012','0','0',NULL,0,'0','0','0','0','2759.0400','331.08','165.54','165.54','',NULL,NULL,'','','2026-08-25','1','7','7','0','0','0','305',NULL,NULL,'0',NULL,'0.00','0','0',NULL,NULL,NULL,484,'484','484',NULL,0,'2026-08-25 13:26:41','2026-08-25 13:26:41',NULL),(12,'303',NULL,NULL,151,151,7,2,'180.0000','18.00','9','9','0','0','0',1,'236','0','0','0','0',NULL,100,'0','0','0','0','0','0.00','0','0','',NULL,NULL,'','','2026-08-25','1','7','2','0','0','0','210',NULL,NULL,'0',NULL,'0.00','0','0',NULL,NULL,NULL,484,'484','484',NULL,0,'2026-08-25 13:26:41','2026-08-25 13:26:41',NULL);
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT 'mrp_value',
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `PROD_ID` int NOT NULL,
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PACK` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BOX` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN_QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `FREE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `CESS_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT 'PUR_DATE',
  `WEIGHT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PRICE_PER` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SALE_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DMG_MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CLOUD_SYNC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `INV_ARR` text COLLATE utf8mb4_general_ci COMMENT 'add_amt',
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'less_amt',
  `LOGIN_ID` int DEFAULT '0',
  `CREATED_BY` int DEFAULT NULL,
  `UPDATED_BY` int DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_TS` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SUPPLIER_ID` int DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8mb4_general_ci,
  `GROUP_ID` int DEFAULT NULL,
  `FINAL_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BATCH_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TCS_TAX` varchar(100) COLLATE utf8mb4_general_ci DEFAULT '0',
  `REFERENCE_NO` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `BROKER_ID` int DEFAULT '0',
  `LOGIN_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
INSERT INTO `PURCHASE_ORDER` VALUES (1,'303',NULL,NULL,'2026-08-25',236,'PC000001','PC','000001','',0,'8','2','16200','0','0','0.00','0','0','0','0','2916','1458','1458','0','0','0','0','0','0','19116','19116.00','90/0','90.00','162000','',3,1,NULL,NULL,0,'0.00','0',0,'0',0,'0',1,0,484,NULL,'0','0',NULL,0,'2026-08-25 13:23:00','2026-08-25 13:23:00',''),(2,'303',NULL,NULL,'2026-08-25',236,'PC000002','PC','000002','',0,'8','2','1178.64','0','0','0.00','0','0','0','0','141.44','70.72','70.72','0','0','0','-0.08','0','0','1320','1320.08','12/0','12.00','1178.64','',3,1,NULL,NULL,0,'0.00','0',0,'0',0,'0',1,0,484,NULL,'0','0',NULL,0,'2026-08-25 13:25:34','2026-08-25 13:25:34',''),(3,'303',NULL,NULL,'2026-08-25',233,'PC000003','PC','000003','',0,'8','2','1123.32','0','0','0.00','0','0','0','0','202.2','101.1','101.1','0','0','0','+0.48','0','0','1326','1325.52','12/0','12.00','1123.32','',3,1,NULL,NULL,0,'0.00','0',0,'0',0,'0',1,0,484,NULL,'0','0',NULL,0,'2026-08-25 13:28:33','2026-08-25 13:28:33','');
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUPPLIER_ID',
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'PUR_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
INSERT INTO `PURCHASE_ORDER_ITEM` VALUES (1,'303',NULL,NULL,151,151,1,2,'180.0000','18.00','9','9','0','0','0',1,'236','90.00','90','0','0',NULL,10,'0','0','0','0','16200.00','2916.00','1458','1458','',NULL,NULL,'','0','2026-08-25','1','7','2','0','0','0','210',484,NULL,'484','484','1',0,'2026-08-25 13:22:43','2026-08-25 13:23:00',NULL),(3,'303',NULL,NULL,4,4,2,7,'98.2200','12.00','6','6','0','0','0',1,'236','12.00','012','0','0',NULL,0,'0','0','0','0','1178.64','141.44','70.72','70.72','',NULL,NULL,'','0','2026-08-25','1','7','7','0','0','0','129',484,NULL,'484','484','1',0,'2026-08-25 13:23:38','2026-08-25 13:25:34',NULL),(5,'303',NULL,NULL,1,1,3,7,'93.6100','18.00','9','9','0','0','0',1,'233','12.00','012','0','0',NULL,0,'0','0','0','0','1123.32','202.20','101.1','101.1','',NULL,NULL,'','0','2026-08-25','1','7','7','0','0','0','189',484,NULL,'484','484','1',0,'2026-08-25 13:27:22','2026-08-25 13:28:33',NULL);
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REGISTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Parent_Superstockist_Distributor',
  `PARENT_USER_NAME` varchar(255) DEFAULT NULL,
  `PARENT_PASSWORD` varchar(255) DEFAULT NULL,
  `IS_SUPERSTOCKIST` tinyint NOT NULL DEFAULT '0',
  `SUPERSTOCKIST_ID` int DEFAULT '0',
  `EXTRA_1` varchar(255) DEFAULT NULL,
  `EXTRA_2` varchar(255) DEFAULT NULL,
  `ADD1` text,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REPORTING_MANAGER_ID` varchar(255) DEFAULT NULL,
  `TRAINER_ID` varchar(255) DEFAULT NULL,
  `PSR_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=485 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (484,'303','0','emDi8JwEsS','Samarth','emDi8JwEsS','samarth@yopmail.com',NULL,NULL,'Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'484','484','',0,'2026-08-25 12:07:00','2026-08-25 12:07:00',NULL,NULL,NULL);
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REMARKS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int DEFAULT '0',
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-08-25 12:06:55',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REPORTING_MANAGER`
--

DROP TABLE IF EXISTS `REPORTING_MANAGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REPORTING_MANAGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REPORTING_MANAGER_NAME` varchar(255) DEFAULT NULL,
  `REPORTING_MANAGER_CODE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REPORTING_MANAGER`
--

LOCK TABLES `REPORTING_MANAGER` WRITE;
/*!40000 ALTER TABLE `REPORTING_MANAGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `REPORTING_MANAGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text,
  `MAC_ID` int DEFAULT '0',
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text,
  `S_ADD2` text,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `DISCOUNT2` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `PROSPECT` varchar(255) DEFAULT NULL,
  `CHANNELTYPE_NAME` varchar(255) DEFAULT NULL,
  `TIER` varchar(255) DEFAULT NULL,
  `CUSTOMER_CODE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=289 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'303',NULL,NULL,'Cash',14,'19373179.61','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'-3226070',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(2,'303',NULL,NULL,'Additional Tax(GST)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(3,'303',NULL,NULL,'Advertisement & Publicity',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'3',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(4,'303',NULL,NULL,'Bad Debts Written Off',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'4',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(5,'303',NULL,NULL,'Bank Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(6,'303',NULL,NULL,'Bonus',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'6',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(7,'303',NULL,NULL,'Books & Periodicals',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(8,'303',NULL,NULL,'Brokerage',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'8',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(9,'303',NULL,NULL,'C Form Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'9',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(10,'303',NULL,NULL,'C Form Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'10',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(11,'303',NULL,NULL,'Capital Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'11',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(12,'303',NULL,NULL,'Central Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'12',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(13,'303',NULL,NULL,'CGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'13',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(14,'303',NULL,NULL,'Charity & Donations',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'14',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(15,'303',NULL,NULL,'Commissions on Sales',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(16,'303',NULL,NULL,'Computers',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'16',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(17,'303',NULL,NULL,'Conveyance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'17',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(18,'303',NULL,NULL,'CST Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'18',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(19,'303',NULL,NULL,'Development Taxes',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'19',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(20,'303',NULL,NULL,'Edu. Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'20',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(21,'303',NULL,NULL,'Edu. Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(22,'303',NULL,NULL,'Edu. Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'22',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(23,'303',NULL,NULL,'Edu. Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'23',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(24,'303',NULL,NULL,'Excise Duties',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'24',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(25,'303',NULL,NULL,'IGST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'25',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(26,'303',NULL,NULL,'SGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'26',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(27,'303',NULL,NULL,'Legal Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(28,'303',NULL,NULL,'Market Fees',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'28',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(29,'303',NULL,NULL,'National VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'29',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(30,'303',NULL,NULL,'RDF',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'30',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(31,'303',NULL,NULL,'Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'31',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(32,'303',NULL,NULL,'SHE Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'32',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(33,'303',NULL,NULL,'SHE Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'33',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(34,'303',NULL,NULL,'SHE Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'34',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(35,'303',NULL,NULL,'SHE Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'35',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(36,'303',NULL,NULL,'Surcharge On VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'36',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(37,'303',NULL,NULL,'TDS (Advertisment)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'37',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(38,'303',NULL,NULL,'TDS (Commission)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'38',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(39,'303',NULL,NULL,'TDS (Contractor)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'39',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(40,'303',NULL,NULL,'TDS (Interest)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'40',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(41,'303',NULL,NULL,'TDS (Rent)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'41',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(42,'303',NULL,NULL,'TDS (Salery)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'42',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(43,'303',NULL,NULL,'VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'43',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(44,'303',NULL,NULL,'Telephone Expenses',19,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'44',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(45,'303',NULL,NULL,'Customer Entertainment Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'45',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(46,'303',NULL,NULL,'Depriciation A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'46',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(47,'303',NULL,NULL,'Discount',20,'77329.8','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'47',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(48,'303',NULL,NULL,'Freight & Forwarding Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'48',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(49,'303',NULL,NULL,'Interest Payable A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'49',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(50,'303',NULL,NULL,'Job Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'50',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(51,'303',NULL,NULL,'Labour',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'51',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(52,'303',NULL,NULL,'Legal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'52',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(53,'303',NULL,NULL,'Misc. Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(54,'303',NULL,NULL,'Miscellaneous Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'54',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(55,'303',NULL,NULL,'Office Maintenance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'55',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(56,'303',NULL,NULL,'Office Rent',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','1','0',NULL,'0','1',NULL,'56',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0','0','',NULL,1,NULL,1,'1','0','0',NULL,'0','-12000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(57,'303',NULL,NULL,'Office Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'57',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(58,'303',NULL,NULL,'Postal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'58',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(59,'303',NULL,NULL,'Printing & Stationery',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','1','0',NULL,'0','1',NULL,'59',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0','0','',NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(60,'303',NULL,NULL,'Rounded Off - Sales',20,'0','CR','DEFAULT',NULL,NULL,'21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','1','0',NULL,'0','1',NULL,'60',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0','0','',NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(61,'303',NULL,NULL,'Salery',20,'20000','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','1','0',NULL,'0','1',NULL,'61',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0','0','',NULL,1,NULL,1,'1','0','0',NULL,'0','-34000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(62,'303',NULL,NULL,'Sales Promotion Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'62',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(63,'303',NULL,NULL,'Sewing Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'63',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(64,'303',NULL,NULL,'Staff Welfare Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'64',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(65,'303',NULL,NULL,'Stitching',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'65',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(66,'303',NULL,NULL,'Travelling Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'66',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(67,'303',NULL,NULL,'Water & Electricity Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'67',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(68,'303',NULL,NULL,'Earnest Money',29,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'68',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(69,'303',NULL,NULL,'Furnituer & Fixture',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'69',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(70,'303',NULL,NULL,'Office Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'70',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(71,'303',NULL,NULL,'Plants & Machinery',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'71',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(72,'303',NULL,NULL,'CST Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'72',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(73,'303',NULL,NULL,'Interstate Retail Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'73',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(74,'303',NULL,NULL,'Local B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'74',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(75,'303',NULL,NULL,'Sales',27,'58302987.77','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'75',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(76,'303',NULL,NULL,'Sales Retail 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'76',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(77,'303',NULL,NULL,'Sales Retail 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'77',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(78,'303',NULL,NULL,'Sales VAT 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'78',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(79,'303',NULL,NULL,'Sales VAT 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'79',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(80,'303',NULL,NULL,'Dammi',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'80',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(81,'303',NULL,NULL,'Income From National VAT',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'81',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(82,'303',NULL,NULL,'Interest Receivable A/c',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'82',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(83,'303',NULL,NULL,'Rate Adjustment',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'83',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(84,'303',NULL,NULL,'Mall Khata A/c',30,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'84',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(85,'303',NULL,NULL,'Profit & Loss',9,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'85',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(86,'303',NULL,NULL,'Purchase',25,'53645913.6','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'86',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(87,'303',NULL,NULL,'Purchase Retail 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'87',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(88,'303',NULL,NULL,'Purchase Retail 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'88',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(89,'303',NULL,NULL,'Purchase VAT 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'89',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(90,'303',NULL,NULL,'Purchase VAT 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'90',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(91,'303',NULL,NULL,'Replacement',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'91',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(92,'303',NULL,NULL,'Stock',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'92',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(93,'303',NULL,NULL,'Salery & Bonus Payable',24,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'93',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(94,'303',NULL,NULL,'Interstate B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'94',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(95,'303',NULL,NULL,'CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'95',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(96,'303',NULL,NULL,'Additional CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'96',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(97,'303',NULL,NULL,'SCHEME-1',20,'35711.8406','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'97',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(98,'303',NULL,NULL,'SCHEME-2',20,'1324.16','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'98',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-08-25 12:06:57','2026-08-25 12:06:57',NULL,NULL,NULL,NULL),(99,'303',NULL,NULL,'YATHRTH KIRANA',5,'0','DR','KHARDI','KHARDI','KHARDI','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'99',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','175',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:05','2026-08-25 12:15:05',NULL,NULL,NULL,NULL),(100,'303',NULL,NULL,'YASHODHA SUPER MARKET',5,'0','DR','KHARDI','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'100',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','172',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(101,'303',NULL,NULL,'VITHAAI MEDICAL',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'101',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','209',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(102,'303',NULL,NULL,'VIREN TRADING',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'102',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','215',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(103,'303',NULL,NULL,'VIMAL TRADING',5,'0','DR','APMC VASHI NAVI MUMBAI-400705','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27','27AACPG5120B1ZI',NULL,'',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'103',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','304',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(104,'303',NULL,NULL,'VIKRAM MEDICAL',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'104',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','208',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(105,'303',NULL,NULL,'VIJAY RAMAKANT KIRANA',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'105',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','184',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(106,'303',NULL,NULL,'VERSHIKA ENTERPRISES',5,'0','DR','AMBERNATH EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'106',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','294',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(107,'303',NULL,NULL,'THE HIMALAYA DRUG COMPANY',11,'0','DR','BLDG NO-2','PRITHAVI COMPLEX','BHIWANDI','21','421302',NULL,'9004661564','',NULL,'27','27AADFT3025B1ZP',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'107',NULL,NULL,NULL,NULL,NULL,'','AADFT3025B','0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','147',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(108,'303',NULL,NULL,'THE HIMALAYA DRUG COMPANY',11,'0','DR','BLDG NO-A2-1& 6& A3-1,2,3,4,5,6','PRITHAVI COMPLEX','BHIWANDI','21','421302',NULL,'9004661564','',NULL,'27','27AADFT3025B1ZP',NULL,'',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'108',NULL,NULL,NULL,NULL,NULL,'','AADFT3025B','0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','146',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(109,'303',NULL,NULL,'THE CARE SWAST AUSHADHI KENDRA',5,'0','DR','NEAR SANJIVANI MEDICO GUPTE ROAD DOM WEST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27','27AUJPK2795D1ZF',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'109',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','270',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(110,'303',NULL,NULL,'SWAST DIAPER HOUSE',5,'0','DR','OLD DOMBIVALI NEAR SHIV MANDIR DOM WEST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'110',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','291',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(111,'303',NULL,NULL,'SWARAJ DIAPER HOUSE',5,'0','DR','NEAR CHAR RASTA DOMBIVALI EAST','NULL','NULL','21',NULL,NULL,'9967387639','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'111',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','275',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(112,'303',NULL,NULL,'SWAMI SAMARTH MEDICAL',5,'0','DR','VASIND','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'112',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','233',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(113,'303',NULL,NULL,'SWAMI SAMARTH KIRANA',5,'0','DR','KINHVALI','KINHVALI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'113',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','188',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(114,'303',NULL,NULL,'SWAMI MEDICAL',5,'0','DR','KINHVALI','KINHVALI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'114',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','187',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(115,'303',NULL,NULL,'SWAMI KIRANA',5,'0','DR','KHARDI','KHARDI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'115',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','182',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(116,'303',NULL,NULL,'SUSHIL MEDICAL',5,'0','DR','NEAR DIPAK STORE','NULL','NULL','21',NULL,NULL,'9860996076','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'116',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','234',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(117,'303',NULL,NULL,'SUNIL MEDICAL',5,'0','DR','KHARDI','KHARDI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'117',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','177',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(118,'303',NULL,NULL,'SUNIL MEDICAL',5,'0','DR','KASARA','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'118',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','171',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(119,'303',NULL,NULL,'SUDHIR SETH',5,'0','DR','SONAR PADA  DOMBIVALI EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'119',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','257',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:06','2026-08-25 12:15:06',NULL,NULL,NULL,NULL),(120,'303',NULL,NULL,'SONU SETH KIRANA',5,'0','DR','KINHVALI','KINHVALI','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'120',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','164',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(121,'303',NULL,NULL,'SIDDHIVINAYAK MEDICAL',5,'0','DR','NEAR ICICI ATM','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'121',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','226',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(122,'303',NULL,NULL,'SHREYA SALES',5,'0','DR','SHOP NO,12 GR FLOOR BLDG NO-3-B ,SWAGT CHS','DAMODER PARK LBS MARG GHATKOPER WEST-400086','MUMBAI','21','400086',NULL,'7977707271','',NULL,'27','27BJZPC5455L1ZG',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'122',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','246',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(123,'303',NULL,NULL,'SHREE RAM MEDICAL',5,'0','DR','SHENVE','KINHVALI','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'123',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','151',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(124,'303',NULL,NULL,'SHREE RADHE INTERNATIONAL',5,'0','DR','OFFICE NO-605,NEELKANTH CORPORATE IT PARK','240/1-8 KIROL ROAD VIDYA VIHAR WEST-400086','NULL','21',NULL,NULL,'8104990050','',NULL,'27','27AYPPS2531K2ZV',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'124',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','320',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(125,'303',NULL,NULL,'SHREE MEDICO',5,'0','DR','VASIND','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'125',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','235',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(126,'303',NULL,NULL,'SHREE MEDICAL',5,'0','DR','VASIND','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'126',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','236',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(127,'303',NULL,NULL,'SHREE LAXMI MEDICAL & GENRAL STORE',5,'0','DR','SHOP N0-5.6 SHREE SAI SAMARTH COMPLEX BLDG NO-1 NO-21','HISA 16 C DAWADI DOM EAST-421203','NULL','21',NULL,NULL,'9372932614','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'127',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','281',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(128,'303',NULL,NULL,'SHREE KRUSHNA AYURVIDEC BHANDAR',5,'0','DR','SHOP,11,SHANTI OM BLDG,LODHA HEAVEN NILJE','DOMBIVALI-EAST-421204','NULL','21',NULL,NULL,'9324610784','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'128',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','322',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(129,'303',NULL,NULL,'SHREE KRUPA AGENCY',5,'0','DR','AT-MALEGOAN TAL- SHAHAHPUR','NULL','NULL','21',NULL,NULL,'9130359143','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'129',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','328',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(130,'303',NULL,NULL,'SHREE KRISHNA MEDICAL',5,'0','DR','SHOP NO-5,6 HOUSE NO-465 OPP HINDI SCHOOL DAWADI DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'130',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','273',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(131,'303',NULL,NULL,'SHREE BALAJI MEDICAL',5,'0','DR','SHOP NO-8 SAI DARSHAN APT DAWDI ROAD DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'131',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','252',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(132,'303',NULL,NULL,'SHREE BALAJI DISTRIBUTORS',11,'0','DR','NE POST OFFICE','OPP SAVITA TOWER','KALYAN','21','421601',NULL,'','',NULL,'27','27AAQFS0919J1ZR',NULL,'',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'132',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','148',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(133,'303',NULL,NULL,'SHREE & SHRIMATI BEAUTY CENTER',5,'0','DR','GUPTE ROAD','NULL','NULL','21','421202',NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'133',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','241',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(134,'303',NULL,NULL,'SHIVSAKTI TRADERS',5,'0','DR','SARALGOAN','SARALGOAN','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'134',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','196',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(135,'303',NULL,NULL,'SHIVSAKTI SUPER MARKET',5,'0','DR','KINHVALI','KINHVALI','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'135',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','162',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(136,'303',NULL,NULL,'SHIVAM MEDICAL',5,'0','DR','GUPTE ROAD DOM WEST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'136',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','268',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(137,'303',NULL,NULL,'SHIVAM MEDICAL',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'137',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','205',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(138,'303',NULL,NULL,'SHIVA SUPER MARKET',5,'0','DR','OPP JSW COPMPANY','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'138',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','231',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(139,'303',NULL,NULL,'SHETTY COSMETIC',5,'0','DR','DESAI  DOMBIVALI EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'139',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','259',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:07','2026-08-25 12:15:07',NULL,NULL,NULL,NULL),(140,'303',NULL,NULL,'SHEETAL ENTERPRISES',5,'0','DR','APMC MARKET-II, DANA BUNDER APMC','VASHI NAVI MUMBAI-4000705','NULL','21',NULL,NULL,'7400298939','',NULL,'27','27AXGPB6819B1ZS',NULL,'',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'140',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','301',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(141,'303',NULL,NULL,'SHARON ENTERPRISES',5,'0','DR','KOPRI GOAN','VASHI','NULL','21',NULL,NULL,'9702105429','',NULL,'27','27BSLPS5128R1ZQ',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'141',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','142',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(142,'303',NULL,NULL,'SHARAD KIRANA',5,'0','DR','NEAR SHREE MEDICO','SHAHAPUR','SHAHAPUR','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'142',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','145',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(143,'303',NULL,NULL,'SHALOM SERVICES',5,'0','DR','FLAT NO,204 HOUSE NO-1464/003 SHREE DATTA','MANDIR KOPRI GOAN VASHI NAVI MUMBAI','NULL','21',NULL,NULL,'8850851067','',NULL,'27','27ATZPC5967A2ZA',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'143',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','298',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(144,'303',NULL,NULL,'SAUNDARYA BEAUTY CENTER',5,'0','DR','SAIBABA MANIR P & COLONY','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'144',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','245',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(145,'303',NULL,NULL,'SARASVATI MEDICAL',5,'0','DR','MALEGOAN','KINHVALI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'145',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','193',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(146,'303',NULL,NULL,'SANSKRUTI MEDICAL',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'146',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','158',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(147,'303',NULL,NULL,'SANJIVANI MEDICAL',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'147',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','198',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(148,'303',NULL,NULL,'SAMRTH KRUPA MEDICAL',5,'0','DR','VASIND W','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'148',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','232',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(149,'303',NULL,NULL,'SAMARTH KRUPA MEDICAL',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'149',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','210',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(150,'303',NULL,NULL,'SAI SHARDDHA MEDICAL',5,'0','DR','SHOP-03,A WING JAYRAM APT AZADEGOAN','DOMBIVALI-WEST','NULL','21',NULL,NULL,'7208203138','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'150',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','326',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(151,'303',NULL,NULL,'SAI RAJ MEDICAL',5,'0','DR','NEAR LIFE LINE HOSP','NULL','SHAHAPUR','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'151',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','224',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(152,'303',NULL,NULL,'SAI MEDICAL',5,'0','DR','KINHVALI','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'152',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','264',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(153,'303',NULL,NULL,'SAI CARE MEDICAL & GENRAL STORE',5,'0','DR','SHOP NO-14,JAI VIGHNAHARTA B/D JAIBAI SCHOOL','KATEMANIVALI VITTALWADI UNR-421300','NULL','21',NULL,NULL,'8850998299','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'153',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','331',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(154,'303',NULL,NULL,'SAHELIBEAUTY',5,'0','DR','PHAKDE ROAD NEAR GURUDEV MEDICAL DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'154',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','288',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(155,'303',NULL,NULL,'SAGAR NOVELTY & GIFT GALLERY',5,'0','DR','SHOP NO-5 SANKARA NAGAR SONARPADA KALYAN SHIL ROAD','OPP DNS BANK DOM EAST','NULL','21',NULL,NULL,'9833065592','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'155',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','283',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(156,'303',NULL,NULL,'SAGAR KIRANA',5,'0','DR','VASIND','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'156',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','166',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(157,'303',NULL,NULL,'RK BAZAR PVT LTD',5,'0','DR','RKW SHOP NO-1 SHIV PLACE CHS.SHASTRI','NAGAR JONDHALE COLLEGE DOM-WEST-421202','NULL','21',NULL,NULL,'8591107290','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'157',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','308',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(158,'303',NULL,NULL,'RK BAZAR PVT LTD',5,'0','DR','RKTE SHOP NO-3TO,13 GROUND FLOOR BLDG NO-1','SARVODAY LEELA CHS NINTY FEET ROAD THAKURLI-EAST-421201','NULL','21',NULL,NULL,'8591107289','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'158',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','313',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:08','2026-08-25 12:15:08',NULL,NULL,NULL,NULL),(159,'303',NULL,NULL,'RK BAZAR PVT LTD',5,'0','DR','RKGM SHOP NO,9 TO 16 GOPI CINE MALL SHOPPING','CENTER N.S.S.ROAD DOM WEST-421201','NULL','21',NULL,NULL,'8591107291','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'159',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','312',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(160,'303',NULL,NULL,'RK BAZAR PVT LTD',5,'0','DR','RKDP SHOP NO1 TO12 ,ANURAJ HEIGHTS,NEAR GOANDEVI','MANDIR,DEVICHA PADA,RETI BUNDERCROSS ROAD DOM-WEST-421202','NULL','21',NULL,NULL,'8652656222','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'160',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','309',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(161,'303',NULL,NULL,'RK BAZAR PVT LTD',5,'0','DR','RKDA SHOP NO-7 BHAGIRATHI APT,BELOW AVDHUL HALL','OPP TO GOPAL ENGLISH SCHOOL DIVA AGASAN ROAD DIVA-400612','NULL','21',NULL,NULL,'7499753811','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'161',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','311',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(162,'303',NULL,NULL,'RK BAZAR PVT LTD',5,'0','DR','RKD SHOP NO 5,6 SONATA COMERCIAL CPMPLEX','NEAR ICICI BANK MILAP NAGAR,DOM EAST-421201','NULL','21',NULL,NULL,'8591107283','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'162',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','310',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(163,'303',NULL,NULL,'RK BAZAR PVT LTD',5,'0','DR','RKA SHOP NO.11,JANABAI MHATRE COMPOUND','GOLVALI, REGENCY ANANTAM DOM-EAST 421203 (RKA)','NULL','21',NULL,NULL,'8591107280','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'163',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','307',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(164,'303',NULL,NULL,'RK BAZAAR PVT LTD',5,'0','DR','RKSN, 001, EKAVEERA AAI APT SWAMI SAMARTH NAGAR','NANDIVALI ROADOPP, ABHINAV SAHAKARI BANK, DOMBIVALI EAST, 421201','NULL','21',NULL,NULL,'8591107285','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'164',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','314',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(165,'303',NULL,NULL,'RK BAZAAR PVT LTD',5,'0','DR','RKRP, SHOP NO-1 AND 2, PATHARLI ROAD BOGRASWADI','OPPOSITE TO NURSHILLA MALLESH APARTMENT DOMBIVALI EAST- 421201','NULL','21',NULL,NULL,'9769999191','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'165',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','315',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(166,'303',NULL,NULL,'RK BAZAAR PVT LTD',5,'0','DR','RKR, D-23, TULIP, REGENCY ESTATE','SANT DNYANESHWAR NAGAR, DOMBIWALI EAST- 421204','NULL','21',NULL,NULL,'8591107281','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'166',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','316',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(167,'303',NULL,NULL,'RK BAZAAR PVT LTD',5,'0','DR','RKGR, SHOP NO-1, A-WING, VITHAI COMPLEX APARTMENT','GYMKHANA ROADSAGARIL GAON, DOMBIVLI EAST- 421203','NULL','21',NULL,NULL,'8591107286','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'167',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','318',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(168,'303',NULL,NULL,'RK BAZAAR PVT LTD',5,'0','DR','RKDS, GROUND FLOOR, LAKSHMI NIWAS SOCIETY, DIVA STATION ROAD','OPP. ABHYUDAYA COOPERATIVE BANK, DIVA EAST- 400612','NULL','21',NULL,NULL,'9372968696','',NULL,'27','27AATCA7728B1ZG',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'168',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','317',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(169,'303',NULL,NULL,'RITU NOVELTY',5,'0','DR','KOPER ROAD','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'169',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','243',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(170,'303',NULL,NULL,'RISABH MEDICAL GENRAL STORE',5,'0','DR','SHOP NO-4 GOVIND NIVAS GUPTE ROAD DOM WEST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'170',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','271',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(171,'303',NULL,NULL,'RIDHI SIDHI NOVELTY',5,'0','DR','GUPTE ROAD DOMBIVALI WEST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'171',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','262',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(172,'303',NULL,NULL,'RAVI MEDICAL',5,'0','DR','SARALGOAN','SARALGOAN','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'172',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','194',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(173,'303',NULL,NULL,'RANUJA MEDICAL',5,'0','DR','OPP PADMAVATI MEDICAL DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'173',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','289',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(174,'303',NULL,NULL,'RAMGOPAL KIRANA',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'174',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','186',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(175,'303',NULL,NULL,'RAMDEV TRADING',5,'0','DR','SARALGOAN','SARALGOAN','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'175',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','197',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(176,'303',NULL,NULL,'RAMDEV SUPER MARKET',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'176',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','160',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(177,'303',NULL,NULL,'RAMDEV STORE',5,'0','DR','DAWADI DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'177',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','279',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(178,'303',NULL,NULL,'RAMDEV NOVELTY',5,'0','DR','SAI PRABHU BUILDING DAWADI ROAD DOM EAST','BHAJI MARKET','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'178',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','253',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:09','2026-08-25 12:15:09',NULL,NULL,NULL,NULL),(179,'303',NULL,NULL,'RAMDEV MEDICAL',5,'0','DR','NEAR GANESH SWEETS NX','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'179',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','229',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(180,'303',NULL,NULL,'RAM KRUSHNA HARI KIRANA',5,'0','DR','KHARDI','KHARDI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'180',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','176',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(181,'303',NULL,NULL,'RAJPRUT MEDICAL',5,'0','DR','GAJANAN CHOWK DESALE PADA DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'181',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','287',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(182,'303',NULL,NULL,'RAJESH PHARMA',5,'0','DR','OPP AMBIKA MATA MANDIR','NULL','SHAHAPUR','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'182',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','222',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(183,'303',NULL,NULL,'RAJESH  MEDICAL',5,'0','DR','NEAR SARKARI HOSPITAL','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'183',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','167',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(184,'303',NULL,NULL,'RAJENDRA MAGANLAL JAGE',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'184',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','156',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(185,'303',NULL,NULL,'RADHA  KISHNA MEDICAL',5,'0','DR','GALA NO-04 JAY MAA APARMENT SAGARLI ROAD','DOM -WEST','NULL','21',NULL,NULL,'7738280688','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'185',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','325',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(186,'303',NULL,NULL,'R L ENTERPRISES',5,'0','DR','FLOOR-GRD,2,PLOT-27,2, SHARDA CHAMBER,KESHAVJI NAIK ROAD','BHAR BAZAR. MASJID,CHINCHBUNDER,MUMBAI-400009','NULL','21',NULL,NULL,'9987339933','',NULL,'27','27CQOPM2488Q1ZP',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'186',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','295',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(187,'303',NULL,NULL,'PUROSHTTAM TRADERS',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'187',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','179',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(188,'303',NULL,NULL,'PURAB MEDICAL',5,'0','DR','SHOP NO-1 OM SAIJOT CHS NEW BHARAT MATA SCHOOL DOMBIVALI WEST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'188',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','267',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(189,'303',NULL,NULL,'PRATIK NOVELTY',5,'0','DR','ASHOCK NAGAR','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'189',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','277',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(190,'303',NULL,NULL,'PRAJAPATI BEAUTY  HOUSE',5,'0','DR','GOPAL BHAVAN KEALKAR ROAD  DOMBIVALI EAST','NULL','NULL','21',NULL,NULL,'8657331480','',NULL,'27','27AFUPJ3399A1Z4',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'190',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','261',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(191,'303',NULL,NULL,'PRADIP MEDICAL',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'1234567890','',NULL,'27','27AVBPS9766M1ZL',NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'191',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','216',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(192,'303',NULL,NULL,'PAWAR KIRANA',5,'0','DR','KINHVALI','KINHVALI','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'192',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','163',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(193,'303',NULL,NULL,'PATKAR KIRANA',5,'0','DR','KHARDI','KHARDI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'193',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','174',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(194,'303',NULL,NULL,'PATEL TRADING CO',5,'0','DR','NEAR KHAPRE DOCTER','NULL','SHAHAPUR','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'194',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','223',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(195,'303',NULL,NULL,'PARAS TRADING CO',5,'0','DR','GALA NO-4-5,KRISHNA COMPLEX,BUILDING NO-P,','NEAR JIO PETROL PUMP,DAPODA ROAD BHIWANDI-421302','NULL','21',NULL,NULL,'9152324967','',NULL,'27','27AOPPS2616P2Z3',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'195',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','306',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(196,'303',NULL,NULL,'PAGLI COLLETION',5,'0','DR','NEAR POOJA CEINEMA STATION DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'196',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','249',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(197,'303',NULL,NULL,'OOSAMA COLLECTION',5,'0','DR','407,SHAIKH MEMON STREET.MUMBAI','OPP CMKT','NULL','21',NULL,NULL,'9699216168','',NULL,'27','27ABXPN3647C1ZA',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'197',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','296',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(198,'303',NULL,NULL,'OM SAI MEDICAL',5,'0','DR','KINHVALI','NULL','KINHVALI','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'198',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','149',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:10','2026-08-25 12:15:10',NULL,NULL,NULL,NULL),(199,'303',NULL,NULL,'OM MEDICO',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'199',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','204',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(200,'303',NULL,NULL,'OM GANESH TRADING',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'200',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','211',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(201,'303',NULL,NULL,'OM AVADHUT MEDICAL',5,'0','DR','NEAR BALKRUSHNA KIRANA','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'201',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','228',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(202,'303',NULL,NULL,'NX 3 MARCHANT NOVELTY',5,'0','DR','NEAR HARI OM MEDICAL','NULL','NULL','21',NULL,NULL,'9167134615','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'202',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','255',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(203,'303',NULL,NULL,'NOVAS IMPEX',5,'0','DR','19,BODKE BLGD,NS ROAD NEAR SATION MULUND MUMBAI-400080','NULL','MUMBAI','21','400080',NULL,'9930949918','',NULL,'27','27AADPT8979L1ZM',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'203',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','239',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(204,'303',NULL,NULL,'NITESH MEDICAL',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'204',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','203',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(205,'303',NULL,NULL,'NISHA NOVELTY',5,'0','DR','OLD DOMBIVALI','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'205',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','248',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(206,'303',NULL,NULL,'NEXUS GLOBAL',5,'0','DR','GROUND FLOOR GARAGE NO-2 KHANDU BHAI DESAI MARG PURAMAL SWEETS VILE PARLE WEST-4000056','NULL','NULL','21',NULL,NULL,'8082430320','',NULL,'27','27AETPD6410L1Z8',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'206',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','297',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(207,'303',NULL,NULL,'NEW RAVI MEDICAL',5,'0','DR','SARALGOAN','SARALGOAN','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'207',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','195',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(208,'303',NULL,NULL,'NEW HARI OM CHEMIST',5,'0','DR','DAWADI DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'208',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','274',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(209,'303',NULL,NULL,'NAVKAR DISTRIBUTORS',5,'0','DR','OFF ,NO-7 1ST FLOOR,ASSEMBLY LANE,','DADI SETH AGIRAY LANE, KALBADEVI ROAD,MUMBAI-400002','NULL','21',NULL,NULL,'9224566067','',NULL,'27','27AVWPS3519F1Z0',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'209',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','293',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(210,'303',NULL,NULL,'NASCENT GLOBAL IMPEX LLP',5,'0','DR','50,JUHU SUPREME SHOPPING CENTER,GULMOHAR','CROSS ROAD NO-9 JVPD,MUMBAI-400049','MUMBAI','21','400049',NULL,'8454085695','',NULL,'27','27AANFN9264A1Z2',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'210',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','238',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(211,'303',NULL,NULL,'MYSORE MEDICAL',5,'0','DR','STATION ROAD OPP RAILWAY STATION DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'211',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','285',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(212,'303',NULL,NULL,'MILAN MEDICAL STORE',5,'0','DR','SHOP NO-1 JAI HANUMAN CHHAYA DAWANDI ROAD','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'212',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','250',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(213,'303',NULL,NULL,'MEET MEDICAL',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'213',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','202',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(214,'303',NULL,NULL,'MAYUR GENRAL STORE',5,'0','DR','VASIND','VASIND','VASIND','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'214',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','161',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(215,'303',NULL,NULL,'MANOJ MEDICAL',5,'0','DR','SHAHAPUR','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'215',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','170',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(216,'303',NULL,NULL,'MANGALMURTI MEDICAL',5,'0','DR','OLD DOMBIVALI WEST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'216',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','276',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(217,'303',NULL,NULL,'MAHESH MEDICAL',5,'0','DR','MALEGOAN','KINHVALI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'217',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','192',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:11','2026-08-25 12:15:11',NULL,NULL,NULL,NULL),(218,'303',NULL,NULL,'MAHESH MEDICAL',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'218',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','214',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(219,'303',NULL,NULL,'MAHASHTRA NOVELTY',5,'0','DR','DAWADI DOM ESAT','NULL','NULL','21',NULL,NULL,'9860466285','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'219',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','280',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(220,'303',NULL,NULL,'MAHALUXMI KIRANA',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'220',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','180',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(221,'303',NULL,NULL,'MAHALAXMI NX',5,'0','DR','NEAR VIKRAM MEDICAL','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'221',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','230',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(222,'303',NULL,NULL,'MAHALAXMI MEDICAL',5,'0','DR','SHOP NO-7MAHALAXMI SHOPPING CENTER SHEETAL','CHWAL VITTALWADI STATION ROAD KALYAN EAST-421306','NULL','21',NULL,NULL,'9166939729','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'222',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','330',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(223,'303',NULL,NULL,'MAHALAXMI MEDICAL',5,'0','DR','SHIWAJI CHOCK LODHA HEVAN DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'223',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','292',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(224,'303',NULL,NULL,'LUCKY BEAUTY',5,'0','DR','STAION ROAD OPP POOJA CEINEMA DOM EAST','NULL','NULL','21',NULL,NULL,'9930809036','',NULL,'27','27AKYPB3398N1Z7',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'224',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','290',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(225,'303',NULL,NULL,'LIFE LINE WELLNESS MEDICO',5,'0','DR','FORAM APARMENT JAI HIND COLONY G G RAOD DOM WEST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'225',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','269',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(226,'303',NULL,NULL,'LAXMI AYURVED BHANDAR',5,'0','DR','SHOP NO-13 KRUSHNA NIWAS CHIPLUNKAR ROAD DOMBIVALI EAST','DOMBIVALI EAST','NULL','21',NULL,NULL,'7900005141','',NULL,'27','27AABFL0175A1ZW',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'226',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','263',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(227,'303',NULL,NULL,'LAVANYA PHARMA',5,'0','DR','GROUND FLOOR HOUSE NO,119/02 GALA NO-02 PARUL APT','RAHUL NAGAR CHERPOLI SHAHAPUR -421601','NULL','21',NULL,NULL,'9579271907','',NULL,'27','27KFFPK2610C1ZS',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'227',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','329',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(228,'303',NULL,NULL,'KRISHNA MEDICAL',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'228',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','157',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(229,'303',NULL,NULL,'KRISHNA MEDICAL',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'229',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','178',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(230,'303',NULL,NULL,'KISAN KIRANA',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'230',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','199',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(231,'303',NULL,NULL,'KHUSHI ENTERPRISES',5,'0','DR','DIVA','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'231',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','260',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(232,'303',NULL,NULL,'KEPS MEDICARE',5,'0','DR','2ND,ROOM NO-3.DEVKARAN MANSION II,','SHAMALDAS GANDHI MARG,PRINCESS STREET,','MUMBAI','21','400002',NULL,'9820222772','',NULL,'27','27AADPG5562A1Z5',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'232',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','219',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(233,'303',NULL,NULL,'JAYESH ENTERPRISES',11,'0','CR','3,R.L.A.TOWER,TANK ROAD,OPP UBOI BANK BHANDUP WEST MUMBAI-400078','NULL','MUMBAI','21',NULL,NULL,'1234567890','',NULL,'27','27AAAPJ9766E1ZJ',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'233',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','258',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(234,'303',NULL,NULL,'JAY AMBE KIRANA',5,'0','DR','GUJRATI BAG','SHAHAPUR','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'234',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','144',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(235,'303',NULL,NULL,'JAMNADAS RUTTONSEY CO',5,'0','DR','24 BELL BUILDIND ,19,SIR PM ROAD','MUMBAI-400001','NULL','21',NULL,NULL,'8795688624','',NULL,'27','27AACFJ5227E1ZM',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'235',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','319',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(236,'303',NULL,NULL,'JAIN TRADERS',11,'0','CR','RADHAKRISHNA BLDG SHOP-3,EDULJI ROAD REMBHI NAKA','THANE WEST-400601','NULL','21',NULL,NULL,'9892179472','',NULL,'27','27AABFJ0313J1ZR',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'236',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','324',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(237,'303',NULL,NULL,'JAI GURUDEV PHARMACY',5,'0','DR','SHOP-9,10 JANARDHAN JADHAV BLDG NEAR HANUMAN MANDIR','MANPADA ROAD DOM EAST','NULL','21',NULL,NULL,'7738614038','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'237',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','327',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:12','2026-08-25 12:15:12',NULL,NULL,NULL,NULL),(238,'303',NULL,NULL,'JAGE MEDICAL',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'238',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','153',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(239,'303',NULL,NULL,'J. D. CORPORATION',5,'0','DR','BUILDING NO.21 GALA NO.5TO 10 &18TO 25','ARIHANT GODOWN COMPLEX THANE BHIWANDI ROAD ,PURNA VILLAGE','BHIWANDI-421302','21','421302',NULL,'8097970031','',NULL,'27','27AAAFJ0848D1ZP',NULL,'',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,'239',NULL,NULL,NULL,NULL,NULL,'10015022004405',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','220',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(240,'303',NULL,NULL,'J RUTTONSEY TRADING CO.',5,'0','DR','505, NEELKANTH BLDG,98,MARINE DRIVE MUMBAI-400002','NULL','NULL','21',NULL,NULL,'7506249592','',NULL,'27','27AACFJ2797H1Z3',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'240',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','321',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(241,'303',NULL,NULL,'HARI OM TRADING',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'241',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','217',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(242,'303',NULL,NULL,'HARI OM MEDICAL',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'242',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','181',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(243,'303',NULL,NULL,'HARI OM CHEMIST',5,'0','DR','SHOP NO-4,5 RAJUBHAI APARMENT NEAR RAM MANDIR DAWADI DOM EAST','NULL','NULL','21',NULL,NULL,'8433620174','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'243',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','272',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(244,'303',NULL,NULL,'GUNJAN MEDICAL',5,'0','DR','KHARDI','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'244',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','173',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(245,'303',NULL,NULL,'GULABCHAND KIRANA',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'245',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','185',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(246,'303',NULL,NULL,'GETWEL MEDICAL',5,'0','DR','NEAR SUSHIL MEDICAL','NULL','VASHIND','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'246',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','225',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(247,'303',NULL,NULL,'GANRAJ  ENTERPRISES',5,'0','DR','PADGHA','NULL','NULL','21',NULL,NULL,'8108452621','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'247',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','265',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(248,'303',NULL,NULL,'GANESH MEDICAL',5,'0','DR','KINHVALI','KINHVALI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'248',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','190',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(249,'303',NULL,NULL,'GANESH KIRANA',5,'0','DR','MALEGOAN','KINHVALI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'249',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','191',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(250,'303',NULL,NULL,'EKVIRA MEDICAL',5,'0','DR','SHOP NO-1 2ND FLOOR SAI PLAZA','NEAR SBI BANK','SHAHAPUR','21',NULL,NULL,'9209219155','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'250',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','221',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(251,'303',NULL,NULL,'EKDANTH MEDICAL',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'251',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','207',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(252,'303',NULL,NULL,'EKDANT MEDICAL',5,'0','DR','KINHVALI','KINHVALI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'252',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','189',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(253,'303',NULL,NULL,'DURGESH MEDICAL',5,'0','DR','KOPER ROAD','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'253',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','244',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(254,'303',NULL,NULL,'DISHA ENTERPRISE',5,'0','DR','64,GELENI PARK SOCIETY -2 BEHIND TULSLI RESTROS','TAPOAN CRICLE TO KALAKUNJ ROAD','SURAT-13','21',NULL,NULL,'9909949559','',NULL,'27','24AKYPJ9620R1Z4',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'254',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','237',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(255,'303',NULL,NULL,'DIPAK STORE',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'255',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','218',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(256,'303',NULL,NULL,'DHANLAXMI KIRANA',5,'0','DR','NEAR VIKRAM MEDICAL','SHAHAPUR','SHAHAPUR','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'256',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','143',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(257,'303',NULL,NULL,'DEV TRADERS',5,'0','DR','SHOP NO-2,PLOT NO-14B,GROHITAM BLDG SEC-19 OPP DAZA BAZAR','APMC VASHI NAVI MUMBAI-400705','NULL','21',NULL,NULL,'1234567890','',NULL,'27','27AFBPR1371P1ZO',NULL,'',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'257',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','300',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:13','2026-08-25 12:15:13',NULL,NULL,NULL,NULL),(258,'303',NULL,NULL,'DEV STATIONERY &  GEN STORE',5,'0','DR','NEAR RIO MEDICAL LODHA DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27','27AJNPN7484K1ZB',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'258',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','266',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(259,'303',NULL,NULL,'CRYSTEL MEDICAL',5,'0','DR','A/04 CHANDARSH OASIS CHS 5-LODHA,2','DOMBIVALI-EAST-421204','NULL','21',NULL,NULL,'9769556545','',NULL,'27','27DDVPK4744Q1ZF',NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'259',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','323',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(260,'303',NULL,NULL,'CHETAN MEDICAL',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'260',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','212',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(261,'303',NULL,NULL,'CHAMUNDA COLLECTION',5,'0','DR','SHOP NO-1 LAXMI TEA CENTER LOKMANYA CHOWK','BHAJI MARKET NEAR EVEREST SHOPPING CENTEREM DOM EAST','NULL','21',NULL,NULL,'9819065015','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'261',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','286',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(262,'303',NULL,NULL,'BUKSHET AGENCY',5,'0','DR','BEHIND ASHOKRAO MANE COLLEGE VATHAR PETH VADGOAN','HATKANANGLE,KOLHAPUR','NULL','21','416112',NULL,'8855931008','',NULL,'27','27ADOPB9746M1ZU',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'262',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','240',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(263,'303',NULL,NULL,'BHUSHAN MEDICAL',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'263',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','213',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(264,'303',NULL,NULL,'BHAGWATI TRADERS',5,'0','DR','MATHADI BHAVAN,SHHOP NO-19,PLOT NO-14A, SEC-19A','APMC VASHI NAVI MUMBAI-400705','NULL','21',NULL,NULL,'8928286578','',NULL,'27','27CEHPK4964A1ZJ',NULL,'',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'264',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','299',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(265,'303',NULL,NULL,'BALKRUSHNA MEDICAL',5,'0','DR','SHAHAPUR','SHAHAPUR','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'265',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','206',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(266,'303',NULL,NULL,'BAJRANG TRADERS',5,'0','DR','MATHADI BHAVAN SHOP NO-17, PLOT NO-14 ,SEC-19 APMC','VASHI NAVI MUMBAI-400705','NULL','21',NULL,NULL,'9594867869','',NULL,'27','27AQVPR9063M1ZM',NULL,'',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'266',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','302',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(267,'303',NULL,NULL,'BAJRANG ENTERPEISES',5,'0','DR','E-8,APMCMARKET1 MUDI BAZAR VASHI NAVI MUMBAI-400705','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27','27AHWPR1341J1ZT',NULL,'',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'267',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','305',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(268,'303',NULL,NULL,'BABY INDIA',5,'0','DR','83,MOHAMMED ALI ROAD OPP,BOMBAY','MERCANTILE CO-OP BANK MUMBAI-400003','NULL','21',NULL,NULL,'9819385757','',NULL,'27','27AIDPT6176B1Z5',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'268',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','278',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(269,'303',NULL,NULL,'ASIAN CHEMIST',5,'0','DR','DAWADI','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'269',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','256',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(270,'303',NULL,NULL,'ASHOK MEDICAL',5,'0','DR','OLD DOMBIVALI','NULL','NULL','21','421202',NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'270',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','242',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(271,'303',NULL,NULL,'ASHOK MAGNLAL JAGE',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'271',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','155',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(272,'303',NULL,NULL,'ASHISH MEDICAL',5,'0','DR','SHAHAPUR','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'272',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','169',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(273,'303',NULL,NULL,'ASHAPURA TRADERS',5,'0','DR','SHOP NO-30,SEC-19,MARATHI BHAVAN,APMC MARKET','VASHI NAVI MUMBAI-4007005','NULL','21',NULL,NULL,'8779156852','',NULL,'27','27AQSPV5638F1Z3',NULL,'',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,'273',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','303',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(274,'303',NULL,NULL,'APPLE CHEMIST',5,'0','DR','SHOP NO-9/10 RAJIBHAI ASHISH TUKARAM CHOWK DAWADI DOM EAST','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'274',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','254',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(275,'303',NULL,NULL,'ANISH KIRANA',5,'0','DR','KHARDI','KHARDI','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'275',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','183',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(276,'303',NULL,NULL,'ANAND MEDICAL',5,'0','DR','KINHVALI','KINHVALI','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'276',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','150',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:14','2026-08-25 12:15:14',NULL,NULL,NULL,NULL),(277,'303',NULL,NULL,'ANAND  MEDICAL',5,'0','DR','VASIND','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'277',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','165',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(278,'303',NULL,NULL,'AMBIKA SUPER MARKET',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'278',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','159',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(279,'303',NULL,NULL,'AMBIKA SUPER MARKET',5,'0','DR','SHENVE','KINHVALI','KINHVALI','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,'279',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','152',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(280,'303',NULL,NULL,'AMBAJI MEDICAL',5,'0','DR','NEAR VIKRAM MEDICAL','SHAHAPUR','NULL','21',NULL,NULL,'8104355537','',NULL,'27','27ARJPC5537E1ZX',NULL,'',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,'280',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','227',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(281,'303',NULL,NULL,'ALL IN ONE STATIONARY & GIFT STORE',5,'0','DR','BEHIND ST JHON SCHOOLE SHOP NO-7','DAWADI SONARPADA DOM EAST','NULL','21',NULL,NULL,'9619792238','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'281',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','282',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(282,'303',NULL,NULL,'ALANKAR BANGALS',5,'0','DR','KHAMBALPADA KANCHAN GOAN','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'282',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','251',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(283,'303',NULL,NULL,'AKSHAY MEDICAL',5,'0','DR','VASIND','NULL','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'283',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','168',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(284,'303',NULL,NULL,'AJIT KIRANA',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'284',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','200',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(285,'303',NULL,NULL,'AGRWAL MEDICAL',5,'0','DR','KASARA','KASARA','NULL','21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,'285',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','154',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(286,'303',NULL,NULL,'AARTI MEDICAL',5,'0','DR','VASIND','VASIND','NULL','21',NULL,NULL,'1234567890','',NULL,'27',NULL,NULL,'',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,'286',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','201',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(287,'303',NULL,NULL,'AAJI CHEMIST',5,'0','DR','SHOP NO-1 AVINASH NIWAS BALAJI NAGAR THAKURLI EAST-421201','NULL','NULL','21',NULL,NULL,'8949827747','',NULL,'27',NULL,NULL,'',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,'287',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','284',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL),(288,'303',NULL,NULL,'AAHA IMPEX PVT LTD',5,'0','DR','130 COMMOFITY EXCHANGE SEC -19 VASHI NAVI MUMBAI','NULL','NULL','21',NULL,NULL,'9324297842','',NULL,'27','27AAECA9146L1ZA',NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'288',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0',NULL,'','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','247',NULL,'0','0',NULL,484,0,'2026-08-25 12:15:15','2026-08-25 12:15:15',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int NOT NULL DEFAULT '0',
  `ADDRESS1` text,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `PROSPECT` varchar(255) DEFAULT NULL,
  `CHANNELTYPE_NAME` varchar(255) DEFAULT NULL,
  `TIER` varchar(255) DEFAULT NULL,
  `CUSTOMER_CODE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
INSERT INTO `SAC_IMPORT` VALUES (1,'303','AAHA IMPEX PVT LTD','5','DR','0','27AAECA9146L1ZA',NULL,NULL,'1','4',0,'130 COMMOFITY EXCHANGE SEC -19 VASHI NAVI MUMBAI','NULL','NULL','Maharashtra','27',NULL,'NULL','9324297842','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'247',NULL,NULL,NULL,NULL),(2,'303','AAJI CHEMIST','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-1 AVINASH NIWAS BALAJI NAGAR THAKURLI EAST-421201','NULL','NULL','Maharashtra','27',NULL,'NULL','8949827747','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'284',NULL,NULL,NULL,NULL),(3,'303','AARTI MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'201',NULL,NULL,NULL,NULL),(4,'303','AGRWAL MEDICAL','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'154',NULL,NULL,NULL,NULL),(5,'303','AJIT KIRANA','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'200',NULL,NULL,NULL,NULL),(6,'303','AKSHAY MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'168',NULL,NULL,NULL,NULL),(7,'303','ALANKAR BANGALS','5','DR','0',NULL,NULL,NULL,'2','10',0,'KHAMBALPADA KANCHAN GOAN','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'251',NULL,NULL,NULL,NULL),(8,'303','ALL IN ONE STATIONARY & GIFT STORE','5','DR','0',NULL,NULL,NULL,'2','10',0,'BEHIND ST JHON SCHOOLE SHOP NO-7','DAWADI SONARPADA DOM EAST','NULL','Maharashtra','27',NULL,'NULL','9619792238','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'282',NULL,NULL,NULL,NULL),(9,'303','AMBAJI MEDICAL','5','DR','0','27ARJPC5537E1ZX',NULL,NULL,'5','5',0,'NEAR VIKRAM MEDICAL','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','8104355537','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'227',NULL,NULL,NULL,NULL),(10,'303','AMBIKA SUPER MARKET','5','DR','0',NULL,NULL,NULL,'6','7',0,'SHENVE','KINHVALI','KINHVALI','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'152',NULL,NULL,NULL,NULL),(11,'303','AMBIKA SUPER MARKET','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'159',NULL,NULL,NULL,NULL),(12,'303','ANAND  MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'165',NULL,NULL,NULL,NULL),(13,'303','ANAND MEDICAL','5','DR','0',NULL,NULL,NULL,'6','7',0,'KINHVALI','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'150',NULL,NULL,NULL,NULL),(14,'303','ANISH KIRANA','5','DR','0',NULL,NULL,NULL,'4','8',0,'KHARDI','KHARDI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'183',NULL,NULL,NULL,NULL),(15,'303','APPLE CHEMIST','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-9/10 RAJIBHAI ASHISH TUKARAM CHOWK DAWADI DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'254',NULL,NULL,NULL,NULL),(16,'303','ASHAPURA TRADERS','5','DR','0','27AQSPV5638F1Z3',NULL,NULL,'7','3',0,'SHOP NO-30,SEC-19,MARATHI BHAVAN,APMC MARKET','VASHI NAVI MUMBAI-4007005','NULL','Maharashtra','27',NULL,'NULL','8779156852','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'303',NULL,NULL,NULL,NULL),(17,'303','ASHISH MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'169',NULL,NULL,NULL,NULL),(18,'303','ASHOK MAGNLAL JAGE','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'155',NULL,NULL,NULL,NULL),(19,'303','ASHOK MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'OLD DOMBIVALI','NULL','NULL','Maharashtra','27','421202','NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'242',NULL,NULL,NULL,NULL),(20,'303','ASIAN CHEMIST','5','DR','0',NULL,NULL,NULL,'2','10',0,'DAWADI','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'256',NULL,NULL,NULL,NULL),(21,'303','BABY INDIA','5','DR','0','27AIDPT6176B1Z5',NULL,NULL,'1','4',0,'83,MOHAMMED ALI ROAD OPP,BOMBAY','MERCANTILE CO-OP BANK MUMBAI-400003','NULL','Maharashtra','27',NULL,'NULL','9819385757','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'278',NULL,NULL,NULL,NULL),(22,'303','BAJRANG ENTERPEISES','5','DR','0','27AHWPR1341J1ZT',NULL,NULL,'7','3',0,'E-8,APMCMARKET1 MUDI BAZAR VASHI NAVI MUMBAI-400705','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'305',NULL,NULL,NULL,NULL),(23,'303','BAJRANG TRADERS','5','DR','0','27AQVPR9063M1ZM',NULL,NULL,'7','3',0,'MATHADI BHAVAN SHOP NO-17, PLOT NO-14 ,SEC-19 APMC','VASHI NAVI MUMBAI-400705','NULL','Maharashtra','27',NULL,'NULL','9594867869','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'302',NULL,NULL,NULL,NULL),(24,'303','BALKRUSHNA MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'206',NULL,NULL,NULL,NULL),(25,'303','BHAGWATI TRADERS','5','DR','0','27CEHPK4964A1ZJ',NULL,NULL,'7','3',0,'MATHADI BHAVAN,SHHOP NO-19,PLOT NO-14A, SEC-19A','APMC VASHI NAVI MUMBAI-400705','NULL','Maharashtra','27',NULL,'NULL','8928286578','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'299',NULL,NULL,NULL,NULL),(26,'303','BHUSHAN MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'213',NULL,NULL,NULL,NULL),(27,'303','BUKSHET AGENCY','5','DR','0','27ADOPB9746M1ZU',NULL,NULL,'1','4',0,'BEHIND ASHOKRAO MANE COLLEGE VATHAR PETH VADGOAN','HATKANANGLE,KOLHAPUR','NULL','Maharashtra','27','416112','NULL','8855931008','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'240',NULL,NULL,NULL,NULL),(28,'303','CHAMUNDA COLLECTION','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-1 LAXMI TEA CENTER LOKMANYA CHOWK','BHAJI MARKET NEAR EVEREST SHOPPING CENTEREM DOM EAST','NULL','Maharashtra','27',NULL,'NULL','9819065015','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'286',NULL,NULL,NULL,NULL),(29,'303','CHETAN MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'212',NULL,NULL,NULL,NULL),(30,'303','CRYSTEL MEDICAL','5','DR','0','27DDVPK4744Q1ZF',NULL,NULL,'2','10',0,'A/04 CHANDARSH OASIS CHS 5-LODHA,2','DOMBIVALI-EAST-421204','NULL','Maharashtra','27',NULL,'NULL','9769556545','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'323',NULL,NULL,NULL,NULL),(31,'303','DEV STATIONERY &  GEN STORE','5','DR','0','27AJNPN7484K1ZB',NULL,NULL,'2','10',0,'NEAR RIO MEDICAL LODHA DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'266',NULL,NULL,NULL,NULL),(32,'303','DEV TRADERS','5','DR','0','27AFBPR1371P1ZO',NULL,NULL,'7','3',0,'SHOP NO-2,PLOT NO-14B,GROHITAM BLDG SEC-19 OPP DAZA BAZAR','APMC VASHI NAVI MUMBAI-400705','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'300',NULL,NULL,NULL,NULL),(33,'303','DHANLAXMI KIRANA','5','DR','0',NULL,NULL,NULL,'5','5',0,'NEAR VIKRAM MEDICAL','SHAHAPUR','SHAHAPUR','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'143',NULL,NULL,NULL,NULL),(34,'303','DIPAK STORE','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'218',NULL,NULL,NULL,NULL),(35,'303','DISHA ENTERPRISE','5','DR','0','24AKYPJ9620R1Z4',NULL,NULL,'1','4',0,'64,GELENI PARK SOCIETY -2 BEHIND TULSLI RESTROS','TAPOAN CRICLE TO KALAKUNJ ROAD','SURAT-13','Maharashtra','27',NULL,'NULL','9909949559','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'237',NULL,NULL,NULL,NULL),(36,'303','DURGESH MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'KOPER ROAD','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'244',NULL,NULL,NULL,NULL),(37,'303','EKDANT MEDICAL','5','DR','0',NULL,NULL,NULL,'6','7',0,'KINHVALI','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'189',NULL,NULL,NULL,NULL),(38,'303','EKDANTH MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'207',NULL,NULL,NULL,NULL),(39,'303','EKVIRA MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHOP NO-1 2ND FLOOR SAI PLAZA','NEAR SBI BANK','SHAHAPUR','Maharashtra','27',NULL,'NULL','9209219155','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'221',NULL,NULL,NULL,NULL),(40,'303','GANESH KIRANA','5','DR','0',NULL,NULL,NULL,'6','7',0,'MALEGOAN','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'191',NULL,NULL,NULL,NULL),(41,'303','GANESH MEDICAL','5','DR','0',NULL,NULL,NULL,'6','7',0,'KINHVALI','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'190',NULL,NULL,NULL,NULL),(42,'303','GANRAJ  ENTERPRISES','5','DR','0',NULL,NULL,NULL,'2','10',0,'PADGHA','NULL','NULL','Maharashtra','27',NULL,'NULL','8108452621','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'265',NULL,NULL,NULL,NULL),(43,'303','GETWEL MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'NEAR SUSHIL MEDICAL','NULL','VASHIND','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'225',NULL,NULL,NULL,NULL),(44,'303','GULABCHAND KIRANA','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'185',NULL,NULL,NULL,NULL),(45,'303','GUNJAN MEDICAL','5','DR','0',NULL,NULL,NULL,'4','8',0,'KHARDI','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'173',NULL,NULL,NULL,NULL),(46,'303','HARI OM CHEMIST','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-4,5 RAJUBHAI APARMENT NEAR RAM MANDIR DAWADI DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','8433620174','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'272',NULL,NULL,NULL,NULL),(47,'303','HARI OM MEDICAL','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'181',NULL,NULL,NULL,NULL),(48,'303','HARI OM TRADING','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'217',NULL,NULL,NULL,NULL),(49,'303','J RUTTONSEY TRADING CO.','5','DR','0','27AACFJ2797H1Z3',NULL,NULL,'2','10',0,'505, NEELKANTH BLDG,98,MARINE DRIVE MUMBAI-400002','NULL','NULL','Maharashtra','27',NULL,'NULL','7506249592','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'321',NULL,NULL,NULL,NULL),(50,'303','J. D. CORPORATION','5','DR','0','27AAAFJ0848D1ZP',NULL,NULL,'8','6',0,'BUILDING NO.21 GALA NO.5TO 10 &18TO 25','ARIHANT GODOWN COMPLEX THANE BHIWANDI ROAD ,PURNA VILLAGE','BHIWANDI-421302','Maharashtra','27','421302','NULL','8097970031','NULL','NULL','0','0','0','NULL','10015022004405',NULL,484,'220',NULL,NULL,NULL,NULL),(51,'303','JAGE MEDICAL','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'153',NULL,NULL,NULL,NULL),(52,'303','JAI GURUDEV PHARMACY','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP-9,10 JANARDHAN JADHAV BLDG NEAR HANUMAN MANDIR','MANPADA ROAD DOM EAST','NULL','Maharashtra','27',NULL,'NULL','7738614038','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'327',NULL,NULL,NULL,NULL),(53,'303','JAIN TRADERS','11','CR','0','27AABFJ0313J1ZR',NULL,NULL,'2','10',0,'RADHAKRISHNA BLDG SHOP-3,EDULJI ROAD REMBHI NAKA','THANE WEST-400601','NULL','Maharashtra','27',NULL,'NULL','9892179472','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'324',NULL,NULL,NULL,NULL),(54,'303','JAMNADAS RUTTONSEY CO','5','DR','0','27AACFJ5227E1ZM',NULL,NULL,'1','4',0,'24 BELL BUILDIND ,19,SIR PM ROAD','MUMBAI-400001','NULL','Maharashtra','27',NULL,'NULL','8795688624','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'319',NULL,NULL,NULL,NULL),(55,'303','JAY AMBE KIRANA','5','DR','0',NULL,NULL,NULL,'5','5',0,'GUJRATI BAG','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'144',NULL,NULL,NULL,NULL),(56,'303','JAYESH ENTERPRISES','11','CR','0','27AAAPJ9766E1ZJ',NULL,NULL,'1','4',0,'3,R.L.A.TOWER,TANK ROAD,OPP UBOI BANK BHANDUP WEST MUMBAI-400078','NULL','MUMBAI','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'258',NULL,NULL,NULL,NULL),(57,'303','KEPS MEDICARE','5','DR','0','27AADPG5562A1Z5',NULL,NULL,'1','4',0,'2ND,ROOM NO-3.DEVKARAN MANSION II,','SHAMALDAS GANDHI MARG,PRINCESS STREET,','MUMBAI','Maharashtra','27','400002','NULL','9820222772','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'219',NULL,NULL,NULL,NULL),(58,'303','KHUSHI ENTERPRISES','5','DR','0',NULL,NULL,NULL,'2','10',0,'DIVA','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'260',NULL,NULL,NULL,NULL),(59,'303','KISAN KIRANA','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'199',NULL,NULL,NULL,NULL),(60,'303','KRISHNA MEDICAL','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'178',NULL,NULL,NULL,NULL),(61,'303','KRISHNA MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'157',NULL,NULL,NULL,NULL),(62,'303','LAVANYA PHARMA','5','DR','0','27KFFPK2610C1ZS',NULL,NULL,'2','10',0,'GROUND FLOOR HOUSE NO,119/02 GALA NO-02 PARUL APT','RAHUL NAGAR CHERPOLI SHAHAPUR -421601','NULL','Maharashtra','27',NULL,'NULL','9579271907','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'329',NULL,NULL,NULL,NULL),(63,'303','LAXMI AYURVED BHANDAR','5','DR','0','27AABFL0175A1ZW',NULL,NULL,'2','10',0,'SHOP NO-13 KRUSHNA NIWAS CHIPLUNKAR ROAD DOMBIVALI EAST','DOMBIVALI EAST','NULL','Maharashtra','27',NULL,'NULL','7900005141','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'263',NULL,NULL,NULL,NULL),(64,'303','LIFE LINE WELLNESS MEDICO','5','DR','0',NULL,NULL,NULL,'2','10',0,'FORAM APARMENT JAI HIND COLONY G G RAOD DOM WEST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'269',NULL,NULL,NULL,NULL),(65,'303','LUCKY BEAUTY','5','DR','0','27AKYPB3398N1Z7',NULL,NULL,'2','10',0,'STAION ROAD OPP POOJA CEINEMA DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','9930809036','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'290',NULL,NULL,NULL,NULL),(66,'303','MAHALAXMI MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHIWAJI CHOCK LODHA HEVAN DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'292',NULL,NULL,NULL,NULL),(67,'303','MAHALAXMI MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-7MAHALAXMI SHOPPING CENTER SHEETAL','CHWAL VITTALWADI STATION ROAD KALYAN EAST-421306','NULL','Maharashtra','27',NULL,'NULL','9166939729','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'330',NULL,NULL,NULL,NULL),(68,'303','MAHALAXMI NX','5','DR','0',NULL,NULL,NULL,'5','5',0,'NEAR VIKRAM MEDICAL','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'230',NULL,NULL,NULL,NULL),(69,'303','MAHALUXMI KIRANA','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'180',NULL,NULL,NULL,NULL),(70,'303','MAHASHTRA NOVELTY','5','DR','0',NULL,NULL,NULL,'2','10',0,'DAWADI DOM ESAT','NULL','NULL','Maharashtra','27',NULL,'NULL','9860466285','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'280',NULL,NULL,NULL,NULL),(71,'303','MAHESH MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'214',NULL,NULL,NULL,NULL),(72,'303','MAHESH MEDICAL','5','DR','0',NULL,NULL,NULL,'6','7',0,'MALEGOAN','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'192',NULL,NULL,NULL,NULL),(73,'303','MANGALMURTI MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'OLD DOMBIVALI WEST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'276',NULL,NULL,NULL,NULL),(74,'303','MANOJ MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'170',NULL,NULL,NULL,NULL),(75,'303','MAYUR GENRAL STORE','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','VASIND','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'161',NULL,NULL,NULL,NULL),(76,'303','MEET MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'202',NULL,NULL,NULL,NULL),(77,'303','MILAN MEDICAL STORE','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-1 JAI HANUMAN CHHAYA DAWANDI ROAD','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'250',NULL,NULL,NULL,NULL),(78,'303','MYSORE MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'STATION ROAD OPP RAILWAY STATION DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'285',NULL,NULL,NULL,NULL),(79,'303','NASCENT GLOBAL IMPEX LLP','5','DR','0','27AANFN9264A1Z2',NULL,NULL,'1','4',0,'50,JUHU SUPREME SHOPPING CENTER,GULMOHAR','CROSS ROAD NO-9 JVPD,MUMBAI-400049','MUMBAI','Maharashtra','27','400049','NULL','8454085695','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'238',NULL,NULL,NULL,NULL),(80,'303','NAVKAR DISTRIBUTORS','5','DR','0','27AVWPS3519F1Z0',NULL,NULL,'1','4',0,'OFF ,NO-7 1ST FLOOR,ASSEMBLY LANE,','DADI SETH AGIRAY LANE, KALBADEVI ROAD,MUMBAI-400002','NULL','Maharashtra','27',NULL,'NULL','9224566067','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'293',NULL,NULL,NULL,NULL),(81,'303','NEW HARI OM CHEMIST','5','DR','0',NULL,NULL,NULL,'2','10',0,'DAWADI DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'274',NULL,NULL,NULL,NULL),(82,'303','NEW RAVI MEDICAL','5','DR','0',NULL,NULL,NULL,'6','7',0,'SARALGOAN','SARALGOAN','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'195',NULL,NULL,NULL,NULL),(83,'303','NEXUS GLOBAL','5','DR','0','27AETPD6410L1Z8',NULL,NULL,'1','4',0,'GROUND FLOOR GARAGE NO-2 KHANDU BHAI DESAI MARG PURAMAL SWEETS VILE PARLE WEST-4000056','NULL','NULL','Maharashtra','27',NULL,'NULL','8082430320','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'297',NULL,NULL,NULL,NULL),(84,'303','NISHA NOVELTY','5','DR','0',NULL,NULL,NULL,'2','10',0,'OLD DOMBIVALI','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'248',NULL,NULL,NULL,NULL),(85,'303','NITESH MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'203',NULL,NULL,NULL,NULL),(86,'303','NOVAS IMPEX','5','DR','0','27AADPT8979L1ZM',NULL,NULL,'1','4',0,'19,BODKE BLGD,NS ROAD NEAR SATION MULUND MUMBAI-400080','NULL','MUMBAI','Maharashtra','27','400080','NULL','9930949918','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'239',NULL,NULL,NULL,NULL),(87,'303','NX 3 MARCHANT NOVELTY','5','DR','0',NULL,NULL,NULL,'2','10',0,'NEAR HARI OM MEDICAL','NULL','NULL','Maharashtra','27',NULL,'NULL','9167134615','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'255',NULL,NULL,NULL,NULL),(88,'303','OM AVADHUT MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'NEAR BALKRUSHNA KIRANA','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'228',NULL,NULL,NULL,NULL),(89,'303','OM GANESH TRADING','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'211',NULL,NULL,NULL,NULL),(90,'303','OM MEDICO','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'204',NULL,NULL,NULL,NULL),(91,'303','OM SAI MEDICAL','5','DR','0',NULL,NULL,NULL,'6','7',0,'KINHVALI','NULL','KINHVALI','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'149',NULL,NULL,NULL,NULL),(92,'303','OOSAMA COLLECTION','5','DR','0','27ABXPN3647C1ZA',NULL,NULL,'1','4',0,'407,SHAIKH MEMON STREET.MUMBAI','OPP CMKT','NULL','Maharashtra','27',NULL,'NULL','9699216168','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'296',NULL,NULL,NULL,NULL),(93,'303','PAGLI COLLETION','5','DR','0',NULL,NULL,NULL,'2','10',0,'NEAR POOJA CEINEMA STATION DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'249',NULL,NULL,NULL,NULL),(94,'303','PARAS TRADING CO','5','DR','0','27AOPPS2616P2Z3',NULL,NULL,'1','4',0,'GALA NO-4-5,KRISHNA COMPLEX,BUILDING NO-P,','NEAR JIO PETROL PUMP,DAPODA ROAD BHIWANDI-421302','NULL','Maharashtra','27',NULL,'NULL','9152324967','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'306',NULL,NULL,NULL,NULL),(95,'303','PATEL TRADING CO','5','DR','0',NULL,NULL,NULL,'5','5',0,'NEAR KHAPRE DOCTER','NULL','SHAHAPUR','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'223',NULL,NULL,NULL,NULL),(96,'303','PATKAR KIRANA','5','DR','0',NULL,NULL,NULL,'4','8',0,'KHARDI','KHARDI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'174',NULL,NULL,NULL,NULL),(97,'303','PAWAR KIRANA','5','DR','0',NULL,NULL,NULL,'6','7',0,'KINHVALI','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'163',NULL,NULL,NULL,NULL),(98,'303','PRADIP MEDICAL','5','DR','0','27AVBPS9766M1ZL',NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'216',NULL,NULL,NULL,NULL),(99,'303','PRAJAPATI BEAUTY  HOUSE','5','DR','0','27AFUPJ3399A1Z4',NULL,NULL,'2','10',0,'GOPAL BHAVAN KEALKAR ROAD  DOMBIVALI EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','8657331480','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'261',NULL,NULL,NULL,NULL),(100,'303','PRATIK NOVELTY','5','DR','0',NULL,NULL,NULL,'2','10',0,'ASHOCK NAGAR','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'277',NULL,NULL,NULL,NULL),(101,'303','PURAB MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-1 OM SAIJOT CHS NEW BHARAT MATA SCHOOL DOMBIVALI WEST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'267',NULL,NULL,NULL,NULL),(102,'303','PUROSHTTAM TRADERS','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'179',NULL,NULL,NULL,NULL),(103,'303','R L ENTERPRISES','5','DR','0','27CQOPM2488Q1ZP',NULL,NULL,'1','4',0,'FLOOR-GRD,2,PLOT-27,2, SHARDA CHAMBER,KESHAVJI NAIK ROAD','BHAR BAZAR. MASJID,CHINCHBUNDER,MUMBAI-400009','NULL','Maharashtra','27',NULL,'NULL','9987339933','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'295',NULL,NULL,NULL,NULL),(104,'303','RADHA  KISHNA MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'GALA NO-04 JAY MAA APARMENT SAGARLI ROAD','DOM -WEST','NULL','Maharashtra','27',NULL,'NULL','7738280688','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'325',NULL,NULL,NULL,NULL),(105,'303','RAJENDRA MAGANLAL JAGE','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'156',NULL,NULL,NULL,NULL),(106,'303','RAJESH  MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'NEAR SARKARI HOSPITAL','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'167',NULL,NULL,NULL,NULL),(107,'303','RAJESH PHARMA','5','DR','0',NULL,NULL,NULL,'5','5',0,'OPP AMBIKA MATA MANDIR','NULL','SHAHAPUR','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'222',NULL,NULL,NULL,NULL),(108,'303','RAJPRUT MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'GAJANAN CHOWK DESALE PADA DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'287',NULL,NULL,NULL,NULL),(109,'303','RAM KRUSHNA HARI KIRANA','5','DR','0',NULL,NULL,NULL,'4','8',0,'KHARDI','KHARDI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'176',NULL,NULL,NULL,NULL),(110,'303','RAMDEV MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'NEAR GANESH SWEETS NX','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'229',NULL,NULL,NULL,NULL),(111,'303','RAMDEV NOVELTY','5','DR','0',NULL,NULL,NULL,'2','10',0,'SAI PRABHU BUILDING DAWADI ROAD DOM EAST','BHAJI MARKET','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'253',NULL,NULL,NULL,NULL),(112,'303','RAMDEV STORE','5','DR','0',NULL,NULL,NULL,'2','10',0,'DAWADI DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'279',NULL,NULL,NULL,NULL),(113,'303','RAMDEV SUPER MARKET','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'160',NULL,NULL,NULL,NULL),(114,'303','RAMDEV TRADING','5','DR','0',NULL,NULL,NULL,'6','7',0,'SARALGOAN','SARALGOAN','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'197',NULL,NULL,NULL,NULL),(115,'303','RAMGOPAL KIRANA','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'186',NULL,NULL,NULL,NULL),(116,'303','RANUJA MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'OPP PADMAVATI MEDICAL DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'289',NULL,NULL,NULL,NULL),(117,'303','RAVI MEDICAL','5','DR','0',NULL,NULL,NULL,'6','7',0,'SARALGOAN','SARALGOAN','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'194',NULL,NULL,NULL,NULL),(118,'303','RIDHI SIDHI NOVELTY','5','DR','0',NULL,NULL,NULL,'2','10',0,'GUPTE ROAD DOMBIVALI WEST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'262',NULL,NULL,NULL,NULL),(119,'303','RISABH MEDICAL GENRAL STORE','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-4 GOVIND NIVAS GUPTE ROAD DOM WEST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'271',NULL,NULL,NULL,NULL),(120,'303','RITU NOVELTY','5','DR','0',NULL,NULL,NULL,'2','10',0,'KOPER ROAD','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'243',NULL,NULL,NULL,NULL),(121,'303','RK BAZAAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKDS, GROUND FLOOR, LAKSHMI NIWAS SOCIETY, DIVA STATION ROAD','OPP. ABHYUDAYA COOPERATIVE BANK, DIVA EAST- 400612','NULL','Maharashtra','27',NULL,'NULL','9372968696','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'317',NULL,NULL,NULL,NULL),(122,'303','RK BAZAAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKGR, SHOP NO-1, A-WING, VITHAI COMPLEX APARTMENT','GYMKHANA ROADSAGARIL GAON, DOMBIVLI EAST- 421203','NULL','Maharashtra','27',NULL,'NULL','8591107286','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'318',NULL,NULL,NULL,NULL),(123,'303','RK BAZAAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKR, D-23, TULIP, REGENCY ESTATE','SANT DNYANESHWAR NAGAR, DOMBIWALI EAST- 421204','NULL','Maharashtra','27',NULL,'NULL','8591107281','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'316',NULL,NULL,NULL,NULL),(124,'303','RK BAZAAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKRP, SHOP NO-1 AND 2, PATHARLI ROAD BOGRASWADI','OPPOSITE TO NURSHILLA MALLESH APARTMENT DOMBIVALI EAST- 421201','NULL','Maharashtra','27',NULL,'NULL','9769999191','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'315',NULL,NULL,NULL,NULL),(125,'303','RK BAZAAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKSN, 001, EKAVEERA AAI APT SWAMI SAMARTH NAGAR','NANDIVALI ROADOPP, ABHINAV SAHAKARI BANK, DOMBIVALI EAST, 421201','NULL','Maharashtra','27',NULL,'NULL','8591107285','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'314',NULL,NULL,NULL,NULL),(126,'303','RK BAZAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKA SHOP NO.11,JANABAI MHATRE COMPOUND','GOLVALI, REGENCY ANANTAM DOM-EAST 421203 (RKA)','NULL','Maharashtra','27',NULL,'NULL','8591107280','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'307',NULL,NULL,NULL,NULL),(127,'303','RK BAZAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKD SHOP NO 5,6 SONATA COMERCIAL CPMPLEX','NEAR ICICI BANK MILAP NAGAR,DOM EAST-421201','NULL','Maharashtra','27',NULL,'NULL','8591107283','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'310',NULL,NULL,NULL,NULL),(128,'303','RK BAZAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKDA SHOP NO-7 BHAGIRATHI APT,BELOW AVDHUL HALL','OPP TO GOPAL ENGLISH SCHOOL DIVA AGASAN ROAD DIVA-400612','NULL','Maharashtra','27',NULL,'NULL','7499753811','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'311',NULL,NULL,NULL,NULL),(129,'303','RK BAZAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKDP SHOP NO1 TO12 ,ANURAJ HEIGHTS,NEAR GOANDEVI','MANDIR,DEVICHA PADA,RETI BUNDERCROSS ROAD DOM-WEST-421202','NULL','Maharashtra','27',NULL,'NULL','8652656222','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'309',NULL,NULL,NULL,NULL),(130,'303','RK BAZAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKGM SHOP NO,9 TO 16 GOPI CINE MALL SHOPPING','CENTER N.S.S.ROAD DOM WEST-421201','NULL','Maharashtra','27',NULL,'NULL','8591107291','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'312',NULL,NULL,NULL,NULL),(131,'303','RK BAZAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKTE SHOP NO-3TO,13 GROUND FLOOR BLDG NO-1','SARVODAY LEELA CHS NINTY FEET ROAD THAKURLI-EAST-421201','NULL','Maharashtra','27',NULL,'NULL','8591107289','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'313',NULL,NULL,NULL,NULL),(132,'303','RK BAZAR PVT LTD','5','DR','0','27AATCA7728B1ZG',NULL,NULL,'2','10',0,'RKW SHOP NO-1 SHIV PLACE CHS.SHASTRI','NAGAR JONDHALE COLLEGE DOM-WEST-421202','NULL','Maharashtra','27',NULL,'NULL','8591107290','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'308',NULL,NULL,NULL,NULL),(133,'303','SAGAR KIRANA','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'166',NULL,NULL,NULL,NULL),(134,'303','SAGAR NOVELTY & GIFT GALLERY','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-5 SANKARA NAGAR SONARPADA KALYAN SHIL ROAD','OPP DNS BANK DOM EAST','NULL','Maharashtra','27',NULL,'NULL','9833065592','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'283',NULL,NULL,NULL,NULL),(135,'303','SAHELIBEAUTY','5','DR','0',NULL,NULL,NULL,'2','10',0,'PHAKDE ROAD NEAR GURUDEV MEDICAL DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'288',NULL,NULL,NULL,NULL),(136,'303','SAI CARE MEDICAL & GENRAL STORE','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-14,JAI VIGHNAHARTA B/D JAIBAI SCHOOL','KATEMANIVALI VITTALWADI UNR-421300','NULL','Maharashtra','27',NULL,'NULL','8850998299','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'331',NULL,NULL,NULL,NULL),(137,'303','SAI MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'KINHVALI','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'264',NULL,NULL,NULL,NULL),(138,'303','SAI RAJ MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'NEAR LIFE LINE HOSP','NULL','SHAHAPUR','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'224',NULL,NULL,NULL,NULL),(139,'303','SAI SHARDDHA MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP-03,A WING JAYRAM APT AZADEGOAN','DOMBIVALI-WEST','NULL','Maharashtra','27',NULL,'NULL','7208203138','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'326',NULL,NULL,NULL,NULL),(140,'303','SAMARTH KRUPA MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'210',NULL,NULL,NULL,NULL),(141,'303','SAMRTH KRUPA MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND W','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'232',NULL,NULL,NULL,NULL),(142,'303','SANJIVANI MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'198',NULL,NULL,NULL,NULL),(143,'303','SANSKRUTI MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','VASIND','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'158',NULL,NULL,NULL,NULL),(144,'303','SARASVATI MEDICAL','5','DR','0',NULL,NULL,NULL,'6','7',0,'MALEGOAN','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'193',NULL,NULL,NULL,NULL),(145,'303','SAUNDARYA BEAUTY CENTER','5','DR','0',NULL,NULL,NULL,'2','10',0,'SAIBABA MANIR P & COLONY','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'245',NULL,NULL,NULL,NULL),(146,'303','SHALOM SERVICES','5','DR','0','27ATZPC5967A2ZA',NULL,NULL,'1','4',0,'FLAT NO,204 HOUSE NO-1464/003 SHREE DATTA','MANDIR KOPRI GOAN VASHI NAVI MUMBAI','NULL','Maharashtra','27',NULL,'NULL','8850851067','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'298',NULL,NULL,NULL,NULL),(147,'303','SHARAD KIRANA','5','DR','0',NULL,NULL,NULL,'5','5',0,'NEAR SHREE MEDICO','SHAHAPUR','SHAHAPUR','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'145',NULL,NULL,NULL,NULL),(148,'303','SHARON ENTERPRISES','5','DR','0','27BSLPS5128R1ZQ',NULL,NULL,'1','4',0,'KOPRI GOAN','VASHI','NULL','Maharashtra','27',NULL,'NULL','9702105429','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'142',NULL,NULL,NULL,NULL),(149,'303','SHEETAL ENTERPRISES','5','DR','0','27AXGPB6819B1ZS',NULL,NULL,'7','3',0,'APMC MARKET-II, DANA BUNDER APMC','VASHI NAVI MUMBAI-4000705','NULL','Maharashtra','27',NULL,'NULL','7400298939','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'301',NULL,NULL,NULL,NULL),(150,'303','SHETTY COSMETIC','5','DR','0',NULL,NULL,NULL,'2','10',0,'DESAI  DOMBIVALI EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'259',NULL,NULL,NULL,NULL),(151,'303','SHIVA SUPER MARKET','5','DR','0',NULL,NULL,NULL,'3','9',0,'OPP JSW COPMPANY','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'231',NULL,NULL,NULL,NULL),(152,'303','SHIVAM MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'205',NULL,NULL,NULL,NULL),(153,'303','SHIVAM MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'GUPTE ROAD DOM WEST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'268',NULL,NULL,NULL,NULL),(154,'303','SHIVSAKTI SUPER MARKET','5','DR','0',NULL,NULL,NULL,'6','7',0,'KINHVALI','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'162',NULL,NULL,NULL,NULL),(155,'303','SHIVSAKTI TRADERS','5','DR','0',NULL,NULL,NULL,'6','7',0,'SARALGOAN','SARALGOAN','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'196',NULL,NULL,NULL,NULL),(156,'303','SHREE & SHRIMATI BEAUTY CENTER','5','DR','0',NULL,NULL,NULL,'2','10',0,'GUPTE ROAD','NULL','NULL','Maharashtra','27','421202','NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'241',NULL,NULL,NULL,NULL),(157,'303','SHREE BALAJI DISTRIBUTORS','11','DR','0','27AAQFS0919J1ZR',NULL,NULL,'8','6',0,'NE POST OFFICE','OPP SAVITA TOWER','KALYAN','Maharashtra','27','421601','NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'148',NULL,NULL,NULL,NULL),(158,'303','SHREE BALAJI MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-8 SAI DARSHAN APT DAWDI ROAD DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'252',NULL,NULL,NULL,NULL),(159,'303','SHREE KRISHNA MEDICAL','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP NO-5,6 HOUSE NO-465 OPP HINDI SCHOOL DAWADI DOM EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'273',NULL,NULL,NULL,NULL),(160,'303','SHREE KRUPA AGENCY','5','DR','0',NULL,NULL,NULL,'2','10',0,'AT-MALEGOAN TAL- SHAHAHPUR','NULL','NULL','Maharashtra','27',NULL,'NULL','9130359143','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'328',NULL,NULL,NULL,NULL),(161,'303','SHREE KRUSHNA AYURVIDEC BHANDAR','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP,11,SHANTI OM BLDG,LODHA HEAVEN NILJE','DOMBIVALI-EAST-421204','NULL','Maharashtra','27',NULL,'NULL','9324610784','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'322',NULL,NULL,NULL,NULL),(162,'303','SHREE LAXMI MEDICAL & GENRAL STORE','5','DR','0',NULL,NULL,NULL,'2','10',0,'SHOP N0-5.6 SHREE SAI SAMARTH COMPLEX BLDG NO-1 NO-21','HISA 16 C DAWADI DOM EAST-421203','NULL','Maharashtra','27',NULL,'NULL','9372932614','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'281',NULL,NULL,NULL,NULL),(163,'303','SHREE MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'236',NULL,NULL,NULL,NULL),(164,'303','SHREE MEDICO','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'235',NULL,NULL,NULL,NULL),(165,'303','SHREE RADHE INTERNATIONAL','5','DR','0','27AYPPS2531K2ZV',NULL,NULL,'2','10',0,'OFFICE NO-605,NEELKANTH CORPORATE IT PARK','240/1-8 KIROL ROAD VIDYA VIHAR WEST-400086','NULL','Maharashtra','27',NULL,'NULL','8104990050','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'320',NULL,NULL,NULL,NULL),(166,'303','SHREE RAM MEDICAL','5','DR','0',NULL,NULL,NULL,'6','7',0,'SHENVE','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'151',NULL,NULL,NULL,NULL),(167,'303','SHREYA SALES','5','DR','0','27BJZPC5455L1ZG',NULL,NULL,'1','4',0,'SHOP NO,12 GR FLOOR BLDG NO-3-B ,SWAGT CHS','DAMODER PARK LBS MARG GHATKOPER WEST-400086','MUMBAI','Maharashtra','27','400086','NULL','7977707271','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'246',NULL,NULL,NULL,NULL),(168,'303','SIDDHIVINAYAK MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'NEAR ICICI ATM','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'226',NULL,NULL,NULL,NULL),(169,'303','SONU SETH KIRANA','5','DR','0',NULL,NULL,NULL,'6','7',0,'KINHVALI','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','NULL','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'164',NULL,NULL,NULL,NULL),(170,'303','SUDHIR SETH','5','DR','0',NULL,NULL,NULL,'2','10',0,'SONAR PADA  DOMBIVALI EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'257',NULL,NULL,NULL,NULL),(171,'303','SUNIL MEDICAL','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'171',NULL,NULL,NULL,NULL),(172,'303','SUNIL MEDICAL','5','DR','0',NULL,NULL,NULL,'4','8',0,'KHARDI','KHARDI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'177',NULL,NULL,NULL,NULL),(173,'303','SUSHIL MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'NEAR DIPAK STORE','NULL','NULL','Maharashtra','27',NULL,'NULL','9860996076','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'234',NULL,NULL,NULL,NULL),(174,'303','SWAMI KIRANA','5','DR','0',NULL,NULL,NULL,'4','8',0,'KHARDI','KHARDI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'182',NULL,NULL,NULL,NULL),(175,'303','SWAMI MEDICAL','5','DR','0',NULL,NULL,NULL,'6','7',0,'KINHVALI','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'187',NULL,NULL,NULL,NULL),(176,'303','SWAMI SAMARTH KIRANA','5','DR','0',NULL,NULL,NULL,'6','7',0,'KINHVALI','KINHVALI','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'188',NULL,NULL,NULL,NULL),(177,'303','SWAMI SAMARTH MEDICAL','5','DR','0',NULL,NULL,NULL,'3','9',0,'VASIND','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'233',NULL,NULL,NULL,NULL),(178,'303','SWARAJ DIAPER HOUSE','5','DR','0',NULL,NULL,NULL,'2','10',0,'NEAR CHAR RASTA DOMBIVALI EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','9967387639','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'275',NULL,NULL,NULL,NULL),(179,'303','SWAST DIAPER HOUSE','5','DR','0',NULL,NULL,NULL,'2','10',0,'OLD DOMBIVALI NEAR SHIV MANDIR DOM WEST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'291',NULL,NULL,NULL,NULL),(180,'303','THE CARE SWAST AUSHADHI KENDRA','5','DR','0','27AUJPK2795D1ZF',NULL,NULL,'2','10',0,'NEAR SANJIVANI MEDICO GUPTE ROAD DOM WEST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'270',NULL,NULL,NULL,NULL),(181,'303','THE HIMALAYA DRUG COMPANY','11','DR','0','27AADFT3025B1ZP',NULL,'AADFT3025B','7','3',0,'BLDG NO-A2-1& 6& A3-1,2,3,4,5,6','PRITHAVI COMPLEX','BHIWANDI','Maharashtra','27','421302','NULL','9004661564','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'146',NULL,NULL,NULL,NULL),(182,'303','THE HIMALAYA DRUG COMPANY','11','DR','0','27AADFT3025B1ZP',NULL,'AADFT3025B','1','4',0,'BLDG NO-2','PRITHAVI COMPLEX','BHIWANDI','Maharashtra','27','421302','NULL','9004661564','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'147',NULL,NULL,NULL,NULL),(183,'303','VERSHIKA ENTERPRISES','5','DR','0',NULL,NULL,NULL,'2','10',0,'AMBERNATH EAST','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'294',NULL,NULL,NULL,NULL),(184,'303','VIJAY RAMAKANT KIRANA','5','DR','0',NULL,NULL,NULL,'4','8',0,'KASARA','KASARA','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'184',NULL,NULL,NULL,NULL),(185,'303','VIKRAM MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'208',NULL,NULL,NULL,NULL),(186,'303','VIMAL TRADING','5','DR','0','27AACPG5120B1ZI',NULL,NULL,'7','3',0,'APMC VASHI NAVI MUMBAI-400705','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'304',NULL,NULL,NULL,NULL),(187,'303','VIREN TRADING','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'215',NULL,NULL,NULL,NULL),(188,'303','VITHAAI MEDICAL','5','DR','0',NULL,NULL,NULL,'5','5',0,'SHAHAPUR','SHAHAPUR','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'209',NULL,NULL,NULL,NULL),(189,'303','YASHODHA SUPER MARKET','5','DR','0',NULL,NULL,NULL,'4','8',0,'KHARDI','NULL','NULL','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'172',NULL,NULL,NULL,NULL),(190,'303','YATHRTH KIRANA','5','DR','0',NULL,NULL,NULL,'4','8',0,'KHARDI','KHARDI','KHARDI','Maharashtra','27',NULL,'NULL','1234567890','NULL','NULL','0','0','0','NULL','NULL',NULL,484,'175',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `PG_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` int DEFAULT '0',
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUB_AC_DEBTORS',
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'SALES_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `INV_ARR` text,
  `INV_NO` text,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'tax_against',
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'van',
  `PROD_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN_QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FREE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROFIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'SALES_DATE',
  `WEIGHT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PRICE_PER` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DMG_MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REMARK` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_ARR` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'add_amt',
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'less_amt',
  `CREATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UPDATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SECURITY_KEY` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AREA` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_MAN` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GROUP_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PARTY_CODE` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FINAL_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BATCH_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `MFG_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `EXP_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `REFERENCE_NO` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int DEFAULT '0',
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int DEFAULT '0',
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUB_AC_DEBTORS',
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'SALES_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int DEFAULT '0',
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SMAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `REPORTING_MANAGER_ID` varchar(255) DEFAULT NULL,
  `TRAINER_ID` varchar(255) DEFAULT NULL,
  `PSR_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYNC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text,
  `UPDATED_VALUE` text,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text,
  `DIACM` text,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int DEFAULT '0',
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int DEFAULT '0',
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-08-25 12:06:55','2026-08-25 12:06:55');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TRAINER_MANAGER`
--

DROP TABLE IF EXISTS `TRAINER_MANAGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TRAINER_MANAGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TRAINER_NAME` varchar(255) DEFAULT NULL,
  `TRAINER_CODE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TRAINER_MANAGER`
--

LOCK TABLES `TRAINER_MANAGER` WRITE;
/*!40000 ALTER TABLE `TRAINER_MANAGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `TRAINER_MANAGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UOM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int DEFAULT '0',
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
INSERT INTO `USER_PREF` VALUES (1,'303',NULL,NULL,'SalesReverseCalculation','1',484,NULL,NULL,NULL,'484','484',NULL,0,'2026-08-25 12:22:11','2026-08-25 12:22:11'),(2,'303',NULL,NULL,'SalesZeroStock','1',484,NULL,NULL,NULL,'484','484',NULL,0,'2026-08-25 12:22:11','2026-08-25 12:22:11'),(3,'303',NULL,NULL,'salesTemplateName','print-A4 Paper.hbs',484,NULL,NULL,NULL,'484','484',NULL,0,'2026-08-25 12:22:11','2026-08-25 12:22:11'),(4,'303',NULL,NULL,'SalesPurchaseDecimal4','1',484,NULL,NULL,NULL,'484','484',NULL,0,'2026-08-25 12:22:11','2026-08-25 12:22:11');
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `WEB_ID` int NOT NULL DEFAULT '0',
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-08-25 12:07:00');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-25 21:00:11
