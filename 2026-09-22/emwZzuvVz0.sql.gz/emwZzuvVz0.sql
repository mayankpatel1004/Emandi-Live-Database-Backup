-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: emwZzuvVz0
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `emwZzuvVz0`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `emwZzuvVz0` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `emwZzuvVz0`;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AREA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
INSERT INTO `AREA` VALUES (1,'316',NULL,NULL,'nonamesalesimport','CHINCHPADA',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(2,'316',NULL,NULL,'nonamesalesimport','KHADEGOLVLI',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(3,'316',NULL,NULL,'nonamesalesimport','KOLSEWADI',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(4,'316',NULL,NULL,'nonamesalesimport','HAJI MALANG ROAD',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(5,'316',NULL,NULL,'nonamesalesimport','PISVALI - AADIVALI',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(6,'316',NULL,NULL,'nonamesalesimport','VALDHUNI',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(7,'316',NULL,NULL,'nonamesalesimport','LOKGRAM',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(8,'316',NULL,NULL,'nonamesalesimport','NEVALI',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(9,'316',NULL,NULL,'nonamesalesimport','Ambivali- Titwala',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19');
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CONFIG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text,
  `MASTER` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'316','0','emwZzuvVz0',316,'','','','2026-09-22 06:16:43','2026-09-22 06:16:43','','','','','','','','','2026-09-22 06:16:43','499','499','',0,'2026-09-22 06:16:43','2026-09-22 06:16:43');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` varchar(255) DEFAULT 'No',
  `REGION_NAME` varchar(255) DEFAULT '',
  `SITE_CODE` varchar(255) DEFAULT '',
  `SITE_NAME` varchar(255) DEFAULT '',
  `DISTRIBUTOR_TYPE` varchar(255) DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=317 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (316,NULL,NULL,'1','GANESH ENTERPRISE','2026-04-01','2027-03-31','TEMBIPADA ROAD','BHANDUP WEST','MUMBAI','21','7738685333','','','','','','','','','','','','','','',NULL,'0',NULL,'SUPER_USER','27','','','ganeshent@yupmail.com','','400078',NULL,'1',NULL,'No','','','',NULL,NULL,'0',NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-09-22 06:16:43','2026-09-22 06:46:38',NULL,'','','ganesh','Yes','','','','');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `CREATED_TS` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `BATCH_ID` int DEFAULT '0',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
INSERT INTO `DERIVED_BATCH_STOCK` VALUES (1,'316',NULL,NULL,1,1,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(2,'316',NULL,NULL,2,2,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(3,'316',NULL,NULL,3,3,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(4,'316',NULL,NULL,4,4,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(5,'316',NULL,NULL,5,5,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(6,'316',NULL,NULL,6,6,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(7,'316',NULL,NULL,7,7,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(8,'316',NULL,NULL,8,8,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(9,'316',NULL,NULL,9,9,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(10,'316',NULL,NULL,10,10,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(11,'316',NULL,NULL,11,11,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(12,'316',NULL,NULL,12,12,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(13,'316',NULL,NULL,13,13,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(14,'316',NULL,NULL,14,14,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(15,'316',NULL,NULL,15,15,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(16,'316',NULL,NULL,16,16,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(17,'316',NULL,NULL,17,17,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(18,'316',NULL,NULL,18,18,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(19,'316',NULL,NULL,19,19,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(20,'316',NULL,NULL,20,20,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(21,'316',NULL,NULL,21,21,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36'),(22,'316',NULL,NULL,22,22,'0.00',NULL,'499','499',NULL,0,0,'2026-09-22 07:33:36','2026-09-22 07:33:36');
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DISP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISTRIBUTORS_IMPORT`
--

DROP TABLE IF EXISTS `DISTRIBUTORS_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DISTRIBUTORS_IMPORT` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NEW_COMPANY_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DB_CREATED` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `NEW_DB_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `UNIT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `COMP_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `COMP_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EMAIL_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PASSWORD` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CLONE_TYPE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `START_DATE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `END_DATE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SITE_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SITE_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISTRIBUTOR_TYPE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DEALS_WITH` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'No',
  `WEB_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `IS_ACTIVE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Yes',
  `ADD1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REGION_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CITY` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PINCODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `MOBILE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISTRIBUTOR_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AREA` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Default Area',
  `MAC_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '5',
  `CUSTOMER_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SAC_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `CUSTOMER_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `AREA_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `GSTIN_NO` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PAN_NO` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SALON_GROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROSPECT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CUSTOMERCODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `CHANNEL_TYPE_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TIER` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PSR_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `PSR_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PSR_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REPORTING_MNGR_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `REPORTING_MNGR_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REPORTING_MNGR_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TRAINER_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `TRAINER_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TRAINER_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TECH_LEAD` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROMOGROUPCODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROMOGROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `VENDOR` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SM_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SALES_MAN` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ACTIVE_STATUS` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Yes',
  `HSN_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PARENT_PRODUCT_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_DIVISION` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_GROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODM_GROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_CATEGORY` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_CATEGORY_ID` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_BRAND` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_BRANDFORM` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_SUBBRANDFORM` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DFU` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PRODUCT_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RLP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `MRP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `RETAILING` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REFERENCE_NO` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `INVOICE_DATE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Sales',
  `SALONGROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GROSS_TOTAL` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNTTOCLAIM` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNTGROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SEC_DISCOUNT_VALUE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SCHEME_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SCHEME_VALUE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAXABLE_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX1_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX1_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX2_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX2_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX3_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX3_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX4_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX4_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX5_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX5_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX6_PERCENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX6_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX1_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX2_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX3_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX4_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX5_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `TAX6_COMPONENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NET_AMOUNT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `REMARKS` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `INVOICE_QTY` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `GROSS_VALUE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNT_VALUE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNT_TO_CLAIM` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `DISCOUNT_GROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `MONTH` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `MONTH_YEAR` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROMO_GROUP_CODE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `PROMO_GROUP` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISTRIBUTORS_IMPORT`
--

LOCK TABLES `DISTRIBUTORS_IMPORT` WRITE;
/*!40000 ALTER TABLE `DISTRIBUTORS_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISTRIBUTORS_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-09-22 06:16:38','2026-09-22 06:16:38');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `DELETED` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int DEFAULT '0',
  `TAX_ID` int DEFAULT '0',
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY_STATUS` varchar(255) DEFAULT 'Y',
  `SELECT_OPTIONS` int NOT NULL DEFAULT '0',
  `GROUP_ID` int NOT NULL DEFAULT '0',
  `DISPLAY_ORDER` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'RETAIL_FIELDS','retailer_name,raddress1,raddress2,rarea,rcity,rstate_name,rstate_code,rpincode,rphone1,rphone2,rgst_no,rfood_lic_no,rcontact_person,rdl_no_1,rdl_no_2,rdl_no_2,rpan_no,remail','Y',0,6,0),(2,'TAXINVOICE_FIELDS','cgst_sgst_igst_tax,cess_tax,additional_cess_tax,total_scheme1_amt,total_scheme2_amt,discount_per,discount_amt,damage_amt,repl_diff_amt,tcs_tax,apmc_tax,add_less,remarks,total_gst_tax,round_off,final_amount,total_qty,gross_total,total_scheme,disp_amt','Y',0,6,0),(3,'PRINTPAGE_WIDTH','900px','Y',0,1,0),(4,'PRINTPAGE_TOP_MARGIN','19px','Y',0,1,0),(5,'PRINTPAGE_BORDER','0','Y',0,1,0),(6,'TOP_LEFT_WIDTH','35%','Y',0,2,0),(7,'TOP_RIGHT_WIDTH','30%','Y',0,2,0),(8,'ITEMS_HEIGHT','45px','Y',0,3,0),(9,'COL_2_WIDTH','6.67%','Y',0,3,0),(10,'COL_4_WIDTH','25.10%','Y',0,3,0),(11,'COL_6_WIDTH','1.96%','Y',0,3,0),(12,'COL_8_WIDTH','6.27%','Y',0,3,0),(13,'COL_10_WIDTH','3.92%','Y',0,3,0),(14,'COL_12_WIDTH','7.84%','Y',0,3,0),(15,'COL_14_WIDTH','0%','Y',0,3,0),(16,'BLANK_SPACE_LEFT_WIDTH','100%','Y',0,4,0),(17,'BLANK_SPACE_RIGHT_WIDTH','0%','Y',0,4,0),(18,'FOOTER_1_WIDTH','18.43%','Y',0,5,0),(19,'FOOTER_3_WIDTH','8.24%','Y',0,5,0),(20,'FOOTER_5_WIDTH','9.41%','Y',0,5,0),(21,'FOOTER_7_WIDTH','8.24%','Y',0,5,0),(22,'FOOTER_9_WIDTH','9.80%','Y',0,5,0),(23,'FOOTER_11_WIDTH','0','Y',0,5,0);
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INV_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'316',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'316',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'316',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'316',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'316',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'316',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'316',NULL,NULL,'1','','S','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LEDGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `MAC_ID` int DEFAULT '0',
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int DEFAULT '0',
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int DEFAULT '0',
  `ROOT_PARENT_ID` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(14,'1',NULL,'1','UPI','UPI','bank','1','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-09-22 06:16:39','2026-09-22 06:16:39');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text,
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `SAC_ID` int NOT NULL DEFAULT '0',
  `REMOTE_ID` int NOT NULL DEFAULT '0',
  `PENDING_AMT` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `PROD_ID` int NOT NULL DEFAULT '0',
  `PACK` int NOT NULL DEFAULT '0',
  `PROD_BATCH_ID` int NOT NULL DEFAULT '0',
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int NOT NULL DEFAULT '0',
  `PUR_RET_QTY` int NOT NULL DEFAULT '0',
  `PUR_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `PUR_TOTAL` int NOT NULL DEFAULT '0',
  `SALE_QTY` int DEFAULT '0',
  `SALE_RET_QTY` int DEFAULT '0',
  `SALE_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `SALE_TOTAL` int NOT NULL DEFAULT '0',
  `OP_STOCK` int NOT NULL DEFAULT '0',
  `CLOSING_STOCK` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-09-22 06:16:38','2026-09-22 06:16:38');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MINIMUM_STOCK_LEVEL` int NOT NULL DEFAULT '0',
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `PARENT_PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DIVISION` varchar(255) DEFAULT NULL,
  `DFU` varchar(255) DEFAULT NULL,
  `PRODUCT_BRANDFORM` varchar(255) DEFAULT NULL,
  `PRODUCT_SUBBRANDFORM` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'316',NULL,NULL,'S008',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(2,'316',NULL,NULL,'S001',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(3,'316',NULL,NULL,'S005',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(4,'316',NULL,NULL,'S002',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(5,'316',NULL,NULL,'S003',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(6,'316',NULL,NULL,'S004',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(7,'316',NULL,NULL,'M001',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(8,'316',NULL,NULL,'K0014',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(9,'316',NULL,NULL,'S006',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(10,'316',NULL,NULL,'K0012',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(11,'316',NULL,NULL,'K0011',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(12,'316',NULL,NULL,'W001',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18',NULL,NULL,NULL,NULL,NULL),(13,'316',NULL,NULL,'K07',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL,NULL),(14,'316',NULL,NULL,'K001',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL,NULL),(15,'316',NULL,NULL,'D001',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL,NULL),(16,'316',NULL,NULL,'S007',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL,NULL),(17,'316',NULL,NULL,'K008',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL,NULL),(18,'316',NULL,NULL,'K0013',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL,NULL),(19,'316',NULL,NULL,'K002',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL,NULL),(20,'316',NULL,NULL,'K009',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL,NULL),(21,'316',NULL,NULL,'K010',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL,NULL),(22,'316',NULL,NULL,'K006',NULL,'Saideep Pooja Oil 800','Saideep Pooja Oil 800','Saideep Pooja Oil 800',NULL,'1','2',NULL,'',NULL,'2','2','1',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'316',NULL,NULL,'SAIDEEP POOJA OIL','1',NULL,NULL,NULL,499,NULL,NULL,'499','499',NULL,0,'2026-09-22 07:14:22','2026-09-22 07:14:22'),(2,'316',NULL,NULL,'KAPOOR','1',NULL,NULL,NULL,499,NULL,NULL,'499','499',NULL,0,'2026-09-22 07:14:22','2026-09-22 07:14:22'),(3,'316',NULL,NULL,'DRAGON AGARBATTI','1',NULL,NULL,NULL,499,NULL,NULL,'499','499',NULL,0,'2026-09-22 07:14:22','2026-09-22 07:14:22');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MINIMUM_STOCK_LEVEL` int NOT NULL DEFAULT '0',
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'316',NULL,NULL,'1','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(2,'316',NULL,NULL,'2','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(3,'316',NULL,NULL,'3','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(4,'316',NULL,NULL,'4','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(5,'316',NULL,NULL,'5','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(6,'316',NULL,NULL,'6','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(7,'316',NULL,NULL,'7','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(8,'316',NULL,NULL,'8','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(9,'316',NULL,NULL,'9','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(10,'316',NULL,NULL,'10','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(11,'316',NULL,NULL,'11','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(12,'316',NULL,NULL,'12','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:18','2026-09-22 07:14:18'),(13,'316',NULL,NULL,'13','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(14,'316',NULL,NULL,'14','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(15,'316',NULL,NULL,'15','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(16,'316',NULL,NULL,'16','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(17,'316',NULL,NULL,'17','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(18,'316',NULL,NULL,'18','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(19,'316',NULL,NULL,'19','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(20,'316',NULL,NULL,'20','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(21,'316',NULL,NULL,'21','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19'),(22,'316',NULL,NULL,'22','220726210241',NULL,NULL,NULL,'115','0.00','0.00','250','115','0','115','0','0','0',NULL,NULL,NULL,0.00,0.00,0.00,0.00,0,NULL,NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19');
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SCHEME1_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME1_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_PER` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SCHEME2_AMT` decimal(10,2) NOT NULL DEFAULT '0.00',
  `MINIMUM_STOCK_LEVEL` int NOT NULL DEFAULT '0',
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_STOCK_REPORT`
--

DROP TABLE IF EXISTS `PROD_STOCK_REPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_STOCK_REPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `PROD_ID` varchar(255) DEFAULT '0',
  `PROD_BATCH_ID` varchar(255) DEFAULT '0',
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_DESCRIPTION` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT '0',
  `PROD_WEIGHT` int NOT NULL DEFAULT '0',
  `PROD_WEIGHT_UNIT` int NOT NULL DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0',
  `PREV_OP_STOCK` varchar(255) DEFAULT '0',
  `OP_STOCK` varchar(255) DEFAULT '0',
  `OP_VALUE` varchar(255) DEFAULT '0',
  `TOTAL_PURCHASE` varchar(255) DEFAULT '0',
  `TOTAL_PURCHASE_RETURN` varchar(255) DEFAULT '0',
  `TOTAL_PURCHASE_CHALLAN` varchar(255) DEFAULT '0',
  `PURCHASE` varchar(255) DEFAULT '0',
  `PURCHASE_VALUE` varchar(255) DEFAULT '0',
  `TOTAL_SALES` varchar(255) DEFAULT '0',
  `TOTAL_SALES_RETURN` varchar(255) DEFAULT '0',
  `TOTAL_SALES_CHALLAN` varchar(255) DEFAULT '0',
  `SALES` varchar(255) DEFAULT '0',
  `SALES_VALUE` varchar(255) DEFAULT '0',
  `CLOSING_STOCK` varchar(255) DEFAULT '0',
  `PUR_AMT` varchar(255) DEFAULT '0',
  `PUR_TAX_AMT` varchar(255) DEFAULT '0',
  `PUR_AMT_WITH_GST` varchar(255) DEFAULT '0',
  `PUR_AMT_WITH_GST_CESS` varchar(255) DEFAULT '0',
  `SALE_AMT` varchar(255) DEFAULT '0',
  `SALE_TAX_AMT` varchar(255) DEFAULT '0',
  `SALE_AMT_WITH_GST` varchar(255) DEFAULT '0',
  `SALE_AMT_WITH_GST_CESS` varchar(255) DEFAULT '0',
  `PUR_SALE_DATE` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `PUR_UNIT` varchar(255) DEFAULT '0',
  `SALE_UNIT` varchar(255) DEFAULT '0',
  `TAX_AGAINST` varchar(255) DEFAULT '0',
  `CESS` varchar(255) NOT NULL DEFAULT '0',
  `CL_VALUE` varchar(255) NOT NULL DEFAULT '0',
  `PUR_WEIGHT` varchar(255) NOT NULL DEFAULT '0',
  `PUR_WEIGHT_UNIT` varchar(255) NOT NULL DEFAULT '0',
  `SALES_WEIGHT` varchar(255) NOT NULL DEFAULT '0',
  `SALES_WEIGHT_UNIT` varchar(255) NOT NULL DEFAULT '0',
  `HSN_SAC_CODE` varchar(255) NOT NULL DEFAULT '',
  `GROUP_NAME` varchar(255) NOT NULL DEFAULT '',
  `SALES_ITEM_ID` varchar(255) NOT NULL DEFAULT '0',
  `TABLE_NAME` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_STOCK_REPORT`
--

LOCK TABLES `PROD_STOCK_REPORT` WRITE;
/*!40000 ALTER TABLE `PROD_STOCK_REPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_STOCK_REPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PSR_MANAGER`
--

DROP TABLE IF EXISTS `PSR_MANAGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PSR_MANAGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PSR_NAME` varchar(255) DEFAULT NULL,
  `PSR_CODE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PSR_MANAGER`
--

LOCK TABLES `PSR_MANAGER` WRITE;
/*!40000 ALTER TABLE `PSR_MANAGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PSR_MANAGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int DEFAULT '0',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int DEFAULT '0',
  `M_ROUND_OFF` int DEFAULT '0',
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUPPLIER_ID',
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'PUR_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text,
  `INV_NO` text,
  `LOGIN_ID` int DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT 'mrp_value',
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `PROD_ID` int NOT NULL,
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PACK` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BOX` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN_QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `FREE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `CESS_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT 'PUR_DATE',
  `WEIGHT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PRICE_PER` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SALE_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DMG_MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CLOUD_SYNC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `INV_ARR` text COLLATE utf8mb4_general_ci COMMENT 'add_amt',
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'less_amt',
  `LOGIN_ID` int DEFAULT '0',
  `CREATED_BY` int DEFAULT NULL,
  `UPDATED_BY` int DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_TS` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SUPPLIER_ID` int DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8mb4_general_ci,
  `GROUP_ID` int DEFAULT NULL,
  `FINAL_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BATCH_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TCS_TAX` varchar(100) COLLATE utf8mb4_general_ci DEFAULT '0',
  `REFERENCE_NO` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `BROKER_ID` int DEFAULT '0',
  `LOGIN_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUPPLIER_ID',
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'PUR_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REGISTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Parent_Superstockist_Distributor',
  `PARENT_USER_NAME` varchar(255) DEFAULT NULL,
  `PARENT_PASSWORD` varchar(255) DEFAULT NULL,
  `IS_SUPERSTOCKIST` tinyint NOT NULL DEFAULT '0',
  `SUPERSTOCKIST_ID` int DEFAULT '0',
  `EXTRA_1` varchar(255) DEFAULT NULL,
  `EXTRA_2` varchar(255) DEFAULT NULL,
  `ADD1` text,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REPORTING_MANAGER_ID` varchar(255) DEFAULT NULL,
  `TRAINER_ID` varchar(255) DEFAULT NULL,
  `PSR_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=500 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (499,'316','0','emwZzuvVz0','ganesh','emwZzuvVz0','ganeshent@yupmail.com',NULL,NULL,'Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'499','1','',0,'2026-09-22 06:16:43','2026-09-22 06:46:38',NULL,NULL,NULL);
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REMARKS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int DEFAULT '0',
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-09-22 06:16:38',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REPORTING_MANAGER`
--

DROP TABLE IF EXISTS `REPORTING_MANAGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REPORTING_MANAGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REPORTING_MANAGER_NAME` varchar(255) DEFAULT NULL,
  `REPORTING_MANAGER_CODE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REPORTING_MANAGER`
--

LOCK TABLES `REPORTING_MANAGER` WRITE;
/*!40000 ALTER TABLE `REPORTING_MANAGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `REPORTING_MANAGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text,
  `MAC_ID` int DEFAULT '0',
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text,
  `S_ADD2` text,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `DISCOUNT2` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `PROSPECT` varchar(255) DEFAULT NULL,
  `CHANNELTYPE_NAME` varchar(255) DEFAULT NULL,
  `TIER` varchar(255) DEFAULT NULL,
  `CUSTOMER_CODE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=987 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'316',NULL,NULL,'Cash',14,'19373179.61','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'-3226070',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(2,'316',NULL,NULL,'Additional Tax(GST)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(3,'316',NULL,NULL,'Advertisement & Publicity',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'3',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(4,'316',NULL,NULL,'Bad Debts Written Off',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'4',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(5,'316',NULL,NULL,'Bank Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(6,'316',NULL,NULL,'Bonus',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'6',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(7,'316',NULL,NULL,'Books & Periodicals',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(8,'316',NULL,NULL,'Brokerage',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'8',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(9,'316',NULL,NULL,'C Form Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'9',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(10,'316',NULL,NULL,'C Form Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'10',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(11,'316',NULL,NULL,'Capital Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'11',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(12,'316',NULL,NULL,'Central Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'12',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(13,'316',NULL,NULL,'CGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'13',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(14,'316',NULL,NULL,'Charity & Donations',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'14',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(15,'316',NULL,NULL,'Commissions on Sales',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(16,'316',NULL,NULL,'Computers',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'16',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(17,'316',NULL,NULL,'Conveyance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'17',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(18,'316',NULL,NULL,'CST Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'18',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(19,'316',NULL,NULL,'Development Taxes',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'19',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(20,'316',NULL,NULL,'Edu. Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'20',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(21,'316',NULL,NULL,'Edu. Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(22,'316',NULL,NULL,'Edu. Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'22',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(23,'316',NULL,NULL,'Edu. Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'23',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(24,'316',NULL,NULL,'Excise Duties',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'24',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(25,'316',NULL,NULL,'IGST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'25',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(26,'316',NULL,NULL,'SGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'26',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(27,'316',NULL,NULL,'Legal Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(28,'316',NULL,NULL,'Market Fees',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'28',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(29,'316',NULL,NULL,'National VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'29',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(30,'316',NULL,NULL,'RDF',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'30',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(31,'316',NULL,NULL,'Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'31',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(32,'316',NULL,NULL,'SHE Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'32',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(33,'316',NULL,NULL,'SHE Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'33',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(34,'316',NULL,NULL,'SHE Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'34',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(35,'316',NULL,NULL,'SHE Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'35',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(36,'316',NULL,NULL,'Surcharge On VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'36',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(37,'316',NULL,NULL,'TDS (Advertisment)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'37',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(38,'316',NULL,NULL,'TDS (Commission)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'38',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(39,'316',NULL,NULL,'TDS (Contractor)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'39',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(40,'316',NULL,NULL,'TDS (Interest)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'40',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(41,'316',NULL,NULL,'TDS (Rent)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'41',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(42,'316',NULL,NULL,'TDS (Salery)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'42',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(43,'316',NULL,NULL,'VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'43',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(44,'316',NULL,NULL,'Telephone Expenses',19,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'44',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(45,'316',NULL,NULL,'Customer Entertainment Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'45',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(46,'316',NULL,NULL,'Depriciation A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'46',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(47,'316',NULL,NULL,'Discount',20,'77329.8','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'47',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(48,'316',NULL,NULL,'Freight & Forwarding Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'48',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(49,'316',NULL,NULL,'Interest Payable A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'49',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(50,'316',NULL,NULL,'Job Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'50',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(51,'316',NULL,NULL,'Labour',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'51',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(52,'316',NULL,NULL,'Legal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'52',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(53,'316',NULL,NULL,'Misc. Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(54,'316',NULL,NULL,'Miscellaneous Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'54',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(55,'316',NULL,NULL,'Office Maintenance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'55',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(56,'316',NULL,NULL,'Office Rent',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','1','0',NULL,'0','1',NULL,'56',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0','0','',NULL,1,NULL,1,'1','0','0',NULL,'0','-12000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(57,'316',NULL,NULL,'Office Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'57',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(58,'316',NULL,NULL,'Postal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'58',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(59,'316',NULL,NULL,'Printing & Stationery',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','1','0',NULL,'0','1',NULL,'59',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0','0','',NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(60,'316',NULL,NULL,'Rounded Off - Sales',20,'0','CR','DEFAULT',NULL,NULL,'21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','1','0',NULL,'0','1',NULL,'60',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0','0','',NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(61,'316',NULL,NULL,'Salery',20,'20000','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','1','0',NULL,'0','1',NULL,'61',NULL,NULL,NULL,NULL,NULL,'',NULL,'0','0','0','',NULL,1,NULL,1,'1','0','0',NULL,'0','-34000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(62,'316',NULL,NULL,'Sales Promotion Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'62',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(63,'316',NULL,NULL,'Sewing Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'63',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(64,'316',NULL,NULL,'Staff Welfare Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'64',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(65,'316',NULL,NULL,'Stitching',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'65',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(66,'316',NULL,NULL,'Travelling Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'66',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(67,'316',NULL,NULL,'Water & Electricity Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'67',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(68,'316',NULL,NULL,'Earnest Money',29,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'68',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(69,'316',NULL,NULL,'Furnituer & Fixture',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'69',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(70,'316',NULL,NULL,'Office Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'70',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(71,'316',NULL,NULL,'Plants & Machinery',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'71',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(72,'316',NULL,NULL,'CST Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'72',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(73,'316',NULL,NULL,'Interstate Retail Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'73',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(74,'316',NULL,NULL,'Local B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'74',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(75,'316',NULL,NULL,'Sales',27,'58302987.77','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'75',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(76,'316',NULL,NULL,'Sales Retail 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'76',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(77,'316',NULL,NULL,'Sales Retail 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'77',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(78,'316',NULL,NULL,'Sales VAT 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'78',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(79,'316',NULL,NULL,'Sales VAT 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'79',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(80,'316',NULL,NULL,'Dammi',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'80',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(81,'316',NULL,NULL,'Income From National VAT',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'81',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(82,'316',NULL,NULL,'Interest Receivable A/c',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'82',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(83,'316',NULL,NULL,'Rate Adjustment',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'83',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(84,'316',NULL,NULL,'Mall Khata A/c',30,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'84',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(85,'316',NULL,NULL,'Profit & Loss',9,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'85',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(86,'316',NULL,NULL,'Purchase',25,'53645913.6','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'86',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(87,'316',NULL,NULL,'Purchase Retail 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'87',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(88,'316',NULL,NULL,'Purchase Retail 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'88',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(89,'316',NULL,NULL,'Purchase VAT 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'89',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(90,'316',NULL,NULL,'Purchase VAT 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'90',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(91,'316',NULL,NULL,'Replacement',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'91',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(92,'316',NULL,NULL,'Stock',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'92',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(93,'316',NULL,NULL,'Salery & Bonus Payable',24,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'93',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(94,'316',NULL,NULL,'Interstate B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'94',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(95,'316',NULL,NULL,'CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'95',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(96,'316',NULL,NULL,'Additional CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'96',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(97,'316',NULL,NULL,'SCHEME-1',20,'35711.8406','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'97',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(98,'316',NULL,NULL,'SCHEME-2',20,'1324.16','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,'98',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,0,'2026-09-22 06:16:40','2026-09-22 06:16:40',NULL,NULL,NULL,NULL),(99,'316',NULL,NULL,'Purabji Super Shopy',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'99',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(100,'316',NULL,NULL,'siddhivinayak gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'100',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(101,'316',NULL,NULL,'Vakrtund Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'101',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(102,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'102',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(103,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'103',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(104,'316',NULL,NULL,'Uma Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'104',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(105,'316',NULL,NULL,'Hari Om Shanti Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'105',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(106,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'106',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(107,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'107',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(108,'316',NULL,NULL,'Jagdamba Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'108',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(109,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'109',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(110,'316',NULL,NULL,'Swami Samarth Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'110',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(111,'316',NULL,NULL,'Sunil Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'111',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(112,'316',NULL,NULL,'Ashapura Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'112',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(113,'316',NULL,NULL,'Sunil Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'113',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(114,'316',NULL,NULL,'Sumariya Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'114',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(115,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'115',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(116,'316',NULL,NULL,'Kailash Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'116',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(117,'316',NULL,NULL,'Shree Krushna Perfume',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'117',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(118,'316',NULL,NULL,'Shree Krushna Perfume',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'118',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(119,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'119',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(120,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'120',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(121,'316',NULL,NULL,'Shiv Fool Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'121',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(122,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'122',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(123,'316',NULL,NULL,'Bhawani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'123',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(124,'316',NULL,NULL,'Bhawani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'124',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(125,'316',NULL,NULL,'Bhawani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'125',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(126,'316',NULL,NULL,'Bhawani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'126',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(127,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'127',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(128,'316',NULL,NULL,'Satgurukripa Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'128',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(129,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'129',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(130,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'130',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(131,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'131',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(132,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'132',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(133,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'133',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(134,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'134',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(135,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'135',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(136,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'136',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(137,'316',NULL,NULL,'Laxmi Grain  Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'137',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(138,'316',NULL,NULL,'Laxmi Grain  Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'138',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(139,'316',NULL,NULL,'Ganeshkrupa Tobaco',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'139',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(140,'316',NULL,NULL,'Sai Shraddha Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'140',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(141,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'141',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(142,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'142',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(143,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'143',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(144,'316',NULL,NULL,'Mahaveer Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'144',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(145,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'145',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(146,'316',NULL,NULL,'Sai Balaji Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'146',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(147,'316',NULL,NULL,'Sai Balaji Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'147',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(148,'316',NULL,NULL,'Sai Balaji Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'148',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(149,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'149',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(150,'316',NULL,NULL,'Durga Gn Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'150',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(151,'316',NULL,NULL,'Durga Gn Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'151',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(152,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'152',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(153,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'153',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(154,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'154',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(155,'316',NULL,NULL,'Chirag Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'155',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(156,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'156',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(157,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'157',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(158,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'158',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(159,'316',NULL,NULL,'Choudhary Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'159',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(160,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'160',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(161,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'161',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(162,'316',NULL,NULL,'Sagar Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'162',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(163,'316',NULL,NULL,'Sagar Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'163',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(164,'316',NULL,NULL,'Matoshree Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'164',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(165,'316',NULL,NULL,'Narayan Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'165',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(166,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'166',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(167,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'167',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(168,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'168',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(169,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'169',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(170,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'170',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(171,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'171',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(172,'316',NULL,NULL,'Radhesham Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'172',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(173,'316',NULL,NULL,'Vashi Bazar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'173',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(174,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'174',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(175,'316',NULL,NULL,'Dhanavtri Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'175',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(176,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'176',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(177,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'177',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(178,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'178',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(179,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'179',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(180,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'180',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(181,'316',NULL,NULL,'New Omkar Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'181',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(182,'316',NULL,NULL,'Nilamber Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'182',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(183,'316',NULL,NULL,'Omkar Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'183',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(184,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'184',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(185,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'185',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(186,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'186',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(187,'316',NULL,NULL,'Om Sairam Kirana Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'187',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(188,'316',NULL,NULL,'Om Sairam Kirana Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'188',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(189,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'189',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(190,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'190',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(191,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'191',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(192,'316',NULL,NULL,'Chamunda Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'192',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(193,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'193',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(194,'316',NULL,NULL,'Omkar Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'194',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(195,'316',NULL,NULL,'Pornima Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'195',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(197,'316',NULL,NULL,'Purabji Super Shopy',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'197',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(198,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'198',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(199,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'199',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(200,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'200',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(201,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'201',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(202,'316',NULL,NULL,'Rudra Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'202',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(203,'316',NULL,NULL,'Rudra Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'203',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(204,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'204',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(205,'316',NULL,NULL,'Sai Balaji Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'205',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(206,'316',NULL,NULL,'Sai Balaji Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'206',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(207,'316',NULL,NULL,'Sai Balaji Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'207',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(208,'316',NULL,NULL,'Sai Balaji Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'208',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(209,'316',NULL,NULL,'Ganesh Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'209',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(210,'316',NULL,NULL,'Ganesh Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'210',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(211,'316',NULL,NULL,'Omkar Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'211',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(212,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'212',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(213,'316',NULL,NULL,'Mahalxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'213',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(214,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'214',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(215,'316',NULL,NULL,'Bholenath Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'215',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(216,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'216',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(217,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'217',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(218,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'218',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(219,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'219',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(220,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'220',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(221,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'221',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(222,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'222',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(223,'316',NULL,NULL,'Shiv Fool Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'223',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(224,'316',NULL,NULL,'Shiv Fool Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'224',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(225,'316',NULL,NULL,'Ashapura Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'225',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(226,'316',NULL,NULL,'Sumariya Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'226',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(227,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'227',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(228,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'228',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(229,'316',NULL,NULL,'Uma Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'229',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(230,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'230',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(231,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'231',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(232,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'232',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(233,'316',NULL,NULL,'Om Sairam Kirana Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'233',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(234,'316',NULL,NULL,'Vps Enterprises',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'234',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(235,'316',NULL,NULL,'Chirag Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'235',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(236,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'236',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(237,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'237',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(238,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'238',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(239,'316',NULL,NULL,'Shree Krushna Perfume',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'239',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(240,'316',NULL,NULL,'Durga Gn Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'240',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(241,'316',NULL,NULL,'Durga Gn Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'241',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(242,'316',NULL,NULL,'Ganeshkrupa Tobaco',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'242',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(243,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'243',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(244,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'244',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(245,'316',NULL,NULL,'Hari Om Shanti Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'245',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(246,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'246',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(248,'316',NULL,NULL,'Uma Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'248',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(249,'316',NULL,NULL,'Uma Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'249',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(250,'316',NULL,NULL,'Sagar Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'250',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(251,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'251',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(252,'316',NULL,NULL,'Sagar Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'252',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(253,'316',NULL,NULL,'Omkar Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'253',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(254,'316',NULL,NULL,'Vps Enterprises',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'254',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(255,'316',NULL,NULL,'Omkar Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'255',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(256,'316',NULL,NULL,'Rudra Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'256',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(257,'316',NULL,NULL,'Sumariya Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'257',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(258,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'258',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(259,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'259',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(260,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'260',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:19','2026-09-22 07:14:19',NULL,NULL,NULL,NULL),(261,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'261',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(262,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'262',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(263,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'263',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(264,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'264',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(265,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'265',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(266,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'266',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(267,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'267',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(268,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'268',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(269,'316',NULL,NULL,'Shree Krushna Perfume',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'269',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(270,'316',NULL,NULL,'Ganesh Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'270',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(271,'316',NULL,NULL,'Chirag Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'271',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(272,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'272',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(273,'316',NULL,NULL,'Mahalxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'273',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(274,'316',NULL,NULL,'Ganeshkrupa Tobaco',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'274',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(275,'316',NULL,NULL,'Sai Shraddha Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'275',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(276,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'276',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(277,'316',NULL,NULL,'Mahalaxmi Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'277',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(278,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'278',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(279,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'279',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(280,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'280',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(281,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'281',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(282,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'282',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(283,'316',NULL,NULL,'Shivam Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'283',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(285,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'285',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(286,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'286',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(287,'316',NULL,NULL,'Krushna Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'287',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(288,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'288',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(289,'316',NULL,NULL,'Dhanlaxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'289',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(290,'316',NULL,NULL,'D R Choudhary Trading',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'290',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(291,'316',NULL,NULL,'Choudhary Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'291',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(292,'316',NULL,NULL,'Purabji Super Shopy',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'292',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(293,'316',NULL,NULL,'Choudhary Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'293',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(294,'316',NULL,NULL,'Jyoti Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'294',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(296,'316',NULL,NULL,'Ashapura Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'296',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(297,'316',NULL,NULL,'Narayan Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'297',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(298,'316',NULL,NULL,'Jagdamba Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'298',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(299,'316',NULL,NULL,'Jagdamba Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'299',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(300,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'300',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(301,'316',NULL,NULL,'Narayan Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'301',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(302,'316',NULL,NULL,'Narayan Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'302',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(303,'316',NULL,NULL,'Hari Om Shanti Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'303',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(304,'316',NULL,NULL,'Hari Om Shanti Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'304',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(305,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'305',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(306,'316',NULL,NULL,'Hari Darshan Farsan',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'306',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(307,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'307',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(308,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'308',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(309,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'309',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(310,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'310',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(311,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'311',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(312,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'312',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(313,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'313',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(314,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'314',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(315,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'315',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(316,'316',NULL,NULL,'Vakrtund Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'316',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(318,'316',NULL,NULL,'D R Choudhary Trading',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'318',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(319,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'319',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(320,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'320',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(321,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'321',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(322,'316',NULL,NULL,'Jagdamba Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'322',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(323,'316',NULL,NULL,'Ashok Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'323',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(324,'316',NULL,NULL,'Chamunda Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'324',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(325,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'325',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(326,'316',NULL,NULL,'Bholenath Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'326',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(327,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'327',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(328,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'328',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(329,'316',NULL,NULL,'Shree Krushna Novelty',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'329',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(331,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'331',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(332,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'332',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(333,'316',NULL,NULL,'Vaishnvi Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'333',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(334,'316',NULL,NULL,'New Omkar Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'334',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(335,'316',NULL,NULL,'Hari Om Shanti Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'335',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(336,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'336',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(337,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'337',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(338,'316',NULL,NULL,'Ramdev Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'338',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(339,'316',NULL,NULL,'Ashapura Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'339',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(340,'316',NULL,NULL,'Shree Krushna Perfume',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'340',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(341,'316',NULL,NULL,'Ganeshkrupa Tobaco',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'341',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(342,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'342',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(343,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'343',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(344,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'344',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(346,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'346',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(347,'316',NULL,NULL,'Ashapura Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'347',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(348,'316',NULL,NULL,'Mahalaxmi Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'348',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(349,'316',NULL,NULL,'Om Sairam Kirana Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'349',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(350,'316',NULL,NULL,'Om Sairam Kirana Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'350',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(352,'316',NULL,NULL,'Rudra Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'352',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(354,'316',NULL,NULL,'Hari Darshan Farsan',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'354',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(355,'316',NULL,NULL,'Hari Darshan Farsan',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'355',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(356,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'356',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(357,'316',NULL,NULL,'Chamunda Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'357',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(358,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'358',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(359,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'359',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(360,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'360',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(361,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'361',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(362,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'362',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(363,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'363',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(364,'316',NULL,NULL,'Satgurukripa Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'364',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(365,'316',NULL,NULL,'Satgurukripa Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'365',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(366,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'366',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(368,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'368',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(369,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'369',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(370,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'370',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(371,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'371',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(372,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'372',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(373,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'373',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(374,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'374',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(376,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'376',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(377,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'377',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(378,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'378',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(379,'316',NULL,NULL,'Sumariya Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'379',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(380,'316',NULL,NULL,'Manish Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'380',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(381,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'381',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(382,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'382',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(383,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'383',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(384,'316',NULL,NULL,'Shree Krushna Perfume',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'384',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(385,'316',NULL,NULL,'Bhole Mishra Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'385',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(386,'316',NULL,NULL,'Uma Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'386',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(387,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'387',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(388,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'388',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(389,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'389',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(390,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'390',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(391,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'391',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(392,'316',NULL,NULL,'Dhanavtri Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'392',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(394,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'394',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(395,'316',NULL,NULL,'Uma Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'395',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(396,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'396',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(397,'316',NULL,NULL,'Hari Om Shanti Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'397',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(399,'316',NULL,NULL,'Dhanavtri Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'399',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(400,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'400',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(402,'316',NULL,NULL,'Amar Dairy',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'402',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(403,'316',NULL,NULL,'Vinayak Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'403',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(404,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'404',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(405,'316',NULL,NULL,'Choudhary Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'405',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(406,'316',NULL,NULL,'Mahalxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'406',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(407,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'407',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(408,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'408',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(409,'316',NULL,NULL,'Hari Om Shanti Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'409',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(410,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'410',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(411,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'411',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(412,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'412',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(413,'316',NULL,NULL,'Hanuman Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'413',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(414,'316',NULL,NULL,'Hanuman Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'414',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(415,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'415',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(416,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'416',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(417,'316',NULL,NULL,'Hari Om Shanti Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'417',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(418,'316',NULL,NULL,'Bholenath Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'418',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(419,'316',NULL,NULL,'Bholenath Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'419',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(420,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'420',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(421,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'421',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(422,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'422',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(423,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'423',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(424,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'424',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(425,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'425',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(427,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'427',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(428,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'428',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(429,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'429',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(430,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'430',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(431,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'431',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(432,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'432',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(433,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'433',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(434,'316',NULL,NULL,'Shree Krushna Grain Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'434',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(435,'316',NULL,NULL,'Bhawani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'435',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(436,'316',NULL,NULL,'Shiv Fool Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'436',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(437,'316',NULL,NULL,'Dhanavtri Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'437',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(438,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'438',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(439,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'439',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(440,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'440',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(441,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'441',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(442,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'442',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(443,'316',NULL,NULL,'Shital Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'443',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(444,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'444',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(445,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'445',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(446,'316',NULL,NULL,'Gaytri Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'446',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(448,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'448',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(449,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'449',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(450,'316',NULL,NULL,'Swami Samarth Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'450',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(451,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'451',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(453,'316',NULL,NULL,'Om Sai Catress',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'453',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(454,'316',NULL,NULL,'Mahalaxmi Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'454',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(455,'316',NULL,NULL,'Ganesh Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'455',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(456,'316',NULL,NULL,'Mahalaxmi Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'456',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(458,'316',NULL,NULL,'Mahalaxmi Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'458',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(459,'316',NULL,NULL,'Mahalaxmi Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'459',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(460,'316',NULL,NULL,'Hari Darshan Farsan',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'460',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(461,'316',NULL,NULL,'Hari Darshan Farsan',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'461',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(462,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'462',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(463,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'463',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(464,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'464',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(465,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'465',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(466,'316',NULL,NULL,'Sagar Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'466',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(467,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'467',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(468,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'468',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(469,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'469',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(470,'316',NULL,NULL,'Uma Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'470',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(471,'316',NULL,NULL,'Ajay Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'471',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(473,'316',NULL,NULL,'S K Agarbathi',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'473',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(474,'316',NULL,NULL,'S K Agarbathi',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'474',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(475,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'475',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(476,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'476',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(477,'316',NULL,NULL,'Shivansh Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'477',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(478,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'478',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(479,'316',NULL,NULL,'Rudra Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'479',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(480,'316',NULL,NULL,'Jagdamba Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'480',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(481,'316',NULL,NULL,'Rudra Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'481',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(482,'316',NULL,NULL,'Rudra Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'482',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(483,'316',NULL,NULL,'Nilamber Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'483',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(484,'316',NULL,NULL,'Nilamber Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'484',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(485,'316',NULL,NULL,'New Rahul Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'485',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(486,'316',NULL,NULL,'New Rahul Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'486',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(487,'316',NULL,NULL,'New Rahul Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'487',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(488,'316',NULL,NULL,'Gulab Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'488',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(489,'316',NULL,NULL,'Gulab Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'489',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(490,'316',NULL,NULL,'Suvidha Super Market',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'490',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(491,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'491',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(492,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'492',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(493,'316',NULL,NULL,'D R Choudhary Trading',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'493',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(494,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'494',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(495,'316',NULL,NULL,'Chamunda Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'495',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(496,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'496',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(497,'316',NULL,NULL,'Ashapura Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'497',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(498,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'498',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(501,'316',NULL,NULL,'Poonam Dry Friut',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'501',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(503,'316',NULL,NULL,'Ganeshkrupa Tobaco',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'503',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(504,'316',NULL,NULL,'Bhole Mishra Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'504',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(505,'316',NULL,NULL,'Navdeep Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'505',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(508,'316',NULL,NULL,'Durga Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'508',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(509,'316',NULL,NULL,'Vps Enterprises',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'509',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(510,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'510',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(512,'316',NULL,NULL,'Gulab Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'512',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(513,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'513',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(514,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'514',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(515,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'515',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(516,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'516',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(517,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'517',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(518,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'518',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(519,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'519',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(520,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'520',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(522,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'522',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(523,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'523',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(524,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'524',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(525,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'525',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(526,'316',NULL,NULL,'Sai Balaji Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'526',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(527,'316',NULL,NULL,'Bhawani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'527',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(528,'316',NULL,NULL,'Bhawani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'528',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(529,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'529',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(530,'316',NULL,NULL,'Dipesh Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'530',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(531,'316',NULL,NULL,'Rashtriy Society',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'531',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(532,'316',NULL,NULL,'Rashtriy Society',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'532',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(534,'316',NULL,NULL,'Rudra Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'534',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(535,'316',NULL,NULL,'Laxmi Grain  Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'535',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(536,'316',NULL,NULL,'Ganesh Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'536',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(538,'316',NULL,NULL,'Omkar Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'538',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(539,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'539',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(540,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'540',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(541,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'541',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(542,'316',NULL,NULL,'Mulund Gheewale',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'542',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(543,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'543',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(544,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'544',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(545,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'545',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(546,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'546',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(547,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'547',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(548,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'548',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(549,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'549',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(550,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'550',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(551,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'551',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(552,'316',NULL,NULL,'Balaji Grain',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'552',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(553,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'553',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(554,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'554',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(555,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'555',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(557,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'557',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(558,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'558',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(559,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'559',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(560,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'560',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(561,'316',NULL,NULL,'Mahaveer Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'561',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(562,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'562',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(563,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'563',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(564,'316',NULL,NULL,'Bholenath Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'564',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(565,'316',NULL,NULL,'Durga Gn Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'565',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(566,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'566',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(567,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'567',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(568,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'568',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(569,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'569',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(570,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'570',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(571,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'571',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(572,'316',NULL,NULL,'Chamunda Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'572',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(573,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'573',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(574,'316',NULL,NULL,'Chirag Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'574',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(575,'316',NULL,NULL,'Hari Darshan Farsan',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'575',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(576,'316',NULL,NULL,'Chirag Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'576',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(577,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'577',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(578,'316',NULL,NULL,'Bhawani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'578',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(579,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'579',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(580,'316',NULL,NULL,'Chirag Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'580',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(581,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'581',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(582,'316',NULL,NULL,'Bholenath Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'582',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(583,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'583',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(584,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'584',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(585,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'585',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(586,'316',NULL,NULL,'New Rahul Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'586',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(588,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'588',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(589,'316',NULL,NULL,'D R Choudhary Trading',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'589',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(590,'316',NULL,NULL,'Sumariya Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'590',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(591,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'591',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(592,'316',NULL,NULL,'Shree Krishna Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'592',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(593,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'593',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(594,'316',NULL,NULL,'D R Choudhary Trading',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'594',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(595,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'595',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(596,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'596',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(597,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'597',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(598,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'598',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(599,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'599',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(600,'316',NULL,NULL,'Narayan Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'600',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(601,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'601',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(602,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'602',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(603,'316',NULL,NULL,'Narayan Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'603',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(604,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'604',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(605,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'605',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(606,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'606',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(607,'316',NULL,NULL,'Narayan Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'607',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(608,'316',NULL,NULL,'Jai Bajarang Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'608',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(609,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'609',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(610,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'610',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(611,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'611',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(612,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'612',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(614,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'614',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(615,'316',NULL,NULL,'Ganesh Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'615',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(616,'316',NULL,NULL,'Shiv Fool Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'616',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(617,'316',NULL,NULL,'Shiv Fool Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'617',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:20','2026-09-22 07:14:20',NULL,NULL,NULL,NULL),(618,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'618',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(620,'316',NULL,NULL,'Anjali Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'620',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(621,'316',NULL,NULL,'D R Choudhary Trading',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'621',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(624,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'624',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(625,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'625',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(626,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'626',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(627,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'627',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(629,'316',NULL,NULL,'Hari Darshan Farsan',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'629',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(630,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'630',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(631,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'631',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(632,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'632',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(633,'316',NULL,NULL,'Hari Darshan Farsan',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'633',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(634,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'634',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(635,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'635',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(636,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'636',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(637,'316',NULL,NULL,'Saraswati Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'637',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(639,'316',NULL,NULL,'Mahalxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'639',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(640,'316',NULL,NULL,'Mahalxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'640',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(641,'316',NULL,NULL,'Mahalxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'641',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(642,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'642',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(643,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'643',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(644,'316',NULL,NULL,'Mahalxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'644',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(645,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'645',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(646,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'646',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(647,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'647',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(648,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'648',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(649,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'649',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(650,'316',NULL,NULL,'Swami Samarth Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'650',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(651,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'651',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(654,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'654',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(655,'316',NULL,NULL,'Swami Samarth Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'655',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(658,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'658',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(660,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'660',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(661,'316',NULL,NULL,'Sagar Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'661',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(662,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'662',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(663,'316',NULL,NULL,'Shree Krishna Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'663',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(664,'316',NULL,NULL,'Nilamber Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'664',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(665,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'665',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(666,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'666',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(667,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'667',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(668,'316',NULL,NULL,'Shree Krishna Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'668',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(669,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'669',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(670,'316',NULL,NULL,'Vps Enterprises',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'670',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(671,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'671',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(672,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'672',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(673,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'673',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(674,'316',NULL,NULL,'Hari Darshan Farsan',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'674',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(675,'316',NULL,NULL,'Sagar Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'675',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(676,'316',NULL,NULL,'Dhyaneshwar Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'676',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(677,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'677',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(678,'316',NULL,NULL,'Durga Gn Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'678',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(679,'316',NULL,NULL,'Sai Shraddha Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'679',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(680,'316',NULL,NULL,'Durga Gn Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'680',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(682,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'682',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(683,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'683',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(684,'316',NULL,NULL,'Sagar Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'684',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(685,'316',NULL,NULL,'Shree Krishna Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'685',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(686,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'686',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(687,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'687',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(688,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'688',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(689,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'689',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(692,'316',NULL,NULL,'Dhanavtri Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'692',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(693,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'693',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(694,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'694',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(697,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'697',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(698,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'698',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(700,'316',NULL,NULL,'Dhanavtri Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'700',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(701,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'701',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(702,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'702',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(706,'316',NULL,NULL,'Ganesh Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'706',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(707,'316',NULL,NULL,'Chirag Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'707',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(709,'316',NULL,NULL,'Prabhu Pan Shop',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'709',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(710,'316',NULL,NULL,'D R Choudhary Trading',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'710',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(713,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'713',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(714,'316',NULL,NULL,'Jai Bhavani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'714',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(715,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'715',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(716,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'716',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(717,'316',NULL,NULL,'Rajendra Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'717',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(718,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'718',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(719,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'719',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(720,'316',NULL,NULL,'Shree Samarth Krupa Home Mart',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'720',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(721,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'721',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(722,'316',NULL,NULL,'Shree Samarth Krupa Home Mart',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'722',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(724,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'724',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(725,'316',NULL,NULL,'Satguru Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'725',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(726,'316',NULL,NULL,'Rudra Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'726',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(729,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'729',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(731,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'731',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(733,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'733',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(734,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'734',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(736,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'736',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(738,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'738',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(740,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'740',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(741,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'741',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(742,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'742',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(743,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'743',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(744,'316',NULL,NULL,'Rajesh Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'744',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(745,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'745',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(746,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'746',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(747,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'747',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(748,'316',NULL,NULL,'Gupta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'748',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(749,'316',NULL,NULL,'Shivshakti Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'749',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(751,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'751',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(752,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'752',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(754,'316',NULL,NULL,'S K Agarbathi',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'754',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(755,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'755',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(756,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'756',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(757,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'757',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(758,'316',NULL,NULL,'Vps Enterprises',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'758',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(759,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'759',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(760,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'760',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(761,'316',NULL,NULL,'S K Agarbathi',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'761',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(762,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'762',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(763,'316',NULL,NULL,'Durga Gn Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'763',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(764,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'764',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(765,'316',NULL,NULL,'Ashapura Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'765',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(766,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'766',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(767,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'767',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(768,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'768',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(769,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'769',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(770,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'770',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(771,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'771',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(772,'316',NULL,NULL,'Mahaveer Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'772',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(773,'316',NULL,NULL,'Shree Krishna Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'773',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(775,'316',NULL,NULL,'S K Agarbathi',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'775',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(777,'316',NULL,NULL,'Gulab Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'777',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(780,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'780',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(781,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'781',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(782,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'782',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(783,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'783',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(785,'316',NULL,NULL,'Bhawani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'785',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(786,'316',NULL,NULL,'Mahalxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'786',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(787,'316',NULL,NULL,'S K Agarbathi',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'787',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(788,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'788',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(790,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'790',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(792,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'792',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(793,'316',NULL,NULL,'Ganesh Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'793',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(797,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'797',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(799,'316',NULL,NULL,'Bhawani Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'799',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(803,'316',NULL,NULL,'Mahakali Kamal Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'803',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(805,'316',NULL,NULL,'Chamunda Prov',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'805',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(807,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'807',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(808,'316',NULL,NULL,'Gurukrupa Dhanya Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'808',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(809,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'809',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(810,'316',NULL,NULL,'Renuka Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'810',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(811,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'811',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(812,'316',NULL,NULL,'Nilamber Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'812',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(813,'316',NULL,NULL,'Nilamber Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'813',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(814,'316',NULL,NULL,'Nilamber Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'814',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(817,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'817',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(818,'316',NULL,NULL,'Prashant Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'818',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(819,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'819',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(820,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'820',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(821,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'821',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(822,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'822',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(823,'316',NULL,NULL,'Gurudev Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'823',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(826,'316',NULL,NULL,'Gurudev Traders',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'826',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(828,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'828',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(829,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'829',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(830,'316',NULL,NULL,'Patel Vallabhji Savji',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'830',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(831,'316',NULL,NULL,'Ganesh Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'831',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(832,'316',NULL,NULL,'Chirag Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'832',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(833,'316',NULL,NULL,'Chirag Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'833',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(835,'316',NULL,NULL,'Sagar Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'835',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(837,'316',NULL,NULL,'D R Choudhary Trading',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'837',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(839,'316',NULL,NULL,'Sagar Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'839',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(846,'316',NULL,NULL,'Jai Bhole Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'846',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(847,'316',NULL,NULL,'Geeta Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'847',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(852,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'852',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(854,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'854',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(855,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'855',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(856,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'856',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(857,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'857',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(858,'316',NULL,NULL,'Counter Sales',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'858',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(861,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'861',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(866,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'866',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(867,'316',NULL,NULL,'Chirag Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'867',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(873,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'873',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(874,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'874',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(875,'316',NULL,NULL,'Bhole Mishra Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'875',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(878,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'878',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(879,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'879',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(888,'316',NULL,NULL,'Sansakar Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'888',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(889,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'889',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(890,'316',NULL,NULL,'Sai Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'890',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(891,'316',NULL,NULL,'Dhyaneshwar Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'891',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(892,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'892',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(894,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'894',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(896,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'896',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(897,'316',NULL,NULL,'Rajesh Flower Mart',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'897',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(898,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'898',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(899,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'899',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(900,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'900',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(901,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'901',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(902,'316',NULL,NULL,'Manpasand Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'902',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(908,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'908',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(910,'316',NULL,NULL,'Sahu Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'910',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(916,'316',NULL,NULL,'Ganesh Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'916',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(917,'316',NULL,NULL,'Ganesh Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'917',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(918,'316',NULL,NULL,'Ganesh Gen',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'918',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(920,'316',NULL,NULL,'Mumbradevi Enterprise',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'920',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(926,'316',NULL,NULL,'Swami Samarth Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'926',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(930,'316',NULL,NULL,'DURGA POOJA BHANDAR',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'930',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(932,'316',NULL,NULL,'Sunil Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'932',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(936,'316',NULL,NULL,'Anvita Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'936',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(937,'316',NULL,NULL,'Anvita Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'937',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(938,'316',NULL,NULL,'Anvita Pooja Bhandar',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'938',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(943,'316',NULL,NULL,'Laxmi Gen Store',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'943',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(959,'316',NULL,NULL,'Gurudev Traders (suman Hosp)',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'959',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(964,'316',NULL,NULL,'Niranjan Masala',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'964',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(973,'316',NULL,NULL,'Swami Samrth Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'973',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(974,'316',NULL,NULL,'Swami Samrth Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'974',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(975,'316',NULL,NULL,'Swami Samrth Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'975',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(976,'316',NULL,NULL,'Khedadevi Kirana',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'976',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(979,'316',NULL,NULL,'Swami Samrth Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'979',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(982,'316',NULL,NULL,'Swami Samrth Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'982',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL),(983,'316',NULL,NULL,'Swami Samrth Pooja',5,'0.00','DR',NULL,NULL,NULL,NULL,NULL,NULL,'','',NULL,'27',NULL,NULL,'',NULL,NULL,'','0',NULL,NULL,NULL,NULL,NULL,'983',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'',NULL,0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','0',NULL,'499','499',NULL,499,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int NOT NULL DEFAULT '0',
  `ADDRESS1` text,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `PROSPECT` varchar(255) DEFAULT NULL,
  `CHANNELTYPE_NAME` varchar(255) DEFAULT NULL,
  `TIER` varchar(255) DEFAULT NULL,
  `CUSTOMER_CODE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `PG_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` int DEFAULT '0',
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUB_AC_DEBTORS',
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'SALES_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `INV_ARR` text,
  `INV_NO` text,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'tax_against',
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'van',
  `PROD_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN_QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FREE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROFIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'SALES_DATE',
  `WEIGHT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PRICE_PER` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DMG_MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REMARK` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_ARR` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'add_amt',
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'less_amt',
  `CREATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UPDATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SECURITY_KEY` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AREA` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_MAN` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GROUP_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PARTY_CODE` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FINAL_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BATCH_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `MFG_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `EXP_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `REFERENCE_NO` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=366 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
INSERT INTO `SALES_ITEM_IMPORT` VALUES (1,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2760','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Purabji Super Shopy','1','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Purabji Super Shopy','2760',NULL,'220726210241','','','00007',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(2,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2760','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'siddhivinayak gen','2','2026-04-16','1','S008','Saideep Pooja Oil 800','1','siddhivinayak gen','2760',NULL,'220726210241','','','00035',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(3,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Pooja Bhandar','4','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Gurudev Pooja Bhandar','2880',NULL,'220726210241','','','00002',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(4,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Om Shanti Pooja Bhandar','3','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Hari Om Shanti Pooja Bhandar','2880',NULL,'220726210241','','','00015',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(5,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2760','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jagdamba Gen Store','4','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Jagdamba Gen Store','2760',NULL,'220726210241','','','00051',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(6,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','72','72','0','0','','','0','0','0','0','0','0','8280','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jai Bhole Pooja Bhandar','2','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Jai Bhole Pooja Bhandar','8280',NULL,'220726210241','','','00023',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(7,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1200','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sunil Gen Store','3','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Sunil Gen Store','1200',NULL,'220726210241','','','00008',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(8,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','13800','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Geeta Pooja Bhandar','1','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Geeta Pooja Bhandar','13800',NULL,'220726210241','','','00041',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(9,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Satgurukripa Gen Store','5','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Satgurukripa Gen Store','2880',NULL,'220726210241','','','00037',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(10,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2760','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','2760',NULL,'220726210241','','','00003',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(11,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganeshkrupa Tobaco','3','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Ganeshkrupa Tobaco','2880',NULL,'220726210241','','','00046',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(12,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Shraddha Pooja Bhandar','6','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Sai Shraddha Pooja Bhandar','2880',NULL,'220726210241','','','00027',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(13,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','72','72','0','0','','','0','0','0','0','0','0','8280','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Pooja Bhandar','2','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Sai Pooja Bhandar','8280',NULL,'220726210241','','','00045',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(14,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','0','0','0','0','0','0','27600','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders','4','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders','27600',NULL,'220726210241','','','00043',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(15,'316','3',NULL,'1','1','0','2','110','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','5280','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','110','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Balaji Traders','1','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Sai Balaji Traders','5280',NULL,'220726210241','','','00028',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(16,'316','3',NULL,'1','1','0','2','110','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2640','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','110','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chirag Gen','6','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Chirag Gen','2640',NULL,'220726210241','','','00060',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(17,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','13800','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Navdeep Kirana','5','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Navdeep Kirana','13800',NULL,'220726210241','','','00025',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(18,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','13800','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Navdeep Kirana','5','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Navdeep Kirana','13800',NULL,'220726210241','','','00026',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(19,'316','3',NULL,'1','1','0','2','110','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','72','72','0','0','','','0','0','0','0','0','0','7920','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','110','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Navdeep Kirana','5','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Navdeep Kirana','7920',NULL,'220726210241','','','00056',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(20,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','5520','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Niranjan Masala','6','2026-04-16','1','S008','Saideep Pooja Oil 800','1','Niranjan Masala','5520',NULL,'220726210241','','','00005',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(21,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1200','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'DURGA POOJA BHANDAR','3','2026-04-16','1','S008','Saideep Pooja Oil 800','1','DURGA POOJA BHANDAR','1200',NULL,'220726210241','','','00018',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(22,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chamunda Prov','1','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Chamunda Prov','2880',NULL,'220726210241','','','00062',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(23,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','144','144','0','0','','','-30','0','0','0','0','0','16560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','16560',NULL,'220726210241','','','00085',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(24,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1150','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Pornima Super Market','1','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Pornima Super Market','1150',NULL,'220726210241','','','00064',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(25,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Purabji Super Shopy','1','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Purabji Super Shopy','2880',NULL,'220726210241','','','00080',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(26,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2760','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Counter Sales','1','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Counter Sales','2760',NULL,'220726210241','','','00073',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(27,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','96','96','0','0','','','0','0','0','0','0','0','11040','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Navdeep Kirana','5','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Navdeep Kirana','11040',NULL,'220726210241','','','00070',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(28,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1380','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Rudra Gen Store','5','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Rudra Gen Store','1380',NULL,'220726210241','','','00075',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(29,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','5760','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Balaji Traders','1','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Sai Balaji Traders','5760',NULL,'220726210241','','','00063',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(30,'316','3',NULL,'1','1','0','2','110','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','5280','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','110','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Balaji Traders','1','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Sai Balaji Traders','5280',NULL,'220726210241','','','00081',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(31,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','5520','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurukrupa Dhanya Bhandar','5','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Gurukrupa Dhanya Bhandar','5520',NULL,'220726210241','','','00077',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(32,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','36','36','0','0','','','0','0','0','0','0','0','4140','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahalxmi Gen Store','3','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Mahalxmi Gen Store','4140',NULL,'220726210241','','','00074',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(33,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','13800','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bholenath Dhanya Bhandar','4','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Bholenath Dhanya Bhandar','13800',NULL,'220726210241','','','00082',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(34,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','0','0','0','0','0','0','27600','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders','4','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders','27600',NULL,'220726210241','','','00071',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(35,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','168','168','0','0','','','0','0','0','0','0','0','19320','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Geeta Pooja Bhandar','1','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Geeta Pooja Bhandar','19320',NULL,'220726210241','','','00068',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(36,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shiv Fool Bhandar','4','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Shiv Fool Bhandar','2880',NULL,'220726210241','','','00084',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(37,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2760','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Counter Sales','1','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Counter Sales','2760',NULL,'220726210241','','','00089',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(38,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2760','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Manpasand Masala','2','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Manpasand Masala','2760',NULL,'220726210241','','','00097',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(39,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2760','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chirag Gen','6','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Chirag Gen','2760',NULL,'220726210241','','','00095',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(40,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','5520','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Pooja Bhandar','2','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Sai Pooja Bhandar','5520',NULL,'220726210241','','','00096',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(41,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Durga Gn Store','3','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Durga Gn Store','2880',NULL,'220726210241','','','00090',499,'2026-09-22 07:14:22','2026-09-22 07:14:22',NULL),(42,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganeshkrupa Tobaco','3','2026-04-29','1','S008','Saideep Pooja Oil 800','1','Ganeshkrupa Tobaco','2880',NULL,'220726210241','','','00092',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(43,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Matoshree Dhanya Bhandar','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Matoshree Dhanya Bhandar','3120',NULL,'220726210241','','','00105',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(44,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Patel Vallabhji Savji','6','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Patel Vallabhji Savji','3120',NULL,'220726210241','','','00104',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(45,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sagar Gen Store','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Sagar Gen Store','3120',NULL,'220726210241','','','00123',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(46,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Omkar Gen','1','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Omkar Gen','3120',NULL,'220726210241','','','00102',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(47,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Vps Enterprises','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Vps Enterprises','3120',NULL,'220726210241','','','00099',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(48,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Rudra Gen Store','5','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Rudra Gen Store','3120',NULL,'220726210241','','','00138',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(49,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sumariya Gen','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Sumariya Gen','3120',NULL,'220726210241','','','00125',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(50,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','0','0','0','0','0','0','31200','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','31200',NULL,'220726210241','','','00113',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(51,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'DURGA POOJA BHANDAR','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','DURGA POOJA BHANDAR','3120',NULL,'220726210241','','','00119',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(52,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'DURGA POOJA BHANDAR','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','DURGA POOJA BHANDAR','3120',NULL,'220726210241','','','00130',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(53,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gupta Pooja Bhandar','1','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Gupta Pooja Bhandar','1560',NULL,'220726210241','','','00107',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(54,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Counter Sales','1','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Counter Sales','3120',NULL,'220726210241','','','00110',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(55,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','3120',NULL,'220726210241','','','00109',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(56,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shree Krushna Perfume','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Shree Krushna Perfume','6240',NULL,'220726210241','','','00116',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(57,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganesh Kirana','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Ganesh Kirana','3120',NULL,'220726210241','','','00106',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(58,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chirag Gen','6','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Chirag Gen','3120',NULL,'220726210241','','','00121',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(59,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','0','0','0','0','0','0','31200','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders','31200',NULL,'220726210241','','','00112',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(60,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahalxmi Gen Store','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Mahalxmi Gen Store','3120',NULL,'220726210241','','','00120',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(61,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganeshkrupa Tobaco','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Ganeshkrupa Tobaco','3120',NULL,'220726210241','','','00135',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(62,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Shraddha Pooja Bhandar','6','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Sai Shraddha Pooja Bhandar','3120',NULL,'220726210241','','','00128',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(63,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Renuka Gen Store','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Renuka Gen Store','3120',NULL,'220726210241','','','00126',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(64,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Renuka Gen Store','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Renuka Gen Store','3120',NULL,'220726210241','','','00117',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(65,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shivam Masala','9','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Shivam Masala','6240',NULL,'220726210241','','','00131',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(66,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Laxmi Gen Store','7','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Laxmi Gen Store','1300',NULL,'220726210241','','','00140',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(67,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Krushna Gen Store','2','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Krushna Gen Store','6240',NULL,'220726210241','','','00132',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(68,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','192','192','0','0','','','0','0','0','0','0','0','24960','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Geeta Pooja Bhandar','1','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Geeta Pooja Bhandar','24960',NULL,'220726210241','','','00122',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(69,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dhanlaxmi Gen Store','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Dhanlaxmi Gen Store','3120',NULL,'220726210241','','','00129',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(70,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'D R Choudhary Trading','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','D R Choudhary Trading','6240',NULL,'220726210241','','','00101',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(71,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Choudhary Super Market','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Choudhary Super Market','3120',NULL,'220726210241','','','00118',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(72,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Purabji Super Shopy','1','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Purabji Super Shopy','3120',NULL,'220726210241','','','00136',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(73,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jyoti Kirana','8','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Jyoti Kirana','3120',NULL,'220726210241','','','00108',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(74,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15600','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ashapura Masala','5','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Ashapura Masala','15600',NULL,'220726210241','','','00137',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(75,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','96','96','0','0','','','0','0','0','0','0','0','12480','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Narayan Pooja Bhandar','2','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Narayan Pooja Bhandar','12480',NULL,'220726210241','','','00133',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(76,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jagdamba Gen Store','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Jagdamba Gen Store','3120',NULL,'220726210241','','','00100',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(77,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','72','72','0','0','','','0','0','0','0','0','0','9360','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurukrupa Dhanya Bhandar','5','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Gurukrupa Dhanya Bhandar','9360',NULL,'220726210241','','','00139',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(78,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Om Shanti Pooja Bhandar','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Hari Om Shanti Pooja Bhandar','3120',NULL,'220726210241','','','00127',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(79,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Darshan Farsan','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Hari Darshan Farsan','3120',NULL,'220726210241','','','00114',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(80,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Satguru Pooja Bhandar','7','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Satguru Pooja Bhandar','1560',NULL,'220726210241','','','00115',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(81,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','0','0','0','0','0','0','31200','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','31200',NULL,'220726210241','','','00147',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(82,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Vakrtund Super Market','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Vakrtund Super Market','3120',NULL,'220726210241','','','00141',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(83,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Purabji Super Shopy','1','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Purabji Super Shopy','2880',NULL,'220726210241','','','00154',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(84,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'D R Choudhary Trading','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','D R Choudhary Trading','6240',NULL,'220726210241','','','00145',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(85,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Renuka Gen Store','3','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Renuka Gen Store','3120',NULL,'220726210241','','','00152',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(86,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Counter Sales','1','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Counter Sales','2880',NULL,'220726210241','','','00155',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(87,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jagdamba Gen Store','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Jagdamba Gen Store','2880',NULL,'220726210241','','','00149',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(88,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chamunda Prov','1','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Chamunda Prov','3120',NULL,'220726210241','','','00146',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(89,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','2880','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','2880',NULL,'220726210241','','','00150',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(90,'316','3',NULL,'1','1','0','2','115','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','13800','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','115','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bholenath Dhanya Bhandar','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Bholenath Dhanya Bhandar','13800',NULL,'220726210241','','','00148',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(91,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','0','0','0','0','0','0','31200','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders','4','2026-05-31','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders','31200',NULL,'220726210241','','','00144',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(92,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Counter Sales','1','2026-06-05','1','S008','Saideep Pooja Oil 800','1','Counter Sales','3120',NULL,'220726210241','','','00156',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(93,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Vaishnvi Kirana','7','2026-06-05','1','S008','Saideep Pooja Oil 800','1','Vaishnvi Kirana','3120',NULL,'220726210241','','','00160',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(94,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Om Shanti Pooja Bhandar','3','2026-06-05','1','S008','Saideep Pooja Oil 800','1','Hari Om Shanti Pooja Bhandar','3120',NULL,'220726210241','','','00157',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(95,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Manpasand Masala','2','2026-06-05','1','S008','Saideep Pooja Oil 800','1','Manpasand Masala','3120',NULL,'220726210241','','','00162',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(96,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ramdev Kirana','4','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Ramdev Kirana','3120',NULL,'220726210241','','','00165',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(97,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ashapura Gen Store','7','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Ashapura Gen Store','3120',NULL,'220726210241','','','00166',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(98,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganeshkrupa Tobaco','3','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Ganeshkrupa Tobaco','3120',NULL,'220726210241','','','00167',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(99,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Prashant Pooja','3','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Prashant Pooja','3120',NULL,'220726210241','','','00164',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(100,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jai Bhole Pooja Bhandar','2','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Jai Bhole Pooja Bhandar','6240',NULL,'220726210241','','','00163',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(101,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','72','72','0','0','','','0','0','0','0','0','0','9360','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'New Omkar Dhanya Bhandar','6','2026-06-06','1','S008','Saideep Pooja Oil 800','1','New Omkar Dhanya Bhandar','9360',NULL,'220726210241','','','00172',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(102,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Om Sairam Kirana Store','1','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Om Sairam Kirana Store','3120',NULL,'220726210241','','','00174',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(103,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','-12','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Rudra Gen Store','5','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Rudra Gen Store','3120',NULL,'220726210241','','','00180',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(104,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Pornima Super Market','1','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Pornima Super Market','1560',NULL,'220726210241','','','00175',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(105,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Darshan Farsan','4','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Hari Darshan Farsan','3120',NULL,'220726210241','','','00176',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(106,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chamunda Prov','1','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Chamunda Prov','3120',NULL,'220726210241','','','00170',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(107,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Pooja Bhandar','4','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Gurudev Pooja Bhandar','3120',NULL,'220726210241','','','00171',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(108,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gupta Pooja Bhandar','1','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Gupta Pooja Bhandar','3120',NULL,'220726210241','','','00169',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(109,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Pooja Bhandar','5','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Gurudev Pooja Bhandar','3120',NULL,'220726210241','','','00179',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(110,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Satgurukripa Gen Store','5','2026-06-06','1','S008','Saideep Pooja Oil 800','1','Satgurukripa Gen Store','3120',NULL,'220726210241','','','00182',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(111,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Krushna Gen Store','2','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Krushna Gen Store','6240',NULL,'220726210241','','','00186',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(112,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15600','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','15600',NULL,'220726210241','','','00183',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(113,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','3120',NULL,'220726210241','','','00184',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(114,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Swami Samarth Pooja Bhandar','3','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Swami Samarth Pooja Bhandar','3120',NULL,'220726210241','','','00185',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(115,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sumariya Gen','3','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Sumariya Gen','3120',NULL,'220726210241','','','00192',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(116,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','168','168','0','0','','','0','0','0','0','0','0','21840','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Geeta Pooja Bhandar','1','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Geeta Pooja Bhandar','21840',NULL,'220726210241','','','00200',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(117,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bhole Mishra Pooja Bhandar','4','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Bhole Mishra Pooja Bhandar','3120',NULL,'220726210241','','','00197',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(118,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Patel Vallabhji Savji','6','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Patel Vallabhji Savji','3120',NULL,'220726210241','','','00198',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(119,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dhanavtri Gen Store','3','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Dhanavtri Gen Store','1300',NULL,'220726210241','','','00191',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(120,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Om Shanti Pooja Bhandar','3','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Hari Om Shanti Pooja Bhandar','3120',NULL,'220726210241','','','00190',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(121,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Manish Super Market','4','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Manish Super Market','1300',NULL,'220726210241','','','00199',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(122,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Counter Sales','1','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Counter Sales','3120',NULL,'220726210241','','','00189',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(123,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','6','6','0','0','','','0','0','0','0','0','0','780','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Amar Dairy','3','2026-06-11','1','S008','Saideep Pooja Oil 800','1','Amar Dairy','780',NULL,'220726210241','','','00193',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(124,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Vinayak Gen Store','4','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Vinayak Gen Store','3120',NULL,'220726210241','','','00203',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(125,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Choudhary Super Market','3','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Choudhary Super Market','3120',NULL,'220726210241','','','00205',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(126,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahalxmi Gen Store','3','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Mahalxmi Gen Store','1560',NULL,'220726210241','','','00206',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(127,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Renuka Gen Store','3','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Renuka Gen Store','3120',NULL,'220726210241','','','00207',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(128,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sahu Kirana','3','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Sahu Kirana','3120',NULL,'220726210241','','','00211',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(129,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Pooja Bhandar','8','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Sai Pooja Bhandar','6240',NULL,'220726210241','','','00220',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(130,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hanuman Super Market','4','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Hanuman Super Market','3120',NULL,'220726210241','','','00215',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(131,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Om Shanti Pooja Bhandar','3','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Hari Om Shanti Pooja Bhandar','3120',NULL,'220726210241','','','00208',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(132,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15600','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bholenath Dhanya Bhandar','4','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Bholenath Dhanya Bhandar','15600',NULL,'220726210241','','','00216',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(133,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Satguru Pooja Bhandar','7','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Satguru Pooja Bhandar','1300',NULL,'220726210241','','','00223',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(134,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15600','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','15600',NULL,'220726210241','','','00224',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(135,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Vakrtund Super Market','3','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Vakrtund Super Market','3120',NULL,'220726210241','','','00214',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(136,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Niranjan Masala','6','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Niranjan Masala','3120',NULL,'220726210241','','','00219',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(137,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shree Krushna Grain Store','2','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Shree Krushna Grain Store','6240',NULL,'220726210241','','','00210',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(138,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bhawani Pooja Bhandar','7','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Bhawani Pooja Bhandar','3120',NULL,'220726210241','','','00222',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(139,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shiv Fool Bhandar','4','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Shiv Fool Bhandar','3120',NULL,'220726210241','','','00221',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(140,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dhanavtri Gen Store','3','2026-06-17','1','S008','Saideep Pooja Oil 800','1','Dhanavtri Gen Store','1560',NULL,'220726210241','','','00209',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(141,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mumbradevi Enterprise','1','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Mumbradevi Enterprise','15000',NULL,'220726210241','','','00226',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(142,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shital Gen','1','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Shital Gen','3120',NULL,'220726210241','','','00227',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(143,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15600','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gaytri Traders','4','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Gaytri Traders','15600',NULL,'220726210241','','','00231',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(144,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurukrupa Dhanya Bhandar','5','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Gurukrupa Dhanya Bhandar','6240',NULL,'220726210241','','','00229',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(145,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','0','0','0','0','0','0','30000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','30000',NULL,'220726210241','','','00232',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(146,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Swami Samarth Gen Store','3','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Swami Samarth Gen Store','3120',NULL,'220726210241','','','00230',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(147,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganesh Kirana','3','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Ganesh Kirana','3120',NULL,'220726210241','','','00233',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(148,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Satgurukripa Gen Store','5','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Satgurukripa Gen Store','6240',NULL,'220726210241','','','00236',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(149,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','6','6','0','0','','','0','0','0','0','0','0','780','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Satguru Pooja Bhandar','7','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Satguru Pooja Bhandar','780',NULL,'220726210241','','','00239',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(150,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sahu Kirana','3','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Sahu Kirana','3120',NULL,'220726210241','','','00255',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(151,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sagar Gen Store','4','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Sagar Gen Store','3120',NULL,'220726210241','','','00251',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(152,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Laxmi Gen Store','7','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Laxmi Gen Store','1300',NULL,'220726210241','','','00246',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(153,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15600','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ajay Pooja Bhandar','4','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Ajay Pooja Bhandar','15600',NULL,'220726210241','','','00266',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(154,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shivansh Gen Store','1','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Shivansh Gen Store','1300',NULL,'220726210241','','','00271',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(155,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Pooja Bhandar','4','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Gurudev Pooja Bhandar','3120',NULL,'220726210241','','','00253',499,'2026-09-22 07:14:23','2026-09-22 07:14:23',NULL),(156,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Nilamber Pooja Bhandar','2','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Nilamber Pooja Bhandar','3120',NULL,'220726210241','','','00254',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(157,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'New Rahul Kirana','1','2026-06-29','1','S008','Saideep Pooja Oil 800','1','New Rahul Kirana','3120',NULL,'220726210241','','','00272',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(158,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Suvidha Super Market','1','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Suvidha Super Market','1560',NULL,'220726210241','','','00240',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(159,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'D R Choudhary Trading','4','2026-06-29','1','S008','Saideep Pooja Oil 800','1','D R Choudhary Trading','3120',NULL,'220726210241','','','00252',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(160,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','3120',NULL,'220726210241','','','00242',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(161,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','24','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chamunda Prov','1','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Chamunda Prov','3120',NULL,'220726210241','','','00268',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(162,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dhanlaxmi Gen Store','3','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Dhanlaxmi Gen Store','3120',NULL,'220726210241','','','00257',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(163,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Poonam Dry Friut','1','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Poonam Dry Friut','1300',NULL,'220726210241','','','00269',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(164,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganeshkrupa Tobaco','3','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Ganeshkrupa Tobaco','3120',NULL,'220726210241','','','00256',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(165,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bhole Mishra Pooja Bhandar','4','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Bhole Mishra Pooja Bhandar','3120',NULL,'220726210241','','','00245',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(166,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15600','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Navdeep Kirana','5','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Navdeep Kirana','15600',NULL,'220726210241','','','00261',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(167,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Durga Gen Store','1','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Durga Gen Store','1300',NULL,'220726210241','','','00270',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(168,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Vps Enterprises','4','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Vps Enterprises','3120',NULL,'220726210241','','','00262',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(169,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jai Bhole Pooja Bhandar','2','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Jai Bhole Pooja Bhandar','3120',NULL,'220726210241','','','00248',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(170,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Uma Gen Store','6','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Uma Gen Store','3120',NULL,'220726210241','','','00238',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(171,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gulab Kirana','6','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Gulab Kirana','3120',NULL,'220726210241','','','00244',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(172,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Patel Vallabhji Savji','6','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Patel Vallabhji Savji','3120',NULL,'220726210241','','','00243',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(173,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'DURGA POOJA BHANDAR','3','2026-06-29','1','S008','Saideep Pooja Oil 800','1','DURGA POOJA BHANDAR','3120',NULL,'220726210241','','','00258',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(174,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Balaji Traders','1','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Sai Balaji Traders','6240',NULL,'220726210241','','','00275',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(175,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Satguru Pooja Bhandar','7','2026-06-29','1','S008','Saideep Pooja Oil 800','1','Satguru Pooja Bhandar','3120',NULL,'220726210241','','','00273',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(176,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dipesh Kirana','7','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Dipesh Kirana','1300',NULL,'220726210241','','','00279',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(177,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Rashtriy Society','2','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Rashtriy Society','3120',NULL,'220726210241','','','00281',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(178,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ashok Gen Store','4','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Ashok Gen Store','3120',NULL,'220726210241','','','00277',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(179,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Rudra Gen Store','5','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Rudra Gen Store','3120',NULL,'220726210241','','','00278',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(180,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganesh Kirana','2','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Ganesh Kirana','1300',NULL,'220726210241','','','00280',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(181,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','3120',NULL,'220726210241','','','00283',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(182,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jai Bhole Pooja Bhandar','2','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Jai Bhole Pooja Bhandar','6240',NULL,'220726210241','','','00286',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(183,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'DURGA POOJA BHANDAR','3','2026-07-10','1','S008','Saideep Pooja Oil 800','1','DURGA POOJA BHANDAR','3120',NULL,'220726210241','','','00282',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(184,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Balaji Grain','4','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Balaji Grain','3120',NULL,'220726210241','','','00284',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(185,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Prashant Pooja','3','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Prashant Pooja','3120',NULL,'220726210241','','','00292',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(186,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','6','6','0','0','','','0','0','0','0','0','0','780','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Amar Dairy','3','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Amar Dairy','780',NULL,'220726210241','','','00291',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(187,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahaveer Kirana','3','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Mahaveer Kirana','3120',NULL,'220726210241','','','00293',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(188,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Durga Gn Store','3','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Durga Gn Store','6240',NULL,'220726210241','','','00304',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(189,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Pooja Bhandar','8','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Sai Pooja Bhandar','3120',NULL,'220726210241','','','00297',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(190,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chamunda Prov','1','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Chamunda Prov','3120',NULL,'220726210241','','','00302',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(191,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sahu Kirana','3','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Sahu Kirana','3120',NULL,'220726210241','','','00303',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(192,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chirag Gen','6','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Chirag Gen','3120',NULL,'220726210241','','','00307',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(193,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Darshan Farsan','4','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Hari Darshan Farsan','3120',NULL,'220726210241','','','00296',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(194,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bhawani Pooja Bhandar','7','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Bhawani Pooja Bhandar','3120',NULL,'220726210241','','','00306',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(195,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bholenath Dhanya Bhandar','4','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Bholenath Dhanya Bhandar','15000',NULL,'220726210241','','','00305',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(196,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','15000',NULL,'220726210241','','','00300',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(197,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'New Rahul Kirana','1','2026-07-10','1','S008','Saideep Pooja Oil 800','1','New Rahul Kirana','6240',NULL,'220726210241','','','00298',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(198,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sahu Kirana','3','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Sahu Kirana','3120',NULL,'220726210241','','','00310',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(199,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'D R Choudhary Trading','4','2026-07-10','1','S008','Saideep Pooja Oil 800','1','D R Choudhary Trading','3120',NULL,'220726210241','','','00311',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(200,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sumariya Gen','3','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Sumariya Gen','3120',NULL,'220726210241','','','00313',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(201,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shree Krishna Prov','3','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Shree Krishna Prov','3120',NULL,'220726210241','','','00315',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(202,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurukrupa Dhanya Bhandar','5','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Gurukrupa Dhanya Bhandar','6000',NULL,'220726210241','','','00309',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(203,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders','4','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders','15000',NULL,'220726210241','','','00317',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(204,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Pooja Bhandar','5','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Gurudev Pooja Bhandar','3120',NULL,'220726210241','','','00319',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(205,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jai Bajarang Pooja Bhandar','4','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Jai Bajarang Pooja Bhandar','3120',NULL,'220726210241','','','00318',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(206,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jai Bhole Pooja Bhandar','2','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Jai Bhole Pooja Bhandar','3120',NULL,'220726210241','','','00322',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(207,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','168','168','0','0','','','0','0','0','0','0','0','21840','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-07-10','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','21840',NULL,'220726210241','','','00321',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(208,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganesh Gen','1','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Ganesh Gen','3120',NULL,'220726210241','','','00326',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(209,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shiv Fool Bhandar','4','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Shiv Fool Bhandar','3120',NULL,'220726210241','','','00324',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(210,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Pooja Bhandar','5','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Gurudev Pooja Bhandar','3120',NULL,'220726210241','','','00334',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(211,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Satgurukripa Gen Store','5','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Satgurukripa Gen Store','6240',NULL,'220726210241','','','00333',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(212,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'D R Choudhary Trading','4','2026-07-18','1','S008','Saideep Pooja Oil 800','1','D R Choudhary Trading','6240',NULL,'220726210241','','','00328',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(213,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','8','8','0','0','','','0','0','0','0','0','0','1040','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Anjali Gen Store','5','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Anjali Gen Store','1040',NULL,'220726210241','','','00335',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(214,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','3120',NULL,'220726210241','','','00330',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(215,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders','4','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders','15000',NULL,'220726210241','','','00331',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(216,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Darshan Farsan','4','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Hari Darshan Farsan','3120',NULL,'220726210241','','','00329',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(217,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Patel Vallabhji Savji','6','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Patel Vallabhji Savji','3120',NULL,'220726210241','','','00336',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(218,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Saraswati Kirana','6','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Saraswati Kirana','3120',NULL,'220726210241','','','00337',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(219,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahalxmi Gen Store','3','2026-07-18','1','S008','Saideep Pooja Oil 800','1','Mahalxmi Gen Store','6240',NULL,'220726210241','','','00339',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(220,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahalxmi Gen Store','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Mahalxmi Gen Store','1300',NULL,'220726210241','','','00349',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(221,'316','3',NULL,'1','1','0','2','192','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','23040','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','192','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Geeta Pooja Bhandar','1','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Geeta Pooja Bhandar','23040',NULL,'220726210241','','','00356',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(222,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurukrupa Dhanya Bhandar','5','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Gurukrupa Dhanya Bhandar','6000',NULL,'220726210241','','','00351',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(223,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Swami Samarth Gen Store','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Swami Samarth Gen Store','3120',NULL,'220726210241','','','00360',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(224,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Omkar Gen','1','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Omkar Gen','3120',NULL,'220726210241','','','00361',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(225,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Nilamber Pooja Bhandar','2','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Nilamber Pooja Bhandar','3120',NULL,'220726210241','','','00348',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(226,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sahu Kirana','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Sahu Kirana','3120',NULL,'220726210241','','','00342',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(227,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shree Krishna Prov','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Shree Krishna Prov','3000',NULL,'220726210241','','','00340',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(228,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Vps Enterprises','4','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Vps Enterprises','3120',NULL,'220726210241','','','00346',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(229,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Swami Samarth Pooja Bhandar','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Swami Samarth Pooja Bhandar','6240',NULL,'220726210241','','','00355',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(230,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Darshan Farsan','4','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Hari Darshan Farsan','3120',NULL,'220726210241','','','00357',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(231,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dhyaneshwar Kirana','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Dhyaneshwar Kirana','3120',NULL,'220726210241','','','00344',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(232,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','3120',NULL,'220726210241','','','00358',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(233,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Durga Gn Store','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Durga Gn Store','6240',NULL,'220726210241','','','00343',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(234,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Shraddha Pooja Bhandar','6','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Sai Shraddha Pooja Bhandar','3000',NULL,'220726210241','','','00347',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(235,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jagdamba Gen Store','4','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Jagdamba Gen Store','3000',NULL,'220726210241','','','00359',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(236,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Swami Samarth Pooja Bhandar','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Swami Samarth Pooja Bhandar','3120',NULL,'220726210241','','','00350',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(237,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','168','168','0','0','','','0','0','0','0','0','0','21000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','21000',NULL,'220726210241','','','00353',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(238,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sagar Gen Store','4','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Sagar Gen Store','3120',NULL,'220726210241','','','00352',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(239,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shree Krishna Prov','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Shree Krishna Prov','3120',NULL,'220726210241','','','00369',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(240,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders','4','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders','15000',NULL,'220726210241','','','00365',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(241,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Om Sairam Kirana Store','1','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Om Sairam Kirana Store','6000',NULL,'220726210241','','','00375',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(242,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jai Bhole Pooja Bhandar','2','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Jai Bhole Pooja Bhandar','6240',NULL,'220726210241','','','00374',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(243,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Pooja Bhandar','8','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Sai Pooja Bhandar','3120',NULL,'220726210241','','','00364',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(244,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sumariya Gen','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Sumariya Gen','3120',NULL,'220726210241','','','00371',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(245,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganeshkrupa Tobaco','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Ganeshkrupa Tobaco','3120',NULL,'220726210241','','','00368',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(246,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Renuka Gen Store','3','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Renuka Gen Store','3120',NULL,'220726210241','','','00367',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(247,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','72','72','0','0','','','0','0','0','0','0','0','9360','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hanuman Super Market','4','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Hanuman Super Market','9360',NULL,'220726210241','','','00380',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(248,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganesh Kirana','2','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Ganesh Kirana','3120',NULL,'220726210241','','','00383',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(249,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chirag Gen','6','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Chirag Gen','3120',NULL,'220726210241','','','00381',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(250,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Durga Gen Store','1','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Durga Gen Store','1300',NULL,'220726210241','','','00376',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(251,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Prabhu Pan Shop','1','2026-07-22','1','S008','Saideep Pooja Oil 800','1','Prabhu Pan Shop','3120',NULL,'220726210241','','','00377',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(252,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'D R Choudhary Trading','4','2026-07-22','1','S008','Saideep Pooja Oil 800','1','D R Choudhary Trading','6240',NULL,'220726210241','','','00378',499,'2026-09-22 07:14:24','2026-09-22 07:14:24',NULL),(253,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jai Bhavani Pooja Bhandar','4','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Jai Bhavani Pooja Bhandar','3120',NULL,'220726210241','','','00388',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(254,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Satguru Pooja Bhandar','7','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Satguru Pooja Bhandar','3120',NULL,'220726210241','','','00386',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(255,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Niranjan Masala','6','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Niranjan Masala','3120',NULL,'220726210241','','','00394',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(256,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','-12','0','0','0','0','0','30000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','30000',NULL,'220726210241','','','00397',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(257,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','192','192','0','0','','','0','0','0','0','0','0','24000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shree Samarth Krupa Home Mart','1','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Shree Samarth Krupa Home Mart','24000',NULL,'220726210241','','','00393',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(258,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurukrupa Dhanya Bhandar','5','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Gurukrupa Dhanya Bhandar','6000',NULL,'220726210241','','','00395',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(259,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sahu Kirana','3','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Sahu Kirana','3120',NULL,'220726210241','','','00385',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(260,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Purabji Super Shopy','1','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Purabji Super Shopy','3120',NULL,'220726210241','','','00384',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(261,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Darshan Farsan','4','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Hari Darshan Farsan','3120',NULL,'220726210241','','','00390',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(262,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Shraddha Pooja Bhandar','6','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Sai Shraddha Pooja Bhandar','3000',NULL,'220726210241','','','00405',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(263,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gupta Pooja Bhandar','1','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Gupta Pooja Bhandar','3120',NULL,'220726210241','','','00403',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(264,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Pooja Bhandar','4','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Gurudev Pooja Bhandar','3120',NULL,'220726210241','','','00402',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(265,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Rajesh Kirana','5','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Rajesh Kirana','3120',NULL,'220726210241','','','00404',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(266,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shivshakti Kirana','8','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Shivshakti Kirana','3000',NULL,'220726210241','','','00400',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(267,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jyoti Kirana','8','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Jyoti Kirana','3120',NULL,'220726210241','','','00399',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(268,'316','3',NULL,'1','1','0','2','240','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','125','125','0','0','','','0','0','0','0','0','0','30000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','240','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders','4','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders','30000',NULL,'220726210241','','','00398',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(269,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','0','0','0','0','0','0','28800','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'S K Agarbathi','1','2026-07-30','1','S008','Saideep Pooja Oil 800','1','S K Agarbathi','28800',NULL,'220726210241','','','00408',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(270,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Vps Enterprises','4','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Vps Enterprises','3120',NULL,'220726210241','','','00419',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(271,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Durga Gn Store','3','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Durga Gn Store','3000',NULL,'220726210241','','','00413',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(272,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Swami Samarth Pooja Bhandar','3','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Swami Samarth Pooja Bhandar','6240',NULL,'220726210241','','','00415',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(273,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ashapura Gen Store','7','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Ashapura Gen Store','3120',NULL,'220726210241','','','00416',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(274,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','14400','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mumbradevi Enterprise','1','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Mumbradevi Enterprise','14400',NULL,'220726210241','','','00421',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(275,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shree Krishna Prov','3','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Shree Krishna Prov','3000',NULL,'220726210241','','','00414',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(276,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','6','6','0','0','','','0','0','0','0','0','0','780','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dhanavtri Gen Store','3','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Dhanavtri Gen Store','780',NULL,'220726210241','','','00412',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(277,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gulab Kirana','6','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Gulab Kirana','3120',NULL,'220726210241','','','00406',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(278,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','3120',NULL,'220726210241','','','00418',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(279,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'DURGA POOJA BHANDAR','3','2026-07-30','1','S008','Saideep Pooja Oil 800','1','DURGA POOJA BHANDAR','3120',NULL,'220726210241','','','00407',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(280,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Radhesham Pooja Bhandar','1','2026-07-30','1','S008','Saideep Pooja Oil 800','1','Radhesham Pooja Bhandar','3120',NULL,'220726210241','','','00410',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(281,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahalxmi Gen Store','8','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Mahalxmi Gen Store','1560',NULL,'220726210241','','','00439',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(282,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Balaji Traders','1','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Sai Balaji Traders','3120',NULL,'220726210241','','','00424',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(283,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganeshkrupa Tobaco','3','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Ganeshkrupa Tobaco','3120',NULL,'220726210241','','','00435',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(284,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Swami Samarth Gen Store','3','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Swami Samarth Gen Store','3120',NULL,'220726210241','','','00434',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(285,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Counter Sales','1','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Counter Sales','3120',NULL,'220726210241','','','00436',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(286,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','6','6','0','0','','','0','0','0','0','0','0','780','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Amar Dairy','3','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Amar Dairy','780',NULL,'220726210241','','','00433',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(287,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shree Krushna Grain Store','2','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Shree Krushna Grain Store','3120',NULL,'220726210241','','','00430',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(288,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahaveer Kirana','2','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Mahaveer Kirana','3120',NULL,'220726210241','','','00427',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(289,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bhawani Pooja Bhandar','7','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Bhawani Pooja Bhandar','3120',NULL,'220726210241','','','00437',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(290,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chamunda Prov','1','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Chamunda Prov','3120',NULL,'220726210241','','','00425',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(291,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahakali Kamal Pooja Bhandar','1','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Mahakali Kamal Pooja Bhandar','15000',NULL,'220726210241','','','00432',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(292,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurukrupa Dhanya Bhandar','5','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Gurukrupa Dhanya Bhandar','6000',NULL,'220726210241','','','00428',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(293,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Renuka Gen Store','3','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Renuka Gen Store','3120',NULL,'220726210241','','','00423',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(294,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Nilamber Pooja Bhandar','2','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Nilamber Pooja Bhandar','6000',NULL,'220726210241','','','00449',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(295,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Rudra Gen Store','5','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Rudra Gen Store','3120',NULL,'220726210241','','','00446',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(296,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Prashant Pooja','3','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Prashant Pooja','3120',NULL,'220726210241','','','00447',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(297,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Pooja Bhandar','8','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Sai Pooja Bhandar','3120',NULL,'220726210241','','','00441',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(298,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sahu Kirana','3','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Sahu Kirana','3120',NULL,'220726210241','','','00448',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(299,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Pooja Bhandar','5','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Gurudev Pooja Bhandar','3120',NULL,'220726210241','','','00440',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(300,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'New Rahul Kirana','1','2026-08-06','1','S008','Saideep Pooja Oil 800','1','New Rahul Kirana','3120',NULL,'220726210241','','','00442',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(301,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Patel Vallabhji Savji','6','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Patel Vallabhji Savji','3120',NULL,'220726210241','','','00452',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(302,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganesh Kirana','2','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Ganesh Kirana','3120',NULL,'220726210241','','','00450',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(303,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chirag Gen','6','2026-08-06','1','S008','Saideep Pooja Oil 800','1','Chirag Gen','3120',NULL,'220726210241','','','00451',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(304,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Om Shanti Pooja Bhandar','3','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Hari Om Shanti Pooja Bhandar','3120',NULL,'220726210241','','','00484',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(305,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Vps Enterprises','4','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Vps Enterprises','3120',NULL,'220726210241','','','00469',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(306,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Choudhary Super Market','3','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Choudhary Super Market','3120',NULL,'220726210241','','','00471',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(307,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Balaji Traders','1','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Sai Balaji Traders','3120',NULL,'220726210241','','','00454',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(308,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chamunda Prov','1','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Chamunda Prov','3120',NULL,'220726210241','','','00453',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(309,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Rajendra Gen Store','4','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Rajendra Gen Store','3120',NULL,'220726210241','','','00465',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(310,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Renuka Gen Store','3','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Renuka Gen Store','3120',NULL,'220726210241','','','00455',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(311,'316','3',NULL,'1','1','0','2','48','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','130','130','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','48','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'D R Choudhary Trading','4','2026-08-12','1','S008','Saideep Pooja Oil 800','1','D R Choudhary Trading','6240',NULL,'220726210241','','','00460',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(312,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Satguru Pooja Bhandar','7','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Satguru Pooja Bhandar','3120',NULL,'220726210241','','','00474',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(313,'316','3',NULL,'1','1','0','2','120','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','600','600','0','0','','','-243','0','0','0','0','0','72000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','120','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Geeta Pooja Bhandar','1','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Geeta Pooja Bhandar','72000',NULL,'220726210241','','','00487',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(314,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Niranjan Masala','6','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Niranjan Masala','3000',NULL,'220726210241','','','00480',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(315,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders','4','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders','15000',NULL,'220726210241','','','00457',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(316,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurukrupa Dhanya Bhandar','5','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Gurukrupa Dhanya Bhandar','3000',NULL,'220726210241','','','00470',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(317,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Durga Gn Store','3','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Durga Gn Store','3000',NULL,'220726210241','','','00483',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(318,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Shraddha Pooja Bhandar','6','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Sai Shraddha Pooja Bhandar','3000',NULL,'220726210241','','','00479',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(319,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bholenath Dhanya Bhandar','4','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Bholenath Dhanya Bhandar','15000',NULL,'220726210241','','','00477',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(320,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'New Rahul Kirana','1','2026-08-12','1','S008','Saideep Pooja Oil 800','1','New Rahul Kirana','6240',NULL,'220726210241','','','00475',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(321,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','96','96','0','0','','','0','0','0','0','0','0','12000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Counter Sales','1','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Counter Sales','12000',NULL,'220726210241','','','00486',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(322,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahalxmi Gen Store','8','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Mahalxmi Gen Store','3120',NULL,'220726210241','','','00468',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(323,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ashok Gen Store','4','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Ashok Gen Store','3120',NULL,'220726210241','','','00464',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(324,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','3120',NULL,'220726210241','','','00459',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(325,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','120','120','0','0','','','0','0','0','0','0','0','15000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Pooja Bhandar','6','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Sai Pooja Bhandar','15000',NULL,'220726210241','','','00481',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(326,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dhyaneshwar Kirana','3','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Dhyaneshwar Kirana','3120',NULL,'220726210241','','','00466',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(327,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'DURGA POOJA BHANDAR','3','2026-08-12','1','S008','Saideep Pooja Oil 800','1','DURGA POOJA BHANDAR','3120',NULL,'220726210241','','','00482',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(328,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sahu Kirana','3','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Sahu Kirana','3120',NULL,'220726210241','','','00472',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(329,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shree Krishna Prov','3','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Shree Krishna Prov','3000',NULL,'220726210241','','','00467',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(330,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahalxmi Gen Store','3','2026-08-12','1','S008','Saideep Pooja Oil 800','1','Mahalxmi Gen Store','1560',NULL,'220726210241','','','00490',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(331,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Hari Darshan Farsan','4','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Hari Darshan Farsan','3120',NULL,'220726210241','','','00494',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(332,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ashapura Gen Store','7','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Ashapura Gen Store','3120',NULL,'220726210241','','','00493',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(333,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sahu Kirana','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Sahu Kirana','3120',NULL,'220726210241','','','00501',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(334,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sahu Kirana','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Sahu Kirana','3120',NULL,'220726210241','','','00499',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(335,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Durga Gen Store','1','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Durga Gen Store','1560',NULL,'220726210241','','','00498',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(336,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sai Pooja Bhandar','8','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Sai Pooja Bhandar','3120',NULL,'220726210241','','','00495',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(337,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganesh Gen','1','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Ganesh Gen','3120',NULL,'220726210241','','','00502',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(338,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','12','12','0','0','','','0','0','0','0','0','0','1560','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Counter Sales','1','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Counter Sales','1560',NULL,'220726210241','','','00496',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(339,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Rajesh Kirana','5','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Rajesh Kirana','3120',NULL,'220726210241','','','00503',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(340,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Swami Samarth Pooja Bhandar','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Swami Samarth Pooja Bhandar','3120',NULL,'220726210241','','','00500',499,'2026-09-22 07:14:25','2026-09-22 07:14:25',NULL),(341,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sansakar Pooja Bhandar','4','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Sansakar Pooja Bhandar','3120',NULL,'220726210241','','','00504',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(342,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chamunda Prov','1','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Chamunda Prov','3120',NULL,'220726210241','','','00506',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(343,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','6','6','0','0','','','0','0','0','0','0','0','780','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sunil Gen Store','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Sunil Gen Store','780',NULL,'220726210241','','','00507',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(344,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Anvita Pooja Bhandar','1','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Anvita Pooja Bhandar','3120',NULL,'220726210241','','','00505',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(345,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'DURGA POOJA BHANDAR','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','DURGA POOJA BHANDAR','3120',NULL,'220726210241','','','00508',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(346,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Vps Enterprises','4','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Vps Enterprises','3120',NULL,'220726210241','','','00519',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(347,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Sumariya Gen','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Sumariya Gen','3120',NULL,'220726210241','','','00512',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(348,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Bhawani Pooja Bhandar','7','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Bhawani Pooja Bhandar','3120',NULL,'220726210241','','','00517',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(349,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Mahaveer Kirana','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Mahaveer Kirana','3120',NULL,'220726210241','','','00510',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(350,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dhyaneshwar Kirana','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Dhyaneshwar Kirana','3120',NULL,'220726210241','','','00509',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(351,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dhanlaxmi Gen Store','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Dhanlaxmi Gen Store','6000',NULL,'220726210241','','','00513',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(352,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Swami Samarth Pooja Bhandar','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Swami Samarth Pooja Bhandar','3120',NULL,'220726210241','','','00515',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(353,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Durga Gn Store','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Durga Gn Store','3120',NULL,'220726210241','','','00514',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(354,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Jai Bajarang Pooja Bhandar','4','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Jai Bajarang Pooja Bhandar','3120',NULL,'220726210241','','','00520',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(355,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','6','6','0','0','','','0','0','0','0','0','0','780','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Dhanavtri Gen Store','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Dhanavtri Gen Store','780',NULL,'220726210241','','','00511',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(356,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Shree Krishna Prov','3','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Shree Krishna Prov','3000',NULL,'220726210241','','','00516',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(357,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','0','0','0','0','0','0','30000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders','4','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders','30000',NULL,'220726210241','','','00523',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(358,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','240','240','0','0','','','0','0','0','0','0','0','30000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Traders (suman Hosp)','4','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Gurudev Traders (suman Hosp)','30000',NULL,'220726210241','','','00524',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(359,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Chirag Gen','6','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Chirag Gen','3120',NULL,'220726210241','','','00527',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(360,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganesh Gen','1','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Ganesh Gen','3120',NULL,'220726210241','','','00526',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(361,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Gurudev Pooja Bhandar','4','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Gurudev Pooja Bhandar','3120',NULL,'220726210241','','','00522',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(362,'316','3',NULL,'1','1','0','2','125','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','144','144','0','0','','','0','0','0','0','0','0','18000','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','125','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Swami Samrth Pooja','1','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Swami Samrth Pooja','18000',NULL,'220726210241','','','00535',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(363,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','10','10','0','0','','','0','0','0','0','0','0','1300','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Khedadevi Kirana','1','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Khedadevi Kirana','1300',NULL,'220726210241','','','00534',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(364,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','24','24','0','0','','','0','0','0','0','0','0','3120','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ashapura Gen Store','2','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Ashapura Gen Store','3120',NULL,'220726210241','','','00531',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL),(365,'316','3',NULL,'1','1','0','2','130','115','0','1','0.5','0.5','0','0','0','0','0','0','0','1','48','48','0','0','','','0','0','0','0','0','0','6240','0','0','0','0','0','0','0','0','0','0','0','','0','0',0,'250','','1','2','0','130','0','0','0','0','0','0','','0','0',0,'N','0','0','499','499','',0,'Ganesh Kirana','2','2026-08-19','1','S008','Saideep Pooja Oil 800','1','Ganesh Kirana','6240',NULL,'220726210241','','','00532',499,'2026-09-22 07:14:26','2026-09-22 07:14:26',NULL);
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int DEFAULT '0',
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int DEFAULT '0',
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL COMMENT 'SUB_AC_DEBTORS',
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL COMMENT 'SALES_DATE',
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `REFERENCE_NO` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int DEFAULT '0',
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SMAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  `REPORTING_MANAGER_ID` varchar(255) DEFAULT NULL,
  `TRAINER_ID` varchar(255) DEFAULT NULL,
  `PSR_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
INSERT INTO `SMAN` VALUES (1,NULL,NULL,'RUPESH 9987489942','RUPESH 9987489942',NULL,NULL,'316',NULL,'499','499',NULL,0,'2026-09-22 07:14:21','2026-09-22 07:14:21',499,NULL,NULL,NULL);
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYNC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text,
  `UPDATED_VALUE` text,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text,
  `DIACM` text,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int DEFAULT '0',
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int DEFAULT '0',
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-09-22 06:16:38','2026-09-22 06:16:38');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TRAINER_MANAGER`
--

DROP TABLE IF EXISTS `TRAINER_MANAGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TRAINER_MANAGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TRAINER_NAME` varchar(255) DEFAULT NULL,
  `TRAINER_CODE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TRAINER_MANAGER`
--

LOCK TABLES `TRAINER_MANAGER` WRITE;
/*!40000 ALTER TABLE `TRAINER_MANAGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `TRAINER_MANAGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UOM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int DEFAULT '0',
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `WEB_ID` int NOT NULL DEFAULT '0',
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-09-22 06:16:43');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-22  8:00:40
