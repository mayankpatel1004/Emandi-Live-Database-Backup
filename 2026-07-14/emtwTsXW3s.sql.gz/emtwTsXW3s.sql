-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: emtwTsXW3s
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `emtwTsXW3s`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `emtwTsXW3s` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `emtwTsXW3s`;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AREA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
INSERT INTO `AREA` VALUES (1,'249',NULL,NULL,'1','DEFAULT',NULL,'397','397',NULL,0,'2026-05-16 10:18:16','2026-05-16 10:18:16'),(2,'249',NULL,NULL,'3','KURLA STN',NULL,'397','397',NULL,0,'2026-05-16 10:18:16','2026-05-16 10:18:16'),(3,'249',NULL,NULL,'4','LTT STN',NULL,'397','397',NULL,0,'2026-05-16 10:18:16','2026-05-16 10:18:16'),(4,'249',NULL,NULL,'5','WS',NULL,'397','397',NULL,0,'2026-05-16 10:18:16','2026-05-16 10:18:16'),(5,'249',NULL,NULL,'6','DADAR',NULL,'397','397',NULL,0,'2026-05-16 10:18:16','2026-05-16 10:18:16'),(6,'249',NULL,NULL,'7','MATUNGA',NULL,'397','397',NULL,0,'2026-05-16 10:18:16','2026-05-16 10:18:16'),(7,'249',NULL,NULL,'8','KANJURMARG',NULL,'397','397',NULL,0,'2026-05-16 10:18:16','2026-05-16 10:18:16'),(8,'249',NULL,NULL,'9','GHATKOPAR',NULL,'397','397',NULL,0,'2026-05-16 10:18:16','2026-05-16 10:18:16');
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CONFIG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text,
  `MASTER` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'249','0','emtwTsXW3s',249,'','','','2026-05-16 07:11:50','2026-05-16 07:11:50','','','','','','','','','2026-05-16 07:11:50','397','397','',0,'2026-05-16 07:11:50','2026-05-16 07:11:50');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` varchar(255) DEFAULT 'No',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (249,NULL,NULL,'0','PUNAM DISTRIBUTORS','2026-04-01','2027-03-31','001,PESTOM SAGAR ROAD NO 3','OPP SHOPPERS STOP CHEMBUR','MUMBAI','21','9111111111','','','','','','','','','','','','','','11519007000199',NULL,'0',NULL,NULL,'27','27AEXPD4855P1ZJ','','punam@yopmail.com','','400089',NULL,'1',NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-05-16 07:11:50','2026-05-16 07:16:22',NULL,'','','punam','Yes');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `CREATED_TS` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `BATCH_ID` int DEFAULT '0',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DISP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `DELETED` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int DEFAULT '0',
  `TAX_ID` int DEFAULT '0',
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) DEFAULT NULL,
  `CONFIG_UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY_STATUS` varchar(255) DEFAULT NULL,
  `SELECT_OPTIONS` varchar(255) DEFAULT NULL,
  `GROUP_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'Printpage_size','255mm 100mm','','Y','1','1'),(2,'Printpage_margin','10mm 0 0 16mm','','Y','1','1'),(3,'invoice_page_width','255','mm','Y','1','1'),(4,'invoice_page_height','100','mm','Y','1','1'),(5,'header_height','20','mm','Y','1','2'),(6,'items_height','30','mm','Y','1','2'),(7,'items_padding_top','1','mm','Y','1','3'),(8,'blank_height','2','mm','Y','1','4'),(9,'footer_height','10','mm','Y','1','4'),(10,'top_left_address_width','97','mm','Y','1','2'),(11,'top_center_address_width','100','mm','Y','1','2'),(12,'top_center_address_padding_top','23','px','Y','1','2'),(13,'top_right_width','27','mm','Y','1','2'),(14,'top_right_padding_top','5','px','Y','1','2'),(15,'top_right_margin_left','15','px','Y','1','2'),(16,'items_qty','47','mm','Y','1','3'),(17,'items_hsn','20','mm','Y','1','3'),(18,'items_mrp','35','mm','Y','1','3'),(19,'items_particular','94','mm','Y','1','3'),(20,'items_rate','23','mm','Y','1','3'),(21,'items_free','5','mm','Y','1','3'),(22,'items_sch','5','mm','Y','1','3'),(23,'items_scheme','25','mm','Y','1','3'),(24,'items_amount','25','mm','Y','1','3'),(25,'items_gst_per','15','mm','Y','1','3'),(26,'items_gst_amt','20','mm','Y','1','3'),(27,'items_net','25','mm','Y','1','3'),(28,'footer_signature','17','mm','Y','1','4'),(29,'footer_gross','25','mm','Y','1','4'),(30,'footer_schemef','21','mm','Y','1','4'),(31,'footer_discount','17','mm','Y','1','4'),(32,'footer_display','24','mm','Y','1','4'),(33,'footer_damage','21','mm','Y','1','4'),(34,'footer_gst','21','mm','Y','1','4'),(35,'footer_add','14','mm','Y','1','4'),(36,'footer_net','25','mm','Y','1','4');
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INV_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'249',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'249',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'249',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'249',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'249',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'249',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'249',NULL,NULL,'1','','S','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(8,'249',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(9,'249',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(10,'249',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(11,'249',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(12,'249',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(13,'249',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(14,'249',NULL,NULL,'1','','','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LEDGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `MAC_ID` int DEFAULT '0',
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int DEFAULT '0',
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int DEFAULT '0',
  `ROOT_PARENT_ID` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text,
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `SAC_ID` int NOT NULL DEFAULT '0',
  `REMOTE_ID` int NOT NULL DEFAULT '0',
  `PENDING_AMT` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `PROD_ID` int NOT NULL DEFAULT '0',
  `PACK` int NOT NULL DEFAULT '0',
  `PROD_BATCH_ID` int NOT NULL DEFAULT '0',
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int NOT NULL DEFAULT '0',
  `PUR_RET_QTY` int NOT NULL DEFAULT '0',
  `PUR_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `PUR_TOTAL` int NOT NULL DEFAULT '0',
  `SALE_QTY` int DEFAULT '0',
  `SALE_RET_QTY` int DEFAULT '0',
  `SALE_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `SALE_TOTAL` int NOT NULL DEFAULT '0',
  `OP_STOCK` int NOT NULL DEFAULT '0',
  `CLOSING_STOCK` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=342 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'249',NULL,NULL,'876C',NULL,'','KHOA 200GM X 50PC','KHOA 200GM X 50PC','0402','1','3',NULL,'1','PARLE','7','10','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(2,'249',NULL,NULL,'987',NULL,'','PARLE G ATTA 5KG','PARLE G ATTA 5KG','11010000','1','3',NULL,'1','PARLE','7','10','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(3,'249',NULL,NULL,'317A',NULL,'','POPPINS','POPPINS','17049020','1','3',NULL,'1','PARLE','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(4,'249',NULL,NULL,'316',NULL,'','ROLLCOLA','ROLLCOLA','17049020','1','3',NULL,'1','PARLE','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(5,'249',NULL,NULL,'300A',NULL,'','MAZELO 10','MAZELO 10','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(6,'249',NULL,NULL,'316A',NULL,'','ROLA COLA 150GM','ROLA COLA 150GM','17049020','1','3',NULL,'1','PARLE','7','10','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(7,'249',NULL,NULL,'328A',NULL,'','CANDY CULTURE','CANDY CULTURE','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(8,'249',NULL,NULL,'330',NULL,'','ZING MANGO','ZING MANGO','17049020','1','3',NULL,'1','PARLE','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(9,'249',NULL,NULL,'300B',NULL,'','MAZELO FRUIT GANG','MAZELO FRUIT GANG','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(10,'249',NULL,NULL,'304A',NULL,'','BIGGER KACCHA MANGO','BIGGER KACCHA MANGO','17049020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(11,'249',NULL,NULL,'312B',NULL,'','BIGGER ORANGE BITE (50)','BIGGER ORANGE BITE (50)','17049020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(12,'249',NULL,NULL,'318B',NULL,'','GRAND LONDONDERRY 50/-','GRAND LONDONDERRY 50/-','17049020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(13,'249',NULL,NULL,'308B',NULL,'','BIGGER MANGO BITE','BIGGER MANGO BITE','17049020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(14,'249',NULL,NULL,'336',NULL,'','ECLAIR TOFFEE 400/-','ECLAIR TOFFEE 400/-','17049020','1','3',NULL,'1','PARLE','7','10','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(15,'249',NULL,NULL,'317C',NULL,'','ROLA COLA 5/-','ROLA COLA 5/-','17049020','1','3',NULL,'1','PARLE','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(16,'249',NULL,NULL,'5607',NULL,'','GRAND LONDONDERRY 800/-','GRAND LONDONDERRY 800/-','17049020','1','3',NULL,'1','PARLE','7','10','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(17,'249',NULL,NULL,'5910',NULL,'','GRAND LONDONDERRY 150/-','GRAND LONDONDERRY 150/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(18,'249',NULL,NULL,'462',NULL,'','BIGGER ORANGE BITE 150/-','BIGGER ORANGE BITE 150/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(19,'249',NULL,NULL,'9048',NULL,'','BIGGER MANGO BITE 150/-','BIGGER MANGO BITE 150/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(20,'249',NULL,NULL,'9054',NULL,'','Bigger Mango Bite 800/-','Bigger Mango Bite 800/-','17049020','1','3',NULL,'1','PARLE','7','10','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(21,'249',NULL,NULL,'9058',NULL,'','BIGGER ORANGE BITE  215/-','BIGGER ORANGE BITE  215/-','17049020','1','3',NULL,'1','PARLE','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(22,'249',NULL,NULL,'9059',NULL,'','BIGGER ORANGE BITE 800/-','BIGGER ORANGE BITE 800/-','17049020','1','3',NULL,'1','PARLE','7','10','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(23,'249',NULL,NULL,'463',NULL,'','BIGGER KACCHA MANGO BITE 150/-','BIGGER KACCHA MANGO BITE 150/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(24,'249',NULL,NULL,'464',NULL,'','BIGGER KACCHA MANGO BITE 800/-','BIGGER KACCHA MANGO BITE 800/-','17049020','1','3',NULL,'1','PARLE','7','10','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(25,'249',NULL,NULL,'471',NULL,'','KAPI CANDY 230/-','KAPI CANDY 230/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(26,'249',NULL,NULL,'9061',NULL,'','KISMI GOLD 800/-','KISMI GOLD 800/-','17049020','1','3',NULL,'1','PARLE','7','10','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(27,'249',NULL,NULL,'472',NULL,'','POPPINS 5-/','POPPINS 5-/','17049020','1','3',NULL,'1','PARLE','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(28,'249',NULL,NULL,'9067',NULL,'','ASSORTED MAZELO 150/-','ASSORTED MAZELO 150/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(29,'249',NULL,NULL,'9087',NULL,'','KISMI  ASSORTED 150/-','KISMI  ASSORTED 150/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(30,'249',NULL,NULL,'9092',NULL,'','ASSORTED MAZELO 50/-','ASSORTED MAZELO 50/-','17049020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(31,'249',NULL,NULL,'476',NULL,'','KAPI CANDY 50/-','KAPI CANDY 50/-','17049020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(32,'249',NULL,NULL,'9097',NULL,'','KISMI GOLD 400/-','KISMI GOLD 400/-','17049020','1','3',NULL,'1','PARLE','7','10','6',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','6','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(33,'249',NULL,NULL,'392',NULL,'','BIGGER 2 IN 1 ECLAIR','BIGGER 2 IN 1 ECLAIR','17049020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(34,'249',NULL,NULL,'482',NULL,'','KAPI CANDY 150','KAPI CANDY 150','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(35,'249',NULL,NULL,'483',NULL,'','FUSION COLA FLOAT 150','FUSION COLA FLOAT 150','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(36,'249',NULL,NULL,'484',NULL,'','FUSION BLBRY CSCK 150/-','FUSION BLBRY CSCK 150/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(37,'249',NULL,NULL,'485',NULL,'','FUSION MANGO FLOAT 150/-','FUSION MANGO FLOAT 150/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(38,'249',NULL,NULL,'486',NULL,'','FUSION MANGO FLOAT 50/','FUSION MANGO FLOAT 50/','17049020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(39,'249',NULL,NULL,'487',NULL,'','DUET 150/-','DUET 150/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(40,'249',NULL,NULL,'488',NULL,'','FUSION BLBRY CSCK 50/-','FUSION BLBRY CSCK 50/-','17049020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(41,'249',NULL,NULL,'491',NULL,'','FUSION COLA FLOAT 50/-','FUSION COLA FLOAT 50/-','17049020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(42,'249',NULL,NULL,'393',NULL,'','2 IN 1 ECLAIR 150/-','2 IN 1 ECLAIR 150/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(43,'249',NULL,NULL,'337B',NULL,'','KISMI BAR 1.88/-','KISMI BAR 1.88/-','17049020','1','3',NULL,'1','PARLE','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(44,'249',NULL,NULL,'317',NULL,'','ROLA COLA 4.70/-','ROLA COLA 4.70/-','17049020','1','3',NULL,'1','PARLE','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(45,'249',NULL,NULL,'5607A',NULL,'','GRAND LONDONDERRY 752/-','GRAND LONDONDERRY 752/-','17049020','1','3',NULL,'1','PARLE','7','10','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(46,'249',NULL,NULL,'464A',NULL,'','BIGGER KACCHA MANGO BITE 752/-','BIGGER KACCHA MANGO BITE 752/-','17049020','1','3',NULL,'1','PARLE','7','10','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(47,'249',NULL,NULL,'340A',NULL,'','KISMI TOFFEE 752/-','KISMI TOFFEE 752/-','17049020','1','3',NULL,'1','PARLE','7','10','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(48,'249',NULL,NULL,'9087A',NULL,'','KISMI ASSORTED 150 /-','KISMI ASSORTED 150 /-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(49,'249',NULL,NULL,'9067A',NULL,'','ASSORTED MAZELO 141/-','ASSORTED MAZELO 141/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(50,'249',NULL,NULL,'482A',NULL,'','KAPI CANDY 141/-','KAPI CANDY 141/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(51,'249',NULL,NULL,'346B',NULL,'','KISMI GOLD 752/-','KISMI GOLD 752/-','17049020','1','3',NULL,'1','PARLE','7','10','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(52,'249',NULL,NULL,'141A',NULL,'','GRAND LONDONDERY 141/-','GRAND LONDONDERY 141/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(53,'249',NULL,NULL,'300C',NULL,'','MAZELO FRUIT GANG 141/-','MAZELO FRUIT GANG 141/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(54,'249',NULL,NULL,'317D',NULL,'','POPPINS 1.88/-','POPPINS 1.88/-','17049020','1','3',NULL,'1','PARLE','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(55,'249',NULL,NULL,'463A',NULL,'','BIGGER KACCHA MANGO BITE 150 /-','BIGGER KACCHA MANGO BITE 150 /-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(56,'249',NULL,NULL,'9048A',NULL,'','BIGGER MANGO BITE 141/-','BIGGER MANGO BITE 141/-','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(57,'249',NULL,NULL,'325',NULL,'','SMOOTHIES BUTTER CANDY','SMOOTHIES BUTTER CANDY','17049020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(58,'249',NULL,NULL,'333',NULL,'','KISMI  ROSE MILK 50/-','KISMI  ROSE MILK 50/-','17049030','1','3',NULL,'1','PARLE','7','10','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(59,'249',NULL,NULL,'346',NULL,'','KISMI GOLD 50/-','KISMI GOLD 50/-','17049030','1','3',NULL,'1','PARLE','7','10','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(60,'249',NULL,NULL,'337A',NULL,'','KISMI BAR 2/','KISMI BAR 2/','17049030','1','3',NULL,'1','PARLE','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(61,'249',NULL,NULL,'344B',NULL,'','Kismi Assort 400','Kismi Assort 400','17049030','1','3',NULL,'1','PARLE','7','10','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(62,'249',NULL,NULL,'332A',NULL,'','ECLAIRS TOFFEE 200','ECLAIRS TOFFEE 200','17049030','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(63,'249',NULL,NULL,'347B',NULL,'','KISMI PAAN 50','KISMI PAAN 50','17049030','1','3',NULL,'1','PARLE','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(64,'249',NULL,NULL,'344C',NULL,'','KISMI ASSORTED 50','KISMI ASSORTED 50','17049030','1','3',NULL,'1','PARLE','7','10','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(65,'249',NULL,NULL,'498A',NULL,'','FULL2 IMLI 47RS','FULL2 IMLI 47RS','17049090','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(66,'249',NULL,NULL,'322',NULL,'','MELODY 50/-','MELODY 50/-','18061000','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(67,'249',NULL,NULL,'323',NULL,'','MELODY 100/-','MELODY 100/-','18061000','1','3',NULL,'1','PARLE','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(68,'249',NULL,NULL,'244',NULL,'','FRIBRERG MILK','FRIBRERG MILK','18063200','1','3',NULL,'1','PARLE','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(69,'249',NULL,NULL,'245',NULL,'','FRIBERG DARK','FRIBERG DARK','18063200','1','3',NULL,'1','PARLE','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(70,'249',NULL,NULL,'9090',NULL,'','MELODY MAX 100/-','MELODY MAX 100/-','18069010','1','3',NULL,'1','PARLE','7','10','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(71,'249',NULL,NULL,'327A',NULL,'','MELODY 712/-','MELODY 712/-','18069010','1','3',NULL,'1','PARLE','7','10','2',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','2','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(72,'249',NULL,NULL,'324',NULL,'','MELODY 133.50/-','MELODY 133.50/-','18069010','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(73,'249',NULL,NULL,'600',NULL,'','CHOCOLAIRS GOLD POUCH PK18 200/-','CHOCOLAIRS GOLD POUCH PK18 200/-','18069020','1','3',NULL,'1','PARLE','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(74,'249',NULL,NULL,'164A',NULL,'','HIDE & SEEK FILLS RS10','HIDE & SEEK FILLS RS10','18069090','1','3',NULL,'1','PARLE','7','10','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(75,'249',NULL,NULL,'164B',NULL,'','HIDE & FILLS 8.90/-','HIDE & FILLS 8.90/-','18069090','1','3',NULL,'1','PARLE','7','10','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(76,'249',NULL,NULL,'957A',NULL,'','ELAICHI RUSK 300GM (32PC)','ELAICHI RUSK 300GM (32PC)','1905','1','3',NULL,'1','PARLE','7','10','32',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','32','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(77,'249',NULL,NULL,'5651',NULL,'','TIGER GLUCOSE 10/-','TIGER GLUCOSE 10/-','19053100','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(78,'249',NULL,NULL,'361',NULL,'','RUSK 200GMS','RUSK 200GMS','19054000','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(79,'249',NULL,NULL,'361A',NULL,'','RUSK','RUSK','19054000','1','3',NULL,'1','PARLE','7','10','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(80,'249',NULL,NULL,'391',NULL,'','RUSK 1KG','RUSK 1KG','19054000','1','3',NULL,'1','PARLE','7','10','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(81,'249',NULL,NULL,'465',NULL,'','RUSK 20/-','RUSK 20/-','19054000','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(82,'249',NULL,NULL,'368D',NULL,'','RUSK 10','RUSK 10','19054000','1','3',NULL,'1','PARLE','7','10','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(83,'249',NULL,NULL,'390',NULL,'','Cake Rusk Vanila 50','Cake Rusk Vanila 50','19059010','1','2',NULL,'1','PARLE','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(84,'249',NULL,NULL,'238',NULL,'','CAKE TF VANILA 5 (360PC)','CAKE TF VANILA 5 (360PC)','19059010','1','3',NULL,'1','PARLE','7','10','360',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','360','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(85,'249',NULL,NULL,'473',NULL,'','HAPPY HAPPY CAKE 40/-','HAPPY HAPPY CAKE 40/-','19059010','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(86,'249',NULL,NULL,'101',NULL,'','PARLE G MRP 2 (360pc)','PARLE G MRP 2 (360pc)','19059020','1','3',NULL,'1','PARLE','7','10','360',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','360','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(87,'249',NULL,NULL,'103',NULL,'','NIMKEEN','NIMKEEN','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(88,'249',NULL,NULL,'104',NULL,'','PARLE G 5/-','PARLE G 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(89,'249',NULL,NULL,'105',NULL,'','PARLE G 10/-','PARLE G 10/-','19059020','1','3',NULL,'1','PARLE','7','10','100',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','100','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(90,'249',NULL,NULL,'106',NULL,'','PARLE G 20/-','PARLE G 20/-','19059020','1','3',NULL,'1','PARLE','7','10','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(91,'249',NULL,NULL,'107',NULL,'','PARLE G 55/-','PARLE G 55/-','19059020','1','3',NULL,'1','PARLE','7','10','14',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','14','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(92,'249',NULL,NULL,'108',NULL,'','PARLE-G GOLD 200GM','PARLE-G GOLD 200GM','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(93,'249',NULL,NULL,'109',NULL,'','PARLE G GOLD 10/-','PARLE G GOLD 10/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(94,'249',NULL,NULL,'110',NULL,'','MONACO 5/-','MONACO 5/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(95,'249',NULL,NULL,'111',NULL,'','MONACO 10 (120PC)','MONACO 10 (120PC)','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(96,'249',NULL,NULL,'112',NULL,'','MONACO 20/-','MONACO 20/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(97,'249',NULL,NULL,'114',NULL,'','KRACKJACK 5/-','KRACKJACK 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(98,'249',NULL,NULL,'116',NULL,'','KRACKJACK 25/-','KRACKJACK 25/-','19059020','1','3',NULL,'1','PARLE','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(99,'249',NULL,NULL,'120',NULL,'','20-20 CASHEW 5/-','20-20 CASHEW 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(100,'249',NULL,NULL,'123',NULL,'','HAPPY HAPPY 5/-Rs','HAPPY HAPPY 5/-Rs','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(101,'249',NULL,NULL,'124',NULL,'','HAPPY HAPPY 10/-','HAPPY HAPPY 10/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(102,'249',NULL,NULL,'133',NULL,'','TOP 10/-','TOP 10/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(103,'249',NULL,NULL,'135',NULL,'','MAGIX CASHEW 5/-','MAGIX CASHEW 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(104,'249',NULL,NULL,'136',NULL,'','MAGIX CHOCO5/-','MAGIX CHOCO5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(105,'249',NULL,NULL,'139',NULL,'','BAKESMITH MARIE 5/-','BAKESMITH MARIE 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(106,'249',NULL,NULL,'140',NULL,'','BAKESMITH MARIE 10/-','BAKESMITH MARIE 10/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(107,'249',NULL,NULL,'141',NULL,'','BAKESMITH MARIE 25/-','BAKESMITH MARIE 25/-','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(108,'249',NULL,NULL,'142',NULL,'','MILANO CENTER FILLED 30/-','MILANO CENTER FILLED 30/-','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(109,'249',NULL,NULL,'143',NULL,'','MILANO CHOCO 40/-','MILANO CHOCO 40/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(110,'249',NULL,NULL,'149',NULL,'','SIMPLY GOOD DIGESTIVE 20/-','SIMPLY GOOD DIGESTIVE 20/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(111,'249',NULL,NULL,'154',NULL,'','BOURBON 10/- (120PC)','BOURBON 10/- (120PC)','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(112,'249',NULL,NULL,'155',NULL,'','BOURBON 40','BOURBON 40','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(113,'249',NULL,NULL,'156',NULL,'','BLACK BOURBON CHOCO 30','BLACK BOURBON CHOCO 30','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(114,'249',NULL,NULL,'157',NULL,'','BLACK BOURBON VANILLA 30','BLACK BOURBON VANILLA 30','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(115,'249',NULL,NULL,'163',NULL,'','FAB VANILLA 20/-','FAB VANILLA 20/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(116,'249',NULL,NULL,'164',NULL,'','HIDE & SEEK 10/-','HIDE & SEEK 10/-','19059020','1','3',NULL,'1','PARLE','7','10','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(117,'249',NULL,NULL,'167',NULL,'','H & S CHOCOLATE 30/-','H & S CHOCOLATE 30/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(118,'249',NULL,NULL,'169',NULL,'','H & S ROLLS CHOCO 40','H & S ROLLS CHOCO 40','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(119,'249',NULL,NULL,'171',NULL,'','H & S  COFFEE 30/-','H & S  COFFEE 30/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(120,'249',NULL,NULL,'173',NULL,'','COCONUT 10/-','COCONUT 10/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(121,'249',NULL,NULL,'176',NULL,'','JAM-IN 10/-','JAM-IN 10/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(122,'249',NULL,NULL,'178',NULL,'','MAGIX RND CHOCO 5/-','MAGIX RND CHOCO 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(123,'249',NULL,NULL,'181',NULL,'','MAGIX RND ELAICHI 5/-','MAGIX RND ELAICHI 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(124,'249',NULL,NULL,'182',NULL,'','MAGIX RND ELAICHI 10/-','MAGIX RND ELAICHI 10/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(125,'249',NULL,NULL,'184',NULL,'','MAGIX RND MANGO 5 (144PC)','MAGIX RND MANGO 5 (144PC)','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(126,'249',NULL,NULL,'186',NULL,'','MAGIX RND ORANGE 5/-','MAGIX RND ORANGE 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(127,'249',NULL,NULL,'187',NULL,'','MAGIX RND ORANGE 10/-','MAGIX RND ORANGE 10/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(128,'249',NULL,NULL,'189',NULL,'','MAGIX RND PINEAPPLE 5/-','MAGIX RND PINEAPPLE 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(129,'249',NULL,NULL,'200',NULL,'','MAGIX RND STRAWBERRY 5/-','MAGIX RND STRAWBERRY 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(130,'249',NULL,NULL,'212',NULL,'','MILKSHAKTI SAND 10/-','MILKSHAKTI SAND 10/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(131,'249',NULL,NULL,'214B',NULL,'','CHEESLING 90/-','CHEESLING 90/-','19059020','1','3',NULL,'1','PARLE','7','10','15',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','15','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(132,'249',NULL,NULL,'215',NULL,'','CHEESLING 1000','CHEESLING 1000','19059020','1','3',NULL,'1','PARLE','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(133,'249',NULL,NULL,'218',NULL,'','NUTRICRUNCH LITE CRAKER 15/-','NUTRICRUNCH LITE CRAKER 15/-','19059020','1','3',NULL,'1','PARLE','7','10','64',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','64','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(134,'249',NULL,NULL,'224',NULL,'','MILKSHAKTI 5/-','MILKSHAKTI 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(135,'249',NULL,NULL,'225',NULL,'','MILKSHAKTI 10/-','MILKSHAKTI 10/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(136,'249',NULL,NULL,'217',NULL,'','SIXER1200','SIXER1200','19059020','1','3',NULL,'1','PARLE','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(137,'249',NULL,NULL,'160A',NULL,'','FAB ORANGE','FAB ORANGE','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(138,'249',NULL,NULL,'158A',NULL,'','FAB CHOC','FAB CHOC','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(139,'249',NULL,NULL,'161A',NULL,'','FAB STRAWBERY','FAB STRAWBERY','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(140,'249',NULL,NULL,'163A',NULL,'','FAB VANILA','FAB VANILA','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(141,'249',NULL,NULL,'179',NULL,'','MAGIX ROUND CHOCO','MAGIX ROUND CHOCO','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(142,'249',NULL,NULL,'142A',NULL,'','MILANO C/F BERRY','MILANO C/F BERRY','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(143,'249',NULL,NULL,'118',NULL,'','20-20 CASHEW 10','20-20 CASHEW 10','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(144,'249',NULL,NULL,'144',NULL,'','MILANO C/F','MILANO C/F','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(145,'249',NULL,NULL,'120A',NULL,'','20-20 BUTTER 30','20-20 BUTTER 30','19059020','1','3',NULL,'1','PARLE','7','10','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(146,'249',NULL,NULL,'177',NULL,'','JAM IN 20','JAM IN 20','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(147,'249',NULL,NULL,'173A',NULL,'','COCONUT 20','COCONUT 20','19059020','1','3',NULL,'1','PARLE','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(148,'249',NULL,NULL,'144B',NULL,'','HAZELNUT 35','HAZELNUT 35','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(149,'249',NULL,NULL,'111A',NULL,'','MONACO PIZZ 10','MONACO PIZZ 10','19059020','1','3',NULL,'1','PARLE','7','10','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(150,'249',NULL,NULL,'109B',NULL,'','GOLD 10 (144PC)','GOLD 10 (144PC)','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(151,'249',NULL,NULL,'179A',NULL,'','MAGIX KR RND CH 25','MAGIX KR RND CH 25','19059020','1','3',NULL,'1','PARLE','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(152,'249',NULL,NULL,'109C',NULL,'','parle GOLD 5','parle GOLD 5','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(153,'249',NULL,NULL,'140D',NULL,'','ARROVITA 20','ARROVITA 20','19059020','1','3',NULL,'1','PARLE','7','7','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(154,'249',NULL,NULL,'225B',NULL,'','Milkshasti 25','Milkshasti 25','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(155,'249',NULL,NULL,'230A',NULL,'','20-20 GOLD CASHEW ALMD 40','20-20 GOLD CASHEW ALMD 40','19059020','1','3',NULL,'1','PARLE','7','10','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(156,'249',NULL,NULL,'320B',NULL,'','20-20 Butter 5','20-20 Butter 5','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(157,'249',NULL,NULL,'232',NULL,'','20-20 GOLD BUTTER 25','20-20 GOLD BUTTER 25','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(158,'249',NULL,NULL,'116B',NULL,'','KRACKJACK 80','KRACKJACK 80','19059020','1','3',NULL,'1','PARLE','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(159,'249',NULL,NULL,'230B',NULL,'','20-20 GOLD CASHW  ALMD 20','20-20 GOLD CASHW  ALMD 20','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(160,'249',NULL,NULL,'108A',NULL,'','PARLE GOLD 1KG','PARLE GOLD 1KG','19059020','1','3',NULL,'1','PARLE','7','10','14',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','14','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(161,'249',NULL,NULL,'234',NULL,'','20-20 CHOCO CHIP 30','20-20 CHOCO CHIP 30','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(162,'249',NULL,NULL,'115C',NULL,'','KRACKJACK 10 (120PC)','KRACKJACK 10 (120PC)','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(163,'249',NULL,NULL,'220',NULL,'','FABIO CHOC 10','FABIO CHOC 10','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(164,'249',NULL,NULL,'221',NULL,'','FABIO CHOC 30','FABIO CHOC 30','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(165,'249',NULL,NULL,'222',NULL,'','FABIO VANILA 30','FABIO VANILA 30','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(166,'249',NULL,NULL,'220A',NULL,'','FABIO VANILA 10','FABIO VANILA 10','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(167,'249',NULL,NULL,'157A',NULL,'','BB VANIL 10','BB VANIL 10','19059020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(168,'249',NULL,NULL,'156A',NULL,'','BB CHOC 10','BB CHOC 10','19059020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(169,'249',NULL,NULL,'142C',NULL,'','MILANO 10','MILANO 10','19059020','1','3',NULL,'1','PARLE','7','10','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(170,'249',NULL,NULL,'105A',NULL,'','PARLE G 10/-','PARLE G 10/-','19059020','1','2',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(171,'249',NULL,NULL,'167C',NULL,'','H & S CHOC ALMOND (60PCS)','H & S CHOC ALMOND (60PCS)','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(172,'249',NULL,NULL,'110A',NULL,'','MONACO PRI PRI 50G*80P','MONACO PRI PRI 50G*80P','19059020','1','2',NULL,'1','PARLE','7','10','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(173,'249',NULL,NULL,'110B',NULL,'','MONACO PIRI PIRI 50 (40pc)','MONACO PIRI PIRI 50 (40pc)','19059020','1','2',NULL,'1','PARLE','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(174,'249',NULL,NULL,'156B',NULL,'','BB CHOC 150','BB CHOC 150','19059020','1','3',NULL,'1','PARLE','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(175,'249',NULL,NULL,'106A',NULL,'','PARLE-G 200GM','PARLE-G 200GM','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(176,'249',NULL,NULL,'149A',NULL,'','DIGESTIVE ORANGE','DIGESTIVE ORANGE','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(177,'249',NULL,NULL,'152',NULL,'','NUTRICRUNCH GINGER DIG 20','NUTRICRUNCH GINGER DIG 20','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(178,'249',NULL,NULL,'104A',NULL,'','PARLE-G 5 /-','PARLE-G 5 /-','19059020','1','3',NULL,'1','PARLE','7','10','192',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','192','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(179,'249',NULL,NULL,'107B',NULL,'','PARLE G 800G (100)','PARLE G 800G (100)','19059020','1','3',NULL,'1','PARLE','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(180,'249',NULL,NULL,'102',NULL,'','PARLE OATS & BERRIES 100G','PARLE OATS & BERRIES 100G','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(181,'249',NULL,NULL,'165',NULL,'','HIDE&SEEK 100G','HIDE&SEEK 100G','19059020','1','3',NULL,'1','PARLE','7','10','90',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','90','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(182,'249',NULL,NULL,'115D',NULL,'','krackjack (108 pc)','krackjack (108 pc)','19059020','1','3',NULL,'1','PARLE','7','10','108',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(183,'249',NULL,NULL,'420',NULL,'','PARLE G ROYAL 72G','PARLE G ROYAL 72G','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(184,'249',NULL,NULL,'111D',NULL,'','MONACO (108) 10/-','MONACO (108) 10/-','19059020','1','3',NULL,'1','PARLE','7','10','108',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','108','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(185,'249',NULL,NULL,'111B',NULL,'','MONACO 80','MONACO 80','19059020','1','3',NULL,'1','PARLE','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(186,'249',NULL,NULL,'139C',NULL,'','MARIE 800GM (120/-)','MARIE 800GM (120/-)','19059020','1','3',NULL,'1','PARLE','7','10','10',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','10','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(187,'249',NULL,NULL,'205',NULL,'','PARLE G COOKIES 10/-','PARLE G COOKIES 10/-','19059020','1','3',NULL,'1','PARLE','7','10','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(188,'249',NULL,NULL,'122',NULL,'','KRACKJACK 20/-','KRACKJACK 20/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(189,'249',NULL,NULL,'451',NULL,'','H & S CHOCO ROLLS 250GM (24PC)','H & S CHOCO ROLLS 250GM (24PC)','19059020','1','3',NULL,'1','PARLE','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(190,'249',NULL,NULL,'454',NULL,'','ALOO BIKKI SPICY MASALA 25/-','ALOO BIKKI SPICY MASALA 25/-','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(191,'249',NULL,NULL,'455',NULL,'','ALOO BIKKI MEXICAN SALSA','ALOO BIKKI MEXICAN SALSA','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(192,'249',NULL,NULL,'456',NULL,'','ALOO BIKKI CHIPOTLE 25/-','ALOO BIKKI CHIPOTLE 25/-','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(193,'249',NULL,NULL,'150',NULL,'','MULTIVITA MARIE 30/-','MULTIVITA MARIE 30/-','19059020','1','3',NULL,'1','PARLE','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(194,'249',NULL,NULL,'205A',NULL,'','PARLE COOKIES 5/-','PARLE COOKIES 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(195,'249',NULL,NULL,'152A',NULL,'','MULTIVITA MARIE 10/- (96PC)','MULTIVITA MARIE 10/- (96PC)','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(196,'249',NULL,NULL,'187A',NULL,'','MAGIX ELAICHI 10/- (72PCS)','MAGIX ELAICHI 10/- (72PCS)','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(197,'249',NULL,NULL,'235',NULL,'','MAGIX KR RD ORANGE (10) 72 PCS','MAGIX KR RD ORANGE (10) 72 PCS','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(198,'249',NULL,NULL,'236',NULL,'','MAGIX RD CHO 10/- 72 PCS','MAGIX RD CHO 10/- 72 PCS','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(199,'249',NULL,NULL,'237',NULL,'','CAKE TF 5/- (288PC)','CAKE TF 5/- (288PC)','19059020','1','3',NULL,'1','PARLE','7','10','288',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(200,'249',NULL,NULL,'459',NULL,'','ALOO BIKKI CHIPOTLE 10/-','ALOO BIKKI CHIPOTLE 10/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(201,'249',NULL,NULL,'460',NULL,'','ALOO BIKKI SPICY MASALA 10/-','ALOO BIKKI SPICY MASALA 10/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(202,'249',NULL,NULL,'461',NULL,'','ALOO BIKKI MEXICAN SALSA 10/-','ALOO BIKKI MEXICAN SALSA 10/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(203,'249',NULL,NULL,'470',NULL,'','20-20 gold chochips 150/-','20-20 gold chochips 150/-','19059020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(204,'249',NULL,NULL,'9060',NULL,'','HAPPY HAPPY VANILA 120PCS','HAPPY HAPPY VANILA 120PCS','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(205,'249',NULL,NULL,'9070',NULL,'','MILANO C/F VANILA 40/-','MILANO C/F VANILA 40/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(206,'249',NULL,NULL,'9093',NULL,'','MONACO ZEERA 10/-','MONACO ZEERA 10/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(207,'249',NULL,NULL,'10007',NULL,'','PARLE G DARK 10/-','PARLE G DARK 10/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(208,'249',NULL,NULL,'1020',NULL,'','NUTRICRUNCH BANANA CINAMON OAT50/-','NUTRICRUNCH BANANA CINAMON OAT50/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(209,'249',NULL,NULL,'1021',NULL,'','NUTRICRUNCH CRANBERY NUT OATS 50/-','NUTRICRUNCH CRANBERY NUT OATS 50/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(210,'249',NULL,NULL,'1022',NULL,'','NUTRICRUNCH CHOCO NUT OAT 50/-','NUTRICRUNCH CHOCO NUT OAT 50/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(211,'249',NULL,NULL,'138A',NULL,'','MARIE 9 /-','MARIE 9 /-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(212,'249',NULL,NULL,'175',NULL,'','HIDE & SEEK CHOCO ROLL 5/-','HIDE & SEEK CHOCO ROLL 5/-','19059020','1','3',NULL,'1','PARLE','7','10','480',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','480','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(213,'249',NULL,NULL,'1023',NULL,'','NUTRICRUNCH MILLET 20/-','NUTRICRUNCH MILLET 20/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(214,'249',NULL,NULL,'180',NULL,'','HIDE & SEEK CREAM PEN','HIDE & SEEK CREAM PEN','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(215,'249',NULL,NULL,'196',NULL,'','MAGIX GREEN APPLE 10/-','MAGIX GREEN APPLE 10/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(216,'249',NULL,NULL,'430',NULL,'','CHEESETWIST 5/-','CHEESETWIST 5/-','19059020','1','3',NULL,'1','PARLE','7','10','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(217,'249',NULL,NULL,'10008',NULL,'','PARLE DARK 20/-','PARLE DARK 20/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(218,'249',NULL,NULL,'196A',NULL,'','MAGIX KREAM GREEN APPLE 5/-','MAGIX KREAM GREEN APPLE 5/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(219,'249',NULL,NULL,'750',NULL,'','MONACO 4.45/-','MONACO 4.45/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(220,'249',NULL,NULL,'710',NULL,'','MONACO 8.90/-','MONACO 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(221,'249',NULL,NULL,'164C',NULL,'','HIDE & SEEK 8.90/-','HIDE & SEEK 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(222,'249',NULL,NULL,'113',NULL,'','MONACO 35.60/-','MONACO 35.60/-','19059020','1','3',NULL,'1','PARLE','7','10','42',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','42','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(223,'249',NULL,NULL,'712',NULL,'','RIKRAK WAF CHOCO 10/-','RIKRAK WAF CHOCO 10/-','19059020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(224,'249',NULL,NULL,'713',NULL,'','RIKRAK WAF ORANGE 10/-','RIKRAK WAF ORANGE 10/-','19059020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(225,'249',NULL,NULL,'714',NULL,'','RIKRAK WAF COFFEE 10/-','RIKRAK WAF COFFEE 10/-','19059020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(226,'249',NULL,NULL,'715',NULL,'','KRACKJACK 4.45/-','KRACKJACK 4.45/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(227,'249',NULL,NULL,'115',NULL,'','KRACKJACK 9/-','KRACKJACK 9/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(228,'249',NULL,NULL,'614',NULL,'','PARLE GOLD 9 /-','PARLE GOLD 9 /-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(229,'249',NULL,NULL,'165A',NULL,'','HIDE & SEEK 8.90/-','HIDE & SEEK 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(230,'249',NULL,NULL,'120B',NULL,'','20-20 BUTTER 26.70/-','20-20 BUTTER 26.70/-','19059020','1','3',NULL,'1','PARLE','7','10','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(231,'249',NULL,NULL,'121B',NULL,'','20-20 CASHEW 31.15/-','20-20 CASHEW 31.15/-','19059020','1','3',NULL,'1','PARLE','7','10','50',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','50','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(232,'249',NULL,NULL,'133A',NULL,'','TOP 9/-','TOP 9/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(233,'249',NULL,NULL,'196B',NULL,'','MAGIX RD GR APPLE 8.90/-','MAGIX RD GR APPLE 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(234,'249',NULL,NULL,'182A',NULL,'','MAGIX RD ELAICHI 8.90/-','MAGIX RD ELAICHI 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(235,'249',NULL,NULL,'1023A',NULL,'','NUTRICRUNCH MILLET 17.80/-','NUTRICRUNCH MILLET 17.80/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(236,'249',NULL,NULL,'118B',NULL,'','20-20 BUTTER 8.90/-','20-20 BUTTER 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(237,'249',NULL,NULL,'119',NULL,'','20-20 CASHEW 8.90/-','20-20 CASHEW 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(238,'249',NULL,NULL,'101A',NULL,'','PARLE G 1.78/-','PARLE G 1.78/-','19059020','1','3',NULL,'1','PARLE','7','10','360',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','360','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(239,'249',NULL,NULL,'1025',NULL,'','OCCASIONS ASSORTED FUSION 150/-','OCCASIONS ASSORTED FUSION 150/-','19059020','1','3',NULL,'1','PARLE','7','10','18',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','18','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(240,'249',NULL,NULL,'176C',NULL,'','JAM IN 8.90/-','JAM IN 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(241,'249',NULL,NULL,'220B',NULL,'','FABIO VANILA 8.90/-','FABIO VANILA 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(242,'249',NULL,NULL,'124A',NULL,'','HAPPY HAPPY 9/-','HAPPY HAPPY 9/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(243,'249',NULL,NULL,'225D',NULL,'','MILKSHAKTI 8.90/-','MILKSHAKTI 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(244,'249',NULL,NULL,'173B',NULL,'','COCONUT 18/-','COCONUT 18/-','19059020','1','3',NULL,'1','PARLE','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(245,'249',NULL,NULL,'173C',NULL,'','TOP 9 /-','TOP 9 /-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(246,'249',NULL,NULL,'10007A',NULL,'','PARLE G DARK 8.90/-','PARLE G DARK 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(247,'249',NULL,NULL,'106B',NULL,'','PARLE G 26.70/-','PARLE G 26.70/-','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(248,'249',NULL,NULL,'146A',NULL,'','NICE 26.70/-','NICE 26.70/-','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(249,'249',NULL,NULL,'138B',NULL,'','PARLE MARIE 1.78/-','PARLE MARIE 1.78/-','19059020','1','3',NULL,'1','PARLE','7','10','810',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','810','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(250,'249',NULL,NULL,'139A',NULL,'','MARIE 4.45/-','MARIE 4.45/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(251,'249',NULL,NULL,'173D',NULL,'','COCONUT 9 /-','COCONUT 9 /-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(252,'249',NULL,NULL,'215A',NULL,'','CHEESLING 979/-','CHEESLING 979/-','19059020','1','3',NULL,'1','PARLE','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(253,'249',NULL,NULL,'1024',NULL,'','NUTRICRUNCH CN/BN/CH 150/-','NUTRICRUNCH CN/BN/CH 150/-','19059020','1','3',NULL,'1','PARLE','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(254,'249',NULL,NULL,'107A',NULL,'','PARLE G 90/-','PARLE G 90/-','19059020','1','3',NULL,'1','PARLE','7','10','16',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','16','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(255,'249',NULL,NULL,'213A',NULL,'','CHEESLING 71.20/-','CHEESLING 71.20/-','19059020','1','3',NULL,'1','PARLE','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(256,'249',NULL,NULL,'152B',NULL,'','MULTIVITA 8.90/-','MULTIVITA 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(257,'249',NULL,NULL,'104B',NULL,'','PARLE G 4.45/-','PARLE G 4.45/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(258,'249',NULL,NULL,'116D',NULL,'','KRACKJACK 35.60/-','KRACKJACK 35.60/-','19059020','1','3',NULL,'1','PARLE','7','10','40',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','40','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(259,'249',NULL,NULL,'102B',NULL,'','KISMI CINAMMON 9 /-','KISMI CINAMMON 9 /-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(260,'249',NULL,NULL,'102C',NULL,'','OATS & BERRIES 9/-','OATS & BERRIES 9/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(261,'249',NULL,NULL,'143A',NULL,'','MILANO COOKIES 35.60/-','MILANO COOKIES 35.60/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(262,'249',NULL,NULL,'155A',NULL,'','BOURBORN 36/-','BOURBORN 36/-','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(263,'249',NULL,NULL,'1008A',NULL,'','PARLE DARK 17.80/-','PARLE DARK 17.80/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(264,'249',NULL,NULL,'183',NULL,'','MGX DU RD 10/-','MGX DU RD 10/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(265,'249',NULL,NULL,'112A',NULL,'','MONACO 17.80/-','MONACO 17.80/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(266,'249',NULL,NULL,'171A',NULL,'','HIDE & SEEK COFFEE 26.70/-','HIDE & SEEK COFFEE 26.70/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(267,'249',NULL,NULL,'144E',NULL,'','MILANO CF HAZELNUT 35.60/-','MILANO CF HAZELNUT 35.60/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(268,'249',NULL,NULL,'156D',NULL,'','BLACK BOURBORN 35.60/-','BLACK BOURBORN 35.60/-','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(269,'249',NULL,NULL,'142D',NULL,'','MILANO 9/-','MILANO 9/-','19059020','1','3',NULL,'1','PARLE','7','10','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(270,'249',NULL,NULL,'143D',NULL,'','MILANO COOKIES 8.90/-','MILANO COOKIES 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(271,'249',NULL,NULL,'165B',NULL,'','HIDE & SEEK CHOCO 26.70/-','HIDE & SEEK CHOCO 26.70/-','19059020','1','3',NULL,'1','PARLE','7','10','90',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','90','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(272,'249',NULL,NULL,'179B',NULL,'','MAGIX RD CHOCO 8.90/-','MAGIX RD CHOCO 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(273,'249',NULL,NULL,'187B',NULL,'','MAGIX RD ORANGE 8.90/-','MAGIX RD ORANGE 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','96',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','96','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(274,'249',NULL,NULL,'145A',NULL,'','NICE 8.90/-','NICE 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(275,'249',NULL,NULL,'122A',NULL,'','KRACKJACK 17.80/-','KRACKJACK 17.80/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(276,'249',NULL,NULL,'108B',NULL,'','PARLE GOLD 26.70/-','PARLE GOLD 26.70/-','19059020','1','3',NULL,'1','PARLE','7','10','48',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','48','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(277,'249',NULL,NULL,'149B',NULL,'','NUTRICRUNCH DIG 17.80/-','NUTRICRUNCH DIG 17.80/-','19059020','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(278,'249',NULL,NULL,'186A',NULL,'','MAGIX RD ORANGE 4.45/-','MAGIX RD ORANGE 4.45/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(279,'249',NULL,NULL,'178A',NULL,'','MAGIX RD CHOCO 4.45/-','MAGIX RD CHOCO 4.45/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(280,'249',NULL,NULL,'160B',NULL,'','FAB ORANGE 35.60/-','FAB ORANGE 35.60/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(281,'249',NULL,NULL,'163B',NULL,'','FAB VANILA 35.60/-','FAB VANILA 35.60/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(282,'249',NULL,NULL,'158',NULL,'','FAB CHOCO 35.60/-','FAB CHOCO 35.60/-','19059020','1','3',NULL,'1','PARLE','7','10','72',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','72','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(283,'249',NULL,NULL,'154A',NULL,'','BOURBORN 9 /-','BOURBORN 9 /-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(284,'249',NULL,NULL,'177B',NULL,'','JAM IN 31.15/-','JAM IN 31.15/-','19059020','1','3',NULL,'1','PARLE','7','10','30',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','30','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(285,'249',NULL,NULL,'120C',NULL,'','20-20 CASHEW 4.45/-','20-20 CASHEW 4.45/-','19059020','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(286,'249',NULL,NULL,'156C',NULL,'','BB CHOC 8.90/-','BB CHOC 8.90/-','19059020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(287,'249',NULL,NULL,'174',NULL,'','JAM-IN ST 9/- 120','JAM-IN ST 9/- 120','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(288,'249',NULL,NULL,'157B',NULL,'','BB VANILLA 8.9/-','BB VANILLA 8.9/-','19059020','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(289,'249',NULL,NULL,'111E',NULL,'','MONACO 9/-','MONACO 9/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(290,'249',NULL,NULL,'164D',NULL,'','HIDE & SEEK 9/-','HIDE & SEEK 9/-','19059020','1','3',NULL,'1','PARLE','7','10','160',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','160','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(291,'249',NULL,NULL,'165C',NULL,'','HIDE \\% SEEK 90PCS 27/-','HIDE \\% SEEK 90PCS 27/-','19059020','1','3',NULL,'1','PARLE','7','10','90',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','90','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(292,'249',NULL,NULL,'420A',NULL,'','PARLE G ROYAL 8.9/-','PARLE G ROYAL 8.9/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(293,'249',NULL,NULL,'218A',NULL,'','NUTRICRUNCH LITE CRACKER 13.35/-','NUTRICRUNCH LITE CRACKER 13.35/-','19059020','1','3',NULL,'1','PARLE','7','10','64',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','64','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(294,'249',NULL,NULL,'145B',NULL,'','NICE 9/-','NICE 9/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(295,'249',NULL,NULL,'220C',NULL,'','FABIO CHOC 8.9/-','FABIO CHOC 8.9/-','19059020','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(296,'249',NULL,NULL,'387',NULL,'','WAF CNO 10/-','WAF CNO 10/-','20052000','1','3',NULL,'1','PARLE','7','10','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(297,'249',NULL,NULL,'388',NULL,'','WAF TT 15','WAF TT 15','20052000','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(298,'249',NULL,NULL,'389',NULL,'','WAF PP 15','WAF PP 15','20052000','1','3',NULL,'1','PARLE','7','10','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(299,'249',NULL,NULL,'9063',NULL,'','Waf Tandoori(10) (168pc)','Waf Tandoori(10) (168pc)','20052000','1','3',NULL,'1','PARLE','7','10','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(300,'249',NULL,NULL,'9064',NULL,'','WAF CNO 20/-','WAF CNO 20/-','20052000','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(301,'249',NULL,NULL,'9065',NULL,'','WAF CS','WAF CS','20052000','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(302,'249',NULL,NULL,'9081',NULL,'','WAF DRAGON CHIPS 10/-','WAF DRAGON CHIPS 10/-','20052000','1','3',NULL,'1','PARLE','7','10','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(303,'249',NULL,NULL,'9200',NULL,'','WAF CHILAM CHILLI 10/-','WAF CHILAM CHILLI 10/-','20052000','1','3',NULL,'1','PARLE','7','10','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(304,'249',NULL,NULL,'387A',NULL,'','WAF CNO 40/- 60PCS','WAF CNO 40/- 60PCS','20052000','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(305,'249',NULL,NULL,'389A',NULL,'','WAF PP 40/- 60PCS','WAF PP 40/- 60PCS','20052000','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(306,'249',NULL,NULL,'388A',NULL,'','WAF TT 40/- 60PCS','WAF TT 40/- 60PCS','20052000','1','3',NULL,'1','PARLE','7','10','60',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','60','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(307,'249',NULL,NULL,'382A',NULL,'','HOT & SPICY 80','HOT & SPICY 80','21069099','1','2',NULL,'1','PARLE','7','10','24',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','24','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(308,'249',NULL,NULL,'385',NULL,'','NAMKEEN COMBI 99','NAMKEEN COMBI 99','21069099','1','3',NULL,'1','PARLE','7','10','8',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','8','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(309,'249',NULL,NULL,'442A',NULL,'','MEXITOS 80','MEXITOS 80','21069099','1','3',NULL,'1','PARLE','7','10','20',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','20','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(310,'249',NULL,NULL,'409A',NULL,'','FT THAI SIRACHA(10)','FT THAI SIRACHA(10)','21069099','1','3',NULL,'1','PARLE','7','10','12',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','12','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(311,'249',NULL,NULL,'439',NULL,'','MEXITOS JALAPENO (25 GM )','MEXITOS JALAPENO (25 GM )','21069099','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(312,'249',NULL,NULL,'440',NULL,'','MEXITOS MUSTAR & HERBS (25 GM )','MEXITOS MUSTAR & HERBS (25 GM )','21069099','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(313,'249',NULL,NULL,'409B',NULL,'','FT NOODLE MASALA 50GM','FT NOODLE MASALA 50GM','21069099','1','3',NULL,'1','PARLE','7','10','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(314,'249',NULL,NULL,'386',NULL,'','FARALI CHIWADA','FARALI CHIWADA','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(315,'249',NULL,NULL,'409C',NULL,'','FT NOODLE MASALA 100G','FT NOODLE MASALA 100G','21069099','1','3',NULL,'1','PARLE','7','10','36',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','36','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(316,'249',NULL,NULL,'419A',NULL,'','CHATKEEN SEV MURMURA','CHATKEEN SEV MURMURA','21069099','1','3',NULL,'1','PARLE','7','10','240',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','240','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(317,'249',NULL,NULL,'466',NULL,'','Punjabi Tadka 10','Punjabi Tadka 10','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(318,'249',NULL,NULL,'467',NULL,'','Lite Chiwda','Lite Chiwda','21069099','1','3',NULL,'1','PARLE','7','10','288',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(319,'249',NULL,NULL,'468',NULL,'','Gujju Mix','Gujju Mix','21069099','1','3',NULL,'1','PARLE','7','10','288',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(320,'249',NULL,NULL,'469',NULL,'','Chatpata Mutter','Chatpata Mutter','21069099','1','3',NULL,'1','PARLE','7','10','288',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(321,'249',NULL,NULL,'9066',NULL,'','ALO BHUJIA','ALO BHUJIA','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(322,'249',NULL,NULL,'9088',NULL,'','HOTS & SPICY (144 PCS)','HOTS & SPICY (144 PCS)','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(323,'249',NULL,NULL,'9089',NULL,'','TIMEPASS CHEESEST TUBES','TIMEPASS CHEESEST TUBES','21069099','1','3',NULL,'1','PARLE','7','10','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(324,'249',NULL,NULL,'474',NULL,'','CHATKEENS KHATTA  MEETHA10/-','CHATKEENS KHATTA  MEETHA10/-','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(325,'249',NULL,NULL,'475',NULL,'','BHUJIA SEV 10/-','BHUJIA SEV 10/-','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(326,'249',NULL,NULL,'386A',NULL,'','CHANA DAL 288/-','CHANA DAL 288/-','21069099','1','3',NULL,'1','PARLE','7','10','288',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','288','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(327,'249',NULL,NULL,'478',NULL,'','CHATKEEN COCKTAIL 10/-','CHATKEEN COCKTAIL 10/-','21069099','1','3',NULL,'1','PARLE','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(328,'249',NULL,NULL,'479',NULL,'','CHATKEEN CHATPT MATR 10/-','CHATKEEN CHATPT MATR 10/-','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(329,'249',NULL,NULL,'480',NULL,'','DHINCHAK NM 10/-','DHINCHAK NM 10/-','21069099','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(330,'249',NULL,NULL,'481',NULL,'','DHINCHAK BG 10/-','DHINCHAK BG 10/-','21069099','1','3',NULL,'1','PARLE','7','10','80',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','80','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(331,'249',NULL,NULL,'490',NULL,'','CHATKEEN CRISPY NUTS 10/-','CHATKEEN CRISPY NUTS 10/-','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(332,'249',NULL,NULL,'605',NULL,'','CHATKEEN MSL CHANA 10/-','CHATKEEN MSL CHANA 10/-','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(333,'249',NULL,NULL,'606',NULL,'','CHATKEEN MOONG DAL 10/-','CHATKEEN MOONG DAL 10/-','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(334,'249',NULL,NULL,'607',NULL,'','FT MILLENT ACHARI 10/-','FT MILLENT ACHARI 10/-','21069099','1','3',NULL,'1','PARLE','7','10','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(335,'249',NULL,NULL,'608',NULL,'','CHATKEENCRISPNTTN 10/-','CHATKEENCRISPNTTN 10/-','21069099','1','3',NULL,'1','PARLE','7','10','144',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','144','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(336,'249',NULL,NULL,'609',NULL,'','FT NOODLE MASALA 10/-','FT NOODLE MASALA 10/-','21069099','1','3',NULL,'1','PARLE','7','10','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(337,'249',NULL,NULL,'10011',NULL,'','FT TANGY TOMATO','FT TANGY TOMATO','21069099','1','3',NULL,'1','PARLE','7','10','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(338,'249',NULL,NULL,'10012',NULL,'','FT CHILLI CHATPATA','FT CHILLI CHATPATA','21069099','1','3',NULL,'1','PARLE','7','10','168',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','168','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(339,'249',NULL,NULL,'9049',NULL,'','NRCT  BLOSSOM 50G- 120','NRCT  BLOSSOM 50G- 120','33049120','1','3',NULL,'1','PARLE','7','10','120',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','120','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(340,'249',NULL,NULL,'0004A',NULL,'','HAND SANITIZER 5 LTR','HAND SANITIZER 5 LTR','3402.','1','3',NULL,'1','PARLE','7','10','4',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','4','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(341,'249',NULL,NULL,'6000',NULL,'','ALNN SCISSORS','ALNN SCISSORS','82130000','1','3',NULL,'1','PARLE','7','7','1',NULL,NULL,'1','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','PARLE',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL);
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'249',NULL,NULL,'PARLE','1',NULL,NULL,NULL,NULL,NULL,'397','397',NULL,0,'2026-05-16 07:24:33','2026-05-16 07:24:33');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=490 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'249',NULL,NULL,'1','200911164253','','','876C','0','0','0','75','63.71','0','3005.71','0','-2942.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(2,'249',NULL,NULL,'2','220307182002','','','987','0','0','0','220','187.07','0','1066.46','0','-879.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(3,'249',NULL,NULL,'2','220728134608','','','987','0','0','0','245','208.33','0','1187.65','0','-979.32','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(4,'249',NULL,NULL,'2','1681816914554','','','987','0','708','708','265','225.34','0','1284.61','0','-1059.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(5,'249',NULL,NULL,'2','1738151631412','','','987','0','132','132','285','242.35','0','1381.56','0','-1139.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(6,'249',NULL,NULL,'2','1774951441398','','','987','0','6','6','262','215.11','0','1226.26','0','-1011.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(7,'249',NULL,NULL,'3','1538295684910231','2000-01-01','','317A','0','5060','5060','2','85.03','0','1470.45','0','-1385.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(8,'249',NULL,NULL,'4','191017120046','','','316','0','238','238','250','194.2','0','1470.45','0','-1276.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(9,'249',NULL,NULL,'5','191121220751','','','300A','0','12','12','120','93.17','0','1058.72','0','-965.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(10,'249',NULL,NULL,'6','200701142305','','','316A','0','107','107','20','15.53','0','529.36','0','-513.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(11,'249',NULL,NULL,'7','220214111841','','','328A','0','106','106','175','135.83','0','1543.98','0','-1408.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(12,'249',NULL,NULL,'8','220214114118','','','330','0','864','864','50','38.82','0','882.27','0','-843.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(13,'249',NULL,NULL,'9','220223160524','','','300B','0','0','0','150','111.6','0','1268.27','0','-1156.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(14,'249',NULL,NULL,'10','220624184826','','','304A','0','1307','1307','50','38.82','0','882.27','0','-843.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(15,'249',NULL,NULL,'11','220630163835','','','312B','0','0','0','50','38.82','0','882.27','0','-843.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(16,'249',NULL,NULL,'12','220715163622','','','318B','0','1832','1832','50','38.82','0','882.27','0','-843.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(17,'249',NULL,NULL,'13','220715163944','','','308B','0','770','770','50','38.82','0','882.27','0','-843.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(18,'249',NULL,NULL,'14','220915154135','','','336','0','3','3','400','318.88','0','1811.81','0','-1492.93','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(19,'249',NULL,NULL,'15','220923150409','','','317C','0','257','257','150','116.95','0','1470.45','0','-1353.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(20,'249',NULL,NULL,'16','221215115742','','','5607','0','10','10','800','621.12','0','1176.36','0','-555.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(21,'249',NULL,NULL,'17','230206183200','','','5910','0','0','0','150','127.55','0','1323.41','0','-1195.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(22,'249',NULL,NULL,'18','230511171106','','','462','0','16','16','150','116.46','0','1323.41','0','-1206.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(23,'249',NULL,NULL,'19','230518114430','','','9048','0','62','62','150','116.46','0','1323.41','0','-1206.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(24,'249',NULL,NULL,'20','230629143843','','','9054','0','27','27','800','621.11','0','1176.35','0','-555.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(25,'249',NULL,NULL,'21','230712180633','','','9058','0','0','0','215','166.92','0','2371.1','0','-2204.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(26,'249',NULL,NULL,'22','230712180947','','','9059','0','0','0','800','621.12','0','1176.36','0','-555.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(27,'249',NULL,NULL,'23','230714185946','','','463','0','227','227','150','116.46','0','1323.41','0','-1206.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(28,'249',NULL,NULL,'24','230714190101','','','464','0','0','0','800','680.27','0','1176.36','0','-496.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(29,'249',NULL,NULL,'25','230728114348','','','471','0','155','155','240','186.34','0','2117.45','0','-1931.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(30,'249',NULL,NULL,'26','230805164124','','','9061','0','366','366','800','621.12','0','1176.36','0','-555.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(31,'249',NULL,NULL,'27','230817191313','','','472','0','11','11','150','127.55','0','1323.41','0','-1195.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(32,'249',NULL,NULL,'28','230926110908','','','9067','0','264','264','150','116.46','0','1323.41','0','-1206.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(33,'249',NULL,NULL,'29','230928145730','','','9087','0','390','390','150','116.46','0','1323.41','0','-1206.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(34,'249',NULL,NULL,'30','231018172426','','','9092','0','0','0','50','38.82','0','1764.54','0','-1725.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(35,'249',NULL,NULL,'31','231120183037','','','476','0','278','278','50','38.82','0','1764.54','0','-1725.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(36,'249',NULL,NULL,'25','1701929610883','','','471','0','0','0','230','178.57','0','2029.22','0','-1850.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(37,'249',NULL,NULL,'32','231211133312','','','9097','0','36','36','400','310.56','0','1764.54','0','-1453.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(38,'249',NULL,NULL,'33','240202122949','','','392','0','46','46','50','38.82','0','1764.55','0','-1725.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(39,'249',NULL,NULL,'34','240911163811','','','482','0','151','151','150','116.46','0','1323.41','0','-1206.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(40,'249',NULL,NULL,'35','240911163920','','','483','0','252','252','150','116.46','0','1323.41','0','-1206.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(41,'249',NULL,NULL,'36','241119151758','','','484','0','62','62','150','127.55','0','1323.41','0','-1195.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(42,'249',NULL,NULL,'37','241127115131','','','485','0','204','204','150','127.55','0','1323.41','0','-1195.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(43,'249',NULL,NULL,'38','241206111945','','','486','0','134','134','50','38.82','0','1764.54','0','-1725.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(44,'249',NULL,NULL,'39','250527115234','','','487','0','263','263','150','124.22','0','1416.33','0','-1292.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(45,'249',NULL,NULL,'40','250718115340','','','488','0','191','191','50','38.82','0','1764.54','0','-1725.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(46,'249',NULL,NULL,'41','250718115454','','','491','0','47','47','50','38.82','0','1764.55','0','-1725.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(47,'249',NULL,NULL,'30','1756548180650','','','9092','0','48','48','60','0','0','2117.45','0','-2117.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(48,'249',NULL,NULL,'42','251008123852','','','393','0','0','0','150','124.23','0','1416.33','0','-1292.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(49,'249',NULL,NULL,'43','251015123407','','','337B','0','28291','28291','1.88','93.6','0','1420.1','0','-1326.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(50,'249',NULL,NULL,'44','251028142326','','','317','0','114','114','0','58.38','0','1171.4','0','-1113.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(51,'249',NULL,NULL,'45','251105120934','','','5607A','0','0','0','752','623','0','1183.42','0','-560.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(52,'249',NULL,NULL,'46','251105121542','','','464A','0','0','0','752','623','0','1183.42','0','-560.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(53,'249',NULL,NULL,'47','251108144346','','','340A','0','0','0','752','657.05','0','1248.56','0','-591.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(54,'249',NULL,NULL,'48','251108144442','','','9087A','0','0','0','141','124.23','0','1331.35','0','-1207.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(55,'249',NULL,NULL,'49','251108145419','','','9067A','0','0','0','141','116.77','0','1331.34','0','-1214.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(56,'249',NULL,NULL,'50','251108145549','','','482A','0','40','40','141','116.77','0','1331.34','0','-1214.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(57,'249',NULL,NULL,'51','251114175559','','','346B','0','0','0','752','622.77','0','1183.42','0','-560.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(58,'249',NULL,NULL,'52','251120141703','','','141A','0','82','82','141','116.77','0','1331.34','0','-1214.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(59,'249',NULL,NULL,'53','251127175016','','','300C','0','0','0','141','116.77','0','1331.34','0','-1214.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(60,'249',NULL,NULL,'54','251130120032','','','317D','0','200','200','1.88','79.94','0','1479.27','0','-1399.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(61,'249',NULL,NULL,'55','251208120704','','','463A','0','0','0','141','119.6','0','1331.34','0','-1211.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(62,'249',NULL,NULL,'56','251226095505','','','9048A','0','0','0','141','119.9','0','1331.34','0','-1211.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(63,'249',NULL,NULL,'43','0','','','337B','0','613','613','1.9','96.94','0','1435.21','0','-1338.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(64,'249',NULL,NULL,'57','260106155110','','','325','0','0','0','150','124.22','0','1416.33','0','-1292.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(65,'249',NULL,NULL,'10','0','','','304A','0','192','192','47','38.93','0','1775.13','0','-1736.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(66,'249',NULL,NULL,'13','0','','','308B','0','0','0','47','39.93','0','1775.13','0','-1735.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(67,'249',NULL,NULL,'35','1770464406290','','','483','0','33','33','141','116.77','0','1331.34','0','-1214.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(68,'249',NULL,NULL,'39','1770464431689','','','487','0','48','48','141','116.77','0','1331.34','0','-1214.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(69,'249',NULL,NULL,'38','1770792553590','','','486','0','48','48','47','38.92','0','1775.13','0','-1736.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(70,'249',NULL,NULL,'20','1772447046251','','','9054','0','0','0','752','622.77','0','1183.42','0','-560.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(71,'249',NULL,NULL,'12','1772789911747','','','318B','0','96','96','47','38.92','0','1775.13','0','-1736.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(72,'249',NULL,NULL,'29','1772794250601','','','9087','0','0','0','141','116.78','0','1331.35','0','-1214.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(73,'249',NULL,NULL,'18','260314112253','','','462','0','0','0','141','116.78','0','0','0','116.78','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(74,'249',NULL,NULL,'52','1773841241162','','','141A','0','0','0','150','124.22','0','1416.33','0','-1292.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(75,'249',NULL,NULL,'45','1773841308233','','','5607A','0','18','18','800','695.66','0','1258.96','0','-563.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(76,'249',NULL,NULL,'55','1773841934469','','','463A','0','0','0','150','130.44','0','1416.33','0','-1285.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(77,'249',NULL,NULL,'57','1773842050314','','','325','0','12','12','141','122.61','0','1416.33','0','-1293.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(78,'249',NULL,NULL,'48','260326093207','','','9087A','0','96','96','150','124.23','0','1416.33','0','-1292.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(79,'249',NULL,NULL,'58','1538295682626859','2000-01-01','','333','0','0','0','50','36.85','0','1152.34','0','-1115.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(80,'249',NULL,NULL,'59','1538295683991169','2000-01-01','','346','0','1605','1605','50','42.52','0','1152.23','0','-1109.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(81,'249',NULL,NULL,'60','1538295686209547','2000-01-01','','337A','0','5513.7','5513.7','2','102.04','0','1411.63','0','-1309.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(82,'249',NULL,NULL,'61','181003125452','','','344B','0','23','23','400','310.56','0','1176.36','0','-865.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(83,'249',NULL,NULL,'62','190323122246','','','332A','0','0','0','200','0','0','155.27','0','-155.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(84,'249',NULL,NULL,'63','200701142507','','','347B','0','93','93','50','38.82','0','882.27','0','-843.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(85,'249',NULL,NULL,'64','210524093853','','','344C','0','2404','2404','50','37.21','0','845.51','0','-808.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(86,'249',NULL,NULL,'64','1633349766120','','','344C','0','439','439','75','55.8','0','1268.26','0','-1212.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(87,'249',NULL,NULL,'64','1770015137513','','','344C','0','1184','1184','47','38.93','0','1183.42','0','-1144.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(88,'249',NULL,NULL,'59','1772794002529','2000-01-01','','346','0','144','144','47','38.93','0','1331.35','0','-1292.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(89,'249',NULL,NULL,'65','260424162509','','','498A','0','0','0','47','38.92','0','1775.13','0','-1736.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(90,'249',NULL,NULL,'66','1538295682181702','2000-01-01','','322','0','-79','-79','50','42.52','0','1113.38','0','-1070.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(91,'249',NULL,NULL,'67','1538295682369931','2000-01-01','','323','0','0','0','100','85.03','0','1670.07','0','-1585.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(92,'249',NULL,NULL,'68','191211123438','','','244','0','0','0','550','372.88','0','362.2','0','10.68','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(93,'249',NULL,NULL,'69','191211123529','','','245','0','0','0','550','372.88','0','362.2','0','10.68','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(94,'249',NULL,NULL,'70','231014155354','','','9090','0','0','0','100','73.69','0','1670.07','0','-1596.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(95,'249',NULL,NULL,'71','251015122126','','','327A','0','0','0','712','605.44','0','1150.48','0','-545.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(96,'249',NULL,NULL,'72','251015122234','','','324','0','0','0','133.5','113.52','0','1294.29','0','-1180.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(97,'249',NULL,NULL,'72','0','','','324','0','0','0','134','113.94','0','1299.14','0','-1185.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(98,'249',NULL,NULL,'73','250731184055','','','600','0','239','239','200','0','0','108.47','0','-108.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(99,'249',NULL,NULL,'74','211030152107','','','164A','0','0','0','10','8.5','0','1371.85','0','-1363.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(100,'249',NULL,NULL,'75','251028142014','','','164B','0','0','0','8.9','7.57','0','1380.58','0','-1373.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(101,'249',NULL,NULL,'75','1767970484666','','','164B','0','525','525','9','7.66','0','1396.09','0','-1388.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(102,'249',NULL,NULL,'76','210402112847','','','957A','0','0','0','55','38.27','0','1306.51','0','-1268.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(103,'249',NULL,NULL,'77','250131115405','','','5651','0','2400','2400','10','0','0','508.2','0','-508.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(104,'249',NULL,NULL,'78','153829568921871','2000-01-01','','361','0','0','0','30','25.51','0','872.56','0','-847.05','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(105,'249',NULL,NULL,'79','1538295690698578','2000-01-01','','361A','0','6048','6048','35','29.76','0','872.56','0','-842.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(106,'249',NULL,NULL,'78','201125104302','2000-01-01','','361','0','0','0','32','27.21','0','930.73','0','-903.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(107,'249',NULL,NULL,'78','220726135248','2000-01-01','','361','0','8812','8812','35','29.76','0','1357.31','0','-1327.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(108,'249',NULL,NULL,'80','220822153425','','','391','0','0','0','170','144.56','0','1098.78','0','-954.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(109,'249',NULL,NULL,'81','230714190208','','','465','0','202','202','20','17.01','0','969.51','0','-952.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(110,'249',NULL,NULL,'82','241029155132','','','368D','0','33924','33924','10','8.51','0','290.85','0','-282.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(111,'249',NULL,NULL,'78','0','2000-01-01','','361','0','2208','2208','40','33.92','0','1551.21','0','-1517.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(112,'249',NULL,NULL,'83','181007154732','','','390','0','0','0','50','37.83','0','857.4','0','-819.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(113,'249',NULL,NULL,'84','230128174600','','','238','0','1296','1296','5','3.78','0','1028.89','0','-1025.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(114,'249',NULL,NULL,'85','230821153955','','','473','0','0','0','40','30.27','0','0','0','30.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(115,'249',NULL,NULL,'86','153829567009924','2000-01-01','','101','0','186749','186749','2','1.54','0','523.8','0','-522.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(116,'249',NULL,NULL,'87','1538295670273906','2000-01-01','','103','0','3456','3456','5','3.78','0','0','0','3.78','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(117,'249',NULL,NULL,'88','1538295670433774','2000-01-01','','104','0','3360','3360','5','4.33','0','523.8','0','-519.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(118,'249',NULL,NULL,'89','1538295670576918','2000-01-01','','105','0','-500','-500','10','8.66','0','436.5','0','-427.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(119,'249',NULL,NULL,'90','1538295670701541','2000-01-01','','106','0','0','0','20','15.41','0','523.8','0','-508.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(120,'249',NULL,NULL,'91','1538295670884124','2000-01-01','','107','0','0','0','55','44.05','0','581.21','0','-537.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(121,'249',NULL,NULL,'92','1538295671073284','2000-01-01','','108','0','0','0','20','15.13','0','514.44','0','-499.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(122,'249',NULL,NULL,'93','15382956712909','2000-01-01','','109','0','347930','347930','10','8.5','0','514.44','0','-505.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(123,'249',NULL,NULL,'94','1538295671424370','2000-01-01','','110','0','653447','653447','5','4.25','0','428.7','0','-424.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(124,'249',NULL,NULL,'95','1538295671592738','2000-01-01','','111','0','12968','12968','10','8.5','0','428.7','0','-420.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(125,'249',NULL,NULL,'96','1538295671743401','2000-01-01','','112','0','38892','38892','20','17','0','618.3','0','-601.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(126,'249',NULL,NULL,'97','1538295672100701','2000-01-01','','114','0','376','376','5','4.25','0','514.44','0','-510.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(127,'249',NULL,NULL,'98','1538295672395859','2000-01-01','','116','0','0','0','25','18.92','0','714.5','0','-695.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(128,'249',NULL,NULL,'99','1538295672519799','2000-01-01','','120','0','0','0','5','4.25','0','514.44','0','-510.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(129,'249',NULL,NULL,'100','1538295672692175','2000-01-01','','123','0','23','23','5','4.25','0','514.44','0','-510.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(130,'249',NULL,NULL,'101','1538295672808479','2000-01-01','','124','0','15384','15384','10','8.5','0','685.92','0','-677.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(131,'249',NULL,NULL,'102','1538295673676408','2000-01-01','','133','0','1258','1258','10','8.5','0','342.96','0','-334.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(132,'249',NULL,NULL,'103','1538295673907638','2000-01-01','','135','0','0','0','5','4.25','0','514.44','0','-510.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(133,'249',NULL,NULL,'104','1538295674098901','2000-01-01','','136','0','24','24','5','4.25','0','514.44','0','-510.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(134,'249',NULL,NULL,'105','1538295674403377','2000-01-01','','139','0','8858','8858','5','4.25','0','428.7','0','-424.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(135,'249',NULL,NULL,'106','1538295674520347','2000-01-01','','140','0','0','0','10','8.5','0','428.7','0','-420.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(136,'249',NULL,NULL,'107','153829567463062','2000-01-01','','141','0','0','0','27','0','0','592.94','0','-592.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(137,'249',NULL,NULL,'108','1538295674784882','2000-01-01','','142','0','221','221','30','22.7','0','1066.56','0','-1043.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(138,'249',NULL,NULL,'109','1538295674896943','2000-01-01','','143','0','123','123','30','34.01','0','1028.89','0','-994.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(139,'249',NULL,NULL,'110','153829567510312','2000-01-01','','149','0','6260','6260','20','17','0','857.4','0','-840.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(140,'249',NULL,NULL,'111','1538295675489663','2000-01-01','','154','0','0','0','10','8.5','0','428.7','0','-420.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(141,'249',NULL,NULL,'112','153829567559847','2000-01-01','','155','0','0','0','25','34.01','0','643.05','0','-609.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(142,'249',NULL,NULL,'113','1538295675704344','2000-01-01','','156','0','0','0','25','18.92','0','643.05','0','-624.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(143,'249',NULL,NULL,'114','1538295675812964','2000-01-01','','157','0','0','0','25','18.92','0','643.05','0','-624.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(144,'249',NULL,NULL,'115','153829567628748','2000-01-01','','163','0','0','0','20','15.13','0','1428.57','0','-1413.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(145,'249',NULL,NULL,'116','1538295676394923','2000-01-01','','164','0','121772','121772','10','8.5','0','1143.2','0','-1134.70','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(146,'249',NULL,NULL,'117','1538295676498913','2000-01-01','','167','0','9713','9713','30','25.51','0','1543.33','0','-1517.82','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(147,'249',NULL,NULL,'118','1538295676691542','2000-01-01','','169','0','0','0','25','18.92','0','1143.2','0','-1124.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(148,'249',NULL,NULL,'119','1538295676929245','2000-01-01','','171','0','4751','4751','30','25.51','0','1543.33','0','-1517.82','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(149,'249',NULL,NULL,'120','1538295677029517','2000-01-01','','173','0','219984','219984','10','8.5','0','342.96','0','-334.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(150,'249',NULL,NULL,'121','1538295677301130','2000-01-01','','176','0','0','0','10','8.5','0','514.44','0','-505.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(151,'249',NULL,NULL,'122','153829567742120','2000-01-01','','178','0','0','0','5','4.25','0','523.8','0','-519.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(152,'249',NULL,NULL,'123','1538295677575295','2000-01-01','','181','0','17958','17958','5','4.25','0','480.15','0','-475.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(153,'249',NULL,NULL,'124','1538295677706276','2000-01-01','','182','0','31958','31958','10','8.5','0','523.8','0','-515.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(154,'249',NULL,NULL,'125','1538295677804564','2000-01-01','','184','0','0','0','5','4.25','0','480.15','0','-475.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(155,'249',NULL,NULL,'126','153829567791252','2000-01-01','','186','0','7428','7428','5','4.25','0','523.8','0','-519.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(156,'249',NULL,NULL,'127','153829567800339','2000-01-01','','187','0','1155','1155','10','8.5','0','523.8','0','-515.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(157,'249',NULL,NULL,'128','1538295678111843','2000-01-01','','189','0','0','0','5','4.25','0','523.8','0','-519.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(158,'249',NULL,NULL,'129','153829567848195','2000-01-01','','200','0','3876','3876','5','4.25','0','480.15','0','-475.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(159,'249',NULL,NULL,'130','1538295679316375','2000-01-01','','212','0','0','0','10','8.5','0','857.4','0','-848.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(160,'249',NULL,NULL,'131','1538295679603828','2000-01-01','','214B','0','0','0','90','0','0','994.32','0','-994.32','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(161,'249',NULL,NULL,'132','1538295679719608','2000-01-01','','215','0','0','0','0','0','0','454.22','0','-454.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(162,'249',NULL,NULL,'133','1538295679980807','2000-01-01','','218','0','30170','30170','15','12.76','0','514.44','0','-501.68','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(163,'249',NULL,NULL,'134','153829568008896','2000-01-01','','224','0','29760','29760','5','4.25','0','514.44','0','-510.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(164,'249',NULL,NULL,'135','1538295680220861','2000-01-01','','225','0','380','380','10','8.5','0','685.92','0','-677.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(165,'249',NULL,NULL,'136','1538295684575512','2000-01-01','','217','0','10','10','1000','756.66','0','714.5','0','42.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(166,'249',NULL,NULL,'137','1538295685228406','2000-01-01','','160A','0','0','0','25','18.92','0','1286.11','0','-1267.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(167,'249',NULL,NULL,'138','1538295685341482','2000-01-01','','158A','0','0','0','25','18.92','0','1286.1','0','-1267.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(168,'249',NULL,NULL,'139','1538295685497378','2000-01-01','','161A','0','0','0','25','18.92','0','1286.1','0','-1267.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(169,'249',NULL,NULL,'140','15382956856274','2000-01-01','','163A','0','0','0','25','18.92','0','1286.1','0','-1267.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(170,'249',NULL,NULL,'141','1538295686809354','2000-01-01','','179','0','5424','5424','10','8.5','0','523.8','0','-515.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(171,'249',NULL,NULL,'142','1538295687234602','2000-01-01','','142A','0','0','0','35','26.48','0','1200.36','0','-1173.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(172,'249',NULL,NULL,'143','153829568790131','2000-01-01','','118','0','85900','85900','10','8.5','0','643.05','0','-634.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(173,'249',NULL,NULL,'144','1538295688817280','2000-01-01','','144','0','0','0','35','26.48','0','1200.36','0','-1173.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(174,'249',NULL,NULL,'145','1538295688934364','2000-01-01','','120A','0','0','0','20','25.51','0','714.5','0','-688.99','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(175,'249',NULL,NULL,'146','1538295689095402','2000-01-01','','177','0','0','0','20','17','0','1071.75','0','-1054.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(176,'249',NULL,NULL,'147','1538295690298465','2000-01-01','','173A','0','53973','53973','20','17','0','428.7','0','-411.70','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(177,'249',NULL,NULL,'148','1538295715091734','2000-01-01','','144B','0','1868','1868','35','26.48','0','1200.37','0','-1173.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(178,'249',NULL,NULL,'149','190119111627','','','111A','0','8916','8916','10','7.57','0','571.6','0','-564.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(179,'249',NULL,NULL,'150','190212101623','','','109B','0','0','0','10','7.57','0','1028.88','0','-1021.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(180,'249',NULL,NULL,'132','190410212736','2000-01-01','','215','0','0','0','900','681','0','643.05','0','37.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(181,'249',NULL,NULL,'151','190425093858','','','179A','0','0','0','25','19.26','0','436.5','0','-417.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(182,'249',NULL,NULL,'112','0','2000-01-01','07-05-2019','155A','0','0','0','30','22.7','0','771.66','0','-748.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(183,'249',NULL,NULL,'113','0','2000-01-01','07-05-2019','156A','0','0','0','30','25.51','0','1028.88','0','-1003.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(184,'249',NULL,NULL,'152','190512111840','','','109C','0','0','0','5','3.78','0','428.7','0','-424.92','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(185,'249',NULL,NULL,'153','190521133349','','','140D','0','0','0','20','15.13','0','714.5','0','-699.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(186,'249',NULL,NULL,'154','190529191013','','','225B','0','0','0','30','22.69','0','771.66','0','-748.97','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(187,'249',NULL,NULL,'155','190615123723','','','230A','0','0','0','40','30.26','0','1028.88','0','-998.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(188,'249',NULL,NULL,'156','190703094553','','','320B','0','0','0','5','3.79','0','471.57','0','-467.78','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(189,'249',NULL,NULL,'157','190717110556','','','232','0','0','0','25','18.91','0','857.4','0','-838.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(190,'249',NULL,NULL,'158','190723092721','','','116B','0','0','0','60','45.39','0','857.4','0','-812.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(191,'249',NULL,NULL,'92','0','2000-01-01','31-07-2019','108','0','0','0','25','18.91','0','643.05','0','-624.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(192,'249',NULL,NULL,'159','190819130940','','','230B','0','0','0','20','15.13','0','857.4','0','-842.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(193,'249',NULL,NULL,'146','0','2000-01-01','20-08-2019','177','0','0','0','30','22.69','0','643.05','0','-620.36','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(194,'249',NULL,NULL,'114','1568608135015','2000-01-01','16-09-2019','157','0','3988','3988','30','22.7','0','1028.88','0','-1006.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(195,'249',NULL,NULL,'160','191013103545','','','108A','0','0','0','110','83.23','0','1100.3','0','-1017.07','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(196,'249',NULL,NULL,'161','191127121032','','','234','0','0','0','30','22.7','0','1286.1','0','-1263.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(197,'249',NULL,NULL,'118','191206090844','2000-01-01','','169','0','0','0','30','22.7','0','1028.88','0','-1006.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(198,'249',NULL,NULL,'153','1577005988126','22-12-2019','22-12-2019','140D','0','490','490','22','16.65','0','785.95','0','-769.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(199,'249',NULL,NULL,'162','200119120621','','','115C','0','56683','56683','10','8.5','0','514.44','0','-505.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(200,'249',NULL,NULL,'163','200205133932','','','220','0','3315','3315','10','7.57','0','857.4','0','-849.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(201,'249',NULL,NULL,'164','200216163009','','','221','0','540','540','30','22.7','0','1028.89','0','-1006.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(202,'249',NULL,NULL,'165','200216163055','','','222','0','534','534','30','22.7','0','1028.89','0','-1006.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(203,'249',NULL,NULL,'137','1582372078754','2000-01-01','22-02-2020','160A','0','0','0','30','22.7','0','1543.32','0','-1520.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(204,'249',NULL,NULL,'139','1582372110832','2000-01-01','22-02-2020','161A','0','0','0','30','22.7','0','1543.32','0','-1520.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(205,'249',NULL,NULL,'140','1582372138658','2000-01-01','22-02-2020','163A','0','2581','2581','30','22.7','0','1543.32','0','-1520.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(206,'249',NULL,NULL,'166','200229103720','','','220A','0','10766','10766','10','7.57','0','857.4','0','-849.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(207,'249',NULL,NULL,'138','1583382914788','2000-01-01','05-03-2020','158A','0','0','0','30','25.51','0','1543.33','0','-1517.82','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(208,'249',NULL,NULL,'146','1583383485711','2000-01-01','05-03-2020','177','0','72','72','25','18.92','0','1339.59','0','-1320.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(209,'249',NULL,NULL,'167','200321142648','','','157A','0','456','456','120','90.8','0','1028.89','0','-938.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(210,'249',NULL,NULL,'168','200321142743','','','156A','0','977','977','120','102.04','0','1028.88','0','-926.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(211,'249',NULL,NULL,'169','200328123133','','','143B','0','95','95','150','127.55','0','857.4','0','-729.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(212,'249',NULL,NULL,'170','200621211341','','','105A','0','2904','2904','10','8.66','0','523.8','0','-515.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(213,'249',NULL,NULL,'160','1593149312310','26-06-2020','26-06-2020','108A','0','0','0','115','87.02','0','1105.3','0','-1018.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(214,'249',NULL,NULL,'171','200727101353','','','167C','0','2159','2159','30','25.51','0','1361.4','0','-1335.89','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(215,'249',NULL,NULL,'172','200729213715','','','110A','0','20755','20755','10','7.57','0','571.6','0','-564.03','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(216,'249',NULL,NULL,'173','200729213901','','','110B','0','146','146','30','22.7','0','857.4','0','-834.70','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(217,'249',NULL,NULL,'174','201212210036','','','156B','0','62','62','100','75.67','0','1714.81','0','-1639.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(218,'249',NULL,NULL,'144','1613193329798','2000-01-01','','144','0','0','0','30','22.7','0','1028.88','0','-1006.18','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(219,'249',NULL,NULL,'160','1620962277431','','','108A','0','0','0','125','94.58','0','1250.38','0','-1155.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(220,'249',NULL,NULL,'175','210626172752','','','106A','0','0','0','22','16.95','0','576.18','0','-559.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(221,'249',NULL,NULL,'176','210706183228','','','149A','0','336','336','15','11.35','0','0','0','11.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(222,'249',NULL,NULL,'177','211213185055','','','152','0','12456','12456','20','15.13','0','857.4','0','-842.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(223,'249',NULL,NULL,'178','220115094454','','','104A','0','-12','-12','5','3.85','0','698.39','0','-694.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(224,'249',NULL,NULL,'92','1642250297703','2000-01-01','','108','0','30266','30266','30','25.51','0','1028.88','0','-1003.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(225,'249',NULL,NULL,'179','220203102749','','','107B','0','0','0','80','61.63','0','931.19','0','-869.56','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(226,'249',NULL,NULL,'145','1644069894386','2000-01-01','','120A','0','0','0','25','18.91','0','893.13','0','-874.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(227,'249',NULL,NULL,'175','1645877923208','','','106A','0','0','0','25','19.26','0','872.99','0','-853.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(228,'249',NULL,NULL,'180','220331154612','','','102','0','0','0','10','8.5','0','523.8','0','-515.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(229,'249',NULL,NULL,'145','1653474045151','2000-01-01','','120A','0','4300','4300','30','25.51','0','1211.89','0','-1186.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(230,'249',NULL,NULL,'110','1653474129353','2000-01-01','','149','0','0','0','25','18.91','0','1071.75','0','-1052.84','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(231,'249',NULL,NULL,'179','1653644493852','','','107B','0','2283','2283','85','65.48','0','989.39','0','-923.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(232,'249',NULL,NULL,'112','1654517549928','2000-01-01','','155','0','0','0','35','26.48','0','1200.36','0','-1173.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(233,'249',NULL,NULL,'181','220701143930','','','165','0','11332','11332','30','25.51','0','1929.16','0','-1903.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(234,'249',NULL,NULL,'182','220704155807','','','115D','0','16740','16740','10','7.56','0','771.66','0','-764.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(235,'249',NULL,NULL,'183','220704160127','','','420','0','80448','80448','10','8.5','0','872.99','0','-864.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(236,'249',NULL,NULL,'132','1657280032815','2000-01-01','','215','0','0','0','1000','756.66','0','714.5','0','42.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(237,'249',NULL,NULL,'184','220713162016','','','111D','0','73931','73931','10','8.5','0','918','0','-909.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(238,'249',NULL,NULL,'185','220813182148','','','111B','0','0','0','70','52.96','0','1000.31','0','-947.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(239,'249',NULL,NULL,'144','1660824494634','2000-01-01','','144','0','0','0','40','34.01','0','1714.81','0','-1680.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(240,'249',NULL,NULL,'186','220829133515','','','139C','0','0','0','120','92.44','0','90.8','0','1.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(241,'249',NULL,NULL,'158','1661761027686','','','116B','0','0','0','70','52.96','0','1000.3','0','-947.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(242,'249',NULL,NULL,'142','220829170958','2000-01-01','','142A','0','2681','2681','40','34.01','0','1714.81','0','-1680.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(243,'249',NULL,NULL,'109','1662117576181','2000-01-01','','143','0','16717','16717','40','30.27','0','1714.81','0','-1684.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(244,'249',NULL,NULL,'187','220902165358','','','205','0','1718','1718','10','7.56','0','571.6','0','-564.04','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(245,'249',NULL,NULL,'118','1662470512840','2000-01-01','','169','0','2505','2505','40','30.27','0','1714.81','0','-1684.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(246,'249',NULL,NULL,'188','220915153739','','','122','0','28526','28526','20','15.13','0','1028.88','0','-1013.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(247,'249',NULL,NULL,'189','220920115309','','','451','0','460','460','150','113.5','0','1770.3','0','-1656.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(248,'249',NULL,NULL,'112','1663924420773','2000-01-01','','155','0','6054','6054','40','30.27','0','1371.85','0','-1341.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(249,'249',NULL,NULL,'190','221111130821','','','454','0','96','96','25','18.92','0','857.41','0','-838.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(250,'249',NULL,NULL,'191','221111130931','','','455','0','576','576','25','18.92','0','857.41','0','-838.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(251,'249',NULL,NULL,'192','221111131022','','','456','0','319','319','25','18.92','0','857.41','0','-838.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:34',NULL),(252,'249',NULL,NULL,'148','1668421981228','2000-01-01','','144B','0','1878','1878','40','30.27','0','1714.81','0','-1684.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(253,'249',NULL,NULL,'179','221115100638','','','107B','0','650','650','90','69.34','0','1047.59','0','-978.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(254,'249',NULL,NULL,'174','221201160138','','','156B','0','19','19','150','113.49','0','2572.21','0','-2458.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(255,'249',NULL,NULL,'193','230113162410','','','150','0','400','400','30','22.69','0','857.4','0','-834.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(256,'249',NULL,NULL,'194','230120185708','','','205A','0','144','144','5','3.78','0','514.44','0','-510.66','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(257,'249',NULL,NULL,'195','230120185935','','','152A','0','4972','4972','10','8.5','0','628.76','0','-620.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(258,'249',NULL,NULL,'196','230120190143','','','187A','0','620','620','10','7.7','0','523.8','0','-516.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(259,'249',NULL,NULL,'197','230128173827','','','235','0','2039','2039','10','7.57','0','523.8','0','-516.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(260,'249',NULL,NULL,'198','230128174242','','','236','0','401','401','10','7.7','0','523.8','0','-516.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(261,'249',NULL,NULL,'199','230128174506','','','237','0','864','864','5','3.78','0','1028.89','0','-1025.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(262,'249',NULL,NULL,'200','230302110819','','','459','0','672','672','10','7.57','0','685.92','0','-678.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(263,'249',NULL,NULL,'201','230309174740','','','460','0','576','576','10','7.57','0','685.92','0','-678.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(264,'249',NULL,NULL,'202','230309174856','','','461','0','384','384','10','7.57','0','685.92','0','-678.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(265,'249',NULL,NULL,'107','230710180036','2000-01-01','','141','0','42','42','25','18.91','0','857.4','0','-838.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(266,'249',NULL,NULL,'158','1690196248095','','','116B','0','0','0','80','60.53','0','1143.2','0','-1082.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(267,'249',NULL,NULL,'203','230724173626','','','470','0','24','24','150','113.5','0','1286.11','0','-1172.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(268,'249',NULL,NULL,'204','230805164026','','','9060','0','120','120','10','7.57','0','857.4','0','-849.83','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(269,'249',NULL,NULL,'205','230823125525','','','9070','0','1108','1108','40','34.01','0','1714.81','0','-1680.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(270,'249',NULL,NULL,'136','1696329919609','2000-01-01','','217','0','61','61','1100','832.33','0','785.96','0','46.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(271,'249',NULL,NULL,'206','231106154011','','','9093','0','0','0','10','8.5','0','969.51','0','-961.01','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(272,'249',NULL,NULL,'179','1706856804415','','','107B','0','3024','3024','100','77.04','0','1163.99','0','-1086.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(273,'249',NULL,NULL,'207','240221111513','','','10007','0','179935','179935','10','8.5','0','514.45','0','-505.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(274,'249',NULL,NULL,'208','240405180909','','','1020','0','0','0','50','37.83','0','2143.5','0','-2105.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(275,'249',NULL,NULL,'209','240405181039','','','1021','0','49','49','50','37.83','0','2143.5','0','-2105.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(276,'249',NULL,NULL,'210','240405181146','','','1022','0','126','126','50','37.83','0','2143.5','0','-2105.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(277,'249',NULL,NULL,'211','240417145918','','','138A','0','12672','12672','8.9','7.57','0','471.57','0','-464.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(278,'249',NULL,NULL,'212','240529161415','','','175','0','0','0','5','0','0','1714.81','0','-1714.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(279,'249',NULL,NULL,'160','1721215145305','','','108A','0','0','0','140','105.93','0','1400.42','0','-1294.49','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(280,'249',NULL,NULL,'173','240803154641','','','110B','0','0','0','50','37.83','0','1513.36','0','-1475.53','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(281,'249',NULL,NULL,'185','1723109815940','','','111B','0','0','0','80','60.53','0','1210.65','0','-1150.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(282,'249',NULL,NULL,'189','1729856234873','','','451','0','29','29','170','64.32','0','1457.59','0','-1393.27','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(283,'249',NULL,NULL,'213','241116150141','','','1023','0','2714','2714','20','17.01','0','857.4','0','-840.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(284,'249',NULL,NULL,'214','241119151612','','','180','0','1080','1080','30','22.7','0','1543.33','0','-1520.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(285,'249',NULL,NULL,'175','1738745151711','','','106A','0','3024','3024','30','25.98','0','1047.59','0','-1021.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(286,'249',NULL,NULL,'215','250208150517','','','196','0','264','264','10','7.06','0','640.2','0','-633.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(287,'249',NULL,NULL,'132','1745211862394','2000-01-01','','215','0','20','20','1100','935.38','0','785.95','0','149.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(288,'249',NULL,NULL,'216','250426184011','','','430','0','278','278','5','151.33','0','1143.2','0','-991.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(289,'249',NULL,NULL,'217','250509145426','','','10008','0','3240','3240','20','15.13','0','1028.89','0','-1013.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(290,'249',NULL,NULL,'136','1748519593377','2000-01-01','','217','0','17','17','1200','907.99','0','857.41','0','50.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(291,'249',NULL,NULL,'137','1750850244089','2000-01-01','','160A','0','0','0','40','30.27','0','2057.77','0','-2027.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(292,'249',NULL,NULL,'139','1750850284565','2000-01-01','','161A','0','0','0','40','30.27','0','2057.77','0','-2027.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(293,'249',NULL,NULL,'140','1750850327056','2000-01-01','','163A','0','648','648','40','30.27','0','2057.77','0','-2027.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(294,'249',NULL,NULL,'138','1750850354145','2000-01-01','','158A','0','1026','1026','40','34.01','0','2057.77','0','-2023.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(295,'249',NULL,NULL,'218','250830153937','','','196A','0','0','0','5','3.85','0','523.8','0','-519.95','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(296,'249',NULL,NULL,'114','1758805230062','2000-01-01','','157','0','216','216','40','34.02','0','1551.21','0','-1517.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(297,'249',NULL,NULL,'113','1758805277316','2000-01-01','','156','0','228','228','40','34.01','0','1551.21','0','-1517.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(298,'249',NULL,NULL,'165','1758805467657','','','222','0','96','96','40','34.01','0','2326.82','0','-2292.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(299,'249',NULL,NULL,'219','250925183713','','','750','0','1020','1020','4.45','3.78','0','431.43','0','-427.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(300,'249',NULL,NULL,'95','251001105019','2000-01-01','','111','0','0','0','8.9','7.57','0','907.2','0','-899.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(301,'249',NULL,NULL,'220','251001171141','','','710','0','132180','132180','8.9','7.57','0','862.86','0','-855.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(302,'249',NULL,NULL,'221','251001171309','','','164C','0','23420','23420','8.9','6.67','0','1150.48','0','-1143.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(303,'249',NULL,NULL,'222','251001171438','','','113','0','4116','4116','35.6','30.27','0','1208.01','0','-1177.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(304,'249',NULL,NULL,'223','251001171622','','','712','0','196','196','120','101.78','0','1163.41','0','-1061.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(305,'249',NULL,NULL,'224','251001171749','','','713','0','170','170','120','101.78','0','1163.41','0','-1061.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(306,'249',NULL,NULL,'225','251001171856','','','714','0','160','160','120','101.78','0','1163.41','0','-1061.63','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(307,'249',NULL,NULL,'226','251001172103','','','715','0','270','270','4.45','3.47','0','474.57','0','-471.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(308,'249',NULL,NULL,'227','251008122741','','','115','0','211920','211920','8.9','7.6','0','862.86','0','-855.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(309,'249',NULL,NULL,'228','251008122955','','','614','0','108720','108720','8.9','7.57','0','517.72','0','-510.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(310,'249',NULL,NULL,'229','251010172937','','','165A','0','50440','50440','8.9','7.57','0','1150.48','0','-1142.91','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(311,'249',NULL,NULL,'230','251010173207','','','120B','0','0','0','26.7','14.19','0','1078.58','0','-1064.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(312,'249',NULL,NULL,'231','251010173333','','','121B','0','0','0','31.15','26.47','0','1258.34','0','-1231.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(313,'249',NULL,NULL,'232','251010173448','','','133A','0','0','0','8.9','7.57','0','517.72','0','-510.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(314,'249',NULL,NULL,'233','251010173703','','','196B','0','3330','3330','8.9','7.71','0','702.84','0','-695.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(315,'249',NULL,NULL,'234','251010173810','','','182A','0','1344','1344','8.9','7.71','0','702.84','0','-695.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(316,'249',NULL,NULL,'170','251011215329','','','105A','0','2664','2664','8.9','7.71','0','527.13','0','-519.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(317,'249',NULL,NULL,'235','251015122357','','','1023A','0','360','360','17.8','15.12','0','862.86','0','-847.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(318,'249',NULL,NULL,'236','251015122654','','','118B','0','0','0','8.9','7.57','0','690.29','0','-682.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(319,'249',NULL,NULL,'237','251015122806','','','119','0','3540','3540','8.9','7.57','0','690.29','0','-682.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(320,'249',NULL,NULL,'238','251015123014','','','101A','0','0','0','1.78','1.62','0','552.23','0','-550.61','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(321,'249',NULL,NULL,'239','251015123119','','','1025','0','90','90','150','95.72','0','1636.96','0','-1541.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(322,'249',NULL,NULL,'240','251015123230','','','176C','0','0','0','8.9','7.57','0','862.86','0','-855.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(323,'249',NULL,NULL,'241','251017115807','','','220B','0','564','564','8.9','7.57','0','862.86','0','-855.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(324,'249',NULL,NULL,'242','251017120234','','','124A','0','0','0','8.9','7.57','0','690.29','0','-682.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(325,'249',NULL,NULL,'243','251017120439','','','225D','0','0','0','8.9','7.57','0','862.86','0','-855.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(326,'249',NULL,NULL,'244','251017120635','','','173B','0','2400','2400','17.8','15.12','0','431.43','0','-416.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(327,'249',NULL,NULL,'245','251017124617','','','173C','0','31236','31236','8.9','7.57','0','550.55','0','-542.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(328,'249',NULL,NULL,'246','251020154321','','','10007A','0','14484','14484','8.9','7.57','0','862.86','0','-855.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(329,'249',NULL,NULL,'247','251020154429','','','106B','0','0','0','26.7','23.12','0','1054.26','0','-1031.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(330,'249',NULL,NULL,'248','251020154544','','','146A','0','0','0','26.7','23.12','0','1054.26','0','-1031.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(331,'249',NULL,NULL,'249','251020154700','','','138B','0','49410','49410','1.78','1.51','0','913.26','0','-911.75','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(332,'249',NULL,NULL,'178','1760960534497','','','104A','0','14400','14400','4.45','3.85','0','554.4','0','-550.55','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(333,'249',NULL,NULL,'89','1760960565617','2000-01-01','','105','0','3000','3000','8.9','7.7','0','554.4','0','-546.70','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(334,'249',NULL,NULL,'94','1760960614217','2000-01-01','','110','0','3840','3840','4.45','4.45','0','453.6','0','-449.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(335,'249',NULL,NULL,'99','251027095707','2000-01-01','','120','0','1291','1291','5','4.25','0','514.44','0','-510.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(336,'249',NULL,NULL,'250','251028124757','','','139A','0','6480','6480','4.45','3.78','0','517.72','0','-513.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(337,'249',NULL,NULL,'251','251028124859','','','173D','0','14436','14436','8.9','7.57','0','517.72','0','-510.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(338,'249',NULL,NULL,'252','251028125008','','','215A','0','31','31','979','832.48','0','790.96','0','41.52','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(339,'249',NULL,NULL,'253','251028125113','','','1024','0','40','40','150','127.55','0','2423.77','0','-2296.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(340,'249',NULL,NULL,'254','251028141306','','','107A','0','16','16','89','77.06','0','1171.4','0','-1094.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(341,'249',NULL,NULL,'255','251028141403','','','213A','0','216','216','71.2','60.54','0','1725.73','0','-1665.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(342,'249',NULL,NULL,'256','251028141453','','','152B','0','0','0','8.9','7.57','0','690.29','0','-682.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(343,'249',NULL,NULL,'257','251028141552','','','104B','0','95','95','4.45','3.85','0','527.13','0','-523.28','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(344,'249',NULL,NULL,'258','251030173941','','','116D','0','400','400','35.6','30.27','0','1150.48','0','-1120.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(345,'249',NULL,NULL,'259','251030174106','','','102B','0','0','0','10','7.71','0','527.13','0','-519.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(346,'249',NULL,NULL,'260','251030174207','','','102C','0','6768','6768','8.9','7.71','0','527.13','0','-519.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(347,'249',NULL,NULL,'261','251030174321','','','143A','0','0','0','35.6','30.27','0','1725.72','0','-1695.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(348,'249',NULL,NULL,'262','251030174435','','','155A','0','132','132','35.6','30.27','0','1150.48','0','-1120.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(349,'249',NULL,NULL,'263','251030174639','','','1008A','0','480','480','17.8','15.12','0','969.51','0','-954.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(350,'249',NULL,NULL,'264','251105120804','','','183','0','7296','7296','10','7.92','0','723.9','0','-715.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(351,'249',NULL,NULL,'265','251108144105','','','112A','0','0','0','17.8','15.14','0','1035.44','0','-1020.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(352,'249',NULL,NULL,'266','251108144616','','','171A','0','72','72','26.7','21.44','0','1466.87','0','-1445.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(353,'249',NULL,NULL,'267','251108144819','','','144E','0','0','0','35.6','30.27','0','1725.72','0','-1695.45','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(354,'249',NULL,NULL,'268','251108144919','','','156D','0','0','0','35.6','30.27','0','1380.58','0','-1350.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(355,'249',NULL,NULL,'269','251108145049','','','142D','0','36','36','8.9','113.52','0','862.86','0','-749.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(356,'249',NULL,NULL,'270','251108145233','','','143D','0','12','12','8.9','113.52','0','862.86','0','-749.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(357,'249',NULL,NULL,'271','251111113603','','','165B','0','1347','1347','26.7','22.7','0','1941.44','0','-1918.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(358,'249',NULL,NULL,'272','251111113917','','','179B','0','2694','2694','8.9','7.71','0','702.84','0','-695.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(359,'249',NULL,NULL,'273','251111115221','','','187B','0','0','0','8.9','7.71','0','702.84','0','-695.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(360,'249',NULL,NULL,'274','251111115436','','','145A','0','1428','1428','8.9','7.71','0','702.84','0','-695.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(361,'249',NULL,NULL,'205','1763122779737','','','9070','0','505','505','35','29.76','0','1696.64','0','-1666.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(362,'249',NULL,NULL,'275','251120141426','','','122A','0','0','0','17.8','15.14','0','1035.44','0','-1020.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(363,'249',NULL,NULL,'276','251120141605','','','108B','0','0','0','26.7','22.71','0','1035.44','0','-1012.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(364,'249',NULL,NULL,'118','1764244657412','2000-01-01','','169','0','480','480','35','29.76','0','1696.64','0','-1666.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(365,'249',NULL,NULL,'270','1764244714456','','','143D','0','63','63','9','114.79','0','872.56','0','-757.77','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(366,'249',NULL,NULL,'277','251127174254','','','149B','0','960','960','17.8','15.12','0','862.86','0','-847.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(367,'249',NULL,NULL,'278','251127174407','','','186A','0','0','0','4.45','3.85','0','527.14','0','-523.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(368,'249',NULL,NULL,'279','251127174459','','','178A','0','792','792','4.5','3.83','0','527.14','0','-523.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(369,'249',NULL,NULL,'280','251127174609','','','160B','0','0','0','35.6','30.27','0','2070.87','0','-2040.60','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(370,'249',NULL,NULL,'281','251127174656','','','163B','0','0','0','35.6','30.27','0','2070.87','0','-2040.60','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(371,'249',NULL,NULL,'282','251127174746','','','158','0','0','0','35.6','30.27','0','2070.87','0','-2040.60','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(372,'249',NULL,NULL,'283','251127174832','','','154A','0','0','0','8.9','7.57','0','862.86','0','-855.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(373,'249',NULL,NULL,'284','251127174919','','','177B','0','0','0','31.15','26.49','0','755','0','-728.51','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(374,'249',NULL,NULL,'285','251127175405','','','120C','0','2952','2952','4.45','3.78','0','517.72','0','-513.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(375,'249',NULL,NULL,'286','251130115630','','','156C','0','22','22','8.9','90.82','0','1035.44','0','-944.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(376,'249',NULL,NULL,'287','251130120521','','','174','0','108','108','8.9','7.57','0','862.86','0','-855.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(377,'249',NULL,NULL,'288','251202170229','','','157B','0','24','24','8.9','90.82','0','1035.44','0','-944.62','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(378,'249',NULL,NULL,'289','251208115714','','','111E','0','179177','179177','9','7.66','0','872.56','0','-864.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(379,'249',NULL,NULL,'290','251208120133','','','164D','0','20030','20030','9','7.63','0','1163.41','0','-1155.78','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(380,'249',NULL,NULL,'291','251208120327','','','165C','0','6584','6584','27','22.91','0','1963.26','0','-1940.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(381,'249',NULL,NULL,'292','251208122013','','','420A','0','1116','1116','8.9','7.55','0','878.55','0','-871.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(382,'249',NULL,NULL,'293','251208122429','','','218A','0','128','128','13.35','11.33','0','690.29','0','-678.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(383,'249',NULL,NULL,'254','251208122625','','','107A','0','0','0','90','77.56','0','1184.56','0','-1107.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(384,'249',NULL,NULL,'294','251208174319','','','145B','0','3196','3196','9','7.66','0','888.42','0','-880.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(385,'249',NULL,NULL,'295','251209180256','','','220C','0','0','0','9','7.65','0','862.86','0','-855.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(386,'249',NULL,NULL,'242','251209180530','','','124A','0','27360','27360','9','7.66','0','698.05','0','-690.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(387,'249',NULL,NULL,'227','251211185122','','','115','0','223580','223580','9','7.66','0','872.56','0','-864.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(388,'249',NULL,NULL,'262','251211185243','','','115A','0','672','672','36','30.62','0','1396.09','0','-1365.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(389,'249',NULL,NULL,'269','251211185349','','','142D','0','60','60','9','114.8','0','872.56','0','-757.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(390,'249',NULL,NULL,'117','251216105311','2000-01-01','','167','0','0','0','27','22.96','0','0','0','22.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(391,'249',NULL,NULL,'251','0','','','173D','0','48606','48606','9','7.66','0','523.53','0','-515.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(392,'249',NULL,NULL,'265','0','','','112A','0','6750','6750','18','15.31','0','1047.07','0','-1031.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(393,'249',NULL,NULL,'228','0','','','614','0','0','0','9','7.66','0','523.53','0','-515.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(394,'249',NULL,NULL,'144','0','2000-01-01','','144','0','48','48','35','29.76','0','1696.64','0','-1666.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(395,'249',NULL,NULL,'261','0','','','143A','0','300','300','35','29.76','0','1696.64','0','-1666.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(396,'249',NULL,NULL,'170','1766221682262','','','105A','0','3618','3618','9','7.79','0','533.05','0','-525.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(397,'249',NULL,NULL,'283','0','','','154A','0','10276.8','10276.8','9','7.66','0','872.56','0','-864.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(398,'249',NULL,NULL,'260','251223191405','','','102C','0','4252','4252','9','7.8','0','533.05','0','-525.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(399,'249',NULL,NULL,'244','251223191513','','','173B','0','5400','5400','18','15.31','0','436.28','0','-420.97','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(400,'249',NULL,NULL,'259','0','','','102B','0','480','480','9','7.8','0','533.05','0','-525.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(401,'249',NULL,NULL,'232','0','','','133A','0','53358','53358','9','7.66','0','523.53','0','-515.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(402,'249',NULL,NULL,'243','0','','','225D','0','228','228','9','7.66','0','872.56','0','-864.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(403,'249',NULL,NULL,'100','251230114342','2000-01-01','','123','0','0','0','4.45','3.78','0','517.72','0','-513.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(404,'249',NULL,NULL,'245','251230114430','','','173c','0','1440','1440','9','7.65','0','0','0','7.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(405,'249',NULL,NULL,'231','0','','','121B','0','0','0','30','25.52','0','1211.89','0','-1186.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(406,'249',NULL,NULL,'114','0','2000-01-01','','157','0','0','0','36','30.62','0','1396.1','0','-1365.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(407,'249',NULL,NULL,'286','0','','','156C','0','31','31','9','91.84','0','1047.07','0','-955.23','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(408,'249',NULL,NULL,'211','251231185931','','','138A','0','3156','3156','9','7.66','0','523.53','0','-515.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(409,'249',NULL,NULL,'237','0','','','119','0','0','0','9','7.66','0','698.05','0','-690.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(410,'249',NULL,NULL,'235','0','','','1023A','0','1930','1930','18','15.31','0','872.56','0','-857.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(411,'249',NULL,NULL,'236','0','','','118B','0','0','0','9','7.66','0','698.05','0','-690.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(412,'249',NULL,NULL,'282','1767970077789','','','158','0','1008','1008','36','30.61','0','2094.15','0','-2063.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(413,'249',NULL,NULL,'139','1767970224885','2000-01-01','','161A','0','594','594','36','30.61','0','2094.15','0','-2063.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(414,'249',NULL,NULL,'281','1767970246532','','','163B','0','72','72','36','30.61','0','2094.15','0','-2063.54','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(415,'249',NULL,NULL,'275','1768057009714','','','122A','0','7686','7686','18','15.31','0','1047.07','0','-1031.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(416,'249',NULL,NULL,'276','1768057104713','','','108B','0','3600','3600','27','22.96','0','1047.07','0','-1024.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(417,'249',NULL,NULL,'277','1768057174346','','','149B','0','360','360','18','15.31','0','872.56','0','-857.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(418,'249',NULL,NULL,'171','1768057211114','','','167C','0','60','60','27','22.96','0','1308.84','0','-1285.88','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(419,'249',NULL,NULL,'273','1768057340572','','','187B','0','576','576','9','7.8','0','710.74','0','-702.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(420,'249',NULL,NULL,'268','1768057396773','','','156D','0','516','516','36','30.62','0','1396.1','0','-1365.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(421,'249',NULL,NULL,'240','1768057443743','','','176C','0','5094','5094','9','7.66','0','872.56','0','-864.90','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(422,'249',NULL,NULL,'230','1768709719934','','','120B','0','0','0','27','22.96','0','1090.7','0','-1067.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(423,'249',NULL,NULL,'280','1770004770255','','','160B','0','54','54','36','30.62','0','2094.15','0','-2063.53','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(424,'249',NULL,NULL,'293','1770463958424','','','218A','0','128','128','13','11.06','0','672.19','0','-661.13','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(425,'249',NULL,NULL,'247','1770464113104','','','106B','0','0','0','27','23.38','0','1066.11','0','-1042.73','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(426,'249',NULL,NULL,'256','1772446728960','','','152B','0','96','96','9','7.65','0','698.05','0','-690.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(427,'249',NULL,NULL,'142','1772790031517','2000-01-01','','142A','0','51','51','35','29.77','0','1696.64','0','-1666.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(428,'249',NULL,NULL,'267','1772790078735','','','144E','0','51','51','35','29.77','0','1696.64','0','-1666.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(429,'249',NULL,NULL,'247','1772891371626','','','106B','0','0','0','30','25.98','0','1184.56','0','-1158.58','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(430,'249',NULL,NULL,'132','1773841630874','2000-01-01','','215','0','5','5','979','874.12','0','790.96','0','83.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(431,'249',NULL,NULL,'146','260319100653','2000-01-01','','177','0','180','180','18','15.31','0','0','0','15.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(432,'249',NULL,NULL,'97','1774067672456','2000-01-01','','1774067672456','0','0','0','4.45','3.78','0','0','0','3.78','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(433,'249',NULL,NULL,'105','1774067703297','2000-01-01','','1774067703295','0','4320','4320','4.45','3.78','0','517.72','0','-513.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(434,'249',NULL,NULL,'112','1774498644365','2000-01-01','','155','0','0','0','36','32.14','0','1396.1','0','-1363.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(435,'249',NULL,NULL,'182','1774851137038','','','115D','0','31320','31320','9','7.66','0','785.3','0','-777.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(436,'249',NULL,NULL,'266','1774951499659','','','171A','0','72','72','27','22.96','0','1570.6','0','-1547.64','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(437,'249',NULL,NULL,'272','1774951554077','','','179B','0','96','96','9','7.8','0','710.74','0','-702.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(438,'249',NULL,NULL,'284','1774951627870','','','177B','0','90','90','31','26.37','0','751.37','0','-725.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(439,'249',NULL,NULL,'234','1775626876996','','','182A','0','0','0','9','7.65','0','710.74','0','-703.09','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(440,'249',NULL,NULL,'296','200102173221','','','387','0','2436','2436','10','8.5','0','1350.58','0','-1342.08','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(441,'249',NULL,NULL,'297','200102173310','','','388','0','240','240','15','6.7','0','756.95','0','-750.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(442,'249',NULL,NULL,'298','200102173418','','','389','0','2136','2136','15','6.7','0','756.95','0','-750.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(443,'249',NULL,NULL,'299','230810123023','','','9063','0','168','168','10','7.14','0','1344','0','-1336.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(444,'249',NULL,NULL,'296','1691672750339','','','387','0','0','0','20','1374','0','0','0','1374.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(445,'249',NULL,NULL,'297','1691672789889','','','388','0','240','240','20','13.74','0','1552.7','0','-1538.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(446,'249',NULL,NULL,'300','230810184930','','','9064','0','360','360','20','13.74','0','1552.7','0','-1538.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(447,'249',NULL,NULL,'301','230810185028','','','9065','0','240','240','20','13.74','0','1552.7','0','-1538.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(448,'249',NULL,NULL,'298','1693561024256','','','389','0','240','240','20','13.73','0','1552.71','0','-1538.98','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(449,'249',NULL,NULL,'302','250904181044','','','9081','0','0','0','10','7.4','0','1171.46','0','-1164.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(450,'249',NULL,NULL,'303','250904181226','','','9200','0','336','336','10','7.4','0','1171.46','0','-1164.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(451,'249',NULL,NULL,'304','260323112633','','','387A','0','60','60','40','25.4','0','1440.62','0','-1415.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(452,'249',NULL,NULL,'305','260323112746','','','389A','0','60','60','40','25.4','0','1440.6','0','-1415.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(453,'249',NULL,NULL,'306','260323112849','','','388A','0','120','120','40','25.4','0','1440.62','0','-1415.22','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(454,'249',NULL,NULL,'307','181009114156','','','382A','0','0','0','80','59.52','0','1345.68','0','-1286.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(455,'249',NULL,NULL,'308','190525113925','','','385','0','0','0','99','73.66','0','555.1','0','-481.44','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(456,'249',NULL,NULL,'307','1571982174115','25-10-2019','25-10-2019','382A','0','0','0','84','62.2','0','1412.96','0','-1350.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(457,'249',NULL,NULL,'309','200216163428','','','442A','0','0','0','80','67.5','0','1271.67','0','-1204.17','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(458,'249',NULL,NULL,'310','201117122214','','','409A','0','84','84','120','95.64','0','901.12','0','-805.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(459,'249',NULL,NULL,'311','210427115604','','','439','0','622','622','10','7.76','0','877.62','0','-869.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(460,'249',NULL,NULL,'312','210427120212','','','440','0','3785','3785','10','7.76','0','877.62','0','-869.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(461,'249',NULL,NULL,'313','210507085138','','','409B','0','648','648','10','7.97','0','901.13','0','-893.16','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(462,'249',NULL,NULL,'314','220201181503','','','386','0','3588','3588','10','7.57','0','968.89','0','-961.32','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(463,'249',NULL,NULL,'315','220609142806','','','409C','0','36','36','30','17.85','0','605.56','0','-587.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(464,'249',NULL,NULL,'316','220617160135','','','419A','0','0','0','10','7.76','0','877.62','0','-869.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(465,'249',NULL,NULL,'317','230718133710','','','466','0','0','0','10','7.57','0','2108.16','0','-2100.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(466,'249',NULL,NULL,'318','230718133836','','','467','0','288','288','10','7.57','0','2108.16','0','-2100.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(467,'249',NULL,NULL,'319','230718133954','','','468','0','0','0','10','7.57','0','2108.16','0','-2100.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(468,'249',NULL,NULL,'320','230718134102','','','469','0','288','288','10','7.57','0','2108.16','0','-2100.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(469,'249',NULL,NULL,'321','230810185520','','','9066','0','1728','1728','10','7.32','0','992.72','0','-985.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(470,'249',NULL,NULL,'322','231004130309','','','9088','0','2016','2016','10','0','0','992.72','0','-992.72','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(471,'249',NULL,NULL,'323','231006155429','','','9089','0','10','10','10','0','0','804.37','0','-804.37','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(472,'249',NULL,NULL,'324','231120182759','','','474','0','288','288','10','7.32','0','992.72','0','-985.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(473,'249',NULL,NULL,'325','231120182857','','','475','0','288','288','10','7.32','0','992.72','0','-985.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(474,'249',NULL,NULL,'326','231219125645','','','386A','0','0','0','10','7.32','0','1985.43','0','-1978.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(475,'249',NULL,NULL,'327','240810161441','','','478','0','0','0','10','7.31','0','1026.37','0','-1019.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(476,'249',NULL,NULL,'328','240810165030','','','479','0','0','0','10','7.31','0','992.72','0','-985.41','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(477,'249',NULL,NULL,'329','240810165304','','','480','0','0','0','10','6.98','0','789.85','0','-782.87','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(478,'249',NULL,NULL,'330','240810165509','','','481','0','0','0','10','6.98','0','526.57','0','-519.59','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(479,'249',NULL,NULL,'331','250522140937','','','490','0','0','0','10','7.31','0','1026.37','0','-1019.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(480,'249',NULL,NULL,'332','251008122131','','','605','0','144','144','10','7.81','0','1062.75','0','-1054.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(481,'249',NULL,NULL,'333','251008122221','','','606','0','288','288','10','7.81','0','1062.75','0','-1054.94','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(482,'249',NULL,NULL,'334','251008122335','','','607','0','336','336','10','7.62','0','1210.12','0','-1202.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(483,'249',NULL,NULL,'335','251008122528','','','608','0','144','144','10','8.07','0','1098.78','0','-1090.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(484,'249',NULL,NULL,'336','251008122626','','','609','0','0','0','10','7.62','0','1210.12','0','-1202.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(485,'249',NULL,NULL,'337','260207171313','','','10011','0','0','0','9.4','7.16','0','1137.51','0','-1130.35','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(486,'249',NULL,NULL,'338','260207171423','','','10012','0','0','0','9.4','7.17','0','1137.51','0','-1130.34','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(487,'249',NULL,NULL,'339','230519164150','','','9049','0','309','309','50','38.52','0','4412.9','0','-4374.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(488,'249',NULL,NULL,'340','211215115059','','','0004A','0','14','14','2500','2125.85','0','2095.2','0','30.65','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL),(489,'249',NULL,NULL,'341','230302124642','','','6000','0','48','48','0','0','0','0','0','0.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-05-16 07:24:35',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=490 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int DEFAULT '0',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int DEFAULT '0',
  `M_ROUND_OFF` int DEFAULT '0',
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text,
  `INV_NO` text,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `PROD_ID` int NOT NULL,
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PACK` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BOX` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN_QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `FREE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `CESS_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `WEIGHT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PRICE_PER` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SALE_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DMG_MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CLOUD_SYNC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `INV_ARR` text COLLATE utf8mb4_general_ci,
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_BY` int DEFAULT NULL,
  `UPDATED_BY` int DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_TS` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SUPPLIER_ID` int DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8mb4_general_ci,
  `GROUP_ID` int DEFAULT NULL,
  `FINAL_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BATCH_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TCS_TAX` varchar(100) COLLATE utf8mb4_general_ci DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `BROKER_ID` int DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REGISTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `PARENT_USER_NAME` varchar(255) DEFAULT NULL,
  `PARENT_PASSWORD` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=398 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (397,'249','0','emtwTsXW3s','punam','emtwTsXW3s','punam@yopmail.com',NULL,'zbsbjqjies35','Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','',NULL,NULL,'397','1','',0,'2026-05-16 07:11:50','2026-05-16 07:16:22');
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REMARKS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int DEFAULT '0',
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-05-16 07:11:45',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text,
  `MAC_ID` int DEFAULT '0',
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text,
  `S_ADD2` text,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=795 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'249',NULL,NULL,'Cash',14,'19373179.61','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'-3226070',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(2,'249',NULL,NULL,'Additional Tax(GST)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(3,'249',NULL,NULL,'Advertisement & Publicity',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(4,'249',NULL,NULL,'Bad Debts Written Off',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(5,'249',NULL,NULL,'Bank Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(6,'249',NULL,NULL,'Bonus',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(7,'249',NULL,NULL,'Books & Periodicals',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(8,'249',NULL,NULL,'Brokerage',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(9,'249',NULL,NULL,'C Form Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(10,'249',NULL,NULL,'C Form Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(11,'249',NULL,NULL,'Capital Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(12,'249',NULL,NULL,'Central Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(13,'249',NULL,NULL,'CGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(14,'249',NULL,NULL,'Charity & Donations',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(15,'249',NULL,NULL,'Commissions on Sales',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(16,'249',NULL,NULL,'Computers',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(17,'249',NULL,NULL,'Conveyance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(18,'249',NULL,NULL,'CST Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(19,'249',NULL,NULL,'Development Taxes',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(20,'249',NULL,NULL,'Edu. Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(21,'249',NULL,NULL,'Edu. Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(22,'249',NULL,NULL,'Edu. Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(23,'249',NULL,NULL,'Edu. Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(24,'249',NULL,NULL,'Excise Duties',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(25,'249',NULL,NULL,'IGST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(26,'249',NULL,NULL,'SGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(27,'249',NULL,NULL,'Legal Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(28,'249',NULL,NULL,'Market Fees',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(29,'249',NULL,NULL,'National VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(30,'249',NULL,NULL,'RDF',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(31,'249',NULL,NULL,'Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(32,'249',NULL,NULL,'SHE Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(33,'249',NULL,NULL,'SHE Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(34,'249',NULL,NULL,'SHE Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(35,'249',NULL,NULL,'SHE Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(36,'249',NULL,NULL,'Surcharge On VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(37,'249',NULL,NULL,'TDS (Advertisment)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(38,'249',NULL,NULL,'TDS (Commission)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(39,'249',NULL,NULL,'TDS (Contractor)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(40,'249',NULL,NULL,'TDS (Interest)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(41,'249',NULL,NULL,'TDS (Rent)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(42,'249',NULL,NULL,'TDS (Salery)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(43,'249',NULL,NULL,'VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(44,'249',NULL,NULL,'Telephone Expenses',19,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(45,'249',NULL,NULL,'Customer Entertainment Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(46,'249',NULL,NULL,'Depriciation A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(47,'249',NULL,NULL,'Discount',20,'77329.8','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(48,'249',NULL,NULL,'Freight & Forwarding Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(49,'249',NULL,NULL,'Interest Payable A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(50,'249',NULL,NULL,'Job Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(51,'249',NULL,NULL,'Labour',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(52,'249',NULL,NULL,'Legal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(53,'249',NULL,NULL,'Misc. Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(54,'249',NULL,NULL,'Miscellaneous Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'54',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(55,'249',NULL,NULL,'Office Maintenance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(56,'249',NULL,NULL,'Office Rent',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'56',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-12000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(57,'249',NULL,NULL,'Office Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'57',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(58,'249',NULL,NULL,'Postal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'58',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(59,'249',NULL,NULL,'Printing & Stationery',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'59',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(60,'249',NULL,NULL,'Rounded Off - Sales',20,'0','CR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'60',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(61,'249',NULL,NULL,'Salery',20,'20000','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'61',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-34000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(62,'249',NULL,NULL,'Sales Promotion Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'62',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(63,'249',NULL,NULL,'Sewing Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'63',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(64,'249',NULL,NULL,'Staff Welfare Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'64',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(65,'249',NULL,NULL,'Stitching',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'65',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(66,'249',NULL,NULL,'Travelling Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'66',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(67,'249',NULL,NULL,'Water & Electricity Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'67',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(68,'249',NULL,NULL,'Earnest Money',29,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'68',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(69,'249',NULL,NULL,'Furnituer & Fixture',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'69',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(70,'249',NULL,NULL,'Office Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'70',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(71,'249',NULL,NULL,'Plants & Machinery',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'71',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(72,'249',NULL,NULL,'CST Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'72',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(73,'249',NULL,NULL,'Interstate Retail Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'73',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(74,'249',NULL,NULL,'Local B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'74',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(75,'249',NULL,NULL,'Sales',27,'58302987.77','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'75',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(76,'249',NULL,NULL,'Sales Retail 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'76',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(77,'249',NULL,NULL,'Sales Retail 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'77',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(78,'249',NULL,NULL,'Sales VAT 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'78',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(79,'249',NULL,NULL,'Sales VAT 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'79',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(80,'249',NULL,NULL,'Dammi',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'80',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(81,'249',NULL,NULL,'Income From National VAT',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'81',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(82,'249',NULL,NULL,'Interest Receivable A/c',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'82',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(83,'249',NULL,NULL,'Rate Adjustment',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'83',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(84,'249',NULL,NULL,'Mall Khata A/c',30,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'84',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(85,'249',NULL,NULL,'Profit & Loss',9,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'85',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(86,'249',NULL,NULL,'Purchase',25,'53645913.6','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'86',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(87,'249',NULL,NULL,'Purchase Retail 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'87',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(88,'249',NULL,NULL,'Purchase Retail 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'88',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(89,'249',NULL,NULL,'Purchase VAT 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'89',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(90,'249',NULL,NULL,'Purchase VAT 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'90',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(91,'249',NULL,NULL,'Replacement',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'91',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(92,'249',NULL,NULL,'Stock',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'92',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(93,'249',NULL,NULL,'Salery & Bonus Payable',24,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'93',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(94,'249',NULL,NULL,'Interstate B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'94',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(95,'249',NULL,NULL,'CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'95',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(96,'249',NULL,NULL,'Additional CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'96',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(97,'249',NULL,NULL,'SCHEME-1',20,'35711.8406','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'97',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(98,'249',NULL,NULL,'SCHEME-2',20,'1324.16','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'98',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-05-16 07:11:47','2026-05-16 07:11:47'),(99,'249',NULL,NULL,'vinkyak store',5,'0','DR','near odian tokies','ghatkopar','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43713','0.00',NULL,'0','0',NULL,'0','714',NULL,'0','0',NULL,0,'2026-05-16 10:18:17','2026-05-16 10:18:17'),(100,'249',NULL,NULL,'mundra mithai ghar',5,'0','DR','opp new mundra','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44185','0.00',NULL,'0','0',NULL,'0','1638',NULL,'0','0',NULL,0,'2026-05-16 10:18:17','2026-05-16 10:18:17'),(101,'249',NULL,NULL,'cash (T.P)',5,'0','DR','NEAR FOOD POINT','','','21','',NULL,'9930987337','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4054',NULL,'0','0',NULL,0,'2026-05-16 10:18:17','2026-05-16 10:18:17'),(102,'249',NULL,NULL,'bread st',5,'0','DR','kirol village','','','21','',NULL,'','',NULL,'27','','','CANARA',NULL,NULL,'VIDYAVIHAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43714','0.00',NULL,'0','0',NULL,'0','721',NULL,'0','0',NULL,0,'2026-05-16 10:18:17','2026-05-16 10:18:17'),(103,'249',NULL,NULL,'amar grain st',5,'0','DR','nr bread st','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43714','0.00',NULL,'0','0',NULL,'0','722',NULL,'0','0',NULL,0,'2026-05-16 10:18:17','2026-05-16 10:18:17'),(104,'249',NULL,NULL,'aarey  140',5,'0','DR','opp  bharat cafe hotel','','','21','',NULL,'9029583587','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44200','0.00',NULL,'0','0',NULL,'0','1652',NULL,'0','0',NULL,0,'2026-05-16 10:18:17','2026-05-16 10:18:17'),(105,'249',NULL,NULL,'WILLFRED',5,'0','DR','VIDHAYAVIHAR KIROL VILLAGE','','','21','',NULL,'9920770907','',NULL,'27','','','CANARA',NULL,NULL,'VIDYA VIHAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43738','0.00',NULL,'0','0',NULL,'0','953',NULL,'0','0',NULL,0,'2026-05-16 10:18:18','2026-05-16 10:18:18'),(106,'249',NULL,NULL,'WELCOME SUPER MARKET',5,'0','DR','GHATKOPAR','GHATKOPAR','Mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AACFW3808N1ZR','','HDFC',NULL,NULL,'GKPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','581',NULL,'0','0',NULL,0,'2026-05-16 10:18:18','2026-05-16 10:18:18'),(107,'249',NULL,NULL,'VORA FACTORY OUTLET',5,'0','DR','NR SATYAM D/F','','','21','',NULL,'8433556555','',NULL,'27','','','CORPORATION',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44168','0.00',NULL,'0','0',NULL,'0','1594',NULL,'0','0',NULL,0,'2026-05-16 10:18:18','2026-05-16 10:18:18'),(108,'249',NULL,NULL,'VINAYAK FOODS',5,'0','DR','BEHIND R ODEON MALL','','','21','',NULL,'','',NULL,'27','','','SHRI ARIHANT',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43989','0.00',NULL,'0','0',NULL,'0','1372',NULL,'0','0',NULL,0,'2026-05-16 10:18:18','2026-05-16 10:18:18'),(109,'249',NULL,NULL,'UDAY STORES',5,'0','DR','SHREE MAHALAXMI APARTMENT SHOP NO 3 CAMA LANE','GHATKOPAR W','Mumbai','21','400077',NULL,'1111111111','',NULL,'27','27AABPP7971N1ZY','','JANKALYAN',NULL,NULL,'GKPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','586',NULL,'0','0',NULL,0,'2026-05-16 10:18:18','2026-05-16 10:18:18'),(110,'249',NULL,NULL,'TIP TOP SNACKS',5,'0','DR','NR FOOD POINT','','Mumbai','21','400071',NULL,'8652222111','',NULL,'27','27ETMPR5807M1ZT','','IMPS',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44163','0.00',NULL,'0','0',NULL,'0','1564',NULL,'0','0',NULL,0,'2026-05-16 10:18:18','2026-05-16 10:18:18'),(111,'249',NULL,NULL,'SUBHAM SUPER STORE',5,'0','DR','SHOP NO 10,SATI KRUPA SHOPING','CENTRE,GARODIAY NGR','GHATKOPAR EAST','21','400077',NULL,'9892982833','',NULL,'27','27AADPG1225G1Z9','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44091','0.00',NULL,'0','0',NULL,'0','1465',NULL,'0','0',NULL,0,'2026-05-16 10:18:18','2026-05-16 10:18:18'),(112,'249',NULL,NULL,'SMILE N BAKE',5,'0','DR','NAVROJI LANE','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43714','0.00',NULL,'0','0',NULL,'0','724',NULL,'0','0',NULL,0,'2026-05-16 10:18:18','2026-05-16 10:18:18'),(113,'249',NULL,NULL,'SHYAM BIHARI DAIRY',5,'0','DR','BEHIND MANEKLAL BUS STOP','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43709','0.00',NULL,'0','0',NULL,'0','706',NULL,'0','0',NULL,0,'2026-05-16 10:18:18','2026-05-16 10:18:18'),(114,'249',NULL,NULL,'SHREE SWAMI SAMART LANCH HOME',5,'0','DR','KHALAI VILLAGE','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','318',NULL,'0','0',NULL,0,'2026-05-16 10:18:18','2026-05-16 10:18:18'),(115,'249',NULL,NULL,'SHREE S S MEDICAL',5,'0','DR','KIROL VILLAGE','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43738','0.00',NULL,'0','0',NULL,'0','954',NULL,'0','0',NULL,0,'2026-05-16 10:18:19','2026-05-16 10:18:19'),(116,'249',NULL,NULL,'SHREE RAM JUICE CENTER',5,'0','DR','OPP HINDUSHABA HOSPTEL','','','21','',NULL,'','',NULL,'27','','','ABHYUDAYA',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43733','0.00',NULL,'0','0',NULL,'0','765',NULL,'0','0',NULL,0,'2026-05-16 10:18:19','2026-05-16 10:18:19'),(117,'249',NULL,NULL,'SHREE LAXMI STORE',5,'0','DR','AIROL VILLAGE','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43735','0.00',NULL,'0','0',NULL,'0','899',NULL,'0','0',NULL,0,'2026-05-16 10:18:19','2026-05-16 10:18:19'),(118,'249',NULL,NULL,'SHREE GANESH CHEMIST',5,'0','DR','GAVDEVI NEAR SHATI NIKETAN HOSPITAL','GHATKOPAR','Mumbai','21','400077',NULL,'1111111111','',NULL,'27','27AGIPA1255H2ZP','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','669',NULL,'0','0',NULL,0,'2026-05-16 10:18:19','2026-05-16 10:18:19'),(119,'249',NULL,NULL,'SHIVRAJ',5,'0','DR','SHOP NO 2 TRAFFIC LITE BLDG NEAR BANK OF BARODA M G ROAD','GHATKOPAR','MUMBAI','21','400077',NULL,'8898903483','',NULL,'27','27ADLFS4359N1Z8','','ICICI',NULL,NULL,'GKTPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','2500','1',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','584',NULL,'0','0',NULL,0,'2026-05-16 10:18:19','2026-05-16 10:18:19'),(120,'249',NULL,NULL,'SHIVAM DRYFRUIT',5,'0','DR','NR SATYAM DRY FRUIT','GOPAL GALLI','','21','',NULL,'','',NULL,'27','','','CORPORATION',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43738','0.00',NULL,'0','0',NULL,'0','958',NULL,'0','0',NULL,0,'2026-05-16 10:18:19','2026-05-16 10:18:19'),(121,'249',NULL,NULL,'SHINDE',5,'0','DR','GHATKOPAR','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','201',NULL,'0','0',NULL,0,'2026-05-16 10:18:19','2026-05-16 10:18:19'),(122,'249',NULL,NULL,'SHIDDHI MEDICAL',5,'0','DR','KHALAI VILLAGE','NEAR KALPTERU GRAIN STORE','','21','',NULL,'9784485237','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43748','0.00',NULL,'0','0',NULL,'0','1003',NULL,'0','0',NULL,0,'2026-05-16 10:18:19','2026-05-16 10:18:19'),(123,'249',NULL,NULL,'SHEETY P/B',5,'0','DR','NEAR PANDY DUGHDHALYA','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','591',NULL,'0','0',NULL,0,'2026-05-16 10:18:19','2026-05-16 10:18:19'),(124,'249',NULL,NULL,'SHAH VELJI',5,'0','DR','OPP LADHUBHAI','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','321',NULL,'0','0',NULL,0,'2026-05-16 10:18:19','2026-05-16 10:18:19'),(125,'249',NULL,NULL,'SHAH RAGHAVJ MONJI',5,'0','DR','NR UDAY THEATRE','','','21','',NULL,'9819080220','',NULL,'27','27AAPPS4910G1ZF','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44171','0.00',NULL,'0','0',NULL,'0','1609',NULL,'0','0',NULL,0,'2026-05-16 10:18:20','2026-05-16 10:18:20'),(126,'249',NULL,NULL,'SHAH DEVRAJ NARAYAN',5,'0','DR','NR KALPATARU STORE','VIDHYAVIHAR KHALAI VILLAGE','','21','',NULL,'','',NULL,'27','','','MUMBAI DISTRICT',NULL,NULL,'GKTPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','652',NULL,'0','0',NULL,0,'2026-05-16 10:18:20','2026-05-16 10:18:20'),(127,'249',NULL,NULL,'SHAH DEVISHI JESANG',5,'0','DR','KAMA LANE OPP LADHU BHAI','','','21','',NULL,'','',NULL,'27','','','BOB',NULL,NULL,'GKTPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43735','0.00',NULL,'0','0',NULL,'0','900',NULL,'0','0',NULL,0,'2026-05-16 10:18:20','2026-05-16 10:18:20'),(128,'249',NULL,NULL,'SATYAM DRYFRUIT',5,'0','DR','OPP DEPAK MEDICAL GOPAL GALI','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43718','0.00',NULL,'0','0',NULL,'0','737',NULL,'0','0',NULL,0,'2026-05-16 10:18:20','2026-05-16 10:18:20'),(129,'249',NULL,NULL,'SATYAM DRY FRUIT',5,'0','DR','GOPAL LANE','','','21','',NULL,'','',NULL,'27','','','ICICI',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43735','0.00',NULL,'0','0',NULL,'0','897',NULL,'0','0',NULL,0,'2026-05-16 10:18:20','2026-05-16 10:18:20'),(130,'249',NULL,NULL,'SANTOSH BHELPURI',5,'0','DR','NEXT TO KHANDALWAL','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','662',NULL,'0','0',NULL,0,'2026-05-16 10:18:20','2026-05-16 10:18:20'),(131,'249',NULL,NULL,'SANDEEP GEN STORE',5,'0','DR','NEAR VIDYHAVIHAR ST','','','21','',NULL,'9326086036','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','317',NULL,'0','0',NULL,0,'2026-05-16 10:18:20','2026-05-16 10:18:20'),(132,'249',NULL,NULL,'SALIM PF 1',5,'0','DR','GHATKOPAR','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','208',NULL,'0','0',NULL,0,'2026-05-16 10:18:20','2026-05-16 10:18:20'),(133,'249',NULL,NULL,'RELISH FOODS & HOSPITALITY',5,'0','DR','SHOP NO 4,SVDD SCHOOL COMPD','HINGWALA LANE GHATKOPAR','Mumbai','21','400077',NULL,'1111111111','',NULL,'27','27BJTPB8356B1Z2','','NEW INDIA',NULL,NULL,'GKPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-45231','0.00',NULL,'0','0',NULL,'0','1236',NULL,'0','0',NULL,0,'2026-05-16 10:18:20','2026-05-16 10:18:20'),(134,'249',NULL,NULL,'REKHA GENERAL STORES',5,'0','DR','SHIV NIWAS RAJAWADI','','','21','',NULL,'','',NULL,'27','27AACPD3469Q1ZA','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44104','0.00',NULL,'0','0',NULL,'0','1482',NULL,'0','0',NULL,0,'2026-05-16 10:18:20','2026-05-16 10:18:20'),(135,'249',NULL,NULL,'REKHA GENERAL STORE',5,'0','DR','RAJAWADI GHATKOPAR','','mumbai','21','400077',NULL,'1111111111','',NULL,'27','27AACPD3469Q1ZA','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44106','0.00',NULL,'0','0',NULL,'0','1483',NULL,'0','0',NULL,0,'2026-05-16 10:18:21','2026-05-16 10:18:21'),(136,'249',NULL,NULL,'RAYSHI BACHUBHAI & COMPANY',5,'0','DR','OPP CAMA LANE M G ROAD GHATKOPAR','GHATKOPAR','mumbai','21','400077',NULL,'1111111111','',NULL,'27','27AAAFR8617A1ZG','','UNION',NULL,NULL,'GKTPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','576',NULL,'0','0',NULL,0,'2026-05-16 10:18:21','2026-05-16 10:18:21'),(137,'249',NULL,NULL,'RATNA SUPER MARKET',5,'0','DR','ASHOK BULDING OPP- PURNIMA BULDING 60 FEET ROAD','GHATKOPER EAST','MUMBAI','21','400071',NULL,'9920123522','',NULL,'27','27ABEFP6888L1ZC','','KOTAK BANK',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6393',NULL,'0','0',NULL,0,'2026-05-16 10:18:21','2026-05-16 10:18:21'),(138,'249',NULL,NULL,'RAMNIK STORE',5,'0','DR','STATION ROAD','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','664',NULL,'0','0',NULL,0,'2026-05-16 10:18:21','2026-05-16 10:18:21'),(139,'249',NULL,NULL,'RAMESHWAR DUGDHALAY',5,'0','DR','KAMA LANE','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','JANKALYAN',NULL,NULL,'CHEMBUR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','297',NULL,'0','0',NULL,0,'2026-05-16 10:18:21','2026-05-16 10:18:21'),(140,'249',NULL,NULL,'RAJKAMAL SWEETS',5,'0','DR','NR AGARWAL JUICE CENTER','','','21','',NULL,'7977015677','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44189','0.00',NULL,'0','0',NULL,'0','1643',NULL,'0','0',NULL,0,'2026-05-16 10:18:21','2026-05-16 10:18:21'),(141,'249',NULL,NULL,'RAJAWADI STALL',5,'0','DR','RAJAWADI HOSPITAL','','','21','',NULL,'9892389218','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44280','0.00',NULL,'0','0',NULL,'0','1761',NULL,'0','0',NULL,0,'2026-05-16 10:18:21','2026-05-16 10:18:21'),(142,'249',NULL,NULL,'RAJAWADI CANTEEN',5,'0','DR','RAJAWADI HOSPITAL','','','21','',NULL,'8097390290','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44270','0.00',NULL,'0','0',NULL,'0','1746',NULL,'0','0',NULL,0,'2026-05-16 10:18:21','2026-05-16 10:18:21'),(143,'249',NULL,NULL,'RAJAL STORE',5,'0','DR','NEAR LAXMI ST','NEAR SANTOSHI MATA MANDIR','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44281','0.00',NULL,'0','0',NULL,'0','1764',NULL,'0','0',NULL,0,'2026-05-16 10:18:21','2026-05-16 10:18:21'),(144,'249',NULL,NULL,'R R FAST FOOD',5,'0','DR','GOREGAON','','','21','',NULL,'9022779629','',NULL,'27','','','SYNDICATE BANK',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1658',NULL,'0','0',NULL,0,'2026-05-16 10:18:21','2026-05-16 10:18:21'),(145,'249',NULL,NULL,'PRADISE MEDICO GENERAL STORE',5,'0','DR','SHOP NO 1 JAY KRISHANA BLDG PL PANTNAGAR , GHATKOPER','ghatkoper','MUMBAI','21','400075',NULL,'7715915928','',NULL,'27','27BHGPJ7058H1Z3','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5390',NULL,'0','0',NULL,0,'2026-05-16 10:18:22','2026-05-16 10:18:22'),(146,'249',NULL,NULL,'PARAS TEA MART',5,'0','DR','OPP GHATKOPAR RAILWAY STATION','','Mumbai','21','400086',NULL,'9324795105','',NULL,'27','27AAEPS9108H4ZD','','CANARA',NULL,NULL,'GKPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43776','0.00',NULL,'0','0',NULL,'0','1175',NULL,'0','0',NULL,0,'2026-05-16 10:18:22','2026-05-16 10:18:22'),(147,'249',NULL,NULL,'PANKAJ   GRAIN        STORE',5,'0','DR','KIROLE VILLAGE OPP TO DHEDIYA BROTHERS','GHATKOPAR','Mumbai','21','400086',NULL,'1111111111','',NULL,'27','27AAAPM7950M1Z9','','UNION',NULL,NULL,'GKTPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43721','0.00',NULL,'0','0',NULL,'0','742',NULL,'0','0',NULL,0,'2026-05-16 10:18:22','2026-05-16 10:18:22'),(148,'249',NULL,NULL,'PANDY DUGDHALYA',5,'0','DR','GAVDEVI','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','588',NULL,'0','0',NULL,0,'2026-05-16 10:18:22','2026-05-16 10:18:22'),(149,'249',NULL,NULL,'NEW MUNDRA SWEET',5,'0','DR','NR WELCOME S/M','','','21','',NULL,'9821426930','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44165','0.00',NULL,'0','0',NULL,'0','1583',NULL,'0','0',NULL,0,'2026-05-16 10:18:22','2026-05-16 10:18:22'),(150,'249',NULL,NULL,'NAYANA ENTERPRISE',5,'0','DR','GHATKOPAR','','','21','',NULL,'','',NULL,'27','','','CORPORATION',NULL,NULL,'GHT','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43875','0.00',NULL,'0','0',NULL,'0','1290',NULL,'0','0',NULL,0,'2026-05-16 10:18:22','2026-05-16 10:18:22'),(151,'249',NULL,NULL,'MUMMA\'S YUMMY',5,'0','DR','SHOP NO 8,SHIV KRUPA SADAN,','KARANI LANE,GHATKOPAR WEST','','21','',NULL,'7208830624','',NULL,'27','','','ICICI',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4019',NULL,'0','0',NULL,0,'2026-05-16 10:18:22','2026-05-16 10:18:22'),(152,'249',NULL,NULL,'MILIND STORE',5,'0','DR','KIROLE VILLAGE OPP DEADEYA STORE','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43780','0.00',NULL,'0','0',NULL,'0','1178',NULL,'0','0',NULL,0,'2026-05-16 10:18:22','2026-05-16 10:18:22'),(153,'249',NULL,NULL,'METRO CHEMIST  GENERAL STORE',5,'0','DR','SHOP NO 2, WING ,PRARTHANA CHS LTD BLDG NO 81 PANTNAGER, GHATKOPER EAST','OPP FLORA MEDICAL','','21','',NULL,'8452903790','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5395',NULL,'0','0',NULL,0,'2026-05-16 10:18:22','2026-05-16 10:18:22'),(154,'249',NULL,NULL,'MEHTA BROTHERS',5,'0','DR','NR HEENA GENERAL STORE','','','21','',NULL,'467889','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5393',NULL,'0','0',NULL,0,'2026-05-16 10:18:22','2026-05-16 10:18:22'),(155,'249',NULL,NULL,'MAULI MEDICAL',5,'0','DR','KIROL VILLAGE NEAR DEDIYA STORES','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1024',NULL,'0','0',NULL,0,'2026-05-16 10:18:23','2026-05-16 10:18:23'),(156,'249',NULL,NULL,'MALANI STORE',5,'0','DR','PASTAM SAGAR ROAD NO 4','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43744','0.00',NULL,'0','0',NULL,'0','976',NULL,'0','0',NULL,0,'2026-05-16 10:18:23','2026-05-16 10:18:23'),(157,'249',NULL,NULL,'MAHARASHTRA G/ S',5,'0','DR','KAHALI VILLAGE','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43735','0.00',NULL,'0','0',NULL,'0','898',NULL,'0','0',NULL,0,'2026-05-16 10:18:23','2026-05-16 10:18:23'),(158,'249',NULL,NULL,'MAHANAGAR  MEDICAL GENERAL STORE',5,'0','DR','SHOP NO 08 OPP FISH MARKET, STATION ROAD, PHANTNAGAR GHATKOPER','','MUMBAI','21','400077',NULL,'9820409103','',NULL,'27','27ALLPK0025B1ZO','','SBI',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5391',NULL,'0','0',NULL,0,'2026-05-16 10:18:23','2026-05-16 10:18:23'),(159,'249',NULL,NULL,'MAHANAGAR',5,'0','DR','OPPNEO WELCOME HOTEL J V ROAD','GHATKOPAR','Mumbai','21','400086',NULL,'1111111111','',NULL,'27','27AKAPK8208L1ZZ','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','530',NULL,'0','0',NULL,0,'2026-05-16 10:18:23','2026-05-16 10:18:23'),(160,'249',NULL,NULL,'MAHALAXMI GEN STORE',5,'0','DR','NEARNOORI BEAKERY','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','612',NULL,'0','0',NULL,0,'2026-05-16 10:18:23','2026-05-16 10:18:23'),(161,'249',NULL,NULL,'LEO 89',5,'0','DR','CHEMBUR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','582',NULL,'0','0',NULL,0,'2026-05-16 10:18:23','2026-05-16 10:18:23'),(162,'249',NULL,NULL,'LAXMI TEA & FARSAN',5,'0','DR','GHATKOPAR ST NEAR NOBAL CHEMIST','GHATKOPAR','Mumabi','21','400086',NULL,'1111111111','',NULL,'27','27AAQHM2606G1Z4','','CANARA BANK',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','595',NULL,'0','0',NULL,0,'2026-05-16 10:18:23','2026-05-16 10:18:23'),(163,'249',NULL,NULL,'LAXMI STORE',5,'0','DR','HANSOTI LANE','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','JANAKALYAN',NULL,NULL,'GKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','298',NULL,'0','0',NULL,0,'2026-05-16 10:18:23','2026-05-16 10:18:23'),(164,'249',NULL,NULL,'LAXMI GRAIN STORE',5,'0','DR','MANEKLAL NEAR BUS STOP','MANEKLAL 1ST BUS STOP','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43718','0.00',NULL,'0','0',NULL,'0','735',NULL,'0','0',NULL,0,'2026-05-16 10:18:23','2026-05-16 10:18:23'),(165,'249',NULL,NULL,'LAXMI GEN STORE',5,'0','DR','HANSOTI LANE','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','JANKALYAN',NULL,NULL,'GKTPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','319',NULL,'0','0',NULL,0,'2026-05-16 10:18:24','2026-05-16 10:18:24'),(166,'249',NULL,NULL,'LAXMI GEN STORE',5,'0','DR','DAMODAR PARK GAVDEVI','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','590',NULL,'0','0',NULL,0,'2026-05-16 10:18:24','2026-05-16 10:18:24'),(167,'249',NULL,NULL,'LAKHANI SUPER MARKET',5,'0','DR','GKHOT GALI','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','KNS',NULL,NULL,'GKPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','593',NULL,'0','0',NULL,0,'2026-05-16 10:18:24','2026-05-16 10:18:24'),(168,'249',NULL,NULL,'LAKHANI GEN STORE',5,'0','DR','GKHOOT GALI','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','KNS',NULL,NULL,'GKPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','594',NULL,'0','0',NULL,0,'2026-05-16 10:18:24','2026-05-16 10:18:24'),(169,'249',NULL,NULL,'LADHUBHAI THOBHAN',5,'0','DR','S.N.D.T COOLAGE','GHATKOPAR (W)','','21','',NULL,'022-25162190','',NULL,'27','27AADPG1207A1ZN','','BOB',NULL,NULL,'G K','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','316',NULL,'0','0',NULL,0,'2026-05-16 10:18:24','2026-05-16 10:18:24'),(170,'249',NULL,NULL,'KRISHNA SWEET',5,'0','DR','NEAR RUSHIKESH MEDICAL','TUNGA','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','610',NULL,'0','0',NULL,0,'2026-05-16 10:18:24','2026-05-16 10:18:24'),(171,'249',NULL,NULL,'KRISHANA MEDICAL AND GENERAL STORE',5,'0','DR','SHOPNO 07,B NO122, CTS5662 PANT NAGAR, MHADA COLONY, MUMBAI GHATKOPER','','','21','',NULL,'7045274298','',NULL,'27','','','IDBI',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5388',NULL,'0','0',NULL,0,'2026-05-16 10:18:24','2026-05-16 10:18:24'),(172,'249',NULL,NULL,'KHANDELWAL & SONS',5,'0','DR','71 HIRACHAND DESAI ROAD MUNICIPAL COMPLEX SARVODAY STATION ROAD','GHATKOPAR (W)','Mumbai','21','400086',NULL,'9967634402','',NULL,'27','27ADQPK1957M1ZU','','SBI',NULL,NULL,'GKTPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','583',NULL,'0','0',NULL,0,'2026-05-16 10:18:24','2026-05-16 10:18:24'),(173,'249',NULL,NULL,'KALPATARU',5,'0','DR','VIDHAYAVIHAR(KHALI VILLAGE','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','648',NULL,'0','0',NULL,0,'2026-05-16 10:18:24','2026-05-16 10:18:24'),(174,'249',NULL,NULL,'JYOTI GEN STORE',5,'0','DR','KAMA LANE NEXT TO S S ND T COOLAGE','GHATKOPAR','Mumbai','21','400086',NULL,'9820747442','',NULL,'27','27APNPC4665F1ZS','','BOB',NULL,NULL,'GKPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','531',NULL,'0','0',NULL,0,'2026-05-16 10:18:24','2026-05-16 10:18:24'),(175,'249',NULL,NULL,'JJC ROYALE JAGDUSHA',5,'0','DR','GHATKOPAR EAST','','Mumbai','21','400086',NULL,'1111111111','',NULL,'27','27AABAJ4071G1ZT','','DENA BANK',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43819','0.00',NULL,'0','0',NULL,'0','1235',NULL,'0','0',NULL,0,'2026-05-16 10:18:25','2026-05-16 10:18:25'),(176,'249',NULL,NULL,'JAY KRISHNA BHANDAR',5,'0','DR','NER CHANDAN STORE','','','21','',NULL,'','',NULL,'27','27AOMPG6147C1Z0','','JANKALYAN',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43864','0.00',NULL,'0','0',NULL,'0','1287',NULL,'0','0',NULL,0,'2026-05-16 10:18:25','2026-05-16 10:18:25'),(177,'249',NULL,NULL,'JAY KRISHNA BANDAR',5,'0','DR','NEAR CAMA LANE','GHATKOPAR','Mumbai','21','400077',NULL,'1111111111','',NULL,'27','27AOMPG6147C1Z0','','JANKALYAN',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','580',NULL,'0','0',NULL,0,'2026-05-16 10:18:25','2026-05-16 10:18:25'),(178,'249',NULL,NULL,'JAY BHARAT STORE (PHARMACY)',5,'0','DR','GR FLR SHOP NO 2 NAVROJI LANE','','Mumbai','21','400086',NULL,'7304443030','',NULL,'27','27AAPFJ3196D1Z3','','BOB',NULL,NULL,'GKTPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43738','0.00',NULL,'0','0',NULL,'0','957',NULL,'0','0',NULL,0,'2026-05-16 10:18:25','2026-05-16 10:18:25'),(179,'249',NULL,NULL,'JAIN DAIRY FARM',5,'0','DR','SHOP NO 7,CHIMAN NIWAS,GOPAL LANE','GHATKOPAR (WEST)','mumbai','21','400086',NULL,'9821388899','',NULL,'27','27AABPS9453Q1ZS','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44274','0.00',NULL,'0','0',NULL,'0','1751',NULL,'0','0',NULL,0,'2026-05-16 10:18:25','2026-05-16 10:18:25'),(180,'249',NULL,NULL,'HARMONY AGENCY',5,'0','DR','RAMABAI COLONY, GHATKOPAR','','','21','',NULL,'','',NULL,'27','27AFOPJ1182P1ZU','','SOUTH INDIAN BANK',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43738','0.00',NULL,'0','0',NULL,'0','938',NULL,'0','0',NULL,0,'2026-05-16 10:18:25','2026-05-16 10:18:25'),(181,'249',NULL,NULL,'HANUMAN STOTES',5,'0','DR','KIROL VILLAGE','NEXT TO PANKAJ STORES','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1025',NULL,'0','0',NULL,0,'2026-05-16 10:18:25','2026-05-16 10:18:25'),(182,'249',NULL,NULL,'GHELANI STORES',5,'0','DR','HINGWALA LANE,','GHATKOPAR (E)','MUMBAI','21','400077',NULL,'9702939030','',NULL,'27','27AAGPS2642Q1Z2','','KOTAK',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43938','0.00',NULL,'0','0',NULL,'0','1342',NULL,'0','0',NULL,0,'2026-05-16 10:18:25','2026-05-16 10:18:25'),(183,'249',NULL,NULL,'GHATKOPAR HARDWARE',5,'0','DR','M G RD','','','21','',NULL,'9821096802','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','3822',NULL,'0','0',NULL,0,'2026-05-16 10:18:25','2026-05-16 10:18:25'),(184,'249',NULL,NULL,'GHATKOPAR AYURVED BHANDAR',5,'0','DR','SH05 NEW ASHISH APT,OPP POPULAR HOTAL HINGWALA LANE GHATKOPER','','MUMBAI','21','400075',NULL,'9967036295','',NULL,'27','27AAEFG0342H1ZR','','BOB',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5387',NULL,'0','0',NULL,0,'2026-05-16 10:18:25','2026-05-16 10:18:25'),(185,'249',NULL,NULL,'GAYATRI CATERERS',5,'0','DR','NR FOOD POINT','','','21','',NULL,'8850665370','',NULL,'27','','','COSMOS',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44035','0.00',NULL,'0','0',NULL,'0','1418',NULL,'0','0',NULL,0,'2026-05-16 10:18:26','2026-05-16 10:18:26'),(186,'249',NULL,NULL,'GAUTAM DUGDHALAYA',5,'0','DR','SHOP NO 3 SIDDHI APARTMENT CAMA LANE','GHATKOPR','MUMBAI','21','400086',NULL,'1111111111','',NULL,'27','27AGCPP4385R1ZJ','','SHRI ARIHANT',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','585',NULL,'0','0',NULL,0,'2026-05-16 10:18:26','2026-05-16 10:18:26'),(187,'249',NULL,NULL,'GANESH PHARMACY',5,'0','DR','OPP CURE MEDICAL','','MUMBAI','21','400077',NULL,'9898989898','',NULL,'27','','','SARASWAT',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5392',NULL,'0','0',NULL,0,'2026-05-16 10:18:26','2026-05-16 10:18:26'),(188,'249',NULL,NULL,'GALA STORE',5,'0','DR','NEXT TO KALPTARU KHALI VILLAGE','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','BOI',NULL,NULL,'GKPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43721','0.00',NULL,'0','0',NULL,'0','743',NULL,'0','0',NULL,0,'2026-05-16 10:18:26','2026-05-16 10:18:26'),(189,'249',NULL,NULL,'GAJANAN PF 2',5,'0','DR','GHATKOPAR','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','200',NULL,'0','0',NULL,0,'2026-05-16 10:18:26','2026-05-16 10:18:26'),(190,'249',NULL,NULL,'FOOD POINT',5,'0','DR','OPP SHIVAM DRYFRUIT GOPAL GTALI','','Mumbai','21','400077',NULL,'1111111111','',NULL,'27','27AALPY1639G1Z9','','CORPORATION BANK',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43738','0.00',NULL,'0','0',NULL,'0','959',NULL,'0','0',NULL,0,'2026-05-16 10:18:26','2026-05-16 10:18:26'),(191,'249',NULL,NULL,'FATIMA MILK CENTER',5,'0','DR','AMAR GRAIN STORE','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','MUMBAI DISTRICT',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43714','0.00',NULL,'0','0',NULL,'0','723',NULL,'0','0',NULL,0,'2026-05-16 10:18:26','2026-05-16 10:18:26'),(192,'249',NULL,NULL,'EVERGREEN FOODS',5,'0','DR','SHOP NO 3,VALUE PLATINUM','RAJAWADI RD,GHATKOPAR EAST','MUMBAI','21','400077',NULL,'8976706666','',NULL,'27','27AAEFE1075D1ZT','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43994','0.00',NULL,'0','0',NULL,'0','1378',NULL,'0','0',NULL,0,'2026-05-16 10:18:26','2026-05-16 10:18:26'),(193,'249',NULL,NULL,'EKAL ENTERPRISES',5,'0','DR','KIROL VILLAGE, VIDHYAVIHAR WEST','OPP NEELKANTH KINGDOM','','21','',NULL,'','',NULL,'27','27AHZPD3764C1Z4','','ICICI',NULL,NULL,'KURLA','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43708','0.00',NULL,'0','0',NULL,'0','694',NULL,'0','0',NULL,0,'2026-05-16 10:18:26','2026-05-16 10:18:26'),(194,'249',NULL,NULL,'DHEDHIYA BROTHERS',5,'0','DR','KIROLE VILLAGE NEXT TO PANKAJ','VIDHAYAVIHAR','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43721','0.00',NULL,'0','0',NULL,'0','741',NULL,'0','0',NULL,0,'2026-05-16 10:18:26','2026-05-16 10:18:26'),(195,'249',NULL,NULL,'DEEPAK MEDICAL & GEN STORE',5,'0','DR','KAPOL WADI','GHATKOPAR WEST','Mumbai','21','400077',NULL,'9820356540','',NULL,'27','27AARFD2720P1ZY','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44122','0.00',NULL,'0','0',NULL,'0','1510',NULL,'0','0',NULL,0,'2026-05-16 10:18:27','2026-05-16 10:18:27'),(196,'249',NULL,NULL,'DEEPAK MEDICAL',5,'0','DR','GOPAL LANE','','Mumbai','21','400086',NULL,'8083038080','',NULL,'27','27AAGPS7815R1ZR','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','680',NULL,'0','0',NULL,0,'2026-05-16 10:18:27','2026-05-16 10:18:27'),(197,'249',NULL,NULL,'DEEPA RESTAURANT',5,'0','DR','NEAR SHREYAS NAKA LBS MARG','GHATKOPAR WEST','','21','',NULL,'9769384735','',NULL,'27','27APLPS2987L2ZV','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','234',NULL,'0','0',NULL,0,'2026-05-16 10:18:27','2026-05-16 10:18:27'),(198,'249',NULL,NULL,'DEDHIYA  BROTHER',5,'0','DR','KIROL VILLAGE OPP MILIND STORES','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43770','0.00',NULL,'0','0',NULL,'0','1155',NULL,'0','0',NULL,0,'2026-05-16 10:18:27','2026-05-16 10:18:27'),(199,'249',NULL,NULL,'D P TRIPATHI PF 1',5,'0','DR','GHATKOPAR 9967594160','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','194',NULL,'0','0',NULL,0,'2026-05-16 10:18:27','2026-05-16 10:18:27'),(200,'249',NULL,NULL,'CHITRA DAIRY',5,'0','DR','KAMRAJ NAGAR','','','21','',NULL,'','',NULL,'27','','','IMPS',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44047','0.00',NULL,'0','0',NULL,'0','1429',NULL,'0','0',NULL,0,'2026-05-16 10:18:27','2026-05-16 10:18:27'),(201,'249',NULL,NULL,'CHHEDA\'S FOOD KINGDOM',5,'0','DR','GHATKOPAR','','mumbai','21','400077',NULL,'1111111111','',NULL,'27','27AAAFC1715G1ZY','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44013','0.00',NULL,'0','0',NULL,'0','1413',NULL,'0','0',NULL,0,'2026-05-16 10:18:27','2026-05-16 10:18:27'),(202,'249',NULL,NULL,'CHETANA MEDICAL GENERAL STORES',5,'0','DR','SHOP NO 03, BLDG NO 25, PANTNAGAR , GHATKOPAR','','','21','',NULL,'9152085920','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5389',NULL,'0','0',NULL,0,'2026-05-16 10:18:27','2026-05-16 10:18:27'),(203,'249',NULL,NULL,'CHETAN GRAIN STORES',5,'0','DR','PANT NAGAR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43942','0.00',NULL,'0','0',NULL,'0','1348',NULL,'0','0',NULL,0,'2026-05-16 10:18:27','2026-05-16 10:18:27'),(204,'249',NULL,NULL,'CHANDAN STORE',5,'0','DR','GHATKOPAR','','','21','',NULL,'','',NULL,'27','','','BOB',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43711','0.00',NULL,'0','0',NULL,'0','713',NULL,'0','0',NULL,0,'2026-05-16 10:18:27','2026-05-16 10:18:27'),(205,'249',NULL,NULL,'CHANDAN PALACE BAR & REST',5,'0','DR','90 FEET RD','','mumbai','21','400077',NULL,'1111111111','',NULL,'27','27AYBPS6630F1ZD','','AXIS',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43848','0.00',NULL,'0','0',NULL,'0','1274',NULL,'0','0',NULL,0,'2026-05-16 10:18:28','2026-05-16 10:18:28'),(206,'249',NULL,NULL,'CHAMUNDA STORE',5,'0','DR','NAIDU COLONY','PANT NGR CIRCLE','MUMBAI','21','400077',NULL,'1111111111','',NULL,'27','27AFFPC0085B1Z3','','THE DECCAN BANK',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43837','0.00',NULL,'0','0',NULL,'0','1262',NULL,'0','0',NULL,0,'2026-05-16 10:18:28','2026-05-16 10:18:28'),(207,'249',NULL,NULL,'CENTRAL STORE',5,'0','DR','STATION ROAD OPP SHIVRAJ','GHATKOPAR','mumbai','21','400086',NULL,'1111111111','',NULL,'27','27AACFC7928B1ZN','','THE DECCAN',NULL,NULL,'GKTPR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43714','0.00',NULL,'0','0',NULL,'0','725',NULL,'0','0',NULL,0,'2026-05-16 10:18:28','2026-05-16 10:18:28'),(208,'249',NULL,NULL,'CASH [C.S]',5,'0','DR','NER ANAD JUIC','','','21','',NULL,'983355426','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43758','0.00',NULL,'0','0',NULL,'0','1057',NULL,'0','0',NULL,0,'2026-05-16 10:18:28','2026-05-16 10:18:28'),(209,'249',NULL,NULL,'CASH SATYAM  DRY',5,'0','DR','GHATKOPER','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43800','0.00',NULL,'0','0',NULL,'0','1199',NULL,'0','0',NULL,0,'2026-05-16 10:18:28','2026-05-16 10:18:28'),(210,'249',NULL,NULL,'CASH (SS)',5,'0','DR','GHATKOPAR','GOPAL GALI','','21','',NULL,'','',NULL,'27','','','IMPS',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43762','0.00',NULL,'0','0',NULL,'0','1080',NULL,'0','0',NULL,0,'2026-05-16 10:18:28','2026-05-16 10:18:28'),(211,'249',NULL,NULL,'CASH (LX)',5,'0','DR','NEAR HANSOTI  LANE','','','21','',NULL,'9930987337','',NULL,'27','','','JANKALAYAN',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4157',NULL,'0','0',NULL,0,'2026-05-16 10:18:28','2026-05-16 10:18:28'),(212,'249',NULL,NULL,'CASH (L.B)',5,'0','DR','GHATKOPAR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43772','0.00',NULL,'0','0',NULL,'0','1161',NULL,'0','0',NULL,0,'2026-05-16 10:18:28','2026-05-16 10:18:28'),(213,'249',NULL,NULL,'CASH (G.C)',5,'0','DR','NEAR F P','','','21','',NULL,'9930987337','',NULL,'27','','','COSMOS BANK',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1818',NULL,'0','0',NULL,0,'2026-05-16 10:18:28','2026-05-16 10:18:28'),(214,'249',NULL,NULL,'CASH (F.P)',5,'0','DR','NEAR ST','','','21','',NULL,'9930987337','',NULL,'27','','','DECCAN',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1815',NULL,'0','0',NULL,0,'2026-05-16 10:18:28','2026-05-16 10:18:28'),(215,'249',NULL,NULL,'CASH ( MAHA)',5,'0','DR','GHTK STN','','','21','',NULL,'9930987337','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1820',NULL,'0','0',NULL,0,'2026-05-16 10:18:29','2026-05-16 10:18:29'),(216,'249',NULL,NULL,'BRIJVASI SWEET',5,'0','DR','NE SHIVANI PHARMASI..9821952941','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44171','0.00',NULL,'0','0',NULL,'0','1606',NULL,'0','0',NULL,0,'2026-05-16 10:18:29','2026-05-16 10:18:29'),(217,'249',NULL,NULL,'BHATLA\'S KITCHEN',5,'0','DR','NEAR RAVI PETROL PUMP','PESTOM SAGAR RD NO4','MUMBAI','21','',NULL,'9324165360','',NULL,'27','27AJIPB4482A1ZL','','HDFC BANK',NULL,NULL,'CHEMBUR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44652','0.00',NULL,'0','0',NULL,'0','1226',NULL,'0','0',NULL,0,'2026-05-16 10:18:29','2026-05-16 10:18:29'),(218,'249',NULL,NULL,'BALRAM SHARMA PF 1',5,'0','DR','GHATKOPAR 8655782456','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','177',NULL,'0','0',NULL,0,'2026-05-16 10:18:29','2026-05-16 10:18:29'),(219,'249',NULL,NULL,'BAKULESH PHARMACY',5,'0','DR','4TH FLR, BAKUL PAREKH HOSP','','','21','',NULL,'8169901502','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44280','0.00',NULL,'0','0',NULL,'0','1762',NULL,'0','0',NULL,0,'2026-05-16 10:18:29','2026-05-16 10:18:29'),(220,'249',NULL,NULL,'AVARYA FINE FOODS',5,'0','DR','LBS MARG,NR SHREYAS CINEMA','GHATKOPAR WEST','mumbai','21','400086',NULL,'1111111111','',NULL,'27','27AAZFA1446R1ZK','','AXIS',NULL,NULL,'GHATKOPAR','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','681',NULL,'0','0',NULL,0,'2026-05-16 10:18:29','2026-05-16 10:18:29'),(221,'249',NULL,NULL,'ANJALI STORE',5,'0','DR','SHOP NO. 9 EGAL CO-OP SOCIETY','SUCHITA BUSINNES PARK','','21','',NULL,'9819987553','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6022',NULL,'0','0',NULL,0,'2026-05-16 10:18:29','2026-05-16 10:18:29'),(222,'249',NULL,NULL,'ANAPURNA DAIRY',5,'0','DR','VIDAYVIHAR STATION W','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43770','0.00',NULL,'0','0',NULL,'0','1156',NULL,'0','0',NULL,0,'2026-05-16 10:18:29','2026-05-16 10:18:29'),(223,'249',NULL,NULL,'ANAND JUICE CENTER',5,'0','DR','OPP CHANDAN STORE','','','21','',NULL,'','',NULL,'27','','','JANKALYAN',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43733','0.00',NULL,'0','0',NULL,'0','766',NULL,'0','0',NULL,0,'2026-05-16 10:18:29','2026-05-16 10:18:29'),(224,'249',NULL,NULL,'AMRUT GRAIN STORE',5,'0','DR','CHHEDA NAGAR','','mumbai','21','400077',NULL,'1111111111','',NULL,'27','27AABPG4583B1Z2','','INDIAN OVER',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44142','0.00',NULL,'0','0',NULL,'0','1533',NULL,'0','0',NULL,0,'2026-05-16 10:18:29','2026-05-16 10:18:29'),(225,'249',NULL,NULL,'AMBIKA MEDICAL',5,'0','DR','GARODIYA NAGER','OPP OM DEPERMENT','','21','',NULL,'3456677','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5386',NULL,'0','0',NULL,0,'2026-05-16 10:18:30','2026-05-16 10:18:30'),(226,'249',NULL,NULL,'AGARWAL JUICE',5,'0','DR','NR..CENTRAL STORES...9967161487','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44171','0.00',NULL,'0','0',NULL,'0','1607',NULL,'0','0',NULL,0,'2026-05-16 10:18:30','2026-05-16 10:18:30'),(227,'249',NULL,NULL,'ADINATH KIRANA',5,'0','DR','GOVN DEVI','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43729','0.00',NULL,'0','0',NULL,'0','759',NULL,'0','0',NULL,0,'2026-05-16 10:18:30','2026-05-16 10:18:30'),(228,'249',NULL,NULL,'AAREY Z 1855',5,'0','DR','OPP PARAS ST','','','21','400077',NULL,'9022779629','',NULL,'27','','','INDIAN',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44123','0.00',NULL,'0','0',NULL,'0','1512',NULL,'0','0',NULL,0,'2026-05-16 10:18:30','2026-05-16 10:18:30'),(229,'249',NULL,NULL,'AAREY SARITA 66',5,'0','DR','BATA SHOES','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','663',NULL,'0','0',NULL,0,'2026-05-16 10:18:30','2026-05-16 10:18:30'),(230,'249',NULL,NULL,'AAREY CENTRE 1833',5,'0','DR','BEHIND RAMESHWAR DUGDHALAYA','GHATKOPAR','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','299',NULL,'0','0',NULL,0,'2026-05-16 10:18:30','2026-05-16 10:18:30'),(231,'249',NULL,NULL,'AAREY CENTER 141',5,'0','DR','OPP BHARAT CAFFE','STATION ROAD','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43776','0.00',NULL,'0','0',NULL,'0','1173',NULL,'0','0',NULL,0,'2026-05-16 10:18:30','2026-05-16 10:18:30'),(232,'249',NULL,NULL,'AAREY 1595',5,'0','DR','NR JOLLY GYMKHANA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','684',NULL,'0','0',NULL,0,'2026-05-16 10:18:30','2026-05-16 10:18:30'),(233,'249',NULL,NULL,'AAREY 1519',5,'0','DR','NEAR JOLLY JIMKHANA','','','21','',NULL,'','',NULL,'27','','','SBI',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43714','0.00',NULL,'0','0',NULL,'0','726',NULL,'0','0',NULL,0,'2026-05-16 10:18:30','2026-05-16 10:18:30'),(234,'249',NULL,NULL,'AARAY  SARITA',5,'0','DR','NEAR 141','STATION ROAD','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43776','0.00',NULL,'0','0',NULL,'0','1174',NULL,'0','0',NULL,0,'2026-05-16 10:18:30','2026-05-16 10:18:30'),(235,'249',NULL,NULL,'AAGAM FOOD N MORE',5,'0','DR','NEAR LADHUBHAI','','','21','',NULL,'9821356124','',NULL,'27','','','HDFC',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44171','0.00',NULL,'0','0',NULL,'0','1608',NULL,'0','0',NULL,0,'2026-05-16 10:18:31','2026-05-16 10:18:31'),(236,'249',NULL,NULL,'A1 MEDICAL',5,'0','DR','NR FATIMA MILK CENTRE','KIROL VILLAGE','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44052','0.00',NULL,'0','0',NULL,'0','1433',NULL,'0','0',NULL,0,'2026-05-16 10:18:31','2026-05-16 10:18:31'),(237,'249',NULL,NULL,'A M SHINDE PF 2',5,'0','DR','GHATKOPAR 9819004041','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','195',NULL,'0','0',NULL,0,'2026-05-16 10:18:31','2026-05-16 10:18:31'),(238,'249',NULL,NULL,'S.S JOG',5,'0','DR','KANJURMARG 7977019143','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','176',NULL,'0','0',NULL,0,'2026-05-16 10:18:31','2026-05-16 10:18:31'),(239,'249',NULL,NULL,'MOON LIGHT STORE',5,'0','DR','DAMODAR PARK','GAVDEVI  NEXT TO NAGORI','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43742','0.00',NULL,'0','0',NULL,'0','973',NULL,'0','0',NULL,0,'2026-05-16 10:18:31','2026-05-16 10:18:31'),(240,'249',NULL,NULL,'CHANTULAL T.S MATUNGA',5,'33739','DR','MATUNGA STN','','','21','',NULL,'8652177248','',NULL,'27','','','IMPS',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','128',NULL,'0','0',NULL,0,'2026-05-16 10:18:31','2026-05-16 10:18:31'),(241,'249',NULL,NULL,'CHANTULAL KHOMCHA MATUNGA',5,'5435','CR','MATUNGA STN','','','21','',NULL,'8446355817','',NULL,'27','','','IMPS',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','129',NULL,'0','0',NULL,0,'2026-05-16 10:18:31','2026-05-16 10:18:31'),(242,'249',NULL,NULL,'A.H WHEELER (MATUNGA) PF 1/2',5,'34921','DR','PF 1/2','','','21','',NULL,'9111111111','',NULL,'27','','','IMPS',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44287','0.00',NULL,'0','0',NULL,'0','1768',NULL,'0','0',NULL,0,'2026-05-16 10:18:31','2026-05-16 10:18:31'),(243,'249',NULL,NULL,'A.H WHEELER & CO.',5,'9676','DR','PF 1/2 KALYAN SIDE','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44270','0.00',NULL,'0','0',NULL,'0','1745',NULL,'0','0',NULL,0,'2026-05-16 10:18:31','2026-05-16 10:18:31'),(244,'249',NULL,NULL,'TRIVENI PF 5',5,'0','DR','DADAR 8108059114','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','168',NULL,'0','0',NULL,0,'2026-05-16 10:18:31','2026-05-16 10:18:31'),(245,'249',NULL,NULL,'SANJAY JUICE PF 7/8',5,'0','DR','DADAR 7400105306','DEFAULT','mumbai','21','400014',NULL,'1111111111','',NULL,'27','27ACSPM6285F1Z0','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','174',NULL,'0','0',NULL,0,'2026-05-16 10:18:32','2026-05-16 10:18:32'),(246,'249',NULL,NULL,'RUKMANI PF 4',5,'0','DR','DADAR 9619337910','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','171',NULL,'0','0',NULL,0,'2026-05-16 10:18:32','2026-05-16 10:18:32'),(247,'249',NULL,NULL,'PRAKASH LALA PF5',5,'0','DR','DADAR 9619337910','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','169',NULL,'0','0',NULL,0,'2026-05-16 10:18:32','2026-05-16 10:18:32'),(248,'249',NULL,NULL,'PRADEEP PF 4',5,'0','DR','DADAR 7410003348','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','173',NULL,'0','0',NULL,0,'2026-05-16 10:18:32','2026-05-16 10:18:32'),(249,'249',NULL,NULL,'KHILONA PF 7/8',5,'0','DR','DADAR 7666060448','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','175',NULL,'0','0',NULL,0,'2026-05-16 10:18:32','2026-05-16 10:18:32'),(250,'249',NULL,NULL,'KASHYAP PF 4',5,'0','DR','DADAR 9324308387','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','172',NULL,'0','0',NULL,0,'2026-05-16 10:18:32','2026-05-16 10:18:32'),(251,'249',NULL,NULL,'CATERING VENDOR PF 5',5,'0','DR','DADAR 9619337910','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','170',NULL,'0','0',NULL,0,'2026-05-16 10:18:32','2026-05-16 10:18:32'),(252,'249',NULL,NULL,'vikram bhavan canteen',5,'0','DR','barc','','','21','',NULL,'9819081841','',NULL,'27','','','SBI',NULL,NULL,'ANUSHAKTI NAGAR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','285',NULL,'0','0',NULL,0,'2026-05-16 10:18:32','2026-05-16 10:18:32'),(253,'249',NULL,NULL,'siraj hair beauty saloon',5,'0','DR','ws','','','21','',NULL,'1234567890','',NULL,'27','','','YES',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4560',NULL,'0','0',NULL,0,'2026-05-16 10:18:32','2026-05-16 10:18:32'),(254,'249',NULL,NULL,'shree gaurishankar saraf',5,'0','DR','hivam north south road number 2.landmark mithibai clg','juhu','','21','',NULL,'1111111111','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6490',NULL,'0','0',NULL,0,'2026-05-16 10:18:32','2026-05-16 10:18:32'),(255,'249',NULL,NULL,'ramesh traders',5,'0','DR','Chembur','chembur','','21','',NULL,'9323182353','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6175',NULL,'0','0',NULL,0,'2026-05-16 10:18:33','2026-05-16 10:18:33'),(256,'249',NULL,NULL,'mumbai natural kulfee',5,'0','DR','Petroaem Pum','deonar','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','270',NULL,'0','0',NULL,0,'2026-05-16 10:18:33','2026-05-16 10:18:33'),(257,'249',NULL,NULL,'mahalaxmi annapurn kandra',5,'0','DR','deonar','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','271',NULL,'0','0',NULL,0,'2026-05-16 10:18:33','2026-05-16 10:18:33'),(258,'249',NULL,NULL,'lea cafe',5,'0','DR','opp bmc office nr natraj cinema','chembur','Mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AAEFK0595L1ZZ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','258',NULL,'0','0',NULL,0,'2026-05-16 10:18:33','2026-05-16 10:18:33'),(259,'249',NULL,NULL,'kappree',5,'0','DR','meghraj appartment shop no 1','YOGESWARY EAST','','21','',NULL,'9004171369','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4766',NULL,'0','0',NULL,0,'2026-05-16 10:18:33','2026-05-16 10:18:33'),(260,'249',NULL,NULL,'ZOMATO',5,'0','DR','ZOMATO','','','21','',NULL,'','',NULL,'27','','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44024','0.00',NULL,'0','0',NULL,'0','1415',NULL,'0','0',NULL,0,'2026-05-16 10:18:33','2026-05-16 10:18:33'),(261,'249',NULL,NULL,'YUKTI ENTERPRISE',5,'0','DR','PARAS GOPAL INDUSTRIES,OPP','BHUMI PLAZA,DADAR WEST','mumbai','21','400027',NULL,'1111111111','',NULL,'27','27FCIPK6936A1ZJ','','RTGS',NULL,NULL,'MUMBAI','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','286',NULL,'0','0',NULL,0,'2026-05-16 10:18:33','2026-05-16 10:18:33'),(262,'249',NULL,NULL,'YOGI HOTEL',5,'0','DR','ST ROAD','CHEMBUR','Mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AAAFY3119J1Z3','','IDBI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','126',NULL,'0','0',NULL,0,'2026-05-16 10:18:33','2026-05-16 10:18:33'),(263,'249',NULL,NULL,'YASH MARKETING',11,'16813798.4','DR','PESTOM SAGAR ROAD 3','','','21','400089',NULL,'8369206130','',NULL,'27','27ADZPD8058M1ZM','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4908',NULL,'0','0',NULL,0,'2026-05-16 10:18:33','2026-05-16 10:18:33'),(264,'249',NULL,NULL,'YASH MARKETING',5,'9403391','CR','1/7,RAVI, KAJUPADA PIPELINE,KURLA','MUMBAI','MUMBAI','21','400072',NULL,'9820229967','',NULL,'27','27ADZPD8058M1ZM','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4854',NULL,'0','0',NULL,0,'2026-05-16 10:18:34','2026-05-16 10:18:34'),(265,'249',NULL,NULL,'YAKUB',5,'0','DR','MUMBAI','','','21','',NULL,'21111111111','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6582',NULL,'0','0',NULL,0,'2026-05-16 10:18:34','2026-05-16 10:18:34'),(266,'249',NULL,NULL,'WONDER CATERING',5,'0','DR','SHOP NO 2/3A,EKTA CHS LTD','KARVE RD,KANJURMARG EAST','MUMBAI','21','400042',NULL,'','',NULL,'27','27AGYPV0791M1Z7','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','273',NULL,'0','0',NULL,0,'2026-05-16 10:18:34','2026-05-16 10:18:34'),(267,'249',NULL,NULL,'Vallabh Marketing',5,'325001','DR','Jankalyan Bhavan,Maurya Compd,Gaondevi','Rd,Bhandup West','Mumbai','21','400078',NULL,'9322914526','',NULL,'27','27AEXPJ1215M1Z3','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6569',NULL,'0','0',NULL,0,'2026-05-16 10:18:34','2026-05-16 10:18:34'),(268,'249',NULL,NULL,'VRD RETAIL PVT LTD',5,'0','DR','SHOP NO 5A, VIKRANT CIRCLE','GHATKOPAR EAST','MUMBAI','21','400077',NULL,'1111111111','',NULL,'27','27AAACI1566J1ZI','','IDBI BANK',NULL,NULL,'MUMBAI','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','520',NULL,'0','0',NULL,0,'2026-05-16 10:18:34','2026-05-16 10:18:34'),(269,'249',NULL,NULL,'VJAY LUNCH HOME',5,'0','DR','N.R OCTROL CHEEK NAKA MANKURD','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','163',NULL,'0','0',NULL,0,'2026-05-16 10:18:34','2026-05-16 10:18:34'),(270,'249',NULL,NULL,'VISION STUDIO INDIA LLP',5,'0','DR','BORIVALI','','mumbai','21','400092',NULL,'1111111111','',NULL,'27','27AAMFV1043N1ZR','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43749','0.00',NULL,'0','0',NULL,'0','1007',NULL,'0','0',NULL,0,'2026-05-16 10:18:34','2026-05-16 10:18:34'),(271,'249',NULL,NULL,'VIPUL BHATIA',5,'0','DR','GHATKOPAR','','','21','',NULL,'','',NULL,'27','','','DECCAN MERCHANT',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1674',NULL,'0','0',NULL,0,'2026-05-16 10:18:34','2026-05-16 10:18:34'),(272,'249',NULL,NULL,'VINOD STORE',5,'0','DR','W/S','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','155',NULL,'0','0',NULL,0,'2026-05-16 10:18:34','2026-05-16 10:18:34'),(273,'249',NULL,NULL,'VIKAS GUPTA',5,'0','DR','MUKTI NAGAR','CHEMBUR','','21','',NULL,'','',NULL,'27','','','GPAY',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43992','0.00',NULL,'0','0',NULL,'0','1377',NULL,'0','0',NULL,0,'2026-05-16 10:18:34','2026-05-16 10:18:34'),(274,'249',NULL,NULL,'VIHAR HOSPITALITY',5,'0','DR','A/10,INDIRA NGR,BANDRA EAST','DEFAULT','Mumbai','21','400051',NULL,'1111111111','',NULL,'27','27AANFV8459K1Z6','','VIJAYA',NULL,NULL,'WADALA','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','231',NULL,'0','0',NULL,0,'2026-05-16 10:18:35','2026-05-16 10:18:35'),(275,'249',NULL,NULL,'VIHANA ENTERPRISES',5,'0','DR','BASEMENT 3B MITAL TOWER','NARIMAN POINT','MUMBAI','21','400021',NULL,'9167915181','',NULL,'27','27AMLPG0446K1ZY','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4836',NULL,'0','0',NULL,0,'2026-05-16 10:18:35','2026-05-16 10:18:35'),(276,'249',NULL,NULL,'VIDYA CATERERS',5,'0','DR','WS','WS','','21','',NULL,'983335425','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','592',NULL,'0','0',NULL,0,'2026-05-16 10:18:35','2026-05-16 10:18:35'),(277,'249',NULL,NULL,'VIBHA HOSPITALITY SERVICE',5,'0','DR','SOMAIYA HOSPITAL','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','227',NULL,'0','0',NULL,0,'2026-05-16 10:18:35','2026-05-16 10:18:35'),(278,'249',NULL,NULL,'VERIEFY BOOK CENTRE',11,'0','DR','A/16 SHOPPING CENTER','RLY STATION GHATKOPER W','','21','',NULL,'8108756674','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4473',NULL,'0','0',NULL,0,'2026-05-16 10:18:35','2026-05-16 10:18:35'),(279,'249',NULL,NULL,'VEER FOUNDATION',5,'0','DR','GHATKOPAR','KUKREJA TOWER','MUMBAI','21','',NULL,'9820042336','',NULL,'27','','','IDBI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4260',NULL,'0','0',NULL,0,'2026-05-16 10:18:35','2026-05-16 10:18:35'),(280,'249',NULL,NULL,'VEER',5,'0','DR','CHEMBUR','','','21','',NULL,'9324711302','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1821',NULL,'0','0',NULL,0,'2026-05-16 10:18:35','2026-05-16 10:18:35'),(281,'249',NULL,NULL,'VALYOU SUPER MART',5,'0','DR','SHOP NO 10,TRISHUL GOLD COAST','PLOT NO 13,SECTOR 9,GHANSOLI','NAVI MUMBAI','21','400701',NULL,'','',NULL,'27','27AYSPP5731D1Z3','','PMC',NULL,NULL,'GKTPR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43728','0.00',NULL,'0','0',NULL,'0','758',NULL,'0','0',NULL,0,'2026-05-16 10:18:35','2026-05-16 10:18:35'),(282,'249',NULL,NULL,'UNIQUE FRAGRANCES',5,'0','DR','Plot No-D-9/8, TTC Industrial Area','MIDC, Turbhe','Navi Mumbai','21','400705',NULL,'6584932432','',NULL,'27','27AAAFU1982B1ZD','','NEFT',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43998','0.00',NULL,'0','0',NULL,'0','1379',NULL,'0','0',NULL,0,'2026-05-16 10:18:35','2026-05-16 10:18:35'),(283,'249',NULL,NULL,'UNIQUE ENTERPRISES',5,'0','DR','LTT TERMINUS','DEFAULT','Mumbai','21','400070',NULL,'1111111111','',NULL,'27','27EDRPK0896I1ZN','','AXIS BANK',NULL,NULL,'BHUSAWAL','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','156',NULL,'0','0',NULL,0,'2026-05-16 10:18:35','2026-05-16 10:18:35'),(284,'249',NULL,NULL,'TRISTAR MANAGEMENT SERVICES PVT LTD',5,'0','DR','UNIT NO. 812 , 8TH FLOOR , GHANSHYAM ENCLAVE , GANDHI NAGAR','LONK ROAD , KANDIWALI WEST','MUMBAI','21','400067',NULL,'1236549870','',NULL,'27','27AADCT2068D1ZI','','YES BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','AADCT2068D','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6510',NULL,'0','0',NULL,0,'2026-05-16 10:18:36','2026-05-16 10:18:36'),(285,'249',NULL,NULL,'TRACE VFX SOLUTIONS PVT LTD',5,'0','DR','UJAGAR SILK MILLS,OPP DEONAR DEPO','MUMBAI 88','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','139',NULL,'0','0',NULL,0,'2026-05-16 10:18:36','2026-05-16 10:18:36'),(286,'249',NULL,NULL,'THEOBROMA FOOD PVT LTD',5,'0','DR','32/33,A DEONAR VILLAGE RD','OPP METAL BOX, GOVANDI (EAST)','Mumbai','21','400088',NULL,'8572684544','',NULL,'27','27AACCT0588K1ZZ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4385',NULL,'0','0',NULL,0,'2026-05-16 10:18:36','2026-05-16 10:18:36'),(287,'249',NULL,NULL,'THE CORPORATE HOUSEKEEPING SOLUTION',5,'0','DR','GROUND FLOOR,C 19','KAILASH ENCLAVE,LBS RD, GHATKOPAR WEST','MUMBAI','21','400086',NULL,'1111111111','',NULL,'27','27FWTPS5910P1ZC','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44073','0.00',NULL,'0','0',NULL,'0','1449',NULL,'0','0',NULL,0,'2026-05-16 10:18:36','2026-05-16 10:18:36'),(288,'249',NULL,NULL,'THE CENTRAL RAILWAY CO.OP.SOCIETY LTD',5,'0','DR','665A,N.M.JOSHI MARG,BYCULLA, MUMBAI','','','21','',NULL,'7039476898','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6318',NULL,'0','0',NULL,0,'2026-05-16 10:18:36','2026-05-16 10:18:36'),(289,'249',NULL,NULL,'THAI TRADE CENTER MUMBAI',5,'0','DR','EXPRESS TOWERS 3RD FLOOR','NARIMAN POINT','MUMBAI','21','400021',NULL,'9819591012','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1772',NULL,'0','0',NULL,0,'2026-05-16 10:18:36','2026-05-16 10:18:36'),(290,'249',NULL,NULL,'TERRARAY SUPPLIES LLP',5,'0','DR','CHINUBHAI HOUSE , AMRUTBAUG COLONY, SARDAR','PATEL STADIUM RD,NR HINDU COLONY,NAVRANGPURA','AHMEDABAD','Gujarat','380014',NULL,'9619997841','',NULL,'0','24AAWFT3271A1Z6','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6581',NULL,'0','0',NULL,0,'2026-05-16 10:18:36','2026-05-16 10:18:36'),(291,'249',NULL,NULL,'TECHWORKS PVT LTD',5,'0','DR','SAKINAKA','DEFAULT','Mumbai','21','400072',NULL,'1111111111','',NULL,'27','27ACKPB4758J1ZC','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','146',NULL,'0','0',NULL,0,'2026-05-16 10:18:36','2026-05-16 10:18:36'),(292,'249',NULL,NULL,'TARKESHWAR SANDWICH',5,'0','DR','REF VISHALBHAI','','','21','',NULL,'','',NULL,'27','','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44113','0.00',NULL,'0','0',NULL,'0','1490',NULL,'0','0',NULL,0,'2026-05-16 10:18:36','2026-05-16 10:18:36'),(293,'249',NULL,NULL,'TANOOR CATERERS',5,'0','DR','JAMNALAL INST','CHURCHGATE','','21','',NULL,'8652542680','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5790',NULL,'0','0',NULL,0,'2026-05-16 10:18:36','2026-05-16 10:18:36'),(294,'249',NULL,NULL,'TAJ WELLINGTON MEWS',5,'12863','DR','PLOT NO 33,TAJ WELLINGTON MEWS,NATHALAL PARIKH MARG,','COLABA','MUMBAI','21','400001',NULL,'1111111111','',NULL,'27','27AAACT3957G6Z2','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4933',NULL,'0','0',NULL,0,'2026-05-16 10:18:37','2026-05-16 10:18:37'),(295,'249',NULL,NULL,'Sunita Agency',5,'0','DR','ws','','','21','',NULL,'1234567890','',NULL,'27','','','DMK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4702',NULL,'0','0',NULL,0,'2026-05-16 10:18:37','2026-05-16 10:18:37'),(296,'249',NULL,NULL,'Siddhivinayak Impex',5,'0','DR','Grd Flr,Shop No 4,46/48,Hira Niwas','Modi Street, Fort','Mumbai','21','400001',NULL,'9404215553','',NULL,'27','27AMGPP7368C1ZS','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5989',NULL,'0','0',NULL,0,'2026-05-16 10:18:37','2026-05-16 10:18:37'),(297,'249',NULL,NULL,'Shri Venkateshwara Traders',5,'0','DR','Nr S.B.I,Grd Flr,Sr No 211,E3','Shree Ram Colony,Bhosari,Pimpri','Pune','21','411039',NULL,'9860606013','',NULL,'27','27AEWFS0037F1ZT','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5979',NULL,'0','0',NULL,0,'2026-05-16 10:18:37','2026-05-16 10:18:37'),(298,'249',NULL,NULL,'Sheetal Agencies',5,'425431','DR','Flr No C1,Sneh Bldg,Thokle Marg,Ambedkar Ngr','Worli','Mumbai','21','400018',NULL,'9687796510','',NULL,'27','27ASSPM7996B1ZZ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6501',NULL,'0','0',NULL,0,'2026-05-16 10:18:37','2026-05-16 10:18:37'),(299,'249',NULL,NULL,'Sachin Challak',5,'0','DR','Ws','','','21','',NULL,'1234567890','',NULL,'27','','','CANARA BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4697',NULL,'0','0',NULL,0,'2026-05-16 10:18:37','2026-05-16 10:18:37'),(300,'249',NULL,NULL,'SWARA ENTERPRISE',5,'0','DR','FLAT NO 14, SHRI GANESH RESIDENCY','LINGAYAT COLONY, DEOLALI GAON','NASHIK','21','422101',NULL,'1111111111','',NULL,'27','27AAWPD5819L1Z2','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6406',NULL,'0','0',NULL,0,'2026-05-16 10:18:37','2026-05-16 10:18:37'),(301,'249',NULL,NULL,'SWAMI VIVEKANAND PRIMARY SCHOOL',5,'0','DR','DEFAULT','DEFAULT','','21','',NULL,'','',NULL,'27','27AAATV2239C1ZP','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','149',NULL,'0','0',NULL,0,'2026-05-16 10:18:37','2026-05-16 10:18:37'),(302,'249',NULL,NULL,'SWAMI VIVEKANAND (PHARMA)',5,'0','DR','VIVEKANAND COLLEGE PHARMACY','','','21','',NULL,'9773566197','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','264',NULL,'0','0',NULL,0,'2026-05-16 10:18:37','2026-05-16 10:18:37'),(303,'249',NULL,NULL,'SUNSHINE CATERERS PRIVATE LIMITED',5,'0','DR','501,SAFALYA BLDG, NR JAI GOPAL INDUSTRIES','DADAR WEST','MUMBAI `','21','400028',NULL,'1111111111','',NULL,'27','27AAECR2970D1ZG','','RTGS',NULL,NULL,'MUMBAI','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','247',NULL,'0','0',NULL,0,'2026-05-16 10:18:37','2026-05-16 10:18:37'),(304,'249',NULL,NULL,'SUNRISE HOSPITALITY',5,'0','DR','CASTALIA SHOPPING,HIRANANDANI ESTAT','E,THANE MUMBAI 400607','mumbai','21','400607',NULL,'1111111111','',NULL,'27','27ADKFS6201Q1Z1','','AXIS BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','181',NULL,'0','0',NULL,0,'2026-05-16 10:18:38','2026-05-16 10:18:38'),(305,'249',NULL,NULL,'SUNLIGHT ENTERPRISES',5,'0','DR','OPP MULTAN GARAGE, 2ND FLOOR, A-201,','HARMONY COMPLEX , KHARDI ROAD, MUMBRA','THANE','21','400612',NULL,'2134563125','',NULL,'27','27AEQFS1657D1ZR','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6488',NULL,'0','0',NULL,0,'2026-05-16 10:18:38','2026-05-16 10:18:38'),(306,'249',NULL,NULL,'SUNDAR VILAS',5,'0','DR','90 FEET ROAD, KUMBARWADA','DHARAVI','','21','',NULL,'24092667','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4692',NULL,'0','0',NULL,0,'2026-05-16 10:18:38','2026-05-16 10:18:38'),(307,'249',NULL,NULL,'SUNANDA TRADING',5,'704965','DR','HOUSE NO. 1773 , KARALE BLDG','TALUKA AKOLE , AHILYA NAGAR','AKOLE','21','422601',NULL,'9820788144','',NULL,'27','27BKHPS7927Q1Z1','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','147',NULL,'0','0',NULL,0,'2026-05-16 10:18:38','2026-05-16 10:18:38'),(308,'249',NULL,NULL,'SUMITRA SANSTHA',5,'0','DR','CHUNABHATTI','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','162',NULL,'0','0',NULL,0,'2026-05-16 10:18:38','2026-05-16 10:18:38'),(309,'249',NULL,NULL,'SUJYOTI FOODS LLP',5,'0','DR','OPP Airtel Gallery,tilak Road','Ghatkopar','Mumbai','21','400077',NULL,'2250156002','',NULL,'27','27ACSFS6752K1Z8','','IMPS',NULL,NULL,'GHTKOPR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','239',NULL,'0','0',NULL,0,'2026-05-16 10:18:38','2026-05-16 10:18:38'),(310,'249',NULL,NULL,'STAR CATERERS',5,'13422','DR','DEFAULT','DEFAULT','','21','',NULL,'','',NULL,'27','','','KOTAK MAHINDRA',NULL,NULL,'GHATKOPAR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','159',NULL,'0','0',NULL,0,'2026-05-16 10:18:38','2026-05-16 10:18:38'),(311,'249',NULL,NULL,'SPORTSMED MUMBAI PVT LTD',5,'0','DR','2ND FLR,PAREL PREMISES,OPP MOTILAL','OSWAL BLDG,PRABHADEVI','MUMBAI','21','400008',NULL,'9664442708','',NULL,'27','27AAFFF3587N1ZT','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4706',NULL,'0','0',NULL,0,'2026-05-16 10:18:38','2026-05-16 10:18:38'),(312,'249',NULL,NULL,'SONIA MARKETING',5,'0','DR','NIRMALA APARTMENT SHOP 6','KHEMANI OPP YATRI NIWAS','ULHAS NAGAR','21','421002',NULL,'1111111111','',NULL,'27','27AFLPB7141P1Z2','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43857','0.00',NULL,'0','0',NULL,'0','1281',NULL,'0','0',NULL,0,'2026-05-16 10:18:38','2026-05-16 10:18:38'),(313,'249',NULL,NULL,'SOMAIYA HOSPITAL',5,'0','DR','CHUNABHATTI','9619619036','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','140',NULL,'0','0',NULL,0,'2026-05-16 10:18:38','2026-05-16 10:18:38'),(314,'249',NULL,NULL,'SOLANKI DINESH NARAYAN',5,'0','DR','MUMBAI','','','21','',NULL,'','',NULL,'27','','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1368',NULL,'0','0',NULL,0,'2026-05-16 10:18:39','2026-05-16 10:18:39'),(315,'249',NULL,NULL,'SOCIETY GRAIN STORE',5,'0','DR','BARC','DEFAULT','','21','',NULL,'','',NULL,'27','27AACPD7377HN1ZM','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','141',NULL,'0','0',NULL,0,'2026-05-16 10:18:39','2026-05-16 10:18:39'),(316,'249',NULL,NULL,'SNOWONS ENTERPRISES',5,'0','DR','57/527,MATA RAMABAI NGR','GHATKOPAR EAST','MUMBAI','21','400075',NULL,'7045571250','',NULL,'27','27CEPPK2072B2ZL','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1831',NULL,'0','0',NULL,0,'2026-05-16 10:18:39','2026-05-16 10:18:39'),(317,'249',NULL,NULL,'SITABEN SHAH MEMORIAL TRUST',5,'0','DR','FORT','','','21','',NULL,'9920157127','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','3588',NULL,'0','0',NULL,0,'2026-05-16 10:18:39','2026-05-16 10:18:39'),(318,'249',NULL,NULL,'SIDHAKALLA VISWASTH MANDAL',5,'0','DR','GHATKOPER EAST','','','21','',NULL,'9833427296','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4664',NULL,'0','0',NULL,0,'2026-05-16 10:18:39','2026-05-16 10:18:39'),(319,'249',NULL,NULL,'SIDDHI ASSOCIATE',5,'0','DR','SR NO 192/FALT NO 4,SHRI HARI','CORNER,PUNE','PUNE','21','411009',NULL,'1111111111','',NULL,'27','27ABQPL9037K1ZY','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43795','0.00',NULL,'0','0',NULL,'0','1195',NULL,'0','0',NULL,0,'2026-05-16 10:18:39','2026-05-16 10:18:39'),(320,'249',NULL,NULL,'SIDDHESHWAR KIRANA',5,'0','DR','@123','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1717',NULL,'0','0',NULL,0,'2026-05-16 10:18:39','2026-05-16 10:18:39'),(321,'249',NULL,NULL,'SHWETA WHOLESALE PRIVATE LIMITED',11,'0','CR','21/31 , GODOWN-1 , NEAR PALAM GREEN HOUSE ,','AABADI OF VILLAGE BAKOLI NORTH DELHI','DELHI','Delhi','110039',NULL,'1234567890','',NULL,'0','07ABHCS2087G1Z6','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6579',NULL,'0','0',NULL,0,'2026-05-16 10:18:39','2026-05-16 10:18:39'),(322,'249',NULL,NULL,'SHUBHANGI CAATERING SERVICES',5,'0','DR','3/18,SADGURU KRIPA BLDG','S.B MARG,MATUNGA WEST','MUMBAI','21','400016',NULL,'1111111111','',NULL,'27','27AEQPG1997L1ZQ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','254',NULL,'0','0',NULL,0,'2026-05-16 10:18:39','2026-05-16 10:18:39'),(323,'249',NULL,NULL,'SHUBHAM ENTERPRISES',5,'0','DR','SHOP NO 33,K/4 BAIGAN WADI','GOVANDI','MUMBAI','21','400043',NULL,'9167633697','',NULL,'27','27ACHPK7432K1ZB','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1799',NULL,'0','0',NULL,0,'2026-05-16 10:18:39','2026-05-16 10:18:39'),(324,'249',NULL,NULL,'SHUBHAM CATERING',5,'0','DR','SOMAIYA HOSPITAL','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','226',NULL,'0','0',NULL,0,'2026-05-16 10:18:40','2026-05-16 10:18:40'),(325,'249',NULL,NULL,'SHUBH STATIONERY & XEROX',5,'0','DR','GROUND FLR, GALA NO D/3,PL26,SIDDHAKALA CHS LTD,','SAVARKAR NAGAR,JAKEGRAM THANE,THANE','MUMBAI','21','400601',NULL,'22-2587722','',NULL,'27','27AJTPV6527B1ZQ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4822',NULL,'0','0',NULL,0,'2026-05-16 10:18:40','2026-05-16 10:18:40'),(326,'249',NULL,NULL,'SHRIJI  ENTERPRISES',11,'781.62','DR','WS','','','21','',NULL,'123456789','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4950',NULL,'0','0',NULL,0,'2026-05-16 10:18:40','2026-05-16 10:18:40'),(327,'249',NULL,NULL,'SHRIDEVI CATERERS',5,'58477','CR','SECTOR-6 ROOM NO 505 MINIR TOWER AIROLI','THANE','MUMBAI','21','400708',NULL,'9820588456','',NULL,'27','27AGVPS5882P1ZX','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6351',NULL,'0','0',NULL,0,'2026-05-16 10:18:40','2026-05-16 10:18:40'),(328,'249',NULL,NULL,'SHRIDEVI CATERERS',5,'260480','DR','258,1ST FLR,SECTOR 5,MAHAVIR SANGAM','CHS,GHANSOLI,NAVI MUMBAI','NAVI MUMBAI','21','400701',NULL,'9820588456','',NULL,'27','27AGVPS5882P1ZX','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5449',NULL,'0','0',NULL,0,'2026-05-16 10:18:40','2026-05-16 10:18:40'),(329,'249',NULL,NULL,'SHRI VARDHMAN STHA JAIN SANGH',5,'1845','DR','148/151 GARODIA NAGAR 1 ST FLOOR KASHMIRA KUNJ','HSG SOCIETY OPP BANK OF RAJSTHAN GHTKOPAR (E)','','21','',NULL,'9699170888','',NULL,'27','','','IOB',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5679',NULL,'0','0',NULL,0,'2026-05-16 10:18:40','2026-05-16 10:18:40'),(330,'249',NULL,NULL,'SHRI RAM ENTERPRISES',11,'0','DR','18/20 IMRANI CHAWL NEAR MUNCIPAL SWDESHI MILL ROAD SION','','','21','',NULL,'7710034885','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5574',NULL,'0','0',NULL,0,'2026-05-16 10:18:40','2026-05-16 10:18:40'),(331,'249',NULL,NULL,'SHRI RAM ENTERPRISE',5,'0','DR','18/20 IMRANI CHAWL NEAR MUNCIPAL SWDESHI MILL ROAD SION','','','21','',NULL,'7710034885','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6402',NULL,'0','0',NULL,0,'2026-05-16 10:18:40','2026-05-16 10:18:40'),(332,'249',NULL,NULL,'SHRI MAMAL MATAJI BHAVIK TRUST',5,'0','DR','Aram Building Gokhle Rd. North','Dadar West','Mumbai','21','400028',NULL,'9820756010','',NULL,'27','','','BOB',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6534',NULL,'0','0',NULL,0,'2026-05-16 10:18:40','2026-05-16 10:18:40'),(333,'249',NULL,NULL,'SHRI JAGADGURU VALLABHACHARYJI JANKALYAN TRUS',5,'0','DR','GHATKOPAR','','','21','',NULL,'','',NULL,'27','','','IDBI',NULL,NULL,'GHATKOPAR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43825','0.00',NULL,'0','0',NULL,'0','1245',NULL,'0','0',NULL,0,'2026-05-16 10:18:40','2026-05-16 10:18:40'),(334,'249',NULL,NULL,'SHREYNSHI ENTERPRISES',5,'0','DR','NEW MANIKLAL','','','21','',NULL,'','',NULL,'27','27ADTFS5699F1Z4','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44272','0.00',NULL,'0','0',NULL,'0','1747',NULL,'0','0',NULL,0,'2026-05-16 10:18:41','2026-05-16 10:18:41'),(335,'249',NULL,NULL,'SHREEJI TRADERS',5,'0','DR','HOUSE NO 532 ABOVE PRITI NOVELTY','GODUNDAR ROAD PATLI PADA,THANE','mumbai','21','400601',NULL,'9621548352','',NULL,'27','27AVMPP9761C1Z3','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4427',NULL,'0','0',NULL,0,'2026-05-16 10:18:41','2026-05-16 10:18:41'),(336,'249',NULL,NULL,'SHREEJI FOODS NX',5,'0','DR','MUMBAI','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43938','0.00',NULL,'0','0',NULL,'0','1343',NULL,'0','0',NULL,0,'2026-05-16 10:18:41','2026-05-16 10:18:41'),(337,'249',NULL,NULL,'SHREEJI ENTERPRISES',5,'90401','DR','SHOP NOA1 ,1ST FLR KONDIVITA','ANDHERI EAST','MUMBAI','21','400069',NULL,'9892684848','',NULL,'27','27ARBPP2139H1ZU','','GP PARSIK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6401',NULL,'0','0',NULL,0,'2026-05-16 10:18:41','2026-05-16 10:18:41'),(338,'249',NULL,NULL,'SHREE MAHAVEER CORPORATION',11,'0','DR','05 MILAN INDUSTRIAL ESTATE GRD FLOOR','OPP ABUDAYA NAGAR CO OP SOCIETY','','21','',NULL,'9664321829','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6516',NULL,'0','0',NULL,0,'2026-05-16 10:18:41','2026-05-16 10:18:41'),(339,'249',NULL,NULL,'SHREE ENTERPRISES',5,'0','DR','6,PRATHMESH CHS,RETI BANDER RD','MOTHAGAON','','21','421202',NULL,'1111111111','',NULL,'27','27CIZPK2623J1ZP','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','164',NULL,'0','0',NULL,0,'2026-05-16 10:18:41','2026-05-16 10:18:41'),(340,'249',NULL,NULL,'SHOURYA ENTERPRISES',5,'0','DR','KALYANJI COMPOUND R.C MARG NEAR BANK OF INDIA','CHEMBUR','MUMBAI','21','400089',NULL,'9321225246','',NULL,'27','27BCHPS2430N1Z8','','MUMBAI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5643',NULL,'0','0',NULL,0,'2026-05-16 10:18:41','2026-05-16 10:18:41'),(341,'249',NULL,NULL,'SHIVRAJ',5,'0','DR','R ODEON MALL','GHATKOPAR EAST','','21','',NULL,'','',NULL,'27','','','ICICI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43811','0.00',NULL,'0','0',NULL,'0','1218',NULL,'0','0',NULL,0,'2026-05-16 10:18:41','2026-05-16 10:18:41'),(342,'249',NULL,NULL,'SHIVAM DRY SNACKS',5,'0','DR','PL ROAD OPP PRASHANT','','','21','',NULL,'','',NULL,'27','27BBMPP9721M1ZU','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','257',NULL,'0','0',NULL,0,'2026-05-16 10:18:41','2026-05-16 10:18:41'),(343,'249',NULL,NULL,'SHIVAM DRY SNACKS',5,'0','DR','PL RD,CHEMBUR','DEFAULT','Mumbai','21','400071',NULL,'1111111111','',NULL,'27','27BBMPP9721M1ZU','','KNS BANK',NULL,NULL,'GOVANDI','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','152',NULL,'0','0',NULL,0,'2026-05-16 10:18:41','2026-05-16 10:18:41'),(344,'249',NULL,NULL,'SHIVAM DAIRY FOODS',5,'0','DR','VIKROLI','','','21','',NULL,'','',NULL,'27','','','AXIS BANK',NULL,NULL,'POWAI','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43797','0.00',NULL,'0','0',NULL,'0','1196',NULL,'0','0',NULL,0,'2026-05-16 10:18:42','2026-05-16 10:18:42'),(345,'249',NULL,NULL,'SHEETAL ENTERPRISES',11,'0','DR','KAJU PADA','','','21','',NULL,'1111111111','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43911','0.00',NULL,'0','0',NULL,'0','1317',NULL,'0','0',NULL,0,'2026-05-16 10:18:42','2026-05-16 10:18:42'),(346,'249',NULL,NULL,'SHEETAL ENTERPRISES',5,'100007','DR','Gala No 17,Wadia Compd,Zakaria Bunder Rd','Cotton Green','MUMBAI','21','400033',NULL,'9030295999','',NULL,'27','27ANZPM5399Q2ZD','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4962',NULL,'0','0',NULL,0,'2026-05-16 10:18:42','2026-05-16 10:18:42'),(347,'249',NULL,NULL,'SHALOM MEGA STORES',5,'0','DR','SHOP NO 16&17, PARAS NIKETAN','CHHEDANAGAR, CHEMBUR (W)','mumbai','21','400089',NULL,'9322294040','',NULL,'27','27BSEPA6242D1Z7','','TMB BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4608',NULL,'0','0',NULL,0,'2026-05-16 10:18:42','2026-05-16 10:18:42'),(348,'249',NULL,NULL,'SHAFIULLAH ENTERPRISES',5,'0','DR','DEFAULT','DEFAULT','','21','',NULL,'','',NULL,'27','','','PUNJAB NATIONAL',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','225',NULL,'0','0',NULL,0,'2026-05-16 10:18:42','2026-05-16 10:18:42'),(349,'249',NULL,NULL,'SELMAX EXPORTS PVT LTD',5,'0','DR','PLOT NO D10/5,T.T.C MIDC AREA','REKUNDA GAON,TURBHE NAVI MUMBAI','NAVI MUMBAI','21','400705',NULL,'9820655796','',NULL,'27','27AAFCS1760B1ZO','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4918',NULL,'0','0',NULL,0,'2026-05-16 10:18:42','2026-05-16 10:18:42'),(350,'249',NULL,NULL,'SEARO PVT LTD',5,'0','DR','CHAWL NO 337,R NO 4077','TAGORE NGR GRP NO 3, OPP BUS STOP','VIKHROLI EAST','21','400083',NULL,'9967400343','',NULL,'27','27AAZCS8608Q1Z0','','INDUSIND',NULL,NULL,'GKPR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','291',NULL,'0','0',NULL,0,'2026-05-16 10:18:42','2026-05-16 10:18:42'),(351,'249',NULL,NULL,'SAY CHEF EATERY PVT LTD',5,'0','DR','UNIT NO 5, SHAH INDL ESTATE','GOVANDI  EAST','MUMBAI','21','400088',NULL,'9920849142','',NULL,'27','27AAWCS7220B1Z8','','YES BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43876','0.00',NULL,'0','0',NULL,'0','1291',NULL,'0','0',NULL,0,'2026-05-16 10:18:42','2026-05-16 10:18:42'),(352,'249',NULL,NULL,'SANT NIRANKARI MANDAL',5,'6211','CR','CHEMBUR','DEFAULT','','21','',NULL,'','',NULL,'27','','','ICICI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','211',NULL,'0','0',NULL,0,'2026-05-16 10:18:42','2026-05-16 10:18:42'),(353,'249',NULL,NULL,'SANKALAP MAHILA MANDAL',5,'0','DR','SAI KRUPA SOCIETY BLD NO 6 A','VASHI NAKA MAHADA COLONY','mumbai','21','400074',NULL,'8655572558','',NULL,'27','27AADAS4440C1ZT','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4182',NULL,'0','0',NULL,0,'2026-05-16 10:18:42','2026-05-16 10:18:42'),(354,'249',NULL,NULL,'SANDY CAFE (SION HOSPITAL)',5,'0','DR','NEAR SANDEEP CATERES CANTEEN','','','21','',NULL,'9136760771','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4183',NULL,'0','0',NULL,0,'2026-05-16 10:18:43','2026-05-16 10:18:43'),(355,'249',NULL,NULL,'SANCHI ENTERPRISES',5,'0','DR','MUMBAI','','','21','',NULL,'','',NULL,'27','','','GPAY',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44092','0.00',NULL,'0','0',NULL,'0','1469',NULL,'0','0',NULL,0,'2026-05-16 10:18:43','2026-05-16 10:18:43'),(356,'249',NULL,NULL,'SANCHI  FOOD HOSPITALITY',5,'0','DR','NR SURANA HOSPITAL','','','21','',NULL,'7021122926','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','246',NULL,'0','0',NULL,0,'2026-05-16 10:18:43','2026-05-16 10:18:43'),(357,'249',NULL,NULL,'SAI ENTERPRISES',5,'0','DR','W/S ROHAN','DEFAULT','Mumbai','21','400070',NULL,'1111111111','',NULL,'27','27APNPA3195C1Z1','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','158',NULL,'0','0',NULL,0,'2026-05-16 10:18:43','2026-05-16 10:18:43'),(358,'249',NULL,NULL,'SAHAJANAND TRADERS',5,'0','DR','1 ST FLR 69B ROOM 39 KUTCHI NIVAS OLD CHAEL MAZGAON MUMBAI','','Mumbai','21','400010',NULL,'1111111111','',NULL,'27','27AIGPA8840E1ZG','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43794','0.00',NULL,'0','0',NULL,'0','1194',NULL,'0','0',NULL,0,'2026-05-16 10:18:43','2026-05-16 10:18:43'),(359,'249',NULL,NULL,'SAGAR CREATIONS & CO',5,'0','DR','1305,13TH FLOOR , DEV CORPORA','','THANE','21','400601',NULL,'9967168160','',NULL,'27','27ANDPJ8183F1ZU','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4921',NULL,'0','0',NULL,0,'2026-05-16 10:18:43','2026-05-16 10:18:43'),(360,'249',NULL,NULL,'S.S ENGINEERS',5,'0','DR','MAROL  MUMBAI','','Mumbai','21','400047',NULL,'1111111111','',NULL,'27','27ABVPY9116F1ZV','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43793','0.00',NULL,'0','0',NULL,'0','1192',NULL,'0','0',NULL,0,'2026-05-16 10:18:43','2026-05-16 10:18:43'),(361,'249',NULL,NULL,'S.A HAMEED PERFUMERS',5,'0','DR','B-13 ARJUN CENTRE ESTATE P.V LTD PLOTNO 231GOVANDI STA','GOVANDI','MUMBAI','21','400088',NULL,'7039484537','',NULL,'27','27AAUPH0869A1ZN','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5688',NULL,'0','0',NULL,0,'2026-05-16 10:18:43','2026-05-16 10:18:43'),(362,'249',NULL,NULL,'S N REDDY',5,'0','DR','VASHI NAKA','','','21','',NULL,'','',NULL,'27','','','G PAY',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43974','0.00',NULL,'0','0',NULL,'0','1366',NULL,'0','0',NULL,0,'2026-05-16 10:18:43','2026-05-16 10:18:43'),(363,'249',NULL,NULL,'Royal Beauty Collection',5,'0','DR','Ws','','','21','',NULL,'1234567891','',NULL,'27','','','DMK JAOLI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4524',NULL,'0','0',NULL,0,'2026-05-16 10:18:43','2026-05-16 10:18:43'),(364,'249',NULL,NULL,'Rohit Marketing',5,'0','DR','Gurunanak Indl Estate','Kurla','Mumbai','21','400070',NULL,'8779721761','',NULL,'27','27AKPPC6596A1Z0','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6350',NULL,'0','0',NULL,0,'2026-05-16 10:18:44','2026-05-16 10:18:44'),(365,'249',NULL,NULL,'Riddhi Vinayak Hospital',5,'6072','DR','559/1,Riddhi Vinayak Lane,S.v Rd,','Malad West','Mumbai','21','400064',NULL,'9633142442','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6515',NULL,'0','0',NULL,0,'2026-05-16 10:18:44','2026-05-16 10:18:44'),(366,'249',NULL,NULL,'RUPAL SYNDICATE',5,'28892','DR','SHOP NO 26 PLOT NO 104,SATI KRUPA SHOPPING','CENTRE GARODIYA NAGAR GHATKOPAR E','MUMBAI','21','400089',NULL,'1111111111','',NULL,'27','27AAEPD8880H1ZI','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6485',NULL,'0','0',NULL,0,'2026-05-16 10:18:44','2026-05-16 10:18:44'),(367,'249',NULL,NULL,'RUPAL KANAKIA',5,'0','DR','VILE PARLE','','','21','',NULL,'9769860861','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','3902',NULL,'0','0',NULL,0,'2026-05-16 10:18:44','2026-05-16 10:18:44'),(368,'249',NULL,NULL,'RUCHITA HOSPITALITY SERVICES',5,'0','DR','SUSHRUT HOSP','','MUMBAI','21','',NULL,'8425962818','',NULL,'27','27AAOFR4901M1ZQ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5834',NULL,'0','0',NULL,0,'2026-05-16 10:18:44','2026-05-16 10:18:44'),(369,'249',NULL,NULL,'ROYAL FOOD PRODUCT',5,'0','DR','GROUND FLOOR SHOP NO 9 REHAB BUILDING NO 8','A WING RANI SATI ROAD MALAD EAST DHANJIWADI','MUMBAI','21','400097',NULL,'1111111111','',NULL,'27','27ABCFR1044A1ZT','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6196',NULL,'0','0',NULL,0,'2026-05-16 10:18:44','2026-05-16 10:18:44'),(370,'249',NULL,NULL,'ROP ENTERPRISES',5,'11699','CR','Ground Floor Shop No.6, Plot No.3B , Kalapana Park','Sector 9 , Near Garam Masala Hotel , Airoli','Navi Mumbai','21','400708',NULL,'9821241879','',NULL,'27','27AQMPG0878L1ZB','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6524',NULL,'0','0',NULL,0,'2026-05-16 10:18:44','2026-05-16 10:18:44'),(371,'249',NULL,NULL,'ROOPAM CHEMIST',5,'0','DR','CHEMBUR NAKA','SION TROMBAY ROAD','MUMBAI','21','400071',NULL,'1111111111','',NULL,'27','27AAHFR1979C1Z2','','CHEMBUR BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43939','0.00',NULL,'0','0',NULL,'0','1344',NULL,'0','0',NULL,0,'2026-05-16 10:18:44','2026-05-16 10:18:44'),(372,'249',NULL,NULL,'ROHIT CATERERS',5,'0','DR','GHATKOPAR','','','21','',NULL,'9819530134','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44112','0.00',NULL,'0','0',NULL,'0','1489',NULL,'0','0',NULL,0,'2026-05-16 10:18:44','2026-05-16 10:18:44'),(373,'249',NULL,NULL,'ROCK CATTERS',5,'0','DR','VIVAKANAD PHARMA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','269',NULL,'0','0',NULL,0,'2026-05-16 10:18:44','2026-05-16 10:18:44'),(374,'249',NULL,NULL,'RIYA ENTERPRISES',5,'0','DR','GRD FLR , R NO.666PATALI PADA','KOLSHET THANE','THANE','21','400607',NULL,'9821546781','',NULL,'27','27AZYPR5603BIZ2','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4426',NULL,'0','0',NULL,0,'2026-05-16 10:18:45','2026-05-16 10:18:45'),(375,'249',NULL,NULL,'RIO ENTERPRISES',5,'0','DR','18,UPPER FLR,MALPA DONGRI NO 3','ANDHERI EAST','MUMBAI','21','400059',NULL,'7738478420','',NULL,'27','27KCYPS2257H1ZM','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4198',NULL,'0','0',NULL,0,'2026-05-16 10:18:45','2026-05-16 10:18:45'),(376,'249',NULL,NULL,'RIHAN CATERERS',5,'0','DR','PLOT NO 8K/11,RD NO 8,BAIGAN WADI','MUMBAI','','21','400043',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1635',NULL,'0','0',NULL,0,'2026-05-16 10:18:45','2026-05-16 10:18:45'),(377,'249',NULL,NULL,'REALOFFICE NEEDS',5,'0','DR','GRD FLR,296,WADIA ESTATE','NR SHARADA MANDIR,MUMBAI','','21','400070',NULL,'989356823','',NULL,'27','27ARGPG7734E1ZT','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4523',NULL,'0','0',NULL,0,'2026-05-16 10:18:45','2026-05-16 10:18:45'),(378,'249',NULL,NULL,'RAVAL TRADING COMPANY',5,'0','DR','NR MONO RAIL CHEMBUR','SITA ESTATE','MUMBAI','21','400074',NULL,'9820605511','',NULL,'27','27AABPR4334F1ZU','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','282',NULL,'0','0',NULL,0,'2026-05-16 10:18:45','2026-05-16 10:18:45'),(379,'249',NULL,NULL,'RATNA SUPER MARKET',5,'0','DR','MAITRIPARK','','','21','',NULL,'7304097220','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4777',NULL,'0','0',NULL,0,'2026-05-16 10:18:45','2026-05-16 10:18:45'),(380,'249',NULL,NULL,'RATAN REFRESHMENT',5,'0','DR','DADAR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43911','0.00',NULL,'0','0',NULL,'0','1316',NULL,'0','0',NULL,0,'2026-05-16 10:18:45','2026-05-16 10:18:45'),(381,'249',NULL,NULL,'RATAN FOOD PRODUCTS',5,'0','DR','602,VIKAS CENTRE,CHEMBUR','DEFAULT','mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AAQFR4726A2Z5','','RTGS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','206',NULL,'0','0',NULL,0,'2026-05-16 10:18:45','2026-05-16 10:18:45'),(382,'249',NULL,NULL,'RAMZAN STORE',5,'0','DR','SHOP NO 12 VANI APARTMENT GOPINATH COMPOUND DR C G ROAD CHEMBUR (BASANT TOKIES )','','','21','',NULL,'25215079  /','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43736','0.00',NULL,'0','0',NULL,'0','919',NULL,'0','0',NULL,0,'2026-05-16 10:18:45','2026-05-16 10:18:45'),(383,'249',NULL,NULL,'RAMDEV TRADERS',5,'12525','DR','AVDHAN , H NO 1155 , MUMBAI AGRA HIGHWAY ,','DHULE','DHULE','21','424001',NULL,'9420589888','',NULL,'27','27CGFPG5989K1ZP','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6567',NULL,'0','0',NULL,0,'2026-05-16 10:18:45','2026-05-16 10:18:45'),(384,'249',NULL,NULL,'RAKESH KYROS',5,'0','DR','CHEMBUR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1538',NULL,'0','0',NULL,0,'2026-05-16 10:18:46','2026-05-16 10:18:46'),(385,'249',NULL,NULL,'RAJU GUPTA',5,'0','DR','PANVEL STATION','AABPG6099C','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','213',NULL,'0','0',NULL,0,'2026-05-16 10:18:46','2026-05-16 10:18:46'),(386,'249',NULL,NULL,'RAHUL KHANNA',5,'0','DR','TILAK NAGAR','','','21','',NULL,'','',NULL,'27','','','G PAY',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43974','0.00',NULL,'0','0',NULL,'0','1367',NULL,'0','0',NULL,0,'2026-05-16 10:18:46','2026-05-16 10:18:46'),(387,'249',NULL,NULL,'R.S.ENTERPRISES',11,'0','DR','ROOM NO 9/12,SURVEY NO 164,SUKH SAI NIKETAN,','DARGHA RD,KHINDIPADA,BHANDUP(WEST)','','21','400027',NULL,'9769101760','',NULL,'27','27BSXPS8433H2ZS','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4801',NULL,'0','0',NULL,0,'2026-05-16 10:18:46','2026-05-16 10:18:46'),(388,'249',NULL,NULL,'R.K.ENTERPRISES',5,'0','DR','GR,FLR,HUTMENTS,P.DEMELLO RD,RLY COMPD,','BACKSIDE OF AROGYA BHAWAN,FORT','MUMBAI','21','400001',NULL,'9172612192','',NULL,'27','27DSJPS0442G1ZM','','SBI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5712',NULL,'0','0',NULL,0,'2026-05-16 10:18:46','2026-05-16 10:18:46'),(389,'249',NULL,NULL,'R.K MARKETING',5,'0','DR','GOVANDI','','','21','',NULL,'','',NULL,'27','27ACRPG0630R1Z5','','NEFT',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44036','0.00',NULL,'0','0',NULL,'0','1422',NULL,'0','0',NULL,0,'2026-05-16 10:18:46','2026-05-16 10:18:46'),(390,'249',NULL,NULL,'R-LITE ELECTRICALS',5,'0','DR','SHOP NO 2,MARYLAND BLDG','SION EAST','MUMBAI','21','400022',NULL,'1111111111','',NULL,'27','27AAOPJ2845C1ZR','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44079','0.00',NULL,'0','0',NULL,'0','1451',NULL,'0','0',NULL,0,'2026-05-16 10:18:46','2026-05-16 10:18:46'),(391,'249',NULL,NULL,'Purple Mango Hospitality',5,'6495','DR','mumbai','','','21','',NULL,'9920523524','',NULL,'27','','','BOB',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6532',NULL,'0','0',NULL,0,'2026-05-16 10:18:46','2026-05-16 10:18:46'),(392,'249',NULL,NULL,'PUNYAM DISTRIBUTOR',5,'0','DR','CHEMBUR','','MUMBAI','21','400089',NULL,'9820229967','',NULL,'27','27AAEHN7306Q1ZN','','KOTAK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','275',NULL,'0','0',NULL,0,'2026-05-16 10:18:46','2026-05-16 10:18:46'),(393,'249',NULL,NULL,'PUNAM DISTRIBUTORS',5,'1017382.66','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','ANDHRA',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43911','0.00',NULL,'0','0',NULL,'0','1315',NULL,'0','0',NULL,0,'2026-05-16 10:18:46','2026-05-16 10:18:46'),(394,'249',NULL,NULL,'PRIME IDEAS',5,'1','CR','103,HEMKUNGBRSHMA KUMARI ROAD,JAWAHAR NAGAR,','GOREGAON W,MUMBAI SUBURBAN','MUMBAI','21','400062',NULL,'9920617677','',NULL,'27','27ABAFP3410C1ZV','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6543',NULL,'0','0',NULL,0,'2026-05-16 10:18:47','2026-05-16 10:18:47'),(395,'249',NULL,NULL,'PRAYOSHA HOSPITALITY SERVICES',5,'4812','CR','2ND FLR ROOM NO 18 POLT 11 NARYAN SMRUTI CHAMILDAS ROAD','DADAR WEST MUMBAI CITY','Mumbai','21','400014',NULL,'1111111111','',NULL,'27','27AYLPM6231A1ZM','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','284',NULL,'0','0',NULL,0,'2026-05-16 10:18:47','2026-05-16 10:18:47'),(396,'249',NULL,NULL,'PRATIMA ICE CREAM',5,'0','DR','NR SHEETALA MATA','','','21','',NULL,'8433878495','',NULL,'27','','','SURYODAY BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4477',NULL,'0','0',NULL,0,'2026-05-16 10:18:47','2026-05-16 10:18:47'),(397,'249',NULL,NULL,'PRASHANT CATERERS',5,'0','DR','GRD FLR,PREM COURT BLDG,','J.M RD,CHURCHGATE','MUMBAI','21','400020',NULL,'8779721761','',NULL,'27','27AAJFP7855K3ZG','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1824',NULL,'0','0',NULL,0,'2026-05-16 10:18:47','2026-05-16 10:18:47'),(398,'249',NULL,NULL,'PRASHANT CATERERS',5,'0','DR','CENTRE POINT INDL ESTATE','A1,OPP BAVLA MASJID,NR CURREY RD STN','LOWER PAREL','21','400013',NULL,'877721761','',NULL,'27','27AAJFP7855K3ZG','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1825',NULL,'0','0',NULL,0,'2026-05-16 10:18:47','2026-05-16 10:18:47'),(399,'249',NULL,NULL,'PRASAM EXPORTS',5,'0','DR','508,BEZZOLA COMPLEX,SION TROMBAY','ROAD,CHEMBUR MUMBAI','mumbai','21','400071',NULL,'9167223871','',NULL,'27','27AAFFP7571C2Z5','','CANARA BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4878',NULL,'0','0',NULL,0,'2026-05-16 10:18:47','2026-05-16 10:18:47'),(400,'249',NULL,NULL,'PRAMOD SUPPLIERS',5,'1077123','DR','45,GULALWADI,1ST FLOOR','MUMBAI','mumbai','21','400004',NULL,'1111111111','',NULL,'27','27AACPD1470H1Z4','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1797',NULL,'0','0',NULL,0,'2026-05-16 10:18:47','2026-05-16 10:18:47'),(401,'249',NULL,NULL,'PRADEEP JAISWAL',5,'0','DR','AMIT  MARS REFERENCE','','','21','',NULL,'','',NULL,'27','','','LAKSHMI VILAS',NULL,NULL,'BOISAR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43716','0.00',NULL,'0','0',NULL,'0','733',NULL,'0','0',NULL,0,'2026-05-16 10:18:47','2026-05-16 10:18:47'),(402,'249',NULL,NULL,'PRABHAKAR RAJE',5,'0','DR','KAJUPADA KURLA','','','21','',NULL,'','',NULL,'27','','','IDBI',NULL,NULL,'KAMOTHE','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43733','0.00',NULL,'0','0',NULL,'0','814',NULL,'0','0',NULL,0,'2026-05-16 10:18:47','2026-05-16 10:18:47'),(403,'249',NULL,NULL,'POOJA ENTERPRISES',5,'0','DR','165,SHOP 6,PATRAKAR CHSL','TILAK NGR,CHEMBUR 89','Mumbai','21','400089',NULL,'1111111111','',NULL,'27','27AXPPR1104C1ZP','','KOTAK MAHINDRA',NULL,NULL,'TILAK NGR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','136',NULL,'0','0',NULL,0,'2026-05-16 10:18:47','2026-05-16 10:18:47'),(404,'249',NULL,NULL,'PICASSO GLOBAL LLP',5,'0','DR','D7-140 BHUMI WORLD','PIMPLAS BHIWANDI','THANE','21','421302',NULL,'8262090909','',NULL,'27','27AAWFP3318G1ZW','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4455',NULL,'0','0',NULL,0,'2026-05-16 10:18:48','2026-05-16 10:18:48'),(405,'249',NULL,NULL,'PHARMO TIPS HEALTHCARE PVT LTD',5,'0','DR','Room No 102,1st Flr,house No 1518/0','Salamatpura,Naigaon,Bhiwandi','Thane','21','421302',NULL,'8888264264','',NULL,'27','27AAJCA2719G1ZR','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5696',NULL,'0','0',NULL,0,'2026-05-16 10:18:48','2026-05-16 10:18:48'),(406,'249',NULL,NULL,'PENINSULA RESTAURANT',5,'0','DR','SION OPP  CINE PLANET','','MUMBAI','21','400022',NULL,'8425936976','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4875',NULL,'0','0',NULL,0,'2026-05-16 10:18:48','2026-05-16 10:18:48'),(407,'249',NULL,NULL,'PAVITHRA HOSPITALITY (GOLF CLUB)',5,'0','DR','THE BOMBAY PRESENDANCY GOLF CLUB UNION PARK CHEMBUR CG ROAD MUMBAI','','MUMBAI','21','400074',NULL,'8169212123','',NULL,'27','27CGZPS6717F2ZJ','','CITY UNION BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4807',NULL,'0','0',NULL,0,'2026-05-16 10:18:48','2026-05-16 10:18:48'),(408,'249',NULL,NULL,'PATEL KIRANA',5,'0','DR','VASHI NAKA','','','21','',NULL,'','',NULL,'27','','','IMPS GPAY',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43979','0.00',NULL,'0','0',NULL,'0','1369',NULL,'0','0',NULL,0,'2026-05-16 10:18:48','2026-05-16 10:18:48'),(409,'249',NULL,NULL,'PARAS SUPER MARKET',5,'0','DR','ST1','','mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AAZFP1287D1ZR','','APNA',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1720',NULL,'0','0',NULL,0,'2026-05-16 10:18:48','2026-05-16 10:18:48'),(410,'249',NULL,NULL,'PARAKH PHARMACY',5,'0','DR','GHATKOPAR','DEFAULT','','21','',NULL,'9820118266','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','5000','1',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','124',NULL,'0','0',NULL,0,'2026-05-16 10:18:48','2026-05-16 10:18:48'),(411,'249',NULL,NULL,'P.G.EXIM PVT LTD',11,'601800','CR','212,216 RANG MAHAL SAMUEL STREET, VADGADI','MANDVI MASJID BUNDER (W)','MUMBAI','21','400003',NULL,'1.54E+13','',NULL,'27','27AAFCP0224R1Z5','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6540',NULL,'0','0',NULL,0,'2026-05-16 10:18:48','2026-05-16 10:18:48'),(412,'249',NULL,NULL,'Online Packaging Pvt Ltd',5,'0','DR','71/72, Ii B Verna Electronic City','Goa','Goa','21','403722',NULL,'','',NULL,'27','30AAACO6491Q1Z1','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','241',NULL,'0','0',NULL,0,'2026-05-16 10:18:48','2026-05-16 10:18:48'),(413,'249',NULL,NULL,'OSWAL DRY FRUIT & GEN STORE',5,'0','DR','GANGAGIRI, PLOT NO 47','VASHI SWC 17','NAVI MUMBAI','21','400703',NULL,'','',NULL,'27','27AQZPS3752L2ZQ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44128','0.00',NULL,'0','0',NULL,'0','1520',NULL,'0','0',NULL,0,'2026-05-16 10:18:48','2026-05-16 10:18:48'),(414,'249',NULL,NULL,'OSCAR MEDICAL STORES',5,'0','DR','S.R.M.& K.P. CARDIAC INST','NR GANGHI MKT,KING CIRCLE','MUMBAI','21','400022',NULL,'9821082912','',NULL,'27','27AAAFO6064A1ZM','','IDBI BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4852',NULL,'0','0',NULL,0,'2026-05-16 10:18:49','2026-05-16 10:18:49'),(415,'249',NULL,NULL,'OM ENTERPRISES',5,'0','DR','SAFALYA BLDG,NR RATANJYOT','BLDG,VILE PARLE WST','mumbai','21','400056',NULL,'9835657841','',NULL,'27','27AZGPD0217P1ZD','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4506',NULL,'0','0',NULL,0,'2026-05-16 10:18:49','2026-05-16 10:18:49'),(416,'249',NULL,NULL,'OM ENTERPRISE',5,'0','DR','ROOM NO S MAHAKALI NAGAR MAROL','MILITARY ROAD ANDHERI EAST MUMBAI','mumbai','21','400059',NULL,'8850346529','',NULL,'27','27AJRPY2328M1ZB','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4308',NULL,'0','0',NULL,0,'2026-05-16 10:18:49','2026-05-16 10:18:49'),(417,'249',NULL,NULL,'OBTAIN IT CONSULTANCY LLP',5,'0','DR','77/2296,PANT NAGAR','GHATKOPAR EAST','MUMBAI','21','400075',NULL,'1111111111','',NULL,'27','27AADFO8957F1ZV','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43991','0.00',NULL,'0','0',NULL,'0','1376',NULL,'0','0',NULL,0,'2026-05-16 10:18:49','2026-05-16 10:18:49'),(418,'249',NULL,NULL,'NULIFE HOSPITAL',5,'0','DR','A-1 HARE KRISHNA BUILDING L B S MARG,','NEAR TELEPHONE EXCHANGE GHATKOPER WEST','MUMBAI','21','400086',NULL,'9821343551','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4815',NULL,'0','0',NULL,0,'2026-05-16 10:18:49','2026-05-16 10:18:49'),(419,'249',NULL,NULL,'NOVO MEDISCIENCS PVT LTD',5,'0','DR','NR.CASH','','','21','',NULL,'8779843484','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4408',NULL,'0','0',NULL,0,'2026-05-16 10:18:49','2026-05-16 10:18:49'),(420,'249',NULL,NULL,'NOVAS IMPEX',5,'0','DR','MUMBAI','','','21','400003',NULL,'9833697676','',NULL,'27','27AADPT8979L1ZM','','UNION BANK',NULL,NULL,'MULUND','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','244',NULL,'0','0',NULL,0,'2026-05-16 10:18:49','2026-05-16 10:18:49'),(421,'249',NULL,NULL,'NITIN FIRE PROTECTION INDUSTRIES LTD',5,'0','DR','5th Floor, 501, Delta, Technology Street, Hiranandani, Powai','mumbai','mumbai','21','400076',NULL,'1111111111','',NULL,'27','27AAACN1967G1ZF','','IDBI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43793','0.00',NULL,'0','0',NULL,'0','1193',NULL,'0','0',NULL,0,'2026-05-16 10:18:49','2026-05-16 10:18:49'),(422,'249',NULL,NULL,'NIKHIL PALAV',5,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43942','0.00',NULL,'0','0',NULL,'0','1350',NULL,'0','0',NULL,0,'2026-05-16 10:18:49','2026-05-16 10:18:49'),(423,'249',NULL,NULL,'NIDHI IMPEX',5,'0','DR','1ST FLOOR PLOT NO CS1491','D.N.ROAD CROWFORD MKT','MUMBAI','21','400001',NULL,'9404215553','',NULL,'27','27AODPD0004Q1Z7','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6046',NULL,'0','0',NULL,0,'2026-05-16 10:18:49','2026-05-16 10:18:49'),(424,'249',NULL,NULL,'NIDHI CATERS (SHAH & ANCHOR)',5,'0','DR','SHAH & ANCHOR COLLEGE','GOVANDI','','21','',NULL,'','',NULL,'27','','','CANARA BANK',NULL,NULL,'GOVANDI','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','267',NULL,'0','0',NULL,0,'2026-05-16 10:18:50','2026-05-16 10:18:50'),(425,'249',NULL,NULL,'NEOGEN CHEMICALS LIMITED',5,'0','DR','1002 DEV CORPORA BUILDING 10TH FLOOR OPP. CADBURY COMPOUND OFF. POKHRAN ROAD NO.2  KHOPAT THANE WEST','','MUMBAI','21','400071',NULL,'8850346529','',NULL,'27','27AAACN5836E1ZJ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4265',NULL,'0','0',NULL,0,'2026-05-16 10:18:50','2026-05-16 10:18:50'),(426,'249',NULL,NULL,'NBH CANTEEN',5,'0','DR','BARC','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','272',NULL,'0','0',NULL,0,'2026-05-16 10:18:50','2026-05-16 10:18:50'),(427,'249',NULL,NULL,'NB MIRCHANDANI',5,'0','DR','GURUNANAK SADAN,3RD FLR','MAHUL RD,CHEMBUR','MUMBAI','21','400074',NULL,'9821648373','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4307',NULL,'0','0',NULL,0,'2026-05-16 10:18:50','2026-05-16 10:18:50'),(428,'249',NULL,NULL,'NARYAN PAN BIDI',5,'0','DR','CHURCH GATE','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','292',NULL,'0','0',NULL,0,'2026-05-16 10:18:50','2026-05-16 10:18:50'),(429,'249',NULL,NULL,'NARSINGH',5,'0','DR','REF AJIT KAKA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44087','0.00',NULL,'0','0',NULL,'0','1459',NULL,'0','0',NULL,0,'2026-05-16 10:18:50','2026-05-16 10:18:50'),(430,'249',NULL,NULL,'NALANDA PACKAGING INDUSTRIES',5,'0','DR','B 207, GOKUL ARCADE','SUBASH RD,VILE PARLE EAST','MUMBAI','21','400057',NULL,'1111111111','',NULL,'27','27AAGFN5207J1Z7','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','240',NULL,'0','0',NULL,0,'2026-05-16 10:18:50','2026-05-16 10:18:50'),(431,'249',NULL,NULL,'NAITIKK SALES',5,'204515','DR','655/9/1, GANGA DHAM UPPER','INDIRA NGR,BIDEWADI','PUNE','21','411037',NULL,'9890170015','',NULL,'27','27AWEPS9245F1Z5','','RTGS',NULL,NULL,'CHEMBUR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','249',NULL,'0','0',NULL,0,'2026-05-16 10:18:50','2026-05-16 10:18:50'),(432,'249',NULL,NULL,'NAGRIK STORE',5,'0','DR','GHATKOPAR','','','21','',NULL,'','',NULL,'27','','','NEFT',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44081','0.00',NULL,'0','0',NULL,'0','1452',NULL,'0','0',NULL,0,'2026-05-16 10:18:50','2026-05-16 10:18:50'),(433,'249',NULL,NULL,'NAGINDAS AMARCHAND BHAGAT WELFARE TRUST',5,'0','DR','GHATKOPAR','','','21','',NULL,'','',NULL,'27','','','UCO BANK',NULL,NULL,'GHATKOPAR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1246',NULL,'0','0',NULL,0,'2026-05-16 10:18:50','2026-05-16 10:18:50'),(434,'249',NULL,NULL,'Mona Beayty Salon',5,'0','DR','Shop No 2 Laxmi Niwas Sitaram Jhadav Marg','Lower Parel','Mumbai','21','400013',NULL,'9768459497','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4819',NULL,'0','0',NULL,0,'2026-05-16 10:18:51','2026-05-16 10:18:51'),(435,'249',NULL,NULL,'Mayekar',5,'0','DR','Dombivali','Mumbai','','21','',NULL,'9820877140','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6047',NULL,'0','0',NULL,0,'2026-05-16 10:18:51','2026-05-16 10:18:51'),(436,'249',NULL,NULL,'MULUND SIDDHI CO OP SOC LTD',5,'0','DR','MULUND','','','21','',NULL,'','',NULL,'27','','','NEW INDIA',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1657',NULL,'0','0',NULL,0,'2026-05-16 10:18:51','2026-05-16 10:18:51'),(437,'249',NULL,NULL,'MULTI DESIGN & PRINT',5,'0','DR','09 SHREE KRISHNA NIVAS BANDEKAR WADI JOGESHWARI EAST','MUMBAI','mumbai','21','400060',NULL,'9257135843','',NULL,'27','27APTPP6291G1Z5','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4201',NULL,'0','0',NULL,0,'2026-05-16 10:18:51','2026-05-16 10:18:51'),(438,'249',NULL,NULL,'MR.VIJAY',5,'0','DR','MUMBAI','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43942','0.00',NULL,'0','0',NULL,'0','1347',NULL,'0','0',NULL,0,'2026-05-16 10:18:51','2026-05-16 10:18:51'),(439,'249',NULL,NULL,'MR ANIL VARMA',5,'0','DR','MUMBAI','','','21','',NULL,'','',NULL,'27','','','CENTRAL BANK',NULL,NULL,'VIKHROLI','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','295',NULL,'0','0',NULL,0,'2026-05-16 10:18:51','2026-05-16 10:18:51'),(440,'249',NULL,NULL,'MONICA RESTAURANT',5,'0','DR','OPP KAILASH TOWER 90FT RD','PANT NAGAR GHATKOPAR E','','21','',NULL,'','',NULL,'27','27AYBPS6630F1ZD','','KOTAK',NULL,NULL,'GHATKOPAR EAST','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','233',NULL,'0','0',NULL,0,'2026-05-16 10:18:51','2026-05-16 10:18:51'),(441,'249',NULL,NULL,'MOMAYA CAPACITORS',5,'0','DR','MANPADA RD','DOMBIVALI EAST','mumbai','21','421204',NULL,'9322265111','',NULL,'27','27AAAFM1710D1ZZ','','UNION',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44155','0.00',NULL,'0','0',NULL,'0','1542',NULL,'0','0',NULL,0,'2026-05-16 10:18:51','2026-05-16 10:18:51'),(442,'249',NULL,NULL,'MITHU EMPORIUM',5,'0','DR','PRABHAT MARKET,27,H.G.B ROAD','AGARTALA,TRIPURA WEST','TRIPURA','Tripura','799001',NULL,'7005025215','',NULL,'0','16AWKPB2403Q1ZI','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4925',NULL,'0','0',NULL,0,'2026-05-16 10:18:51','2026-05-16 10:18:51'),(443,'249',NULL,NULL,'MILIND DEDHIA',5,'0','DR','KURLA CHADWA NAGAR','','','21','400070',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44681','0.00',NULL,'0','0',NULL,'0','1774',NULL,'0','0',NULL,0,'2026-05-16 10:18:51','2026-05-16 10:18:51'),(444,'249',NULL,NULL,'MILIND DEDHIA',5,'0','DR','KURLA','','','21','',NULL,'','',NULL,'27','','','GPAY',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43990','0.00',NULL,'0','0',NULL,'0','1374',NULL,'0','0',NULL,0,'2026-05-16 10:18:52','2026-05-16 10:18:52'),(445,'249',NULL,NULL,'MICHAEL SCHOOL',5,'0','DR','KAMANI','NEAR SHEETAL CENEMA','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','262',NULL,'0','0',NULL,0,'2026-05-16 10:18:52','2026-05-16 10:18:52'),(446,'249',NULL,NULL,'MEHTA AND CO',5,'0','DR','SHOP NO 5 KADRI MANSION BH','KISMAT LOUNDARY SION','MUMBAI','21','400022',NULL,'9619997841','',NULL,'27','27CFYPM4254B2Z4','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5716',NULL,'0','0',NULL,0,'2026-05-16 10:18:52','2026-05-16 10:18:52'),(447,'249',NULL,NULL,'MEHAK AGENCY',5,'0','DR','C/49,ASLAM COMPD,NR MANOJ','KUMAR STUDIO, NR OBEROI GARDEN','CHANDIVLI SAKINAKA','21','400072',NULL,'1111111111','',NULL,'27','27CVSPK0407Q1ZY','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43857','0.00',NULL,'0','0',NULL,'0','1284',NULL,'0','0',NULL,0,'2026-05-16 10:18:52','2026-05-16 10:18:52'),(448,'249',NULL,NULL,'MEENA INDUSTRIES',5,'7234','DR','GALA NO 21,KOHINOOR TEXTILE PRINTING','BEHIND SWASTIK DISA','GHATKOPAR WEST','21','400071',NULL,'1111111111','',NULL,'27','27AAKFM3322K1Z6','','KOTAK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43776','0.00',NULL,'0','0',NULL,'0','1172',NULL,'0','0',NULL,0,'2026-05-16 10:18:52','2026-05-16 10:18:52'),(449,'249',NULL,NULL,'MAYUR BARIK',5,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43942','0.00',NULL,'0','0',NULL,'0','1352',NULL,'0','0',NULL,0,'2026-05-16 10:18:52','2026-05-16 10:18:52'),(450,'249',NULL,NULL,'MAX CORPORATIONS',5,'0','DR','411,KAILASH INDUSTRIAL COMPLEX, G WING.SAVAKARMARG,','VIKHAROLI (W)','MUMBAI','21','400079',NULL,'9545512226','',NULL,'27','27AKVPP4150D1ZX','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4796',NULL,'0','0',NULL,0,'2026-05-16 10:18:52','2026-05-16 10:18:52'),(451,'249',NULL,NULL,'MANSI MAHILA AUDYOGIK',5,'0','DR','VIKHROLI PARK SIDE','','','21','',NULL,'9221282157','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5274',NULL,'0','0',NULL,0,'2026-05-16 10:18:52','2026-05-16 10:18:52'),(452,'249',NULL,NULL,'MANOJ ENTERPRISES',11,'0','DR','18/11,HARHARWALA BLDG','N.M JOSHI MRG,MUMBAI','','21','400011',NULL,'','',NULL,'27','27BTEPS1995N1ZS','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43877','0.00',NULL,'0','0',NULL,'0','1294',NULL,'0','0',NULL,0,'2026-05-16 10:18:52','2026-05-16 10:18:52'),(453,'249',NULL,NULL,'MANOHAR LALS SUPER MARKET',5,'0','DR','COLLECTOR COLONY','CHEMBUR','Mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AAAPT9186C1ZF','','IDFC',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43813','0.00',NULL,'0','0',NULL,'0','1224',NULL,'0','0',NULL,0,'2026-05-16 10:18:52','2026-05-16 10:18:52'),(454,'249',NULL,NULL,'MANJUSHRI CATTERES',5,'0','DR','NEAR SHUSHRUT HOSPITAL CHEMBUR','','','21','',NULL,'8928395589','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44159','0.00',NULL,'0','0',NULL,'0','1545',NULL,'0','0',NULL,0,'2026-05-16 10:18:53','2026-05-16 10:18:53'),(455,'249',NULL,NULL,'MANI KAMAT',5,'0','DR','CST','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','207',NULL,'0','0',NULL,0,'2026-05-16 10:18:53','2026-05-16 10:18:53'),(456,'249',NULL,NULL,'MANGAL MISHRA',5,'0','DR','CHEMBUR','','','21','',NULL,'','',NULL,'27','','','GPAY IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43979','0.00',NULL,'0','0',NULL,'0','1370',NULL,'0','0',NULL,0,'2026-05-16 10:18:53','2026-05-16 10:18:53'),(457,'249',NULL,NULL,'MANAS ENTERPRISES',5,'0','DR','RIGOLD HOUSE PLOMET NO A-34 CROSS ROAD NO-02','','Mumbai','21','400093',NULL,'9867310378','',NULL,'27','27AJGPH5487B1Z8','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4440',NULL,'0','0',NULL,0,'2026-05-16 10:18:53','2026-05-16 10:18:53'),(458,'249',NULL,NULL,'MAN ENTERPRISES',5,'0','DR','MERIGOLD HOUSE PLOT NO A-34 CROSS ROAD','NO 2 MAROL MIDC ANDHERI EAST','MUMBAI','21','400093',NULL,'9930340027','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4318',NULL,'0','0',NULL,0,'2026-05-16 10:18:53','2026-05-16 10:18:53'),(459,'249',NULL,NULL,'MALDE CAPACITORS MFG CO',5,'0','DR','MANPADA RD','DOMBIVALI EAST','mumbai','21','421204',NULL,'9322265111','',NULL,'27','27AACPK5099B1ZS','','UNION',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44155','0.00',NULL,'0','0',NULL,'0','1543',NULL,'0','0',NULL,0,'2026-05-16 10:18:53','2026-05-16 10:18:53'),(460,'249',NULL,NULL,'MAHARASHTRA SUPER MARKET',5,'0','DR','PLOT NO 31/42,G M LINK RD','GOVANDI','mumbai','21','400043',NULL,'1111111111','',NULL,'27','27ABOFM0213G1ZH','','NAVI MUMBAI',NULL,NULL,'GOVANDI','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','ABOFM0213G','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1566',NULL,'0','0',NULL,0,'2026-05-16 10:18:53','2026-05-16 10:18:53'),(461,'249',NULL,NULL,'MAHALAXMI TRADERS',5,'126790','CR','AT POST TULJAPUR','DIST OSMANABAD','mumbai','21','413601',NULL,'1111111111','',NULL,'27','27AHCPA4482F1ZN','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','289',NULL,'0','0',NULL,0,'2026-05-16 10:18:53','2026-05-16 10:18:53'),(462,'249',NULL,NULL,'MAGICO FOODWORK',5,'0','DR','SHOP NO 3,WATERFILED RD','BANDRA WEST','MUMBAI','21','400027',NULL,'9967677808','',NULL,'27','','','ICICI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44116','0.00',NULL,'0','0',NULL,'0','1503',NULL,'0','0',NULL,0,'2026-05-16 10:18:53','2026-05-16 10:18:53'),(463,'249',NULL,NULL,'MAGICDIL HEALTH LLP',5,'0','DR','CHEMBUR RAILWAY ST','CHEMBUR EAST','MUMBAI','21','400071',NULL,'7208520196','',NULL,'27','27ABEFM0732E1ZD','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','259',NULL,'0','0',NULL,0,'2026-05-16 10:18:53','2026-05-16 10:18:53'),(464,'249',NULL,NULL,'M/S KRISHNA COLLECTION',5,'0','DR','SHOP NO..3&4GOKULDHAM MARKET','MALAD (E) NR- SHOPPERS SPOTGEN','MUMBAI','21','400097',NULL,'9253468542','',NULL,'27','27AKLPC1366L1ZZ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4484',NULL,'0','0',NULL,0,'2026-05-16 10:18:54','2026-05-16 10:18:54'),(465,'249',NULL,NULL,'LOVELY DRY FRUIT',5,'0','DR','KURLA','','Mumbai','21','400070',NULL,'1111111111','',NULL,'27','27AAAPF1139K1ZZ','','NEFT',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44008','0.00',NULL,'0','0',NULL,'0','1380',NULL,'0','0',NULL,0,'2026-05-16 10:18:54','2026-05-16 10:18:54'),(466,'249',NULL,NULL,'LOHMARG MUKHYALAY DAIRY',5,'0','DR','RAILWAY POLICE QUARTER','PANTNAGAR GHATKOPAR','EAST','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44261','0.00',NULL,'0','0',NULL,'0','1735',NULL,'0','0',NULL,0,'2026-05-16 10:18:54','2026-05-16 10:18:54'),(467,'249',NULL,NULL,'LION TARACHAND BAPA HOPITAL & RESEARCH CENTRE',5,'0','DR','SION WEST','','','21','',NULL,'7506069014','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4186',NULL,'0','0',NULL,0,'2026-05-16 10:18:54','2026-05-16 10:18:54'),(468,'249',NULL,NULL,'LIFESTYLE STATIONERY',5,'0','DR','PRABHADEVI DADAR','','Mumbai','21','400025',NULL,'1111111111','',NULL,'27','27AEWPC2836C1ZJ','','BOM',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44106','0.00',NULL,'0','0',NULL,'0','1484',NULL,'0','0',NULL,0,'2026-05-16 10:18:54','2026-05-16 10:18:54'),(469,'249',NULL,NULL,'LAXMI SALES AGENCY',5,'0','DR','GALA NO 2,HARI OM COMPD,','J.M.M RD,KHEANI RD','MUMBAI','21','400084',NULL,'9867093128','',NULL,'27','27AABPG8430B1Z8','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4174',NULL,'0','0',NULL,0,'2026-05-16 10:18:54','2026-05-16 10:18:54'),(470,'249',NULL,NULL,'LAXMI GENERAL STORES',5,'0','DR','AGRI PADA,CHANDOLKAR MARG','MUMBAI','mumbai','21','400011',NULL,'1111111111','',NULL,'27','27AACPG2572P1ZF','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44027','0.00',NULL,'0','0',NULL,'0','1416',NULL,'0','0',NULL,0,'2026-05-16 10:18:54','2026-05-16 10:18:54'),(471,'249',NULL,NULL,'LALANI TECHNOLOGY',5,'0','DR','SHOP 4,LABH ASHISH BLDG,','DADA BHAI RD,VILE PARLE WEST','MUMBAI','21','400056',NULL,'7045123333','',NULL,'27','27BPSPD9285A1ZL','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4505',NULL,'0','0',NULL,0,'2026-05-16 10:18:54','2026-05-16 10:18:54'),(472,'249',NULL,NULL,'LAKE VIEW HOSPITALITY',5,'0','DR','(RAIN FOREST GHATKOPAR)','DEFAULT','mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AADFL2325A1ZY','','HDFC BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','153',NULL,'0','0',NULL,0,'2026-05-16 10:18:54','2026-05-16 10:18:54'),(473,'249',NULL,NULL,'L.K.WOOLLEN & SILK MILLS',5,'0','DR','E-14,NANDJYOT INDUSTRIAL ESTATE,','ANDHERI -KURLA ROAD SAKINAKA','MUMBAI','21','400069',NULL,'2241205194','lkwoollen@gmail.com',NULL,'27','27AAAPG9544R1Z3','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5649',NULL,'0','0',NULL,0,'2026-05-16 10:18:54','2026-05-16 10:18:54'),(474,'249',NULL,NULL,'L P DSOUZA (ST ANTHONYS SCHOOL)',5,'0','DR','ST ANTHONYS SCHOOL CHEMBUR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','268',NULL,'0','0',NULL,0,'2026-05-16 10:18:55','2026-05-16 10:18:55'),(475,'249',NULL,NULL,'Khyati Global Ventures Ltd',5,'0','DR','54,Juhu Supreme Shopping Center,Gulmohar Cross Rd','No 9,Jvpd Scheme','Mumbai','21','400049',NULL,'9320554665','',NULL,'27','27AAACK1682P1Z3','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6517',NULL,'0','0',NULL,0,'2026-05-16 10:18:55','2026-05-16 10:18:55'),(476,'249',NULL,NULL,'KUSHAL MARKETING',5,'1352014','DR','Plot 25/26,Gandhi Nagar','Akkalkot Rd','Solapur','21','413216',NULL,'9422647136','',NULL,'27','27ABUPV7269B1ZX','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6405',NULL,'0','0',NULL,0,'2026-05-16 10:18:55','2026-05-16 10:18:55'),(477,'249',NULL,NULL,'KUSHAL AGENCY',5,'48236','DR','25/26/B , OLD AKKALKOT NAKA','SOLAPUR','SOLAPUR','21','413006',NULL,'1234567890','',NULL,'27','27AALPV0710B1Z0','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6541',NULL,'0','0',NULL,0,'2026-05-16 10:18:55','2026-05-16 10:18:55'),(478,'249',NULL,NULL,'KULSWAMINI TRADING',5,'3792416','DR','FLAT NO. 02 , SARGAM PLACES NO. 312/313 , KALA NAGAR','MAHASRUL , NASHIK','NASHIK','21','422004',NULL,'8369428756','',NULL,'27','27DYOPS7491J1ZB','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6576',NULL,'0','0',NULL,0,'2026-05-16 10:18:55','2026-05-16 10:18:55'),(479,'249',NULL,NULL,'KRUSHNATH MORE',5,'0','DR','AGARGAON DIST BARSI','','','21','413401',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','BTEPM7342D','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','287',NULL,'0','0',NULL,0,'2026-05-16 10:18:55','2026-05-16 10:18:55'),(480,'249',NULL,NULL,'KRISHNA OVERSEAS INC.',5,'75283','DR','229 DADA DEEPU CHOWK','BHARTAL SECTOR 26','DWARAKA','Delhi','110077',NULL,'7894561230','',NULL,'0','07AAHFK5581H1Z3','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6570',NULL,'0','0',NULL,0,'2026-05-16 10:18:55','2026-05-16 10:18:55'),(481,'249',NULL,NULL,'KOHINOOR HOSPITAL PVT LTD',5,'0','DR','KOHINOOR CITY,KIROL RD','KURLA WEST MUMBAI','mumbai','21','400070',NULL,'2267556755','',NULL,'27','27AADCK3848G1ZF','','SBI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1636',NULL,'0','0',NULL,0,'2026-05-16 10:18:55','2026-05-16 10:18:55'),(482,'249',NULL,NULL,'KISHOR KAMBLE',5,'0','DR','DEFAULT','DEFAULT','','21','',NULL,'','',NULL,'27','','','BOI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','224',NULL,'0','0',NULL,0,'2026-05-16 10:18:55','2026-05-16 10:18:55'),(483,'249',NULL,NULL,'KINGCRAFT RESTAURANTS PVT LTD',5,'0','DR','SHOP NO 6,AJMERA ROYAL CHS','OPP CRYTAL PLAZA','ANDHERI WEST','21','400053',NULL,'1111111111','',NULL,'27','27AAHCK3834C1ZP','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','283',NULL,'0','0',NULL,0,'2026-05-16 10:18:56','2026-05-16 10:18:56'),(484,'249',NULL,NULL,'KIBIL CHEMISTS DRUGGISTS & GENERAL STORES',5,'0','DR','DR.MENDADKARS HOSPITAL','NEXT TO SAWALI HOTEL,NEHRU NAGAR KURLA EAST','','21','',NULL,'223630809','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4184',NULL,'0','0',NULL,0,'2026-05-16 10:18:56','2026-05-16 10:18:56'),(485,'249',NULL,NULL,'KANAKA FOOD MANAGEMENT SERVICES',5,'0','DR','TATA POWER TROMBAY 7400279303','DEFAULT','Mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AADCK2583J1ZA','','KARNATAKA BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','202',NULL,'0','0',NULL,0,'2026-05-16 10:18:56','2026-05-16 10:18:56'),(486,'249',NULL,NULL,'KAMADHENU CATERERS',5,'0','DR','DADAR','','','21','',NULL,'9594811043','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4917',NULL,'0','0',NULL,0,'2026-05-16 10:18:56','2026-05-16 10:18:56'),(487,'249',NULL,NULL,'KALPESH TIVOLI',5,'0','DR','HIRANANDANI','','','21','',NULL,'9820088828','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44054','0.00',NULL,'0','0',NULL,'0','1434',NULL,'0','0',NULL,0,'2026-05-16 10:18:56','2026-05-16 10:18:56'),(488,'249',NULL,NULL,'KAILASH SONI',5,'0','DR','KAJUPADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44086','0.00',NULL,'0','0',NULL,'0','1458',NULL,'0','0',NULL,0,'2026-05-16 10:18:56','2026-05-16 10:18:56'),(489,'249',NULL,NULL,'KAILASH',5,'0','DR','CHEMBUR','','','21','',NULL,'1.11E+26','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6522',NULL,'0','0',NULL,0,'2026-05-16 10:18:56','2026-05-16 10:18:56'),(490,'249',NULL,NULL,'KA HOSPITALITY PVT LTD',5,'210318.16','DR','S-201 , BLOCK NO.5 , THE LODHA LOGISTIC PARK','NR. PHOENIX MARKET CITY , PIPELINE RD., KURLA WEST','Mumbai','21','400070',NULL,'8149870351','',NULL,'27','27AADCK9508M1Z1','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4806',NULL,'0','0',NULL,0,'2026-05-16 10:18:56','2026-05-16 10:18:56'),(491,'249',NULL,NULL,'K.Y.A APPARELL LLP',5,'0','DR','MUMBAI','','mumbai','21','400020',NULL,'1111111111','',NULL,'27','27AAMFK3840Q1ZN','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44176','0.00',NULL,'0','0',NULL,'0','1619',NULL,'0','0',NULL,0,'2026-05-16 10:18:56','2026-05-16 10:18:56'),(492,'249',NULL,NULL,'K STUDIO INC',5,'0','DR','UNIT NO 1, CTS 176,OPP KHATAU MILL','GAYATRI MANDIR','mumbai','21','400071',NULL,'9355114433','',NULL,'27','27AAHPS6652D1ZI','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6508',NULL,'0','0',NULL,0,'2026-05-16 10:18:56','2026-05-16 10:18:56'),(493,'249',NULL,NULL,'K N & SONS',5,'0','DR','SHOP NO 10,GHANSHYAM NAGAR','TRIKAMDAS RD, KANDIVALI WEST','MUMBAI','21','400087',NULL,'9892038782','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4161',NULL,'0','0',NULL,0,'2026-05-16 10:18:57','2026-05-16 10:18:57'),(494,'249',NULL,NULL,'K J SOMAIYA HOSPITAL',5,'0','DR','SURESH SHETTY','EVARARD NAGAR,CHUNABHATTI','','21','',NULL,'','',NULL,'27','27AOBPS031631Z1','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','135',NULL,'0','0',NULL,0,'2026-05-16 10:18:57','2026-05-16 10:18:57'),(495,'249',NULL,NULL,'JUST PRINT SOLUTION',5,'0','DR','A-2/12A,SHAH & NAHAR INDUSTRIAL','ESTATE,LOWER PAREL','MUMBAI','21','400013',NULL,'9167212781','',NULL,'27','27AMOPP1570C1Z0','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4410',NULL,'0','0',NULL,0,'2026-05-16 10:18:57','2026-05-16 10:18:57'),(496,'249',NULL,NULL,'JOLLY GYM KHANA',5,'0','DR','NR OPP FATIMA SCHOOL','GHATKOPAR EAST','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43844','0.00',NULL,'0','0',NULL,'0','1269',NULL,'0','0',NULL,0,'2026-05-16 10:18:57','2026-05-16 10:18:57'),(497,'249',NULL,NULL,'JOEL BARETTO',5,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43909','0.00',NULL,'0','0',NULL,'0','1305',NULL,'0','0',NULL,0,'2026-05-16 10:18:57','2026-05-16 10:18:57'),(498,'249',NULL,NULL,'JITENDRA',5,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1351',NULL,'0','0',NULL,0,'2026-05-16 10:18:57','2026-05-16 10:18:57'),(499,'249',NULL,NULL,'JIMIT ENTERPRISES',5,'0','DR','PRABHAT NGR,GRD FLR,FLAT 10','KAJUPADA PIPELINE,ANDHERI EAST','MUMBAI','21','400072',NULL,'8097262491','',NULL,'27','27ALQPT6288A1ZJ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5159',NULL,'0','0',NULL,0,'2026-05-16 10:18:57','2026-05-16 10:18:57'),(500,'249',NULL,NULL,'JAYSHREE ENTERPRISE',5,'0','DR','116,KESHAVJI NAIK RD,MULJI DEVSHI','BLDG,GRD FLR,GALA NO 1','CHINCHBUNDER','21','400009',NULL,'2223723414','',NULL,'27','27AAAFJ7687G1Z0','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4403',NULL,'0','0',NULL,0,'2026-05-16 10:18:57','2026-05-16 10:18:57'),(501,'249',NULL,NULL,'JAY INFOTECH',5,'0','DR','CHEMBUR','DEFAULT','Mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AAEHN7306Q1ZN','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','143',NULL,'0','0',NULL,0,'2026-05-16 10:18:57','2026-05-16 10:18:57'),(502,'249',NULL,NULL,'JAY BHAVANI MAHILA SANSTHA',5,'0','DR','PARK SIDE','','','21','',NULL,'9221405991','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4868',NULL,'0','0',NULL,0,'2026-05-16 10:18:57','2026-05-16 10:18:57'),(503,'249',NULL,NULL,'JAY BHAIRAVNATH KIRANA ST',5,'0','DR','BLD NO 152','EKTA SOCITY','mumbai','21','400097',NULL,'8692954156','',NULL,'27','27AUWPC3004E1ZW','','HDFC BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4450',NULL,'0','0',NULL,0,'2026-05-16 10:18:58','2026-05-16 10:18:58'),(504,'249',NULL,NULL,'JASH DEALMARK LTD',5,'0','DR','C/18,SAHAKAR VISHWA,SARVODAYA','NAGAR,NAHUR RD,MULUND WEST','','21','400080',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','122',NULL,'0','0',NULL,0,'2026-05-16 10:18:58','2026-05-16 10:18:58'),(505,'249',NULL,NULL,'JAJU ENTERPRISES',5,'810070','DR','97/17,AGRO INDUSTRIES ,','MARKET YARD , SOLAPUR','SOLAPUR','21','413005',NULL,'9881310982','',NULL,'27','27AHWPJ4437B1Z7','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6566',NULL,'0','0',NULL,0,'2026-05-16 10:18:58','2026-05-16 10:18:58'),(506,'249',NULL,NULL,'JAI SANTOSHI MATA PHARMACY',5,'0','DR','C/O RANE HOSPITAL','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43916','0.00',NULL,'0','0',NULL,'0','1320',NULL,'0','0',NULL,0,'2026-05-16 10:18:58','2026-05-16 10:18:58'),(507,'249',NULL,NULL,'JAI LAXMI MEDICAL',5,'0','DR','KAJUPADA','','','21','',NULL,'1111111111','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6404',NULL,'0','0',NULL,0,'2026-05-16 10:18:58','2026-05-16 10:18:58'),(508,'249',NULL,NULL,'J.RUTTONSEY TRADINGCO.',5,'0','DR','505A,NEELKANTH BLDG','MARINE DRIVE,MARINE LINE','MUMBAI','21','400002',NULL,'1111111111','',NULL,'27','27AACFJ2797H1Z3','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44036','0.00',NULL,'0','0',NULL,'0','1423',NULL,'0','0',NULL,0,'2026-05-16 10:18:58','2026-05-16 10:18:58'),(509,'249',NULL,NULL,'J.K BROTHERS',5,'0','DR','SHOP NO 81/4,RAJAWADI D COLONY','GHATKOPAR EAST','','21','400077',NULL,'','',NULL,'27','27ACVPT9446J1ZG','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43813','0.00',NULL,'0','0',NULL,'0','1227',NULL,'0','0',NULL,0,'2026-05-16 10:18:58','2026-05-16 10:18:58'),(510,'249',NULL,NULL,'INFINITE INTERIO',5,'0','DR','06 YAC INDUSTRIAL NEAR REGENT HOTEL KONDIVITA ROAD ANDHERI EAST','MUMBAI','mumbai','21','400059',NULL,'8850346529','',NULL,'27','27AXNPV0975D3ZY','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4200',NULL,'0','0',NULL,0,'2026-05-16 10:18:58','2026-05-16 10:18:58'),(511,'249',NULL,NULL,'II WALLS HOSPITALITY',5,'0','DR','KURLA','DEFAULT','','21','',NULL,'','',NULL,'27','27AAPFM9711M1ZK','','AXIS BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','165',NULL,'0','0',NULL,0,'2026-05-16 10:18:58','2026-05-16 10:18:58'),(512,'249',NULL,NULL,'II WALLS HOSPITALITY',5,'0','DR','BELAPUR','DEFAULT','','21','',NULL,'','',NULL,'27','27AAPFM9711M1ZK','','AXIS BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','166',NULL,'0','0',NULL,0,'2026-05-16 10:18:58','2026-05-16 10:18:58'),(513,'249',NULL,NULL,'II WALLS HOSPITALITY',5,'0','DR','ASHA USHA COMPD,MEHERA ESTATE','NR MAHINDRA SHOWROOM','','21','',NULL,'','',NULL,'27','27AAPFM9711M1ZK','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','148',NULL,'0','0',NULL,0,'2026-05-16 10:18:59','2026-05-16 10:18:59'),(514,'249',NULL,NULL,'HUNGER INC HOSPITALITY PVT LTD TBC',5,'0','DR','UNIT 1,PROCESS HOUSE,KAMLA CITY','SB MARG LOWER PAREL','MUMBAI','21','400013',NULL,'','',NULL,'27','27AADCH3020R1ZF','','KVB BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43727','0.00',NULL,'0','0',NULL,'0','754',NULL,'0','0',NULL,0,'2026-05-16 10:18:59','2026-05-16 10:18:59'),(515,'249',NULL,NULL,'HUNGER INC HOSPITALITY PVT LTD',5,'0','DR','O PEDRO, UNIT NO 2,JET AIRWAYS','GODREJ BKC,BANDRA EAST','MUMBAI 400051','21','400051',NULL,'1111111111','',NULL,'27','27AADCH3020R1ZF','','KVB BANK',NULL,NULL,'FORT','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43721','0.00',NULL,'0','0',NULL,'0','739',NULL,'0','0',NULL,0,'2026-05-16 10:18:59','2026-05-16 10:18:59'),(516,'249',NULL,NULL,'HOTEL WEST END',5,'0','DR','OPP BOMBAY HOSPITAL','MARINE LINES STATION','Mumbai','21','400020',NULL,'1111111111','',NULL,'27','27AAACW0047J1ZE','','BOI',NULL,NULL,'MUMBAI','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43743','0.00',NULL,'0','0',NULL,'0','975',NULL,'0','0',NULL,0,'2026-05-16 10:18:59','2026-05-16 10:18:59'),(517,'249',NULL,NULL,'HOTEL MAYFAIR PVT LTD',5,'0','DR','OPP GLORIA HIGH SCHOOL','BYCULLA EAST','mumbai','21','400011',NULL,'9820388051','',NULL,'27','27AAACH1782T1Z5','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4707',NULL,'0','0',NULL,0,'2026-05-16 10:18:59','2026-05-16 10:18:59'),(518,'249',NULL,NULL,'HOLS CHEF HOSPITALITY',5,'0','DR','BEHIND ICE FACTORY,NR RAHEJA VIHAR','CHANDIVLI,MUMBAI 72','mumbai','21','400072',NULL,'1111111111','',NULL,'27','27AADCH3662D1ZS','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','151',NULL,'0','0',NULL,0,'2026-05-16 10:18:59','2026-05-16 10:18:59'),(519,'249',NULL,NULL,'HOG TAPROOM',5,'0','DR','G9,Hosptilality & Catering','2nd Floor, Hotel Bahri Residency','Opp K Star Mall','21','400071',NULL,'','',NULL,'27','','','BHARAT BANK',NULL,NULL,'CHEMBUR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43749','0.00',NULL,'0','0',NULL,'0','1010',NULL,'0','0',NULL,0,'2026-05-16 10:18:59','2026-05-16 10:18:59'),(520,'249',NULL,NULL,'HINAL ENTERPRISES',5,'0','DR','273/277 ANANT DEEP CHAMBER SHOP NO. 1','BHAT BAZER NARSH NATHA STREET MASJID','MUMBAI','21','400009',NULL,'7021930395','',NULL,'27','27AMMPS6027P1Z6','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6398',NULL,'0','0',NULL,0,'2026-05-16 10:18:59','2026-05-16 10:18:59'),(521,'249',NULL,NULL,'HEM FOOD',5,'0','DR','GHATKOPAR','','Mumbai','21','400071',NULL,'9819099589','',NULL,'27','27AHQPD5066J1ZZ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4261',NULL,'0','0',NULL,0,'2026-05-16 10:18:59','2026-05-16 10:18:59'),(522,'249',NULL,NULL,'HAYAAT PLUS MEDICAL',5,'0','DR','EXCEL REISDENCY, SHOP NO 1TO 5','DOCKYARD RLY STN','MUMBAI','21','400010',NULL,'1111111111','',NULL,'27','27AKDPB0733E2ZT','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1355',NULL,'0','0',NULL,0,'2026-05-16 10:18:59','2026-05-16 10:18:59'),(523,'249',NULL,NULL,'HAYAAT PLUS CHEMIST',5,'0','DR','SHOP NO 2,2A/2B, ZOHRA MANZIL','DONGRI','MUMBAI','21','400009',NULL,'1111111111','',NULL,'27','27AAKFH1056P1ZY','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1356',NULL,'0','0',NULL,0,'2026-05-16 10:19:00','2026-05-16 10:19:00'),(524,'249',NULL,NULL,'HAYAAT PHARMACY',5,'0','DR','SHOP 1,22/24,K.B.J MANSION','MAHIM WEST','Mumbai','21','400016',NULL,'1111111111','',NULL,'27','27AAIFH5996E1ZY','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43951','0.00',NULL,'0','0',NULL,'0','1354',NULL,'0','0',NULL,0,'2026-05-16 10:19:00','2026-05-16 10:19:00'),(525,'249',NULL,NULL,'HAYAAT CHEMIST',5,'0','DR','SHOP NO 1/4,LOVE LANE','MAZGAON','Mumbai','21','400010',NULL,'1111111111','',NULL,'27','27AALFH6846G1Z0','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1357',NULL,'0','0',NULL,0,'2026-05-16 10:19:00','2026-05-16 10:19:00'),(526,'249',NULL,NULL,'HARSH TRADING COMPANY',5,'0','DR','223,AVON ARCADE,2ND FLR','D.J RD,VILEPARLE (W)','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','125',NULL,'0','0',NULL,0,'2026-05-16 10:19:00','2026-05-16 10:19:00'),(527,'249',NULL,NULL,'HARE KRISHNA GROUP',5,'0','DR','SHOP NO 3/4,KHODIYAR NIWAS,','LOKMANYA TILAK NGR,SAKINAKA','MUMBAI','21','400072',NULL,'','',NULL,'27','27AALFH0007R1Z4','','KNS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'3.02E+16','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43826','0.00',NULL,'0','0',NULL,'0','1250',NULL,'0','0',NULL,0,'2026-05-16 10:19:00','2026-05-16 10:19:00'),(528,'249',NULL,NULL,'GURUKUL COACHING CLASSES',5,'0','DR','KAJUPADA','','','21','',NULL,'','',NULL,'27','','','CORPORATION',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43868','0.00',NULL,'0','0',NULL,'0','1288',NULL,'0','0',NULL,0,'2026-05-16 10:19:00','2026-05-16 10:19:00'),(529,'249',NULL,NULL,'GUNJAN STORES',5,'0','DR','GROUND FLOOR G-16 NEW ANANT BHAVAN','NARSHI STREET MASJID BUNDER','MUMBAI','21','400009',NULL,'1111111111','',NULL,'27','27AAHPM2742E1ZV','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5991',NULL,'0','0',NULL,0,'2026-05-16 10:19:00','2026-05-16 10:19:00'),(530,'249',NULL,NULL,'GRAND CENTRAL HOTEL',5,'0','DR','CHEMBUR','OPP CHEMBUR STATION','mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AHZPS2453D2ZU','','HDFC BANK',NULL,NULL,'CHEMBUR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','232',NULL,'0','0',NULL,0,'2026-05-16 10:19:00','2026-05-16 10:19:00'),(531,'249',NULL,NULL,'GODREJ & BOYCE MANUFACTURING CO',5,'0','DR','UDAYACHAL HIGH SCHOOL,NEAR PRAGATI KENDRA','VIKHROLI EAST','MUMBAI','21','400079',NULL,'9819039787','',NULL,'27','27AAACG1395D1ZU','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4958',NULL,'0','0',NULL,0,'2026-05-16 10:19:00','2026-05-16 10:19:00'),(532,'249',NULL,NULL,'GODREJ & BOYCE MANUFACTURING CO',5,'0','DR','CANTEEN STORE PLANT 13','ANNEX GRD FLR,VIKHROLI','MUMBAI','21','400079',NULL,'','',NULL,'27','27AAACG1395D1ZU','','NEFT',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','274',NULL,'0','0',NULL,0,'2026-05-16 10:19:00','2026-05-16 10:19:00'),(533,'249',NULL,NULL,'GODREJ & BOYCE CO.',5,'0','DR','IDC 1ST FLOOR, PLANT 13','ANNEX,VIKHROLI EAST','MUMBAI','21','400079',NULL,'','',NULL,'27','27AAACG1395D1ZU','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1304',NULL,'0','0',NULL,0,'2026-05-16 10:19:01','2026-05-16 10:19:01'),(534,'249',NULL,NULL,'GEETA MOURYA',5,'0','DR','MULUND','','','21','',NULL,'1234567890','',NULL,'27','','','BOB',NULL,NULL,'MULUND','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4471',NULL,'0','0',NULL,0,'2026-05-16 10:19:01','2026-05-16 10:19:01'),(535,'249',NULL,NULL,'GAURI ENTERPRISES (DB)',5,'0','DR','EDEN VILLA, MHADA COLONY','MULUND EAST','mumbai','21','400081',NULL,'1111111111','',NULL,'27','27AYJPB8601K1ZC','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43759','0.00',NULL,'0','0',NULL,'0','1061',NULL,'0','0',NULL,0,'2026-05-16 10:19:01','2026-05-16 10:19:01'),(536,'249',NULL,NULL,'GANESH FARSAN',5,'0','DR','SHELL COLONY CHEMBUR','','mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AAWPN7121M1ZZ','','DENA BANK',NULL,NULL,'CHEMBUR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','278',NULL,'0','0',NULL,0,'2026-05-16 10:19:01','2026-05-16 10:19:01'),(537,'249',NULL,NULL,'FRESH CHOICE FOOD BAZAAR',5,'0','DR','SHOP NO 2,ECO RESIDENCY,OPP VASANT OASIS,','MILTARY RD,MAROL,ANDHERI (E)','Mumbai','21','400059',NULL,'1111111111','',NULL,'27','27AAHFF1738K1Z8','','ICICI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44103','0.00',NULL,'0','0',NULL,'0','1479',NULL,'0','0',NULL,0,'2026-05-16 10:19:01','2026-05-16 10:19:01'),(538,'249',NULL,NULL,'FOUZIYA HOSPITAL CANTEEN',5,'0','DR','ABS ROAD KURLA UR WEST','','','21','',NULL,'9372130834','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4185',NULL,'0','0',NULL,0,'2026-05-16 10:19:01','2026-05-16 10:19:01'),(539,'249',NULL,NULL,'FLAVOUR KRAFT CATERERS',5,'88902','DR','KJ SOMAIYA HOSPITAL OF PHYSIOTHERAPY','AYURVIHAR COMPLEX SION EAST','Mumbai','21','400022',NULL,'1111111111','',NULL,'27','27CYCPM4162R1ZS','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','144',NULL,'0','0',NULL,0,'2026-05-16 10:19:01','2026-05-16 10:19:01'),(540,'249',NULL,NULL,'FC EDUCATION SERVICES PVT LTD',5,'0','DR','UNIT 10,DEVJI KESHAVJI INDL ESTATE','NR VANMALI CHS,OPP SHATABDI','HOSPITAL, GOVANDI','21','400071',NULL,'','',NULL,'27','27AACCF7596H1Z6','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43829','0.00',NULL,'0','0',NULL,'0','1255',NULL,'0','0',NULL,0,'2026-05-16 10:19:01','2026-05-16 10:19:01'),(541,'249',NULL,NULL,'FARIYAS HOTEL PVT LTD',5,'0','DR','25 OFF ARTHUR BUNDER','COLABA','MUMBAI','21','400005',NULL,'9594968407','',NULL,'27','27AAACF0225F1Z8','','IDBI',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43928','0.00',NULL,'0','0',NULL,'0','1334',NULL,'0','0',NULL,0,'2026-05-16 10:19:01','2026-05-16 10:19:01'),(542,'249',NULL,NULL,'Emami Limited',5,'0','DR','A-3,Godown No 9 To 12,Shree Ganesh Complex','','Thane','21','421302',NULL,'9100000000','',NULL,'27','27AAACH7412G1ZT','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6204',NULL,'0','0',NULL,0,'2026-05-16 10:19:01','2026-05-16 10:19:01'),(543,'249',NULL,NULL,'ESQUIRE EXPORTERS',5,'50929','DR','LAL DONGAR','DEFAULT','mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AAAFE0388F1ZN','','KOTAK',NULL,NULL,'CHEMBUR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','142',NULL,'0','0',NULL,0,'2026-05-16 10:19:02','2026-05-16 10:19:02'),(544,'249',NULL,NULL,'ENKAY SOLUTIONS',5,'0','DR','A/G4,GRD FLR, BLDG NO 21','TILAK NGR,GURUKRUPA CHS','MUMBAI','21','400089',NULL,'8365214781','',NULL,'27','27ANDPR1784Q1Z6','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6397',NULL,'0','0',NULL,0,'2026-05-16 10:19:02','2026-05-16 10:19:02'),(545,'249',NULL,NULL,'EMPIRE INDUSTRIES LTD',5,'18781','DR','414,EMPIRE COMPLEX,LOWER PAREL','MUMBAI 13','Mumbai','21','400013',NULL,'1111111111','',NULL,'27','27AAACE2757R1Z3','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','119',NULL,'0','0',NULL,0,'2026-05-16 10:19:02','2026-05-16 10:19:02'),(546,'249',NULL,NULL,'EMERALD LEISURES LTD',5,'0','DR','CLUB EMERALD','SWASTIK PARK NR MANGAL ANAND HOSP','MUMBAI','21','400071',NULL,'9223379085','',NULL,'27','27AACCA3326L1ZQ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4264',NULL,'0','0',NULL,0,'2026-05-16 10:19:02','2026-05-16 10:19:02'),(547,'249',NULL,NULL,'ECO PACKAGING',5,'29','CR','06 YAC INDUSTRIAL NEAR REGENT HOTEL KONDIVITA ROAD ANDHERI EAST','','mumbai','21','400059',NULL,'9892187279','',NULL,'27','27ANPPP4722J1ZI','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4274',NULL,'0','0',NULL,0,'2026-05-16 10:19:02','2026-05-16 10:19:02'),(548,'249',NULL,NULL,'DR. TILAKRAJ SHARMA',5,'0','DR','NR. KALPATARU RESIDENCY','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1773',NULL,'0','0',NULL,0,'2026-05-16 10:19:02','2026-05-16 10:19:02'),(549,'249',NULL,NULL,'DNYANESHWAR LOKHANDE',5,'0','DR','MUMBAI','','','21','',NULL,'','',NULL,'27','','','JANKALYAN',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43932','0.00',NULL,'0','0',NULL,'0','1338',NULL,'0','0',NULL,0,'2026-05-16 10:19:02','2026-05-16 10:19:02'),(550,'249',NULL,NULL,'DHRUV ENTERPRISES',5,'0','DR','BLG NO 1,WING -C,PLOT NO 4,ROOM NO 5,','INDRAYANI NAGARI NIVARA CHS LTD,GEN A.K VAIDYA MARG,FILM CITY RD,GOREGAON (E)','MUMBAI','21','400065',NULL,'1234567890','',NULL,'27','27CPLPS8783N1ZK','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5481',NULL,'0','0',NULL,0,'2026-05-16 10:19:02','2026-05-16 10:19:02'),(551,'249',NULL,NULL,'DHIRU KAKA',5,'5969','DR','GHATKOPAR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1794',NULL,'0','0',NULL,0,'2026-05-16 10:19:02','2026-05-16 10:19:02'),(552,'249',NULL,NULL,'DESIRE BEVERAGES LLP',5,'0','DR','SHOP NO 4 RADHIKA RESENDENCY','MANDAKNI ROAD','','21','',NULL,'222524343','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4472',NULL,'0','0',NULL,0,'2026-05-16 10:19:02','2026-05-16 10:19:02'),(553,'249',NULL,NULL,'DESIRE BEVERAGES LLP',11,'0','DR','SHOP NO 4','RADHIKA RESIDENLY','','21','',NULL,'2225243434','',NULL,'27','27AAMFD6088R1ZE','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4474',NULL,'0','0',NULL,0,'2026-05-16 10:19:03','2026-05-16 10:19:03'),(554,'249',NULL,NULL,'DEEPA RESTAURANT',5,'0','DR','NEAR SHREYAS NAKA LBS MARG','GHATKOPAR WEST','','21','',NULL,'9769384735','',NULL,'27','27APLPS2987L2ZV','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','235',NULL,'0','0',NULL,0,'2026-05-16 10:19:03','2026-05-16 10:19:03'),(555,'249',NULL,NULL,'DECENT DEPARTMENTAL STORE',5,'0','DR','SHOP NO1,BANDRA NATRAJ CHS','HILL RD,BANDRA (W)','mumbai','21','400050',NULL,'8356098822','',NULL,'27','27AANFD5157C1ZG','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4835',NULL,'0','0',NULL,0,'2026-05-16 10:19:03','2026-05-16 10:19:03'),(556,'249',NULL,NULL,'DARSHAN SANGOI',5,'0','DR','BHATH BAZAR','','','21','',NULL,'9819191919','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4449',NULL,'0','0',NULL,0,'2026-05-16 10:19:03','2026-05-16 10:19:03'),(557,'249',NULL,NULL,'DARSHAN MEHTA HUF',5,'0','DR','INLAC HOSPITAL','MUMBAI','mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AAKHD0932Q1ZX','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1725',NULL,'0','0',NULL,0,'2026-05-16 10:19:03','2026-05-16 10:19:03'),(558,'249',NULL,NULL,'DARSHAN KETAN SANGOI',5,'0','DR','MUMBAI','','','21','',NULL,'9819420420','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4199',NULL,'0','0',NULL,0,'2026-05-16 10:19:03','2026-05-16 10:19:03'),(559,'249',NULL,NULL,'D B C SWAMI VIVEKANAND SCHOOL',5,'0','DR','DEFAULT','DEFAULT','','21','',NULL,'','',NULL,'27','27AAATV2239C1ZP','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','150',NULL,'0','0',NULL,0,'2026-05-16 10:19:03','2026-05-16 10:19:03'),(560,'249',NULL,NULL,'CRYSTAL TRADING',5,'0','DR','SHOP NO 41,NANDLAL JANI RD','OPP KURLA STREET,MASJID BUNDER','MUMBAI','21','400009',NULL,'8291696402','',NULL,'27','27ACDPL5244J1ZI','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','ACDPL5244L','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1610',NULL,'0','0',NULL,0,'2026-05-16 10:19:03','2026-05-16 10:19:03'),(561,'249',NULL,NULL,'CLASSIC CATERING SERVICES',5,'0','DR','SOMAIYA HOSPITAL','ENGINEERING COLLEGE','','21','',NULL,'','',NULL,'27','','','SBI',NULL,NULL,'BELAPUR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','276',NULL,'0','0',NULL,0,'2026-05-16 10:19:03','2026-05-16 10:19:03'),(562,'249',NULL,NULL,'CHANDAN PALACE BAR & RESTAURANT',5,'0','DR','GHATKOPAR EAST GARODIYA NAGAR','','','21','',NULL,'8879253278','',NULL,'27','27AYBPS6630F1ZD','','AXIS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4323',NULL,'0','0',NULL,0,'2026-05-16 10:19:03','2026-05-16 10:19:03'),(563,'249',NULL,NULL,'CATALYST OVERSEAS TRADING LLP',5,'0','DR','ROOM NO 17,PRABHA SMRITI','S T RD, MULUND EAST','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','127',NULL,'0','0',NULL,0,'2026-05-16 10:19:04','2026-05-16 10:19:04'),(564,'249',NULL,NULL,'CASH (WD)',5,'0','DR','WS','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43779','0.00',NULL,'0','0',NULL,'0','1177',NULL,'0','0',NULL,0,'2026-05-16 10:19:04','2026-05-16 10:19:04'),(565,'249',NULL,NULL,'CASH (VM)',5,'0','DR','MUMBAI','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43800','0.00',NULL,'0','0',NULL,'0','1198',NULL,'0','0',NULL,0,'2026-05-16 10:19:04','2026-05-16 10:19:04'),(566,'249',NULL,NULL,'CASH (V.B)',5,'0','DR','MUMBAI','','','21','',NULL,'','',NULL,'27','','','BOB',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43801','0.00',NULL,'0','0',NULL,'0','1200',NULL,'0','0',NULL,0,'2026-05-16 10:19:04','2026-05-16 10:19:04'),(567,'249',NULL,NULL,'CASH (DE)',5,'0','DR','OVER THE COUNTER','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44078','0.00',NULL,'0','0',NULL,'0','1450',NULL,'0','0',NULL,0,'2026-05-16 10:19:04','2026-05-16 10:19:04'),(568,'249',NULL,NULL,'CASH',5,'535129','DR','OVER THE COUNTER','','','21','',NULL,'','',NULL,'27','','','IMPS',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','251',NULL,'0','0',NULL,0,'2026-05-16 10:19:04','2026-05-16 10:19:04'),(569,'249',NULL,NULL,'Bliss Enterprises',5,'0','DR','Grd Flr,Dattaram Koyande Marg,Belvedre','Mazgaon','Mumbai','21','400010',NULL,'9320399979','',NULL,'27','27AUKPM8810A1ZQ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6475',NULL,'0','0',NULL,0,'2026-05-16 10:19:04','2026-05-16 10:19:04'),(570,'249',NULL,NULL,'Bhanu Traders',5,'0','DR','SAI BABA HSG SOC F2 ASALPHA VILLAGE','GHATKOPAR WEST','Mumbai','21','400086',NULL,'9404215553','',NULL,'27','27AFIPB9325E1ZM','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6227',NULL,'0','0',NULL,0,'2026-05-16 10:19:04','2026-05-16 10:19:04'),(571,'249',NULL,NULL,'BRANDAVAN FOOD PRODUCTS',5,'0','DR','COMEUM THE FOOD JUNCTION','MUMBAI CENTERAL RLY STAION','mumbai','21','400008',NULL,'1147100200','',NULL,'27','27AAGFB5137P1Z2','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','281',NULL,'0','0',NULL,0,'2026-05-16 10:19:04','2026-05-16 10:19:04'),(572,'249',NULL,NULL,'BOTREE BILL CUSTOMERS',5,'0','DR','BOTREE','','','21','',NULL,'','',NULL,'27','','','SHAMRAO',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43909','0.00',NULL,'0','0',NULL,'0','1313',NULL,'0','0',NULL,0,'2026-05-16 10:19:04','2026-05-16 10:19:04'),(573,'249',NULL,NULL,'BOMBAY GRAPHICS',5,'0','DR','45A,GRD FLOOR, SHAH & NAHAR INDL','ESTATE,LOWER PAREL','MUMBAI','21','400013',NULL,'8268539133','',NULL,'27','27AGJPP2619R1ZN','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4533',NULL,'0','0',NULL,0,'2026-05-16 10:19:05','2026-05-16 10:19:05'),(574,'249',NULL,NULL,'BLUE PEARL FOUNDATION',5,'0','DR','PL LOKHANDE MRG,CHEMBUR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43810','0.00',NULL,'0','0',NULL,'0','1215',NULL,'0','0',NULL,0,'2026-05-16 10:19:05','2026-05-16 10:19:05'),(575,'249',NULL,NULL,'BIG DEALS 24X7',5,'0','DR','704A,PRAMILA APT,OPP KALINA UNIV','SANTACRUZ EAST, MUMBAI','','21','400098',NULL,'8097262491','',NULL,'27','27AARFB8088L1ZJ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4763',NULL,'0','0',NULL,0,'2026-05-16 10:19:05','2026-05-16 10:19:05'),(576,'249',NULL,NULL,'BHARAT ENGINEERS',5,'0','DR','1ST FLR,BLDG 150,PANT NGR PARIVARTAN CHS','PANT NAGAR,GHATKOPAR EAST','MUMBAI','21','400075',NULL,'9820260639','',NULL,'27','27AJEPG2942G1ZF','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4770',NULL,'0','0',NULL,0,'2026-05-16 10:19:05','2026-05-16 10:19:05'),(577,'249',NULL,NULL,'BHAGWATI TRADERS',5,'0','DR','AT SOANGAON POST SAYKHEDA','DIST NASHIK','NASHIK','21','422210',NULL,'','',NULL,'27','27BEYPC9311K1ZZ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43849','0.00',NULL,'0','0',NULL,'0','1276',NULL,'0','0',NULL,0,'2026-05-16 10:19:05','2026-05-16 10:19:05'),(578,'249',NULL,NULL,'BAVISHI ENTERPRISES',5,'0','DR','GD 3/4,SUYOG INDL ESTATE','OPP VITRUM GLASS FACT, LBS MARG','VIKHROLI','21','',NULL,'9820428075','',NULL,'27','','27ABPPB0492H1ZN','UNION BANK',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4352',NULL,'0','0',NULL,0,'2026-05-16 10:19:05','2026-05-16 10:19:05'),(579,'249',NULL,NULL,'BARC SCHOOL NO 6',5,'0','DR','BARC','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','250',NULL,'0','0',NULL,0,'2026-05-16 10:19:05','2026-05-16 10:19:05'),(580,'249',NULL,NULL,'BANDRINGA FOODS AND BEVERAGES PVT LTD',5,'0','DR','A301,Ali Bilal Siddhi Bldg,S.G Barve Mrg','Kurla East','MUMBAI','21','400024',NULL,'8080189505','',NULL,'27','27AAKCB4426A1Z1','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5893',NULL,'0','0',NULL,0,'2026-05-16 10:19:05','2026-05-16 10:19:05'),(581,'249',NULL,NULL,'BALAJI TRADERS',5,'156193','DR','SOYEGAON MARKET SATANA MALEGAON','','MUMBAI','21','423203',NULL,'1.11E+14','',NULL,'27','27AOEPS6558R1ZU','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6523',NULL,'0','0',NULL,0,'2026-05-16 10:19:05','2026-05-16 10:19:05'),(582,'249',NULL,NULL,'B.P.C.L',5,'0','DR','B.T.E.C PLOT NO 6,SECTOR 2,BEHIND','CIDCO GARDEN,KHARGHAR,','NAVI MUMBAI','21','410210',NULL,'9967288655','',NULL,'27','27AAACB2902M1ZT','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1804',NULL,'0','0',NULL,0,'2026-05-16 10:19:05','2026-05-16 10:19:05'),(583,'249',NULL,NULL,'Arham Enterprises',5,'40133','DR','R NO 17, DOMNIC CHAWL','NR REEMA COMPLXVIDHYAVIHAR WEST','MUMBAI','21','400086',NULL,'9820397484','',NULL,'27','27AFAPJ5167N1Z3','','JANKALYAN',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','252',NULL,'0','0',NULL,0,'2026-05-16 10:19:06','2026-05-16 10:19:06'),(584,'249',NULL,NULL,'Amarjit Singh',5,'0','DR','Nr Gopal Dairy','IIT Market','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43890','0.00',NULL,'0','0',NULL,'0','1302',NULL,'0','0',NULL,0,'2026-05-16 10:19:06','2026-05-16 10:19:06'),(585,'249',NULL,NULL,'Aditya Birla New Age Hospitality Private Limited',5,'0','DR','B-WING , 5TH FLOOR , BIRLA CENTURION ,','CENTURY MILLS , WORLI , MUMBAI','MUMBAI','21','400030',NULL,'8149870351','',NULL,'27','27AADCK9508M1Z1','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6580',NULL,'0','0',NULL,0,'2026-05-16 10:19:06','2026-05-16 10:19:06'),(586,'249',NULL,NULL,'ARROW ELECTRICALS INDIA LIMITED',5,'0','DR','11a 11b k.t. industrial park gorai pada','KT Industrial Park ,Vasai (E) VasaiVirar','PALGHAR','21','401208',NULL,'8135976984','',NULL,'27','27AATCA7251M1ZZ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4315',NULL,'0','0',NULL,0,'2026-05-16 10:19:06','2026-05-16 10:19:06'),(587,'249',NULL,NULL,'ARPAN BLOOD BANK',5,'0','DR','ANIRAJ TOWER SECOND FLOOR JANTA MARKET OPP METRO MALL','','','21','',NULL,'7507771544','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4237',NULL,'0','0',NULL,0,'2026-05-16 10:19:06','2026-05-16 10:19:06'),(588,'249',NULL,NULL,'ANVIKSHA BLOOD BANK',5,'1308','DR','GHATKOPAR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','279',NULL,'0','0',NULL,0,'2026-05-16 10:19:06','2026-05-16 10:19:06'),(589,'249',NULL,NULL,'ANUMATI SUPERMARKET',5,'177913','DR','SHOP 1 ,2 & 3 , SHOPPING VILLAGE , NR. ROYAL PALMS','HOTEL , MASTER MIND 4 , GOREGAON (E)','MUMBAI','21','400065',NULL,'7400226976','',NULL,'27','27BAXPP9744A1Z3','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6577',NULL,'0','0',NULL,0,'2026-05-16 10:19:06','2026-05-16 10:19:06'),(590,'249',NULL,NULL,'ANNAPURNA ENTERPRISES',11,'0','DR','JHONE ROBERT COMPOUND SEWREE (EAST)','','MUMBAI','21','400015',NULL,'7875130642','annapurnaenterprises1982@gmail.com',NULL,'27','27AREPG4638B1Z4','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6472',NULL,'0','0',NULL,0,'2026-05-16 10:19:06','2026-05-16 10:19:06'),(591,'249',NULL,NULL,'ANKIT BHARAT SHAH',5,'300317','CR','GHATKOPAR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44114','0.00',NULL,'0','0',NULL,'0','1492',NULL,'0','0',NULL,0,'2026-05-16 10:19:06','2026-05-16 10:19:06'),(592,'249',NULL,NULL,'ANIKET',5,'3177','DR','PESTOM SAGAR','','','21','',NULL,'11111111111','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4774',NULL,'0','0',NULL,0,'2026-05-16 10:19:06','2026-05-16 10:19:06'),(593,'249',NULL,NULL,'ANANDA DEVKATE',5,'0','DR','*123','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1718',NULL,'0','0',NULL,0,'2026-05-16 10:19:07','2026-05-16 10:19:07'),(594,'249',NULL,NULL,'AMAFHH FINISHERS',5,'0','DR','BHARAT GALVANIZING COMPD,','LBS MRG,OPP TUBE MILLS','VIKHROLI','21','400083',NULL,'8742369832','',NULL,'27','27AAAPH4095E1ZX','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4534',NULL,'0','0',NULL,0,'2026-05-16 10:19:07','2026-05-16 10:19:07'),(595,'249',NULL,NULL,'ALWAYS FRESH',11,'0','DR','CHAWL 341,ROOM NO 4124,','GROUP NO 3 TAGORE NAGAR VIKROLI (EAST)','MUMBAI','21','400083',NULL,'9987259431','',NULL,'27','27AOYPP1333H1ZJ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6489',NULL,'0','0',NULL,0,'2026-05-16 10:19:07','2026-05-16 10:19:07'),(596,'249',NULL,NULL,'ALKO ENTERPRISES',5,'0','DR','92,PATEL VAS,NR MAHAKALI MANDIR','VANDHIYA,DIST BHARUCH','KUTCH GUJARAT','21','370150',NULL,'7874748371','',NULL,'27','24GBSPD1472E1ZQ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4509',NULL,'0','0',NULL,0,'2026-05-16 10:19:07','2026-05-16 10:19:07'),(597,'249',NULL,NULL,'AJIT KAKA',5,'3181','DR','PUNAM','','','21','',NULL,'','',NULL,'27','','','GPAY 2063',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43843','0.00',NULL,'0','0',NULL,'0','1268',NULL,'0','0',NULL,0,'2026-05-16 10:19:07','2026-05-16 10:19:07'),(598,'249',NULL,NULL,'AGARWAL KIRANA',5,'0','DR','TULJAPUR','','','21','',NULL,'','',NULL,'27','','27AKSPA0929Q1ZL','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','256',NULL,'0','0',NULL,0,'2026-05-16 10:19:07','2026-05-16 10:19:07'),(599,'249',NULL,NULL,'ADITYA CATERERS',5,'0','DR','VES COLLEGE,COLLECTOR COL','CHEMBUR 74','mumba','21','400071',NULL,'1111111111','',NULL,'27','27ANKPS2095J1ZE','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','228',NULL,'0','0',NULL,0,'2026-05-16 10:19:07','2026-05-16 10:19:07'),(600,'249',NULL,NULL,'ADITYA BIRLA NEW AGE RESTAURANT & CAFE PRIVATE LTD',5,'23712','DR','2 ND FLOOR BULD NO 213 TV INDUSTRIAL ESTATE','52 S K AHIRE MARG WORLI VILLAGE','MUMBAI','21','400030',NULL,'1111111111','',NULL,'27','27AAWCA5360J1Z4','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6505',NULL,'0','0',NULL,0,'2026-05-16 10:19:07','2026-05-16 10:19:07'),(601,'249',NULL,NULL,'ACHARAY COLLAGE',5,'0','DR','CHEMBUR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','263',NULL,'0','0',NULL,0,'2026-05-16 10:19:07','2026-05-16 10:19:07'),(602,'249',NULL,NULL,'ACE INTERGLOBE',5,'0','DR','108,MAHINDRA CHAMBERS,OPP DUKES','CHEMBUR,MUMBAI71','mumbai','21','400071',NULL,'1111111111','',NULL,'27','27AAZFA9540N1ZH','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','138',NULL,'0','0',NULL,0,'2026-05-16 10:19:07','2026-05-16 10:19:07'),(603,'249',NULL,NULL,'ACE EXPORTS',5,'88173','DR','PLOT NO D-123,TTC,MIDC,NODE NERUL','SHIRVANE THANE','mumbai','21','400706',NULL,'9022399979','',NULL,'27','27ABVFA9948B1ZW','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4884',NULL,'0','0',NULL,0,'2026-05-16 10:19:08','2026-05-16 10:19:08'),(604,'249',NULL,NULL,'ABHAY MULTIPRO',5,'0','DR','TILAK NAGAR','MUMBAI','mumbai','21','400089',NULL,'1111111111','',NULL,'27','27AAJPM8079L1ZW','','SARASWAT',NULL,NULL,'CHEMBUR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','123',NULL,'0','0',NULL,0,'2026-05-16 10:19:08','2026-05-16 10:19:08'),(605,'249',NULL,NULL,'AASIKA CATERING SERVICES',5,'0','DR','SOMAIYA COLLEGE','DEFAULT','mumbai','21','400077',NULL,'1111111111','',NULL,'27','27EOUPS8693F1ZR','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','145',NULL,'0','0',NULL,0,'2026-05-16 10:19:08','2026-05-16 10:19:08'),(606,'249',NULL,NULL,'A.P.FOODS',5,'18225','DR','D-905 AGARWAL RESIDENCY','SHANKAR LANE KANDIVALI','MUMBAI','21','400067',NULL,'1111111111','',NULL,'27','27ANRPS4136M1Z7','','NEFT',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','261',NULL,'0','0',NULL,0,'2026-05-16 10:19:08','2026-05-16 10:19:08'),(607,'249',NULL,NULL,'A.N MAKHIJANI',5,'0','DR','CST STATION PF 14','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43737','0.00',NULL,'0','0',NULL,'0','920',NULL,'0','0',NULL,0,'2026-05-16 10:19:08','2026-05-16 10:19:08'),(608,'249',NULL,NULL,'A.J.S CATERERS (MUMBAI CENTRAL)',5,'0','DR','MUMBAI CENTRAL','','','21','',NULL,'','',NULL,'27','27ABAFA6497Q1ZO','','UCO BANK',NULL,NULL,'CHEMBUR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','255',NULL,'0','0',NULL,0,'2026-05-16 10:19:08','2026-05-16 10:19:08'),(609,'249',NULL,NULL,'A.J.S CATERERS (BANDRA TERMINUS)',5,'0','DR','BANDRA TERMINUS','','','21','',NULL,'','',NULL,'27','27ABAFA6497Q1ZO','','UCO',NULL,NULL,'CHEMBUR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','260',NULL,'0','0',NULL,0,'2026-05-16 10:19:08','2026-05-16 10:19:08'),(610,'249',NULL,NULL,'A.J.S CATERERS',5,'0','DR','TILAK NAGAR TERMINUS','','mumbai','21','400089',NULL,'1111111111','',NULL,'27','27ABAFA6497Q1ZO','','UCO BANK',NULL,NULL,'CHEMBUR','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','248',NULL,'0','0',NULL,0,'2026-05-16 10:19:08','2026-05-16 10:19:08'),(611,'249',NULL,NULL,'A.J.S CATERERS',5,'0','DR','CHURCHGATE','','','21','',NULL,'','',NULL,'27','27ABAFA6497Q1ZO','','UCO',NULL,NULL,'','4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43816','0.00',NULL,'0','0',NULL,'0','1233',NULL,'0','0',NULL,0,'2026-05-16 10:19:08','2026-05-16 10:19:08'),(612,'249',NULL,NULL,'Scalable Hospitality management & canteen',5,'2459','DR','SRV Hospital,Tilak Nagar','','','21','',NULL,'9920523524','',NULL,'27','','','IMPS',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6407',NULL,'0','0',NULL,0,'2026-05-16 10:19:08','2026-05-16 10:19:08'),(613,'249',NULL,NULL,'SIDDHI SERVICES (MANGEMENT)',5,'0','DR','VIDHYAVIHAR','SOMAIYA COLLAGE','Mumbai','21','400089',NULL,'1111111111','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','237',NULL,'0','0',NULL,0,'2026-05-16 10:19:09','2026-05-16 10:19:09'),(614,'249',NULL,NULL,'SIDDHI SERVICES (ENGINEERING)',5,'6458','DR','AUROBINDU VIDHYAVIHAR','SOMAIYA COLLEGE','mumbai','21','400076',NULL,'9619289791','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','236',NULL,'0','0',NULL,0,'2026-05-16 10:19:09','2026-05-16 10:19:09'),(615,'249',NULL,NULL,'SIDDHI SERVICES (AUROBINDU)',5,'4006','DR','VIDHYAVIHAR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','238',NULL,'0','0',NULL,0,'2026-05-16 10:19:09','2026-05-16 10:19:09'),(616,'249',NULL,NULL,'SHIVSHAKTI FOODS',5,'0','DR','LTT','','Mumbai','21','400089',NULL,'1111111111','',NULL,'27','27BBBPA8798N1ZZ','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44175','0.00',NULL,'0','0',NULL,'0','1618',NULL,'0','0',NULL,0,'2026-05-16 10:19:09','2026-05-16 10:19:09'),(617,'249',NULL,NULL,'SHAILADEVI  STALL PF - 1 (V.T SIDE)',5,'0','DR','NR TILAK NGR','TICKET COUNTER,9098700492','Mumbai','21','400089',NULL,'9098700492','',NULL,'27','27CXIPD6176R1ZN','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44234','0.00',NULL,'0','0',NULL,'0','1705',NULL,'0','0',NULL,0,'2026-05-16 10:19:09','2026-05-16 10:19:09'),(618,'249',NULL,NULL,'S.A TADVI',5,'0','DR','LTT','','','21','',NULL,'9111111111','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5600',NULL,'0','0',NULL,0,'2026-05-16 10:19:09','2026-05-16 10:19:09'),(619,'249',NULL,NULL,'S D JADHAV KOMACHA',5,'0','DR','VIDHYAVIHAR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','253',NULL,'0','0',NULL,0,'2026-05-16 10:19:09','2026-05-16 10:19:09'),(620,'249',NULL,NULL,'S D JADHAV',5,'0','DR','VIDHYAVIHAR','9320943071','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','134',NULL,'0','0',NULL,0,'2026-05-16 10:19:09','2026-05-16 10:19:09'),(621,'249',NULL,NULL,'N.R VAJRANI TS1 CLD DRINK',5,'0','DR','PF 1 SION','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44263','0.00',NULL,'0','0',NULL,'0','1736',NULL,'0','0',NULL,0,'2026-05-16 10:19:09','2026-05-16 10:19:09'),(622,'249',NULL,NULL,'N R VAJRANI T.S 2/3',5,'0','DR','SION STN','7506002235','','21','',NULL,'','',NULL,'27','','','IMPS',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','133',NULL,'0','0',NULL,0,'2026-05-16 10:19:09','2026-05-16 10:19:09'),(623,'249',NULL,NULL,'N R VAJRANI T.S 1',5,'0','DR','SION STN','8291198055','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','131',NULL,'0','0',NULL,0,'2026-05-16 10:19:10','2026-05-16 10:19:10'),(624,'249',NULL,NULL,'N R VAJRANI KHOMCHA 1',5,'0','DR','SION STN','9920142958','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','130',NULL,'0','0',NULL,0,'2026-05-16 10:19:10','2026-05-16 10:19:10'),(625,'249',NULL,NULL,'N R VAJRANI KHMOCHA 2/3',5,'0','DR','SION STN','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','132',NULL,'0','0',NULL,0,'2026-05-16 10:19:10','2026-05-16 10:19:10'),(626,'249',NULL,NULL,'MULTIPURPOSE STALL',5,'0','DR','LTT NR WAITING HALL','','','21','',NULL,'9111111111','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5589',NULL,'0','0',NULL,0,'2026-05-16 10:19:10','2026-05-16 10:19:10'),(627,'249',NULL,NULL,'M.R ENTERPRISES',5,'0','DR','LTT','53/3A,NR MAHALAXMI MANDIR','BHUSAWAL,JALGAON','21','425201',NULL,'','',NULL,'27','27DLCPK7297H1ZM','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1548',NULL,'0','0',NULL,0,'2026-05-16 10:19:10','2026-05-16 10:19:10'),(628,'249',NULL,NULL,'M K JAIN LTT',5,'0','DR','LTT','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','115',NULL,'0','0',NULL,0,'2026-05-16 10:19:10','2026-05-16 10:19:10'),(629,'249',NULL,NULL,'M K ENTERPRISES',5,'0','DR','PATRAKAR SOCIETY, SHOP 7,BLDG 165','TILAK NGR,CHEMBUR WEST','MUMBAI','21','400089',NULL,'9320534415','',NULL,'27','27DTUPK0951A1ZN','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4417',NULL,'0','0',NULL,0,'2026-05-16 10:19:10','2026-05-16 10:19:10'),(630,'249',NULL,NULL,'FAYAZ',5,'0','DR','LTT','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','121',NULL,'0','0',NULL,0,'2026-05-16 10:19:10','2026-05-16 10:19:10'),(631,'249',NULL,NULL,'DILIPKUMAR & CO',5,'0','DR','LTT STN','9323284666','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','111',NULL,'0','0',NULL,0,'2026-05-16 10:19:10','2026-05-16 10:19:10'),(632,'249',NULL,NULL,'CHEMIST STALL',5,'0','DR','OLD HALL','','Mumbai','21','400089',NULL,'1111111111','',NULL,'27','27ALUPP1443P1Z9','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','294',NULL,'0','0',NULL,0,'2026-05-16 10:19:10','2026-05-16 10:19:10'),(633,'249',NULL,NULL,'CARIO C LTT PF4',5,'0','DR','LTT','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','114',NULL,'0','0',NULL,0,'2026-05-16 10:19:11','2026-05-16 10:19:11'),(634,'249',NULL,NULL,'CARIO B LTT PF4',5,'0','DR','LTT','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','113',NULL,'0','0',NULL,0,'2026-05-16 10:19:11','2026-05-16 10:19:11'),(635,'249',NULL,NULL,'CARIO A LTT PF4',5,'0','DR','LTT','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','112',NULL,'0','0',NULL,0,'2026-05-16 10:19:11','2026-05-16 10:19:11'),(636,'249',NULL,NULL,'AH WHILER STALL (CHEMBUR )',5,'0','DR','CHEMBUR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1748',NULL,'0','0',NULL,0,'2026-05-16 10:19:11','2026-05-16 10:19:11'),(637,'249',NULL,NULL,'A.H WHEELER LTT',5,'0','DR','NR WAITING HALL, LTT','','','21','',NULL,'8355967549','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','3754',NULL,'0','0',NULL,0,'2026-05-16 10:19:11','2026-05-16 10:19:11'),(638,'249',NULL,NULL,'A S SALES',5,'0','DR','LTT  9340051736','DEFAULT','','21','',NULL,'9340051736','',NULL,'27','','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','192',NULL,'0','0',NULL,0,'2026-05-16 10:19:11','2026-05-16 10:19:11'),(639,'249',NULL,NULL,'gupta',5,'0','DR','nr station','','','21','',NULL,'8355967549','',NULL,'27','','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','280',NULL,'0','0',NULL,0,'2026-05-16 10:19:11','2026-05-16 10:19:11'),(640,'249',NULL,NULL,'SHRUTI ENTERPRISES',5,'12597','DR','SHOP NO 2/3,RADHIKA RESIDENCY','MAHATMA PHULE NGR,TILAK NAGAR,','MUMBAI','21','400089',NULL,'7720935631','',NULL,'27','27ABRPB2888F1ZD','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','118',NULL,'0','0',NULL,0,'2026-05-16 10:19:11','2026-05-16 10:19:11'),(641,'249',NULL,NULL,'RAWAL TRADING',5,'0','DR','MUMBAI','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','116',NULL,'0','0',NULL,0,'2026-05-16 10:19:11','2026-05-16 10:19:11'),(642,'249',NULL,NULL,'JAY INFOTECH SALES',5,'0','DR','DEFAULT','DEFAULT','','21','27',NULL,'','',NULL,'27','','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','137',NULL,'0','0',NULL,0,'2026-05-16 10:19:11','2026-05-16 10:19:11'),(643,'249',NULL,NULL,'JANTA CANTEEN',5,'0','DR','KURLA','9967290983','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','101',NULL,'0','0',NULL,0,'2026-05-16 10:19:12','2026-05-16 10:19:12'),(644,'249',NULL,NULL,'GYAN BHAI TEA STALL',5,'0','DR','PF 7/8','KURLA','Mumbai','21','400070',NULL,'8291453286','',NULL,'27','27AAGPJ6173P1Z3','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','102',NULL,'0','0',NULL,0,'2026-05-16 10:19:12','2026-05-16 10:19:12'),(645,'249',NULL,NULL,'CHANTULAL TEA STALL PF 7/8 KALYAN SIDE',5,'112','DR','PF 7/8','KURLA','','21','',NULL,'7506887966','',NULL,'27','','','IMPS',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','103',NULL,'0','0',NULL,0,'2026-05-16 10:19:12','2026-05-16 10:19:12'),(646,'249',NULL,NULL,'CHANTULAL TEA STALL PF 5/6 CST SIDE',5,'37256','DR','PF 3/4','KURLA','','21','',NULL,'8454972995','',NULL,'27','','','IMPS',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','108',NULL,'0','0',NULL,0,'2026-05-16 10:19:12','2026-05-16 10:19:12'),(647,'249',NULL,NULL,'CHANTULAL TEA STALL PF 1',5,'11911','DR','PF 1','KURLA','','21','',NULL,'9004108696','',NULL,'27','','','IMPS',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','106',NULL,'0','0',NULL,0,'2026-05-16 10:19:12','2026-05-16 10:19:12'),(648,'249',NULL,NULL,'CHANTULAL KHOMCHA VT SIDE',5,'6027','DR','PF 5/6','KURLA','','21','',NULL,'9860607763/957544451','',NULL,'27','','','IMPS',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','107',NULL,'0','0',NULL,0,'2026-05-16 10:19:12','2026-05-16 10:19:12'),(649,'249',NULL,NULL,'CHANTULAL KHOMCHA PF 7/8',5,'100','DR','PF 7/8','KURLA','','21','',NULL,'6263060293','',NULL,'27','','','IMPS',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','104',NULL,'0','0',NULL,0,'2026-05-16 10:19:12','2026-05-16 10:19:12'),(650,'249',NULL,NULL,'CHANTULAL KHOMCHA  KL SIDE',5,'3877','CR','PF 5/6','KURLA','','21','',NULL,'8108045936','',NULL,'27','','','IMPS',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','105',NULL,'0','0',NULL,0,'2026-05-16 10:19:12','2026-05-16 10:19:12'),(651,'249',NULL,NULL,'BHAVANI MEDICAL',5,'0','DR','VASALA TAI NAGAR KURLA','KURLA','','21','',NULL,'9898989898','',NULL,'27','','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5545',NULL,'0','0',NULL,0,'2026-05-16 10:19:12','2026-05-16 10:19:12'),(652,'249',NULL,NULL,'A.H WHEELER PF 1/2 (KURLA)',5,'84111','DR','PF NO 1/2','','','21','',NULL,'9867998081','',NULL,'27','','','IMPS',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-45035','0.00',NULL,'0','0',NULL,'0','1744',NULL,'0','0',NULL,0,'2026-05-16 10:19:12','2026-05-16 10:19:12'),(653,'249',NULL,NULL,'A.H WHEELER (KURLA) PF 5/6',5,'5435','DR','PF 5/6','','','21','',NULL,'1111111111','',NULL,'27','','','IMPS',NULL,NULL,'','2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44277','0.00',NULL,'0','0',NULL,'0','1756',NULL,'0','0',NULL,0,'2026-05-16 10:19:13','2026-05-16 10:19:13'),(654,'249',NULL,NULL,'shree nakoda agency',11,'0','DR','83/20+83/82 ashapura bldg grond fllor bhodwada khadak road bhiwandi thana','','','21','',NULL,'8806568000','',NULL,'27','27AABHS8486H1ZL','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4894',NULL,'0','0',NULL,0,'2026-05-16 10:19:13','2026-05-16 10:19:13'),(655,'249',NULL,NULL,'punit',5,'0','DR','chembur','','','21','',NULL,'4856485674','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6558',NULL,'0','0',NULL,0,'2026-05-16 10:19:13','2026-05-16 10:19:13'),(656,'249',NULL,NULL,'omkar enterprises',5,'29697','CR','chembur','','','21','',NULL,'8923563445','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6556',NULL,'0','0',NULL,0,'2026-05-16 10:19:13','2026-05-16 10:19:13'),(657,'249',NULL,NULL,'challan purchase',11,'0','DR','v','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','290',NULL,'0','0',NULL,0,'2026-05-16 10:19:13','2026-05-16 10:19:13'),(658,'249',NULL,NULL,'ZENITA LEISUVE HOLIDAYS',11,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43927','0.00',NULL,'0','0',NULL,'0','1328',NULL,'0','0',NULL,0,'2026-05-16 10:19:13','2026-05-16 10:19:13'),(659,'249',NULL,NULL,'WONDER CAREERING',11,'0','DR','SHOP NO 2/3A EKATA CHS,LTD','KARVE NG KANGUR Marg (E)42','','21','',NULL,'9664245889','',NULL,'27','27AGYPV0791M1Z7','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','265',NULL,'0','0',NULL,0,'2026-05-16 10:19:13','2026-05-16 10:19:13'),(660,'249',NULL,NULL,'WESTAN RAILWAY',5,'0','DR','RAILWAY','','','21','',NULL,'9876543210','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4863',NULL,'0','0',NULL,0,'2026-05-16 10:19:13','2026-05-16 10:19:13'),(661,'249',NULL,NULL,'WAN & LAN INTERNET PVT LTD',11,'0','DR','GHATKOPAR EAST','','','21','',NULL,'','',NULL,'27','27AAACW8618H1Z2','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','AAACW8618H','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1536',NULL,'0','0',NULL,0,'2026-05-16 10:19:13','2026-05-16 10:19:13'),(662,'249',NULL,NULL,'VISION STUDIO',5,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43942','0.00',NULL,'0','0',NULL,'0','1349',NULL,'0','0',NULL,0,'2026-05-16 10:19:13','2026-05-16 10:19:13'),(663,'249',NULL,NULL,'VIKRANT ENTERPRISES',11,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43927','0.00',NULL,'0','0',NULL,'0','1330',NULL,'0','0',NULL,0,'2026-05-16 10:19:14','2026-05-16 10:19:14'),(664,'249',NULL,NULL,'VIJAYRAJ ARVIND',5,'50000','CR','CHEMBUR','','','21','',NULL,'7785605054','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6573',NULL,'0','0',NULL,0,'2026-05-16 10:19:14','2026-05-16 10:19:14'),(665,'249',NULL,NULL,'VIJAY DURGA SALON',5,'0','DR','DADOJI KONDDEV MARG','BYCULLA','','21','',NULL,'8600693489','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6438',NULL,'0','0',NULL,0,'2026-05-16 10:19:14','2026-05-16 10:19:14'),(666,'249',NULL,NULL,'VIHSNA ENTERPRISES',5,'0','DR','3/B,MITTAL TOWER, BASEMENT, NARIMAN POINT,','','','21','',NULL,'9167915181','',NULL,'27','27AMLPG0446K1ZY','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4837',NULL,'0','0',NULL,0,'2026-05-16 10:19:14','2026-05-16 10:19:14'),(667,'249',NULL,NULL,'VELTOSA PRIVATE LIMITED',11,'0','DR','AHMEDABAD','','','21','380005',NULL,'','',NULL,'27','24AAGCR5939Q1ZM','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1667',NULL,'0','0',NULL,0,'2026-05-16 10:19:14','2026-05-16 10:19:14'),(668,'249',NULL,NULL,'VASUDHA OMKAR',5,'30000','CR','CHEMBUR','','','21','',NULL,'8725651265','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6571',NULL,'0','0',NULL,0,'2026-05-16 10:19:14','2026-05-16 10:19:14'),(669,'249',NULL,NULL,'VARIETY INFOTECH',11,'0','DR','GHATKOPAR WEST','','','21','',NULL,'','',NULL,'27','27AAFPS2096D1ZM','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43773','0.00',NULL,'0','0',NULL,'0','1162',NULL,'0','0',NULL,0,'2026-05-16 10:19:14','2026-05-16 10:19:14'),(670,'249',NULL,NULL,'VARIETY BOOK CENTRE',11,'3000','CR','OPP RAILWAY STN, GHATKOPAR WEST','','','21','',NULL,'1111111111','',NULL,'27','27AAFPS2098P1ZV','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43773','0.00',NULL,'0','0',NULL,'0','1165',NULL,'0','0',NULL,0,'2026-05-16 10:19:14','2026-05-16 10:19:14'),(671,'249',NULL,NULL,'VARIA INFOTECH',11,'25223','CR','Shop No. 12, Gulmohar Greenways Bldg. No. 7/8 CHS,',', Beside Majestic Suites Hotel, Mahajanwadi,Mira Goanthan, Mira Road (E)','THANE','21','401107',NULL,'9819218100','vimalvaria@hotmail.com',NULL,'27','27ACCPV6964E1Z7','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','ACCPV6964E','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6533',NULL,'0','0',NULL,0,'2026-05-16 10:19:14','2026-05-16 10:19:14'),(672,'249',NULL,NULL,'V.R.DISTRIBUTORS',11,'0','DR','3C SAMRAT SLICK MILK COMPOUNT LBS NARG VIKHROLI','VIKHROLI','','21','',NULL,'022-25785723','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43728','0.00',NULL,'0','0',NULL,'0','757',NULL,'0','0',NULL,0,'2026-05-16 10:19:15','2026-05-16 10:19:15'),(673,'249',NULL,NULL,'V R DISTRIBUTORS',11,'0','DR','VIKHROLI','','','21','',NULL,'','',NULL,'27','27AKLPV8673R1Z0','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43727','0.00',NULL,'0','0',NULL,'0','755',NULL,'0','0',NULL,0,'2026-05-16 10:19:15','2026-05-16 10:19:15'),(674,'249',NULL,NULL,'V A ENTERPRISES',11,'0','DR','PATRA CHAWL,NR RAILWAY COLONY','KURLA EAST','','21','400024',NULL,'9029028555','',NULL,'27','27AEPPT6609F2ZZ','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4753',NULL,'0','0',NULL,0,'2026-05-16 10:19:15','2026-05-16 10:19:15'),(675,'249',NULL,NULL,'URMILA STORE',5,'0','DR','POWAI','','','21','',NULL,'9769585871','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','443',NULL,'0','0',NULL,0,'2026-05-16 10:19:15','2026-05-16 10:19:15'),(676,'249',NULL,NULL,'UNIQUE SALES',11,'0','DR','GALA NO 49B,BOMBAY TIMBER','MKT,REY RD,','MUMBAI','21','400010',NULL,'','',NULL,'27','27AAFFU7248D1Z1','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44237','0.00',NULL,'0','0',NULL,'0','1708',NULL,'0','0',NULL,0,'2026-05-16 10:19:15','2026-05-16 10:19:15'),(677,'249',NULL,NULL,'TULJAI ENTERPRISE',5,'0','DR','OPP HANUMAN MANDIR,NR 90FT','RD,PANT NAGAR','GHATKOPAR','21','400086',NULL,'1111111111','',NULL,'27','27BFYPS6872J1Z7','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1615',NULL,'0','0',NULL,0,'2026-05-16 10:19:15','2026-05-16 10:19:15'),(678,'249',NULL,NULL,'TULJAI ENTERPRISE',11,'408','CR','OPP HANUMAN MANDIR NEAR 90FT CIRCA NAYADU COLONY PANTNAGAR','GHATKOPAR E','','21','',NULL,'9967516585','',NULL,'27','27BFYPS6872J1Z7','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6486',NULL,'0','0',NULL,0,'2026-05-16 10:19:15','2026-05-16 10:19:15'),(679,'249',NULL,NULL,'TJUK TRADE NETWORK PVT.LTD',11,'0','DR','PLOT NO 55, HINDUSTAN BUILDING','NEAR BMC OFFICE WAMAN PATIL MARG NEXT TO DENOER VILLAGE','MUMBAI','21','400043',NULL,'2067877700','',NULL,'27','27AACCT0200E1Z3','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4817',NULL,'0','0',NULL,0,'2026-05-16 10:19:15','2026-05-16 10:19:15'),(680,'249',NULL,NULL,'TECHSTAR INDIA LIMITED',11,'0','DR','A-306 / RAJDARSHAN CHS , DADA PATIL WADI , NR. RLY STATION','THANE WEST','MUMBAI','21','400601',NULL,'1234567890','',NULL,'27','27AAFCT5860K1ZV','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6509',NULL,'0','0',NULL,0,'2026-05-16 10:19:15','2026-05-16 10:19:15'),(681,'249',NULL,NULL,'TECHG INFOTECH',11,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43927','0.00',NULL,'0','0',NULL,'0','1331',NULL,'0','0',NULL,0,'2026-05-16 10:19:15','2026-05-16 10:19:15'),(682,'249',NULL,NULL,'TATSAT ENTERPRISES',11,'0','DR','SHOP NO 6,PURNASHANTI HEIGHTS','KHARTAN RD,NR DARGHA,THANE WEST','','21','',NULL,'','',NULL,'27','27AJQPP2884C1ZT','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','160',NULL,'0','0',NULL,0,'2026-05-16 10:19:16','2026-05-16 10:19:16'),(683,'249',NULL,NULL,'TATA CONSUMER PRODUCTS LTD',11,'0','DR','SAI KRISHNA COMPLEX THANE','','','21','',NULL,'0','',NULL,'27','27AABCT0602K1ZL','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5695',NULL,'0','0',NULL,0,'2026-05-16 10:19:16','2026-05-16 10:19:16'),(684,'249',NULL,NULL,'SWASTIK HARDWARE STORES',11,'0','DR','SHOP NO 1A,POLICE PATEL HOUSE','LBS MRG,GHATKOPAR WEST','','21','400086',NULL,'9125159932','',NULL,'27','27AAPFS1453A1ZC','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4892',NULL,'0','0',NULL,0,'2026-05-16 10:19:16','2026-05-16 10:19:16'),(685,'249',NULL,NULL,'SURTI DISTRIBUTORS',11,'0','DR','18,PAREL,SHIV SMRUTI','GANDHI NGR,WORLI','MUMBAI','21','400018',NULL,'9822222222','',NULL,'27','27BLJPS1599B1ZS','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4690',NULL,'0','0',NULL,0,'2026-05-16 10:19:16','2026-05-16 10:19:16'),(686,'249',NULL,NULL,'SUNRISE CHEMICALS',5,'135003','DR','207,2ND FLOOR,SAMUEL STREET,','MASJID BUNDER W,','MUMBAI','21','400003',NULL,'9891457897','indianfmcg03@gmail.com',NULL,'27','27AACFS3511N1Z3','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6557',NULL,'0','0',NULL,0,'2026-05-16 10:19:16','2026-05-16 10:19:16'),(687,'249',NULL,NULL,'SUNDAR VILAS BAR & RESTRAURANT',5,'0','DR','90 FEET ROAD, KUMBARWADA DHARAVI','','','21','',NULL,'9004663945','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4832',NULL,'0','0',NULL,0,'2026-05-16 10:19:16','2026-05-16 10:19:16'),(688,'249',NULL,NULL,'STASTIK ENTERPRISES',5,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43942','0.00',NULL,'0','0',NULL,'0','1345',NULL,'0','0',NULL,0,'2026-05-16 10:19:16','2026-05-16 10:19:16'),(689,'249',NULL,NULL,'SK ENTAERPRISES',11,'0','DR','JOHN MARY ECLAVE BASEMENT','NR L WARD OFFICE OPP KNS BANK','','21','',NULL,'9323592750','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4951',NULL,'0','0',NULL,0,'2026-05-16 10:19:16','2026-05-16 10:19:16'),(690,'249',NULL,NULL,'SIGNATURES INTERNATIONAL',11,'0','DR','A/102,SKYLINE EPITOME, 1ST FLOOR ACME COMPOUND BEHIND','JOLLY GYMKHANA KIROL ROAD,VIDYAVIHAR (W)','MUMBAI','21','',NULL,'7303680966','',NULL,'27','27AADHS0709P1ZS','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4813',NULL,'0','0',NULL,0,'2026-05-16 10:19:16','2026-05-16 10:19:16'),(691,'249',NULL,NULL,'SHRUTI ENTERPRISES',11,'0','DR','RADHIKA RESIDENCY,','TILAK NGR','MUMBAI','21','400089',NULL,'1212121212','',NULL,'27','27ABRPB2888F1ZD','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44208','0.00',NULL,'0','0',NULL,'0','1666',NULL,'0','0',NULL,0,'2026-05-16 10:19:16','2026-05-16 10:19:16'),(692,'249',NULL,NULL,'SHREE PARAS MARKETING',11,'0','DR','218/315,BUSSA INDL ESTATE','CENTURY BAZAAR,PRABHADEVI','','21','400025',NULL,'','',NULL,'27','27AACPK0417H1Z4','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43773','0.00',NULL,'0','0',NULL,'0','1164',NULL,'0','0',NULL,0,'2026-05-16 10:19:17','2026-05-16 10:19:17'),(693,'249',NULL,NULL,'SHREE KRISHNA AGENCIES',11,'0','DR','COPPER ROLLER PREMISES,','BHANDUP WEST','MUMBAI','21','400027',NULL,'','',NULL,'27','27ADNFS6679K1Z1','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43991','0.00',NULL,'0','0',NULL,'0','1375',NULL,'0','0',NULL,0,'2026-05-16 10:19:17','2026-05-16 10:19:17'),(694,'249',NULL,NULL,'SHREE DHARAMRAJ AGENCY',11,'0','DR','B82,M.N RD,BAIL BAZAR,NR TURDE WINE','KURLA WEST','MUMBAI','21','400070',NULL,'9892444277','',NULL,'27','27AEIFS3561E1ZY','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5342',NULL,'0','0',NULL,0,'2026-05-16 10:19:17','2026-05-16 10:19:17'),(695,'249',NULL,NULL,'SHREE DATTA TRADING',5,'3582540','DR','WEST SIDE GODOWN KASARA DUMALA SANGAMNER ROAD','AHILYANAGAR','MAHARASHTRA','21','422605',NULL,'8545614651','',NULL,'27','27PURPK2832J1ZT','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6575',NULL,'0','0',NULL,0,'2026-05-16 10:19:17','2026-05-16 10:19:17'),(696,'249',NULL,NULL,'SHIVAM LIFE STYLE',5,'0','DR','MUMBAI','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1584',NULL,'0','0',NULL,0,'2026-05-16 10:19:17','2026-05-16 10:19:17'),(697,'249',NULL,NULL,'SHIVAM AGENCY',11,'0','DR','SHOP NO 1,MOON APT,V.B NGR,','PIPELINE,KURLA WEST,M 70','','21','',NULL,'','',NULL,'27','27AIDPD8869P1ZG','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','161',NULL,'0','0',NULL,0,'2026-05-16 10:19:17','2026-05-16 10:19:17'),(698,'249',NULL,NULL,'SANGHVI COMPUTERS',11,'0','DR','TARA TEMPLE LANE,MADAN BLDG','LAMINTON RD,MUMBAI','','21','400007',NULL,'23861785','',NULL,'27','27ABAPS8813J1ZB','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4881',NULL,'0','0',NULL,0,'2026-05-16 10:19:17','2026-05-16 10:19:17'),(699,'249',NULL,NULL,'SAN LOGISTIX',11,'0','DR','PLOT 23,KANDIVLI INDL','ESTATE,KANDIVLI WEST','','21','',NULL,'','',NULL,'27','27ADYFS0019E1ZX','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44233','0.00',NULL,'0','0',NULL,'0','1700',NULL,'0','0',NULL,0,'2026-05-16 10:19:17','2026-05-16 10:19:17'),(700,'249',NULL,NULL,'SAMPLE',5,'0','DR','CHEMBUR','','','21','',NULL,'98211000101','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6167',NULL,'0','0',NULL,0,'2026-05-16 10:19:17','2026-05-16 10:19:17'),(701,'249',NULL,NULL,'Rohit Marketing',11,'1107401','CR','Safedpool Sakinaka','','Mumbai','21','400072',NULL,'8779721761','',NULL,'27','27AKPPC6596A1Z0','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6032',NULL,'0','0',NULL,0,'2026-05-16 10:19:17','2026-05-16 10:19:17'),(702,'249',NULL,NULL,'Raj Sales',11,'0','CR','375/377, Shop 1,Babu Bldg','Laminton Rd, Grant Rd','Mumbai','21','400007',NULL,'9594867223','',NULL,'27','27ADDPC7174K1ZE','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6578',NULL,'0','0',NULL,0,'2026-05-16 10:19:18','2026-05-16 10:19:18'),(703,'249',NULL,NULL,'ROP ENTERPRISES',11,'15000','CR','SHOP NO 2 WHISPERING PALM CHS','SECTOR 19 NEAR BANK OF INDIA','','21','',NULL,'9821241879','',NULL,'27','27AQMPG0878L1ZB','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4563',NULL,'0','0',NULL,0,'2026-05-16 10:19:18','2026-05-16 10:19:18'),(704,'249',NULL,NULL,'RK ENTERPRISES',11,'0','DR','GOVANDI','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43721','0.00',NULL,'0','0',NULL,'0','744',NULL,'0','0',NULL,0,'2026-05-16 10:19:18','2026-05-16 10:19:18'),(705,'249',NULL,NULL,'RISHIKESH MEDICAL',5,'0','DR','TUNGA','TUNGA','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','625',NULL,'0','0',NULL,0,'2026-05-16 10:19:18','2026-05-16 10:19:18'),(706,'249',NULL,NULL,'RELIANCE RETAIL LIMITED',11,'0','DR','O1PLINTH NUMBER 1 7 SAGAR COMPLEX','MUM NASHIK HIGHWAY OPP HP PETROL PUMP','','21','',NULL,'1556544165','',NULL,'27','27AABCR1718E1ZP','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4846',NULL,'0','0',NULL,0,'2026-05-16 10:19:18','2026-05-16 10:19:18'),(707,'249',NULL,NULL,'REGAL ENTERPRISES',11,'0','DR','SHOP NO 2 PLT 149 VITHAL CHAWL KHERWADI','BANDRA EAST','','21','',NULL,'9322866991','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4945',NULL,'0','0',NULL,0,'2026-05-16 10:19:18','2026-05-16 10:19:18'),(708,'249',NULL,NULL,'REAL AGENCY',11,'0','DR','OPP SHIVAJI NAGAR NEW BUS DEPO 90 FEET ROAD','GOVANDI','MUMBAI','21','',NULL,'','',NULL,'27','27CASPM0324B1ZY','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','296',NULL,'0','0',NULL,0,'2026-05-16 10:19:18','2026-05-16 10:19:18'),(709,'249',NULL,NULL,'RAJ TRADERS',11,'0','DR','GALA NO 3, VEDANT HOSPITAL','THANE','','21','400607',NULL,'','',NULL,'27','27AAPHA6784E1ZY','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44038','0.00',NULL,'0','0',NULL,'0','1424',NULL,'0','0',NULL,0,'2026-05-16 10:19:18','2026-05-16 10:19:18'),(710,'249',NULL,NULL,'R.K MARKETING',11,'0','DR','GOVANDI STN WEST','','','21','400043',NULL,'','',NULL,'27','27ACRPG0630R1Z5','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43752','0.00',NULL,'0','0',NULL,'0','1014',NULL,'0','0',NULL,0,'2026-05-16 10:19:18','2026-05-16 10:19:18'),(711,'249',NULL,NULL,'R.D.DISTRIBUTORS',11,'503139','DR','MOTILAL NGR NO 1,79/634','goregaon west','Mumbai','21','400104',NULL,'1111111112','',NULL,'27','27AAJPM7505P1Z3','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6511',NULL,'0','0',NULL,0,'2026-05-16 10:19:18','2026-05-16 10:19:18'),(712,'249',NULL,NULL,'PUNYAM DISTRIBUTOR',11,'0','DR','CHEMBUR','','','21','',NULL,'','',NULL,'27','27AAEHN7306Q1ZN','','KOTAK',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','300',NULL,'0','0',NULL,0,'2026-05-16 10:19:19','2026-05-16 10:19:19'),(713,'249',NULL,NULL,'PRIVATE LIMITED COMPANY',5,'0','DR','KRUSHAL COMM COMPLEX AMAR MAHAL G.M.ROAD','CHEMBUR','MUMBAI','21','400089',NULL,'1111111111','',NULL,'27','27AABCP6227E1ZL','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6527',NULL,'0','0',NULL,0,'2026-05-16 10:19:19','2026-05-16 10:19:19'),(714,'249',NULL,NULL,'PRANJAL RAMESH',5,'0','DR','CHEMBUR','','','21','',NULL,'9526545426','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6572',NULL,'0','0',NULL,0,'2026-05-16 10:19:19','2026-05-16 10:19:19'),(715,'249',NULL,NULL,'POOJA BANGALI SWEETS',5,'0','DR','POWAI','','','21','',NULL,'8850117382','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','446',NULL,'0','0',NULL,0,'2026-05-16 10:19:19','2026-05-16 10:19:19'),(716,'249',NULL,NULL,'PARLE SAMPLING CODE',5,'930','DR','VILE PARLE EAST','VS KHANDEKAR MAGR','MUMBAI','21','400057',NULL,'8850503436','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6521',NULL,'0','0',NULL,0,'2026-05-16 10:19:19','2026-05-16 10:19:19'),(717,'249',NULL,NULL,'PARLE PRODUCTS PVT LTD',11,'0','DR','VILE PARLE EAST,MUMBAI 57','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','110',NULL,'0','0',NULL,0,'2026-05-16 10:19:19','2026-05-16 10:19:19'),(718,'249',NULL,NULL,'PARLE BISCUITS PVT LTD',11,'40513917','CR','VILE PARLE EAST,MUMBAI 57','DEFAULT','','21','',NULL,'9820221421','',NULL,'27','27AAACP0485D1ZO','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.00E+13','AAACP0485D','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','109',NULL,'0','0',NULL,0,'2026-05-16 10:19:19','2026-05-16 10:19:19'),(719,'249',NULL,NULL,'PARLE AGRO PVT.LTD',11,'2305834.3','CR','M/S PARIJIT LOGISTICS PVT LTD CTS NO 596-A,OLD METAL BOX FACTORY','M WARD L.U.GADKARI MARG PRAYAG NAGAR','MUMBAI','21','400071',NULL,'2151641545','',NULL,'27','27AAACP8416G1ZF','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','AAACP8416G','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6528',NULL,'0','0',NULL,0,'2026-05-16 10:19:19','2026-05-16 10:19:19'),(720,'249',NULL,NULL,'PARK NEXT HOTELS PROVITE LTD',5,'13986','DR','KRUSHAL COMM COMPLEX AMAR MAHAL','G M ROAD CHEMBUR','MUMBAI','21','400089',NULL,'4564658458','',NULL,'27','27AABCP6227E1ZL','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6553',NULL,'0','0',NULL,0,'2026-05-16 10:19:19','2026-05-16 10:19:19'),(721,'249',NULL,NULL,'OMKAR',5,'0','DR','CHEMBUR','','','21','',NULL,'8854894849','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6550',NULL,'0','0',NULL,0,'2026-05-16 10:19:19','2026-05-16 10:19:19'),(722,'249',NULL,NULL,'OMEGA HOSPITALITY',5,'6904','DR','6TH,613 ANURAG BUSINESS CENTRE PREM CO.OP SOC.LTD','WT PATIL MARG,NEAR AMAR CINEMA','MUMBAI','21','400071',NULL,'8752164658','',NULL,'27','27ADJPC1769J1ZD','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6537',NULL,'0','0',NULL,0,'2026-05-16 10:19:20','2026-05-16 10:19:20'),(723,'249',NULL,NULL,'NEO PLANET SYSTEM',11,'0','DR','312,ADITYA ARCADE,','LAMINTON RD','','21','',NULL,'','',NULL,'27','27AJWPJ3868L1Z8','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43773','0.00',NULL,'0','0',NULL,'0','1163',NULL,'0','0',NULL,0,'2026-05-16 10:19:20','2026-05-16 10:19:20'),(724,'249',NULL,NULL,'NAVIIN DEDHIA',5,'0','DR','CHEMBUR','','','21','',NULL,'1111111111','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6498',NULL,'0','0',NULL,0,'2026-05-16 10:19:20','2026-05-16 10:19:20'),(725,'249',NULL,NULL,'NANDINI ENTERPRISES',11,'0','DR','1ST FLOOR 151 GARDEN PLOT KHERWADI ROAD NR BHAUMIYA MANDIR','BANDRA E','','21','',NULL,'9322565522','',NULL,'27','27BMQPG5832H1ZR','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6399',NULL,'0','0',NULL,0,'2026-05-16 10:19:20','2026-05-16 10:19:20'),(726,'249',NULL,NULL,'Mona Beauty Salon',5,'0','DR','shop no 2 laxmi niwas sita ram jhadav marg','Lower Parel','mumbai','21','400013',NULL,'9768459497','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4818',NULL,'0','0',NULL,0,'2026-05-16 10:19:20','2026-05-16 10:19:20'),(727,'249',NULL,NULL,'Marrix Academy',11,'0','DR','Ws','','','21','',NULL,'1234567890','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4616',NULL,'0','0',NULL,0,'2026-05-16 10:19:20','2026-05-16 10:19:20'),(728,'249',NULL,NULL,'MIHIR ENTERPRISES',11,'0','DR','SHOP NO 4,VASUDEO CHAWL','PARASWADI GHATKOPAR WEST','','21','400086',NULL,'','',NULL,'27','27ATLPP9237A1ZH','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44220','0.00',NULL,'0','0',NULL,'0','1684',NULL,'0','0',NULL,0,'2026-05-16 10:19:20','2026-05-16 10:19:20'),(729,'249',NULL,NULL,'METRO CASH AND CARRY INDIA PVT LTD',11,'0','DR','LBS MARG, BHANDUP','WEST','','21','400078',NULL,'','',NULL,'27','27AACCM4684P1ZR','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44287','0.00',NULL,'0','0',NULL,'0','1766',NULL,'0','0',NULL,0,'2026-05-16 10:19:20','2026-05-16 10:19:20'),(730,'249',NULL,NULL,'METHA & COMPANY',5,'0','DR','GRD FLOOR SHOP NO 5 & 6KADRI MANSION SIPN ROAD NO 24B NEAR','TARACHAND BAPA SION (W)','','21','',NULL,'9619997841','',NULL,'27','27CFYPM4254B2Z4','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5761',NULL,'0','0',NULL,0,'2026-05-16 10:19:20','2026-05-16 10:19:20'),(731,'249',NULL,NULL,'MEENA INDUSTRIES',11,'22311','CR','GALA NO 21,KOHINOOR TEXTILE PRTG WORK','GHATKOPAR WEST','MUMBAI','21','400086',NULL,'9930993977','',NULL,'27','27AAKFM3322K1Z6','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44123','0.00',NULL,'0','0',NULL,'0','1511',NULL,'0','0',NULL,0,'2026-05-16 10:19:20','2026-05-16 10:19:20'),(732,'249',NULL,NULL,'MEADOWS INDIA-(23-24)',11,'0','DR','A4 PRIME PLAZA GR FLOOR BM MARG JV PATEL','COM. OPP RAILWAY STATION ELPHINSTONE','','21','',NULL,'1111111111','',NULL,'27','27ABBFM1453H1ZG','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6408',NULL,'0','0',NULL,0,'2026-05-16 10:19:21','2026-05-16 10:19:21'),(733,'249',NULL,NULL,'MAYURI DEDHIA',5,'0','DR','CHEMBUR','','','21','',NULL,'1111111111','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6499',NULL,'0','0',NULL,0,'2026-05-16 10:19:21','2026-05-16 10:19:21'),(734,'249',NULL,NULL,'MAYORA INDIA PRIVATE LTD',11,'0','DR','SUREY NO H383/9 GALA 5/8 PATRA SHED MAHAIR COMP.AAMANE','VILLAGE BHIWANDI','','21','',NULL,'9004541045','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6052',NULL,'0','0',NULL,0,'2026-05-16 10:19:21','2026-05-16 10:19:21'),(735,'249',NULL,NULL,'MARS INTERNATIONAL INDIA PVT LTD',11,'0','DR','C/O ROBINSON CARGO & LOGISTIC','BHIWANID NASHIK RD,','BHIWANDI THANE','21','421302',NULL,'','',NULL,'27','27AAACE6794J1Z6','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.00E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','266',NULL,'0','0',NULL,0,'2026-05-16 10:19:21','2026-05-16 10:19:21'),(736,'249',NULL,NULL,'MANIRATNAM BOUTIQ',11,'0','DR','44,RC MARG,NR FINE ARTS','CHEMBUR','','21','',NULL,'9619667588','',NULL,'27','27ARBPV0195K1ZD','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','3921',NULL,'0','0',NULL,0,'2026-05-16 10:19:21','2026-05-16 10:19:21'),(737,'249',NULL,NULL,'MALLIARJUN',5,'94500','CR','CHEMBUR','','','21','',NULL,'8451635655','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6574',NULL,'0','0',NULL,0,'2026-05-16 10:19:21','2026-05-16 10:19:21'),(738,'249',NULL,NULL,'MAHARASHTRA DHANYA BHANDAR',5,'0','DR','POWAI','','','21','',NULL,'2225782137','',NULL,'27','27ABYPP7065P2ZB','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','444',NULL,'0','0',NULL,0,'2026-05-16 10:19:21','2026-05-16 10:19:21'),(739,'249',NULL,NULL,'MAHALAXMI ENTERPRISES',11,'0','DR','Shop 4,Opp Thakur Engg College','Kandivali West','Mumbai','21','400101',NULL,'9987621563','',NULL,'27','27AHQPC9763P1ZC','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6114',NULL,'0','0',NULL,0,'2026-05-16 10:19:21','2026-05-16 10:19:21'),(740,'249',NULL,NULL,'MAHA LAXMI G/S',5,'0','DR','POWAI','','','21','',NULL,'9867762431','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','441',NULL,'0','0',NULL,0,'2026-05-16 10:19:21','2026-05-16 10:19:21'),(741,'249',NULL,NULL,'M N ENTERPRISES',11,'0','DR','HANUMAN TEKDI,NAWA GAON','DAHISAR (W)','','21','',NULL,'','',NULL,'27','27AXSPP8901C1Z5','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','193',NULL,'0','0',NULL,0,'2026-05-16 10:19:21','2026-05-16 10:19:21'),(742,'249',NULL,NULL,'M J TRADERS',5,'0','DR','GROUND FLOOR , 2 PLT 273/ 277 ANANT DEEP','CHAMBERS NARSHINATHA STREET BHAT BAZAR MASJID (W)','MUMBAI','21','400009',NULL,'0','',NULL,'27','27CEIPS8460N1ZK','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5660',NULL,'0','0',NULL,0,'2026-05-16 10:19:22','2026-05-16 10:19:22'),(743,'249',NULL,NULL,'LOREAL INDIA PVT LTD',11,'29401.11','CR','DHL SUPPLY CHAM,428,CHAKAN','CHAKAN','PUNE','21','410501',NULL,'2267003000','',NULL,'27','27AAACL0738K1ZH','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4181',NULL,'0','0',NULL,0,'2026-05-16 10:19:22','2026-05-16 10:19:22'),(744,'249',NULL,NULL,'LAMINATE PALACE',11,'0','DR','SHOP 17,PRANIK CHAMBERS,OPP EXCOM HOUSE','SAKIVIHAR RD,SAKINAKA','MUMBAI','21','400072',NULL,'8812111111','',NULL,'27','27AADHJ4032Q1ZZ','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4934',NULL,'0','0',NULL,0,'2026-05-16 10:19:22','2026-05-16 10:19:22'),(745,'249',NULL,NULL,'Khushi Enterprises',11,'0','DR','1 ST FLOOR, UNIT NO C- 108 SHANTI INDUSTRIAL PREMISES CSL','SAROJINI NAIDU ROAD, MULUND (W)','MUMBAI','21','400080',NULL,'8211111111','',NULL,'27','27AHIPT2109C1ZK','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5821',NULL,'0','0',NULL,0,'2026-05-16 10:19:22','2026-05-16 10:19:22'),(746,'249',NULL,NULL,'KOTAK MAHINDRA',12,'3745565.78','CR','DEFAULT','','','21','',NULL,'','',NULL,'27','','','KOTAK MAHINDRA',NULL,NULL,'TILAK NGR','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43725','0.00',NULL,'0','0',NULL,'0','753',NULL,'0','0',NULL,0,'2026-05-16 10:19:22','2026-05-16 10:19:22'),(747,'249',NULL,NULL,'KARANI SALES',11,'559396','CR','AT SHEKHANCHA GAON, (SATGHAR), POST-NARANGI, TAL-ALIBAUG, RAIGAD','','RAIGAD','21','402201',NULL,'8698464747','',NULL,'27','27BWWPK5894F1ZN','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6518',NULL,'0','0',NULL,0,'2026-05-16 10:19:22','2026-05-16 10:19:22'),(748,'249',NULL,NULL,'KAMLESH DEDHIA',5,'288300','CR','PROP','','','21','',NULL,'','',NULL,'27','','','KOTAK',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43909','0.00',NULL,'0','0',NULL,'0','1314',NULL,'0','0',NULL,0,'2026-05-16 10:19:22','2026-05-16 10:19:22'),(749,'249',NULL,NULL,'KAMDHENU CATERERS PRIVATE LTD (25-26)',5,'0','DR','BABU RAO PARULAKER MARG,5 TH FLOOR,','FLAT NO.501 SAFALYA BUILDING,DADAR -W','MUMBAI','21','400028',NULL,'1111111111','',NULL,'27','27AAFCK6219H2ZF','','IMPS',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6520',NULL,'0','0',NULL,0,'2026-05-16 10:19:22','2026-05-16 10:19:22'),(750,'249',NULL,NULL,'KAMAT HOLIDAYS',11,'0','DR','SHOP NO 3,BLDG 1,WE HIGHWAY,BANDRA','EAST, MUMBAI 51','','21','',NULL,'','',NULL,'27','27AMJPK8247Q1ZS','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','167',NULL,'0','0',NULL,0,'2026-05-16 10:19:22','2026-05-16 10:19:22'),(751,'249',NULL,NULL,'K . T . TRADERS',5,'0','DR','SHOP NO 18-19 GANDHI BAZAR','CHEMBUR COLONY','MUMBAI','21','400074',NULL,'9004958451','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6210',NULL,'0','0',NULL,0,'2026-05-16 10:19:22','2026-05-16 10:19:22'),(752,'249',NULL,NULL,'Jalaram Corp',11,'0','DR','Ghatkopar','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1732',NULL,'0','0',NULL,0,'2026-05-16 10:19:23','2026-05-16 10:19:23'),(753,'249',NULL,NULL,'JYOTHY LABS LTD',11,'0','DR','GALA NO 1,RAJLAXMI LOGISTIC PRK','BHIWANDI','MUMBAI','21','421302',NULL,'9702790610','',NULL,'27','27AAACJ3213B1ZA','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','3466',NULL,'0','0',NULL,0,'2026-05-16 10:19:23','2026-05-16 10:19:23'),(754,'249',NULL,NULL,'JAY INFOTECH',11,'0','DR','CHEMBUR','DEFAULT','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','117',NULL,'0','0',NULL,0,'2026-05-16 10:19:23','2026-05-16 10:19:23'),(755,'249',NULL,NULL,'JADIGH STORE',5,'0','DR','POWAI','','','21','',NULL,'9833028449','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','442',NULL,'0','0',NULL,0,'2026-05-16 10:19:23','2026-05-16 10:19:23'),(756,'249',NULL,NULL,'J.P ENTERPRISE',11,'0','DR','BHAWESHWAR ARCADE','GHATKOPAR WEST','','21','',NULL,'','',NULL,'27','27AACPM8979L1ZU','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-44233','0.00',NULL,'0','0',NULL,'0','1699',NULL,'0','0',NULL,0,'2026-05-16 10:19:23','2026-05-16 10:19:23'),(757,'249',NULL,NULL,'J.K BROTHERS',11,'0','DR','SHOP NO 81/4,RAJAWADI','D COLONY OPP YASHODA NIWAS','GHATKOPAR EAST','21','400077',NULL,'','',NULL,'27','27ACVPT9446J1ZG','','SVC',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','293',NULL,'0','0',NULL,0,'2026-05-16 10:19:23','2026-05-16 10:19:23'),(758,'249',NULL,NULL,'ICICI',12,'0','DR','DEFAULT','','','21','',NULL,'','',NULL,'27','','','ICICI',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5018',NULL,'0','0',NULL,0,'2026-05-16 10:19:23','2026-05-16 10:19:23'),(759,'249',NULL,NULL,'HONESTY NET SOLUTION',11,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43909','0.00',NULL,'0','0',NULL,'0','1307',NULL,'0','0',NULL,0,'2026-05-16 10:19:23','2026-05-16 10:19:23'),(760,'249',NULL,NULL,'HECTOR BEVERAGES PVT LTD',11,'0','DR','BHIWANDI','DEFAULT','','21','',NULL,'','',NULL,'27','27AACCH2747N1Z8','','FDRL',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','217',NULL,'0','0',NULL,0,'2026-05-16 10:19:23','2026-05-16 10:19:23'),(761,'249',NULL,NULL,'HARMONY AGENCY',11,'0','DR','GHATKOPAR','YESHODHARA CHAWL COMMITTE NALANDA NAGAR BEHINDE NALANDA NAGAR EXPRESE HIGH WAY','','21','',NULL,'9320996563','',NULL,'27','27AFOPJ1182P1ZU','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43735','0.00',NULL,'0','0',NULL,'0','896',NULL,'0','0',NULL,0,'2026-05-16 10:19:23','2026-05-16 10:19:23'),(762,'249',NULL,NULL,'HARMANI AGENCY',11,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43924','0.00',NULL,'0','0',NULL,'0','1323',NULL,'0','0',NULL,0,'2026-05-16 10:19:24','2026-05-16 10:19:24'),(763,'249',NULL,NULL,'GUJARAT CO OPERATIVE MILK MKTG FEDERATION LTD',11,'0','DR','SOUTH MUMBAI RAMPART HOUSE','4TH FLOOR, MUMBAI','','21','400023',NULL,'','',NULL,'27','27AAAAG5588Q1ZW','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','AAAG5588Q','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','288',NULL,'0','0',NULL,0,'2026-05-16 10:19:24','2026-05-16 10:19:24'),(764,'249',NULL,NULL,'GP PARSIK',12,'2146730.16','CR','DEFAULT','','','21','',NULL,'','',NULL,'27','27AAAAP0267H2ZN','','GP PARSIK',NULL,NULL,'GHATKOPAR EAST','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1585',NULL,'0','0',NULL,0,'2026-05-16 10:19:24','2026-05-16 10:19:24'),(765,'249',NULL,NULL,'GP ICICI',12,'0','DR','DEFAULT','','','21','',NULL,'','',NULL,'27','','','GP ICICI',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5777',NULL,'0','0',NULL,0,'2026-05-16 10:19:24','2026-05-16 10:19:24'),(766,'249',NULL,NULL,'GOVIND ENTERPRISES',11,'0','DR','SHOP NO.2,VISHNU NAGAR, NR HANUMAN MANDIR,','L.U.GADKARI MARG,CHEMBUR','','21','',NULL,'7021446484','',NULL,'27','27BDEPD2612M2ZP','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4829',NULL,'0','0',NULL,0,'2026-05-16 10:19:24','2026-05-16 10:19:24'),(767,'249',NULL,NULL,'GENSTAR CABLES',11,'0','DR','GHATKOPER WEST','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43909','0.00',NULL,'0','0',NULL,'0','1306',NULL,'0','0',NULL,0,'2026-05-16 10:19:24','2026-05-16 10:19:24'),(768,'249',NULL,NULL,'GENERAL MILLS INDIA PVT LTD',11,'0','DR','GALA 53, JAI MATA DI COMPD','BLDG NO U,THANE','THANE','21','421302',NULL,'','',NULL,'27','27AAACG1773B1Z0','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','242',NULL,'0','0',NULL,0,'2026-05-16 10:19:24','2026-05-16 10:19:24'),(769,'249',NULL,NULL,'GDR Agency LLP',11,'17328','CR','Grd Flr,Hira Bldg,Jahangir Street,Bhatia Hosp','Grand Rd (W)','Mumbai','21','400004',NULL,'7738783421','',NULL,'27','27AAVFG6753B1Z3','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6544',NULL,'0','0',NULL,0,'2026-05-16 10:19:24','2026-05-16 10:19:24'),(770,'249',NULL,NULL,'GAURI ENTERPRISES',11,'0','DR','MULUND','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43717','0.00',NULL,'0','0',NULL,'0','734',NULL,'0','0',NULL,0,'2026-05-16 10:19:24','2026-05-16 10:19:24'),(771,'249',NULL,NULL,'G.C.MARKETING',5,'0','DR','RAJESHREE SHAHU NAGAR , BUILDING NO E-6 JASMINE MILL ROAD,','MAHIM WAST','','21','',NULL,'9819143475','',NULL,'27','27AATFG4703F1ZB','','KOTAK BANK',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4834',NULL,'0','0',NULL,0,'2026-05-16 10:19:24','2026-05-16 10:19:24'),(772,'249',NULL,NULL,'FRESH-N-FUSION AGRO FOOD PVT LTD',11,'0','DR','112,1ST FLR,LODHA SUPREMO RD','RD NO 22,WAGLE ESTATE','THANE','21','400604',NULL,'2225827322','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4027',NULL,'0','0',NULL,0,'2026-05-16 10:19:25','2026-05-16 10:19:25'),(773,'249',NULL,NULL,'ENRISSION INDIA PVT LTD',11,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43912','0.00',NULL,'0','0',NULL,'0','1319',NULL,'0','0',NULL,0,'2026-05-16 10:19:25','2026-05-16 10:19:25'),(774,'249',NULL,NULL,'EMAMI LIMITED',11,'0','DR','GODOWN 9/12,SHREE GANESH COMPLEX','DAPODA RD,BHIWANDI','','21','421302',NULL,'1111111111','',NULL,'27','27AAACH7412G1ZT','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43713','0.00',NULL,'0','0',NULL,'0','718',NULL,'0','0',NULL,0,'2026-05-16 10:19:25','2026-05-16 10:19:25'),(775,'249',NULL,NULL,'DHARAMRAJ AGENCY',11,'0','DR','M N RD BAIL BAZAR','','','21','400070',NULL,'','',NULL,'27','27AHKPJ9400G1ZC','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1771',NULL,'0','0',NULL,0,'2026-05-16 10:19:25','2026-05-16 10:19:25'),(776,'249',NULL,NULL,'DHARAMRAJ AGENCY',5,'0','DR','BAIL BAZAR, KURLA WEST','MUMBAI','','21','400070',NULL,'','',NULL,'27','27AHKPJ9400G1ZC','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43864','0.00',NULL,'0','0',NULL,'0','1286',NULL,'0','0',NULL,0,'2026-05-16 10:19:25','2026-05-16 10:19:25'),(777,'249',NULL,NULL,'DABUR INDIA LTD',11,'0','DR','BHIWANDI','DEFAULT','','21','',NULL,'','',NULL,'27','27AAACD0474C1Z5','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','216',NULL,'0','0',NULL,0,'2026-05-16 10:19:25','2026-05-16 10:19:25'),(778,'249',NULL,NULL,'COSMOS CATERING SERVICE',5,'180856','DR','IIPS  SOMAIYYA HOSPITAL','CHUNNABHATTI','','21','',NULL,'9322361017','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5874',NULL,'0','0',NULL,0,'2026-05-16 10:19:25','2026-05-16 10:19:25'),(779,'249',NULL,NULL,'BOMBAY STATIONERS',11,'0','DR','SHOP 5,A WING,MITTAL TOWERS','NARIMAN POINT','','21','400021',NULL,'9930949970','',NULL,'27','27AYXPR8262J1ZB','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4573',NULL,'0','0',NULL,0,'2026-05-16 10:19:25','2026-05-16 10:19:25'),(780,'249',NULL,NULL,'BIGDEALS 24*7',5,'0','DR','704/A,PRAMILA APT.OPP KALINA UNIVERSITY','SANTACRUZ EAST','400098','21','',NULL,'8955465625','',NULL,'27','27AARFB8088L1ZJ','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4769',NULL,'0','0',NULL,0,'2026-05-16 10:19:25','2026-05-16 10:19:25'),(781,'249',NULL,NULL,'BHATT COMPUTERS',11,'0','DR','GAONDEVI CHS,BHANDUP WEST','','','21','400078',NULL,'','',NULL,'27','27AELPB5287K1Z3','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','1634',NULL,'0','0',NULL,0,'2026-05-16 10:19:25','2026-05-16 10:19:25'),(782,'249',NULL,NULL,'BHARAT PUMP  SERVICES',5,'0','DR','SHOP NO 19,KANARA BUSINESS CENTRE PROMISES','LAXMI NAGAR GHATKOPAR EAST','MUMBAI','21','400075',NULL,'1111111111','',NULL,'27','27AAQHA5561E1Z8','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6519',NULL,'0','0',NULL,0,'2026-05-16 10:19:26','2026-05-16 10:19:26'),(783,'249',NULL,NULL,'B.R ENTERPRISES PVT LTD',11,'0','DR','SONA UDYOG IND ESTATE','ANDHERI EAST','','21','',NULL,'','',NULL,'27','27AABCB9657J1Z8','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','230',NULL,'0','0',NULL,0,'2026-05-16 10:19:26','2026-05-16 10:19:26'),(784,'249',NULL,NULL,'Ace enterprises',11,'0','DR','B15,Badridhamchsl,90ft Rd','Sakinaka','Mumbai','21','400072',NULL,'9076324878','',NULL,'27','27AAZPU2280R1ZD','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6395',NULL,'0','0',NULL,0,'2026-05-16 10:19:26','2026-05-16 10:19:26'),(785,'249',NULL,NULL,'AZA MARKETING',11,'30592','CR','GROUND FLOOR FLAT NO 1 KARIM MANSION SHAIDA MARG','CHINCHBUNDER MUMBAI','MUMBAI','21','400009',NULL,'87515164584','',NULL,'27','27AVYPA0187H1ZA','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','6545',NULL,'0','0',NULL,0,'2026-05-16 10:19:26','2026-05-16 10:19:26'),(786,'249',NULL,NULL,'AXIS CC',12,'6290003.62','DR','DEFAULT','','','21','',NULL,'','',NULL,'27','','','AXIS CC',NULL,NULL,'GHATKOPAR EAST','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4866',NULL,'0','0',NULL,0,'2026-05-16 10:19:26','2026-05-16 10:19:26'),(787,'249',NULL,NULL,'ARIHANT MARKETING',11,'0','DR','16A, SAMRAT MILL COMPD','LBS MRG, VIKHROLI WEST','MUMBAI','21','400079',NULL,'','',NULL,'27','27AADHH8867H1ZT','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1.15E+13','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43926','0.00',NULL,'0','0',NULL,'0','1327',NULL,'0','0',NULL,0,'2026-05-16 10:19:26','2026-05-16 10:19:26'),(788,'249',NULL,NULL,'APL TECHNO',11,'11999.66','DR','A601,6TH FLR,RAHEJA POINT1,','NEHRU RD,NXT TO SVC BANK','OPP VAKOLA CHURCH,VAKOLA','21','400027',NULL,'9111111111','',NULL,'27','27ABRFA3497M1ZL','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4869',NULL,'0','0',NULL,0,'2026-05-16 10:19:26','2026-05-16 10:19:26'),(789,'249',NULL,NULL,'ANNAPURNA FOODS',11,'0','DR','GHATKOPAR EAST','','','21','',NULL,'9323427666','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','5670',NULL,'0','0',NULL,0,'2026-05-16 10:19:26','2026-05-16 10:19:26'),(790,'249',NULL,NULL,'ANDHRA BANK',12,'0','DR','DEFAULT','','','21','',NULL,'','',NULL,'27','','','ANDHRA BANK',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','277',NULL,'0','0',NULL,0,'2026-05-16 10:19:26','2026-05-16 10:19:26'),(791,'249',NULL,NULL,'AMUL PRODUCT',11,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43911','0.00',NULL,'0','0',NULL,'0','1318',NULL,'0','0',NULL,0,'2026-05-16 10:19:26','2026-05-16 10:19:26'),(792,'249',NULL,NULL,'AMRUT MARKETING',11,'0','DR','13,PARAS NIKETAN,CHHEDA NAGAR','CHEMBUR','','21','400089',NULL,'9321773737','',NULL,'27','27AAIFA4740M1Z8','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','4954',NULL,'0','0',NULL,0,'2026-05-16 10:19:27','2026-05-16 10:19:27'),(793,'249',NULL,NULL,'ADVANCE ENGINEERING SERVICE',11,'0','DR','KAJU PADA','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43934','0.00',NULL,'0','0',NULL,'0','1341',NULL,'0','0',NULL,0,'2026-05-16 10:19:27','2026-05-16 10:19:27'),(794,'249',NULL,NULL,'A1',11,'0','DR','GKTPR','','','21','',NULL,'','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0','undefined-undefined-43759','0.00',NULL,'0','0',NULL,'0','1058',NULL,'0','0',NULL,0,'2026-05-16 10:19:27','2026-05-16 10:19:27');
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int NOT NULL DEFAULT '0',
  `ADDRESS1` text,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `REMOTE_ID` varchar(255) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=697 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
INSERT INTO `SAC_IMPORT` VALUES (1,'249','A1','11','DR','0','','','','1','1',0,'GKTPR','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43759','1058'),(2,'249','ADVANCE ENGINEERING SERVICE','11','DR','0','','','','1','1',0,'KAJU PADA','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43934','1341'),(3,'249','AMRUT MARKETING','11','DR','0','27AAIFA4740M1Z8','','','1','1',0,'13,PARAS NIKETAN,CHHEDA NAGAR','CHEMBUR','','Maharashtra','27','400089','','9321773737','','','0','0','0','0','',NULL,'4954'),(4,'249','AMUL PRODUCT','11','DR','0','','','','1','1',0,'KAJU PADA','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43911','1318'),(5,'249','ANDHRA BANK','12','DR','0','','','','1','1',0,'DEFAULT','','','Maharashtra','27','','','','ANDHRA BANK','','0','0','0','0','',NULL,'277'),(6,'249','ANNAPURNA FOODS','11','DR','0','','','','1','1',0,'GHATKOPAR EAST','','','Maharashtra','27','','','9323427666','','','0','0','0','0','',NULL,'5670'),(7,'249','APL TECHNO','11','DR','11999.66','27ABRFA3497M1ZL','','','1','1',0,'A601,6TH FLR,RAHEJA POINT1,','NEHRU RD,NXT TO SVC BANK','OPP VAKOLA CHURCH,VAKOLA','Maharashtra','27','400027','','9111111111','','','0','0','0','0','',NULL,'4869'),(8,'249','ARIHANT MARKETING','11','DR','0','27AADHH8867H1ZT','','','1','1',0,'16A, SAMRAT MILL COMPD','LBS MRG, VIKHROLI WEST','MUMBAI','Maharashtra','27','400079','','','','','0','0','0','0','1.15E+13','undefined-undefined-43926','1327'),(9,'249','AXIS CC','12','DR','6290003.62','','','','1','1',0,'DEFAULT','','','Maharashtra','27','','','','AXIS CC','GHATKOPAR EAST','0','0','0','0','',NULL,'4866'),(10,'249','AZA MARKETING','11','CR','30592','27AVYPA0187H1ZA','','','1','1',0,'GROUND FLOOR FLAT NO 1 KARIM MANSION SHAIDA MARG','CHINCHBUNDER MUMBAI','MUMBAI','Maharashtra','27','400009','','87515164584','','','0','0','0','0','1.15E+13',NULL,'6545'),(11,'249','Ace enterprises','11','DR','0','27AAZPU2280R1ZD','','','1','1',0,'B15,Badridhamchsl,90ft Rd','Sakinaka','Mumbai','Maharashtra','27','400072','','9076324878','','','0','0','0','0','',NULL,'6395'),(12,'249','B.R ENTERPRISES PVT LTD','11','DR','0','27AABCB9657J1Z8','','','1','1',0,'SONA UDYOG IND ESTATE','ANDHERI EAST','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'230'),(13,'249','BHARAT PUMP  SERVICES','5','DR','0','27AAQHA5561E1Z8','','','1','1',0,'SHOP NO 19,KANARA BUSINESS CENTRE PROMISES','LAXMI NAGAR GHATKOPAR EAST','MUMBAI','Maharashtra','27','400075','','1111111111','','','0','0','0','0','',NULL,'6519'),(14,'249','BHATT COMPUTERS','11','DR','0','27AELPB5287K1Z3','','','1','1',0,'GAONDEVI CHS,BHANDUP WEST','','','Maharashtra','27','400078','','','','','0','0','0','0','',NULL,'1634'),(15,'249','BIGDEALS 24*7','5','DR','0','27AARFB8088L1ZJ','','','1','1',0,'704/A,PRAMILA APT.OPP KALINA UNIVERSITY','SANTACRUZ EAST','400098','Maharashtra','27','','','8955465625','','','0','0','0','0','',NULL,'4769'),(16,'249','BOMBAY STATIONERS','11','DR','0','27AYXPR8262J1ZB','','','1','1',0,'SHOP 5,A WING,MITTAL TOWERS','NARIMAN POINT','','Maharashtra','27','400021','','9930949970','','','0','0','0','0','',NULL,'4573'),(17,'249','COSMOS CATERING SERVICE','5','DR','180856','','','','1','1',0,'IIPS  SOMAIYYA HOSPITAL','CHUNNABHATTI','','Maharashtra','27','','','9322361017','','','0','0','0','0','',NULL,'5874'),(18,'249','DABUR INDIA LTD','11','DR','0','27AAACD0474C1Z5','','','1','1',0,'BHIWANDI','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'216'),(19,'249','DHARAMRAJ AGENCY','5','DR','0','27AHKPJ9400G1ZC','','','1','1',0,'BAIL BAZAR, KURLA WEST','MUMBAI','','Maharashtra','27','400070','','','','','0','0','0','0','','undefined-undefined-43864','1286'),(20,'249','DHARAMRAJ AGENCY','11','DR','0','27AHKPJ9400G1ZC','','','1','1',0,'M N RD BAIL BAZAR','','','Maharashtra','27','400070','','','','','0','0','0','0','',NULL,'1771'),(21,'249','EMAMI LIMITED','11','DR','0','27AAACH7412G1ZT','','','1','1',0,'GODOWN 9/12,SHREE GANESH COMPLEX','DAPODA RD,BHIWANDI','','Maharashtra','27','421302','','1111111111','','','0','0','0','0','','undefined-undefined-43713','718'),(22,'249','ENRISSION INDIA PVT LTD','11','DR','0','','','','1','1',0,'KAJU PADA','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43912','1319'),(23,'249','FRESH-N-FUSION AGRO FOOD PVT LTD','11','DR','0','','','','1','1',0,'112,1ST FLR,LODHA SUPREMO RD','RD NO 22,WAGLE ESTATE','THANE','Maharashtra','27','400604','','2225827322','','','0','0','0','0','',NULL,'4027'),(24,'249','G.C.MARKETING','5','DR','0','27AATFG4703F1ZB','','','1','1',0,'RAJESHREE SHAHU NAGAR , BUILDING NO E-6 JASMINE MILL ROAD,','MAHIM WAST','','Maharashtra','27','','','9819143475','KOTAK BANK','','0','0','0','0','',NULL,'4834'),(25,'249','GAURI ENTERPRISES','11','DR','0','','','','1','1',0,'MULUND','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43717','734'),(26,'249','GDR Agency LLP','11','CR','17328','27AAVFG6753B1Z3','','','1','1',0,'Grd Flr,Hira Bldg,Jahangir Street,Bhatia Hosp','Grand Rd (W)','Mumbai','Maharashtra','27','400004','','7738783421','','','0','0','0','0','',NULL,'6544'),(27,'249','GENERAL MILLS INDIA PVT LTD','11','DR','0','27AAACG1773B1Z0','','','1','1',0,'GALA 53, JAI MATA DI COMPD','BLDG NO U,THANE','THANE','Maharashtra','27','421302','','','','','0','0','0','0','',NULL,'242'),(28,'249','GENSTAR CABLES','11','DR','0','','','','1','1',0,'GHATKOPER WEST','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43909','1306'),(29,'249','GOVIND ENTERPRISES','11','DR','0','27BDEPD2612M2ZP','','','1','1',0,'SHOP NO.2,VISHNU NAGAR, NR HANUMAN MANDIR,','L.U.GADKARI MARG,CHEMBUR','','Maharashtra','27','','','7021446484','','','0','0','0','0','',NULL,'4829'),(30,'249','GP ICICI','12','DR','0','','','','1','1',0,'DEFAULT','','','Maharashtra','27','','','','GP ICICI','','0','0','0','0','',NULL,'5777'),(31,'249','GP PARSIK','12','CR','2146730.16','27AAAAP0267H2ZN','','','1','1',0,'DEFAULT','','','Maharashtra','27','','','','GP PARSIK','GHATKOPAR EAST','0','0','0','0','',NULL,'1585'),(32,'249','GUJARAT CO OPERATIVE MILK MKTG FEDERATION LTD','11','DR','0','27AAAAG5588Q1ZW','','AAAG5588Q','1','1',0,'SOUTH MUMBAI RAMPART HOUSE','4TH FLOOR, MUMBAI','','Maharashtra','27','400023','','','','','0','0','0','0','1.15E+13',NULL,'288'),(33,'249','HARMANI AGENCY','11','DR','0','','','','1','1',0,'KAJU PADA','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43924','1323'),(34,'249','HARMONY AGENCY','11','DR','0','27AFOPJ1182P1ZU','','','1','1',0,'GHATKOPAR','YESHODHARA CHAWL COMMITTE NALANDA NAGAR BEHINDE NALANDA NAGAR EXPRESE HIGH WAY','','Maharashtra','27','','','9320996563','','','0','0','0','0','','undefined-undefined-43735','896'),(35,'249','HECTOR BEVERAGES PVT LTD','11','DR','0','27AACCH2747N1Z8','','','1','1',0,'BHIWANDI','DEFAULT','','Maharashtra','27','','','','FDRL','','0','0','0','0','',NULL,'217'),(36,'249','HONESTY NET SOLUTION','11','DR','0','','','','1','1',0,'KAJU PADA','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43909','1307'),(37,'249','ICICI','12','DR','0','','','','1','1',0,'DEFAULT','','','Maharashtra','27','','','','ICICI','','0','0','0','0','',NULL,'5018'),(38,'249','J.K BROTHERS','11','DR','0','27ACVPT9446J1ZG','','','1','1',0,'SHOP NO 81/4,RAJAWADI','D COLONY OPP YASHODA NIWAS','GHATKOPAR EAST','Maharashtra','27','400077','','','SVC','','0','0','0','0','',NULL,'293'),(39,'249','J.P ENTERPRISE','11','DR','0','27AACPM8979L1ZU','','','1','1',0,'BHAWESHWAR ARCADE','GHATKOPAR WEST','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44233','1699'),(40,'249','JADIGH STORE','5','DR','0','','','','1','1',0,'POWAI','','','Maharashtra','27','','','9833028449','','','0','0','0','0','',NULL,'442'),(41,'249','JAY INFOTECH','11','DR','0','','','','1','1',0,'CHEMBUR','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'117'),(42,'249','JYOTHY LABS LTD','11','DR','0','27AAACJ3213B1ZA','','','1','1',0,'GALA NO 1,RAJLAXMI LOGISTIC PRK','BHIWANDI','MUMBAI','Maharashtra','27','421302','','9702790610','','','0','0','0','0','',NULL,'3466'),(43,'249','Jalaram Corp','11','DR','0','','','','1','1',0,'Ghatkopar','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'1732'),(44,'249','K . T . TRADERS','5','DR','0','','','','1','1',0,'SHOP NO 18-19 GANDHI BAZAR','CHEMBUR COLONY','MUMBAI','Maharashtra','27','400074','','9004958451','','','0','0','0','0','',NULL,'6210'),(45,'249','KAMAT HOLIDAYS','11','DR','0','27AMJPK8247Q1ZS','','','1','1',0,'SHOP NO 3,BLDG 1,WE HIGHWAY,BANDRA','EAST, MUMBAI 51','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'167'),(46,'249','KAMDHENU CATERERS PRIVATE LTD (25-26)','5','DR','0','27AAFCK6219H2ZF','','','1','1',0,'BABU RAO PARULAKER MARG,5 TH FLOOR,','FLAT NO.501 SAFALYA BUILDING,DADAR -W','MUMBAI','Maharashtra','27','400028','','1111111111','IMPS','','0','0','0','0','',NULL,'6520'),(47,'249','KAMLESH DEDHIA','5','CR','288300','','','','1','1',0,'PROP','','','Maharashtra','27','','','','KOTAK','','0','0','0','0','','undefined-undefined-43909','1314'),(48,'249','KARANI SALES','11','CR','559396','27BWWPK5894F1ZN','','','1','1',0,'AT SHEKHANCHA GAON, (SATGHAR), POST-NARANGI, TAL-ALIBAUG, RAIGAD','','RAIGAD','Maharashtra','27','402201','','8698464747','','','0','0','0','0','1.15E+13',NULL,'6518'),(49,'249','KOTAK MAHINDRA','12','CR','3745565.78','','','','1','1',0,'DEFAULT','','','Maharashtra','27','','','','KOTAK MAHINDRA','TILAK NGR','0','0','0','0','','undefined-undefined-43725','753'),(50,'249','Khushi Enterprises','11','DR','0','27AHIPT2109C1ZK','','','1','1',0,'1 ST FLOOR, UNIT NO C- 108 SHANTI INDUSTRIAL PREMISES CSL','SAROJINI NAIDU ROAD, MULUND (W)','MUMBAI','Maharashtra','27','400080','','8211111111','','','0','0','0','0','',NULL,'5821'),(51,'249','LAMINATE PALACE','11','DR','0','27AADHJ4032Q1ZZ','','','1','1',0,'SHOP 17,PRANIK CHAMBERS,OPP EXCOM HOUSE','SAKIVIHAR RD,SAKINAKA','MUMBAI','Maharashtra','27','400072','','8812111111','','','0','0','0','0','',NULL,'4934'),(52,'249','LOREAL INDIA PVT LTD','11','CR','29401.11','27AAACL0738K1ZH','','','1','1',0,'DHL SUPPLY CHAM,428,CHAKAN','CHAKAN','PUNE','Maharashtra','27','410501','','2267003000','','','0','0','0','0','',NULL,'4181'),(53,'249','M J TRADERS','5','DR','0','27CEIPS8460N1ZK','','','1','1',0,'GROUND FLOOR , 2 PLT 273/ 277 ANANT DEEP','CHAMBERS NARSHINATHA STREET BHAT BAZAR MASJID (W)','MUMBAI','Maharashtra','27','400009','','0','','','0','0','0','0','',NULL,'5660'),(54,'249','M N ENTERPRISES','11','DR','0','27AXSPP8901C1Z5','','','1','1',0,'HANUMAN TEKDI,NAWA GAON','DAHISAR (W)','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'193'),(55,'249','MAHA LAXMI G/S','5','DR','0','','','','1','1',0,'POWAI','','','Maharashtra','27','','','9867762431','','','0','0','0','0','',NULL,'441'),(56,'249','MAHALAXMI ENTERPRISES','11','DR','0','27AHQPC9763P1ZC','','','1','1',0,'Shop 4,Opp Thakur Engg College','Kandivali West','Mumbai','Maharashtra','27','400101','','9987621563','','','0','0','0','0','',NULL,'6114'),(57,'249','MAHARASHTRA DHANYA BHANDAR','5','DR','0','27ABYPP7065P2ZB','','','1','1',0,'POWAI','','','Maharashtra','27','','','2225782137','','','0','0','0','0','',NULL,'444'),(58,'249','MALLIARJUN','5','CR','94500','','','','1','1',0,'CHEMBUR','','','Maharashtra','27','','','8451635655','','','0','0','0','0','',NULL,'6574'),(59,'249','MANIRATNAM BOUTIQ','11','DR','0','27ARBPV0195K1ZD','','','1','1',0,'44,RC MARG,NR FINE ARTS','CHEMBUR','','Maharashtra','27','','','9619667588','','','0','0','0','0','',NULL,'3921'),(60,'249','MARS INTERNATIONAL INDIA PVT LTD','11','DR','0','27AAACE6794J1Z6','','','1','1',0,'C/O ROBINSON CARGO & LOGISTIC','BHIWANID NASHIK RD,','BHIWANDI THANE','Maharashtra','27','421302','','','','','0','0','0','0','1.00E+13',NULL,'266'),(61,'249','MAYORA INDIA PRIVATE LTD','11','DR','0','','','','1','1',0,'SUREY NO H383/9 GALA 5/8 PATRA SHED MAHAIR COMP.AAMANE','VILLAGE BHIWANDI','','Maharashtra','27','','','9004541045','','','0','0','0','0','1.15E+13',NULL,'6052'),(62,'249','MAYURI DEDHIA','5','DR','0','','','','1','1',0,'CHEMBUR','','','Maharashtra','27','','','1111111111','','','0','0','0','0','',NULL,'6499'),(63,'249','MEADOWS INDIA-(23-24)','11','DR','0','27ABBFM1453H1ZG','','','1','1',0,'A4 PRIME PLAZA GR FLOOR BM MARG JV PATEL','COM. OPP RAILWAY STATION ELPHINSTONE','','Maharashtra','27','','','1111111111','','','0','0','0','0','',NULL,'6408'),(64,'249','MEENA INDUSTRIES','11','CR','22311','27AAKFM3322K1Z6','','','1','1',0,'GALA NO 21,KOHINOOR TEXTILE PRTG WORK','GHATKOPAR WEST','MUMBAI','Maharashtra','27','400086','','9930993977','','','0','0','0','0','','undefined-undefined-44123','1511'),(65,'249','METHA & COMPANY','5','DR','0','27CFYPM4254B2Z4','','','1','1',0,'GRD FLOOR SHOP NO 5 & 6KADRI MANSION SIPN ROAD NO 24B NEAR','TARACHAND BAPA SION (W)','','Maharashtra','27','','','9619997841','','','0','0','0','0','',NULL,'5761'),(66,'249','METRO CASH AND CARRY INDIA PVT LTD','11','DR','0','27AACCM4684P1ZR','','','1','1',0,'LBS MARG, BHANDUP','WEST','','Maharashtra','27','400078','','','','','0','0','0','0','','undefined-undefined-44287','1766'),(67,'249','MIHIR ENTERPRISES','11','DR','0','27ATLPP9237A1ZH','','','1','1',0,'SHOP NO 4,VASUDEO CHAWL','PARASWADI GHATKOPAR WEST','','Maharashtra','27','400086','','','','','0','0','0','0','','undefined-undefined-44220','1684'),(68,'249','Marrix Academy','11','DR','0','','','','1','1',0,'Ws','','','Maharashtra','27','','','1234567890','','','0','0','0','0','',NULL,'4616'),(69,'249','Mona Beauty Salon','5','DR','0','','','','1','1',0,'shop no 2 laxmi niwas sita ram jhadav marg','Lower Parel','mumbai','Maharashtra','27','400013','','9768459497','','','0','0','0','0','',NULL,'4818'),(70,'249','NANDINI ENTERPRISES','11','DR','0','27BMQPG5832H1ZR','','','1','1',0,'1ST FLOOR 151 GARDEN PLOT KHERWADI ROAD NR BHAUMIYA MANDIR','BANDRA E','','Maharashtra','27','','','9322565522','','','0','0','0','0','',NULL,'6399'),(71,'249','NAVIIN DEDHIA','5','DR','0','','','','1','1',0,'CHEMBUR','','','Maharashtra','27','','','1111111111','','','0','0','0','0','',NULL,'6498'),(72,'249','NEO PLANET SYSTEM','11','DR','0','27AJWPJ3868L1Z8','','','1','1',0,'312,ADITYA ARCADE,','LAMINTON RD','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43773','1163'),(73,'249','OMEGA HOSPITALITY','5','DR','6904','27ADJPC1769J1ZD','','','1','1',0,'6TH,613 ANURAG BUSINESS CENTRE PREM CO.OP SOC.LTD','WT PATIL MARG,NEAR AMAR CINEMA','MUMBAI','Maharashtra','27','400071','','8752164658','','','0','0','0','0','',NULL,'6537'),(74,'249','OMKAR','5','DR','0','','','','1','1',0,'CHEMBUR','','','Maharashtra','27','','','8854894849','','','0','0','0','0','',NULL,'6550'),(75,'249','PARK NEXT HOTELS PROVITE LTD','5','DR','13986','27AABCP6227E1ZL','','','1','1',0,'KRUSHAL COMM COMPLEX AMAR MAHAL','G M ROAD CHEMBUR','MUMBAI','Maharashtra','27','400089','','4564658458','','','0','0','0','0','',NULL,'6553'),(76,'249','PARLE AGRO PVT.LTD','11','CR','2305834.3','27AAACP8416G1ZF','','AAACP8416G','1','1',0,'M/S PARIJIT LOGISTICS PVT LTD CTS NO 596-A,OLD METAL BOX FACTORY','M WARD L.U.GADKARI MARG PRAYAG NAGAR','MUMBAI','Maharashtra','27','400071','','2151641545','','','0','0','0','0','1.15E+13',NULL,'6528'),(77,'249','PARLE BISCUITS PVT LTD','11','CR','40513917','27AAACP0485D1ZO','','AAACP0485D','1','1',0,'VILE PARLE EAST,MUMBAI 57','DEFAULT','','Maharashtra','27','','','9820221421','','','0','0','0','0','1.00E+13',NULL,'109'),(78,'249','PARLE PRODUCTS PVT LTD','11','DR','0','','','','1','1',0,'VILE PARLE EAST,MUMBAI 57','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'110'),(79,'249','PARLE SAMPLING CODE','5','DR','930','','','','1','1',0,'VILE PARLE EAST','VS KHANDEKAR MAGR','MUMBAI','Maharashtra','27','400057','','8850503436','','','0','0','0','0','',NULL,'6521'),(80,'249','POOJA BANGALI SWEETS','5','DR','0','','','','1','1',0,'POWAI','','','Maharashtra','27','','','8850117382','','','0','0','0','0','',NULL,'446'),(81,'249','PRANJAL RAMESH','5','DR','0','','','','1','1',0,'CHEMBUR','','','Maharashtra','27','','','9526545426','','','0','0','0','0','',NULL,'6572'),(82,'249','PRIVATE LIMITED COMPANY','5','DR','0','27AABCP6227E1ZL','','','1','1',0,'KRUSHAL COMM COMPLEX AMAR MAHAL G.M.ROAD','CHEMBUR','MUMBAI','Maharashtra','27','400089','','1111111111','','','0','0','0','0','',NULL,'6527'),(83,'249','PUNYAM DISTRIBUTOR','11','DR','0','27AAEHN7306Q1ZN','','','1','1',0,'CHEMBUR','','','Maharashtra','27','','','','KOTAK','','0','0','0','0','',NULL,'300'),(84,'249','R.D.DISTRIBUTORS','11','DR','503139','27AAJPM7505P1Z3','','','1','1',0,'MOTILAL NGR NO 1,79/634','goregaon west','Mumbai','Maharashtra','27','400104','','1111111112','','','0','0','0','0','',NULL,'6511'),(85,'249','R.K MARKETING','11','DR','0','27ACRPG0630R1Z5','','','1','1',0,'GOVANDI STN WEST','','','Maharashtra','27','400043','','','','','0','0','0','0','','undefined-undefined-43752','1014'),(86,'249','RAJ TRADERS','11','DR','0','27AAPHA6784E1ZY','','','1','1',0,'GALA NO 3, VEDANT HOSPITAL','THANE','','Maharashtra','27','400607','','','','','0','0','0','0','','undefined-undefined-44038','1424'),(87,'249','REAL AGENCY','11','DR','0','27CASPM0324B1ZY','','','1','1',0,'OPP SHIVAJI NAGAR NEW BUS DEPO 90 FEET ROAD','GOVANDI','MUMBAI','Maharashtra','27','','','','','','0','0','0','0','',NULL,'296'),(88,'249','REGAL ENTERPRISES','11','DR','0','','','','1','1',0,'SHOP NO 2 PLT 149 VITHAL CHAWL KHERWADI','BANDRA EAST','','Maharashtra','27','','','9322866991','','','0','0','0','0','',NULL,'4945'),(89,'249','RELIANCE RETAIL LIMITED','11','DR','0','27AABCR1718E1ZP','','','1','1',0,'O1PLINTH NUMBER 1 7 SAGAR COMPLEX','MUM NASHIK HIGHWAY OPP HP PETROL PUMP','','Maharashtra','27','','','1556544165','','','0','0','0','0','',NULL,'4846'),(90,'249','RISHIKESH MEDICAL','5','DR','0','','','','1','1',0,'TUNGA','TUNGA','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'625'),(91,'249','RK ENTERPRISES','11','DR','0','','','','1','1',0,'GOVANDI','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43721','744'),(92,'249','ROP ENTERPRISES','11','CR','15000','27AQMPG0878L1ZB','','','1','1',0,'SHOP NO 2 WHISPERING PALM CHS','SECTOR 19 NEAR BANK OF INDIA','','Maharashtra','27','','','9821241879','','','0','0','0','0','',NULL,'4563'),(93,'249','Raj Sales','11','CR','0','27ADDPC7174K1ZE','','','1','1',0,'375/377, Shop 1,Babu Bldg','Laminton Rd, Grant Rd','Mumbai','Maharashtra','27','400007','','9594867223','','','0','0','0','0','',NULL,'6578'),(94,'249','Rohit Marketing','11','CR','1107401','27AKPPC6596A1Z0','','','1','1',0,'Safedpool Sakinaka','','Mumbai','Maharashtra','27','400072','','8779721761','','','0','0','0','0','',NULL,'6032'),(95,'249','SAMPLE','5','DR','0','','','','1','1',0,'CHEMBUR','','','Maharashtra','27','','','98211000101','','','0','0','0','0','',NULL,'6167'),(96,'249','SAN LOGISTIX','11','DR','0','27ADYFS0019E1ZX','','','1','1',0,'PLOT 23,KANDIVLI INDL','ESTATE,KANDIVLI WEST','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44233','1700'),(97,'249','SANGHVI COMPUTERS','11','DR','0','27ABAPS8813J1ZB','','','1','1',0,'TARA TEMPLE LANE,MADAN BLDG','LAMINTON RD,MUMBAI','','Maharashtra','27','400007','','23861785','','','0','0','0','0','',NULL,'4881'),(98,'249','SHIVAM AGENCY','11','DR','0','27AIDPD8869P1ZG','','','1','1',0,'SHOP NO 1,MOON APT,V.B NGR,','PIPELINE,KURLA WEST,M 70','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'161'),(99,'249','SHIVAM LIFE STYLE','5','DR','0','','','','1','1',0,'MUMBAI','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'1584'),(100,'249','SHREE DATTA TRADING','5','DR','3582540','27PURPK2832J1ZT','','','1','1',0,'WEST SIDE GODOWN KASARA DUMALA SANGAMNER ROAD','AHILYANAGAR','MAHARASHTRA','Maharashtra','27','422605','','8545614651','','','0','0','0','0','',NULL,'6575'),(120,'249','URMILA STORE','5','DR','0','','','','1','1',0,'POWAI','','','Maharashtra','27','','','9769585871','','','0','0','0','0','',NULL,'443'),(154,'249','RAWAL TRADING','5','DR','0','','','','2','3',0,'MUMBAI','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'116'),(157,'249','A S SALES','5','DR','0','','','','3','4',0,'LTT  9340051736','DEFAULT','','Maharashtra','27','','','9340051736','','','0','0','0','0','',NULL,'192'),(178,'249','SHAILADEVI  STALL PF - 1 (V.T SIDE)','5','DR','0','27CXIPD6176R1ZN','','','3','4',0,'NR TILAK NGR','TICKET COUNTER,9098700492','Mumbai','Maharashtra','27','400089','','9098700492','','','0','0','0','0','','undefined-undefined-44234','1705'),(179,'249','SHIVSHAKTI FOODS','5','DR','0','27BBBPA8798N1ZZ','','','3','4',0,'LTT','','Mumbai','Maharashtra','27','400089','','1111111111','','','0','0','0','0','','undefined-undefined-44175','1618'),(180,'249','SIDDHI SERVICES (AUROBINDU)','5','DR','4006','','','','3','4',0,'VIDHYAVIHAR','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'238'),(182,'249','SIDDHI SERVICES (MANGEMENT)','5','DR','0','','','','3','4',0,'VIDHYAVIHAR','SOMAIYA COLLAGE','Mumbai','Maharashtra','27','400089','','1111111111','','','0','0','0','0','',NULL,'237'),(183,'249','Scalable Hospitality management & canteen','5','DR','2459','','','','3','4',0,'SRV Hospital,Tilak Nagar','','','Maharashtra','27','','','9920523524','IMPS','','0','0','0','0','',NULL,'6407'),(184,'249','A.J.S CATERERS','5','DR','0','27ABAFA6497Q1ZO','','','4','5',0,'CHURCHGATE','','','Maharashtra','27','','','','UCO','','0','0','0','0','','undefined-undefined-43816','1233'),(185,'249','A.J.S CATERERS','5','DR','0','27ABAFA6497Q1ZO','','','4','5',0,'TILAK NAGAR TERMINUS','','mumbai','Maharashtra','27','400089','','1111111111','UCO BANK','CHEMBUR','0','0','0','0','',NULL,'248'),(186,'249','A.J.S CATERERS (BANDRA TERMINUS)','5','DR','0','27ABAFA6497Q1ZO','','','4','5',0,'BANDRA TERMINUS','','','Maharashtra','27','','','','UCO','CHEMBUR','0','0','0','0','',NULL,'260'),(187,'249','A.J.S CATERERS (MUMBAI CENTRAL)','5','DR','0','27ABAFA6497Q1ZO','','','4','5',0,'MUMBAI CENTRAL','','','Maharashtra','27','','','','UCO BANK','CHEMBUR','0','0','0','0','',NULL,'255'),(188,'249','A.N MAKHIJANI','5','DR','0','','','','4','5',0,'CST STATION PF 14','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43737','920'),(189,'249','A.P.FOODS','5','DR','18225','27ANRPS4136M1Z7','','','4','5',0,'D-905 AGARWAL RESIDENCY','SHANKAR LANE KANDIVALI','MUMBAI','Maharashtra','27','400067','','1111111111','NEFT','','0','0','0','0','2.15E+13',NULL,'261'),(190,'249','AASIKA CATERING SERVICES','5','DR','0','27EOUPS8693F1ZR','','','4','5',0,'SOMAIYA COLLEGE','DEFAULT','mumbai','Maharashtra','27','400077','','1111111111','','','0','0','0','0','',NULL,'145'),(191,'249','ABHAY MULTIPRO','5','DR','0','27AAJPM8079L1ZW','','','4','5',0,'TILAK NAGAR','MUMBAI','mumbai','Maharashtra','27','400089','','1111111111','SARASWAT','CHEMBUR','0','0','0','0','',NULL,'123'),(196,'249','ADITYA CATERERS','5','DR','0','27ANKPS2095J1ZE','','','4','5',0,'VES COLLEGE,COLLECTOR COL','CHEMBUR 74','mumba','Maharashtra','27','400071','','1111111111','','','0','0','0','0','',NULL,'228'),(197,'249','AGARWAL KIRANA','5','DR','0','','27AKSPA0929Q1ZL','','4','5',0,'TULJAPUR','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'256'),(198,'249','AJIT KAKA','5','DR','3181','','','','4','5',0,'PUNAM','','','Maharashtra','27','','','','GPAY 2063','','0','0','0','0','','undefined-undefined-43843','1268'),(199,'249','ALKO ENTERPRISES','5','DR','0','24GBSPD1472E1ZQ','','','4','5',0,'92,PATEL VAS,NR MAHAKALI MANDIR','VANDHIYA,DIST BHARUCH','KUTCH GUJARAT','Maharashtra','27','370150','','7874748371','','','0','0','0','0','',NULL,'4509'),(203,'249','ANIKET','5','DR','3177','','','','4','5',0,'PESTOM SAGAR','','','Maharashtra','27','','','11111111111','','','0','0','0','0','',NULL,'4774'),(204,'249','ANKIT BHARAT SHAH','5','CR','300317','','','','4','5',0,'GHATKOPAR','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44114','1492'),(205,'249','ANNAPURNA ENTERPRISES','11','DR','0','27AREPG4638B1Z4','','','4','5',0,'JHONE ROBERT COMPOUND SEWREE (EAST)','','MUMBAI','Maharashtra','27','400015','annapurnaenterprises1982@gmail.com','7875130642','','','0','0','0','0','',NULL,'6472'),(209,'249','ARROW ELECTRICALS INDIA LIMITED','5','DR','0','27AATCA7251M1ZZ','','','4','5',0,'11a 11b k.t. industrial park gorai pada','KT Industrial Park ,Vasai (E) VasaiVirar','PALGHAR','Maharashtra','27','401208','','8135976984','','','0','0','0','0','',NULL,'4315'),(210,'249','Aditya Birla New Age Hospitality Private Limited','5','DR','0','27AADCK9508M1Z1','','','4','5',0,'B-WING , 5TH FLOOR , BIRLA CENTURION ,','CENTURY MILLS , WORLI , MUMBAI','MUMBAI','Maharashtra','27','400030','','8149870351','','','0','0','0','0','',NULL,'6580'),(212,'249','Arham Enterprises','5','DR','40133','27AFAPJ5167N1Z3','','','4','5',0,'R NO 17, DOMNIC CHAWL','NR REEMA COMPLXVIDHYAVIHAR WEST','MUMBAI','Maharashtra','27','400086','','9820397484','JANKALYAN','','0','0','0','0','',NULL,'252'),(214,'249','BALAJI TRADERS','5','DR','156193','27AOEPS6558R1ZU','','','4','5',0,'SOYEGAON MARKET SATANA MALEGAON','','MUMBAI','Maharashtra','27','423203','','1.11E+14','','','0','0','0','0','1.15E+13',NULL,'6523'),(215,'249','BANDRINGA FOODS AND BEVERAGES PVT LTD','5','DR','0','27AAKCB4426A1Z1','','','4','5',0,'A301,Ali Bilal Siddhi Bldg,S.G Barve Mrg','Kurla East','MUMBAI','Maharashtra','27','400024','','8080189505','','','0','0','0','0','',NULL,'5893'),(218,'249','BHAGWATI TRADERS','5','DR','0','27BEYPC9311K1ZZ','','','4','5',0,'AT SOANGAON POST SAYKHEDA','DIST NASHIK','NASHIK','Maharashtra','27','422210','','','','','0','0','0','0','','undefined-undefined-43849','1276'),(219,'249','BHARAT ENGINEERS','5','DR','0','27AJEPG2942G1ZF','','','4','5',0,'1ST FLR,BLDG 150,PANT NGR PARIVARTAN CHS','PANT NAGAR,GHATKOPAR EAST','MUMBAI','Maharashtra','27','400075','','9820260639','','','0','0','0','0','',NULL,'4770'),(220,'249','BIG DEALS 24X7','5','DR','0','27AARFB8088L1ZJ','','','4','5',0,'704A,PRAMILA APT,OPP KALINA UNIV','SANTACRUZ EAST, MUMBAI','','Maharashtra','27','400098','','8097262491','','','0','0','0','0','',NULL,'4763'),(221,'249','BLUE PEARL FOUNDATION','5','DR','0','','','','4','5',0,'PL LOKHANDE MRG,CHEMBUR','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43810','1215'),(222,'249','BOMBAY GRAPHICS','5','DR','0','27AGJPP2619R1ZN','','','4','5',0,'45A,GRD FLOOR, SHAH & NAHAR INDL','ESTATE,LOWER PAREL','MUMBAI','Maharashtra','27','400013','','8268539133','','','0','0','0','0','',NULL,'4533'),(223,'249','BOTREE BILL CUSTOMERS','5','DR','0','','','','4','5',0,'BOTREE','','','Maharashtra','27','','','','SHAMRAO','','0','0','0','0','','undefined-undefined-43909','1313'),(229,'249','CASH (V.B)','5','DR','0','','','','4','5',0,'MUMBAI','','','Maharashtra','27','','','','BOB','','0','0','0','0','','undefined-undefined-43801','1200'),(243,'249','DESIRE BEVERAGES LLP','5','DR','0','','','','4','5',0,'SHOP NO 4 RADHIKA RESENDENCY','MANDAKNI ROAD','','Maharashtra','27','','','222524343','','','0','0','0','0','',NULL,'4472'),(245,'249','DHRUV ENTERPRISES','5','DR','0','27CPLPS8783N1ZK','','','4','5',0,'BLG NO 1,WING -C,PLOT NO 4,ROOM NO 5,','INDRAYANI NAGARI NIVARA CHS LTD,GEN A.K VAIDYA MARG,FILM CITY RD,GOREGAON (E)','MUMBAI','Maharashtra','27','400065','','1234567890','','','0','0','0','0','',NULL,'5481'),(301,'249','K J SOMAIYA HOSPITAL','5','DR','0','27AOBPS031631Z1','','','4','5',0,'SURESH SHETTY','EVARARD NAGAR,CHUNABHATTI','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'135'),(302,'249','K N & SONS','5','DR','0','','','','4','5',0,'SHOP NO 10,GHANSHYAM NAGAR','TRIKAMDAS RD, KANDIVALI WEST','MUMBAI','Maharashtra','27','400087','','9892038782','','','0','0','0','0','',NULL,'4161'),(303,'249','K STUDIO INC','5','DR','0','27AAHPS6652D1ZI','','','4','5',0,'UNIT NO 1, CTS 176,OPP KHATAU MILL','GAYATRI MANDIR','mumbai','Maharashtra','27','400071','','9355114433','','','0','0','0','0','',NULL,'6508'),(304,'249','K.Y.A APPARELL LLP','5','DR','0','27AAMFK3840Q1ZN','','','4','5',0,'MUMBAI','','mumbai','Maharashtra','27','400020','','1111111111','','','0','0','0','0','','undefined-undefined-44176','1619'),(305,'249','KA HOSPITALITY PVT LTD','5','DR','210318.16','27AADCK9508M1Z1','','','4','5',0,'S-201 , BLOCK NO.5 , THE LODHA LOGISTIC PARK','NR. PHOENIX MARKET CITY , PIPELINE RD., KURLA WEST','Mumbai','Maharashtra','27','400070','','8149870351','','','0','0','0','0','',NULL,'4806'),(306,'249','KAILASH','5','DR','0','','','','4','5',0,'CHEMBUR','','','Maharashtra','27','','','1.11E+26','','','0','0','0','0','',NULL,'6522'),(307,'249','KAILASH SONI','5','DR','0','','','','4','5',0,'KAJUPADA','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44086','1458'),(308,'249','KALPESH TIVOLI','5','DR','0','','','','4','5',0,'HIRANANDANI','','','Maharashtra','27','','','9820088828','','','0','0','0','0','','undefined-undefined-44054','1434'),(309,'249','KAMADHENU CATERERS','5','DR','0','','','','4','5',0,'DADAR','','','Maharashtra','27','','','9594811043','','','0','0','0','0','',NULL,'4917'),(310,'249','KANAKA FOOD MANAGEMENT SERVICES','5','DR','0','27AADCK2583J1ZA','','','4','5',0,'TATA POWER TROMBAY 7400279303','DEFAULT','Mumbai','Maharashtra','27','400071','','1111111111','KARNATAKA BANK','','0','0','0','0','',NULL,'202'),(311,'249','KIBIL CHEMISTS DRUGGISTS & GENERAL STORES','5','DR','0','','','','4','5',0,'DR.MENDADKARS HOSPITAL','NEXT TO SAWALI HOTEL,NEHRU NAGAR KURLA EAST','','Maharashtra','27','','','223630809','','','0','0','0','0','',NULL,'4184'),(312,'249','KINGCRAFT RESTAURANTS PVT LTD','5','DR','0','27AAHCK3834C1ZP','','','4','5',0,'SHOP NO 6,AJMERA ROYAL CHS','OPP CRYTAL PLAZA','ANDHERI WEST','Maharashtra','27','400053','','1111111111','','','0','0','0','0','',NULL,'283'),(313,'249','KISHOR KAMBLE','5','DR','0','','','','4','5',0,'DEFAULT','DEFAULT','','Maharashtra','27','','','','BOI','','0','0','0','0','',NULL,'224'),(314,'249','KOHINOOR HOSPITAL PVT LTD','5','DR','0','27AADCK3848G1ZF','','','4','5',0,'KOHINOOR CITY,KIROL RD','KURLA WEST MUMBAI','mumbai','Maharashtra','27','400070','','2267556755','SBI','','0','0','0','0','',NULL,'1636'),(315,'249','KRISHNA OVERSEAS INC.','5','DR','75283','07AAHFK5581H1Z3','','','4','5',0,'229 DADA DEEPU CHOWK','BHARTAL SECTOR 26','DWARAKA','Delhi','0','110077','','7894561230','','','0','0','0','0','',NULL,'6570'),(320,'249','Khyati Global Ventures Ltd','5','DR','0','27AAACK1682P1Z3','','','4','5',0,'54,Juhu Supreme Shopping Center,Gulmohar Cross Rd','No 9,Jvpd Scheme','Mumbai','Maharashtra','27','400049','','9320554665','','','0','0','0','0','',NULL,'6517'),(322,'249','L.K.WOOLLEN & SILK MILLS','5','DR','0','27AAAPG9544R1Z3','','','4','5',0,'E-14,NANDJYOT INDUSTRIAL ESTATE,','ANDHERI -KURLA ROAD SAKINAKA','MUMBAI','Maharashtra','27','400069','lkwoollen@gmail.com','2241205194','','','0','0','0','0','',NULL,'5649'),(323,'249','LAKE VIEW HOSPITALITY','5','DR','0','27AADFL2325A1ZY','','','4','5',0,'(RAIN FOREST GHATKOPAR)','DEFAULT','mumbai','Maharashtra','27','400071','','1111111111','HDFC BANK','','0','0','0','0','',NULL,'153'),(324,'249','LALANI TECHNOLOGY','5','DR','0','27BPSPD9285A1ZL','','','4','5',0,'SHOP 4,LABH ASHISH BLDG,','DADA BHAI RD,VILE PARLE WEST','MUMBAI','Maharashtra','27','400056','','7045123333','','','0','0','0','0','',NULL,'4505'),(325,'249','LAXMI GENERAL STORES','5','DR','0','27AACPG2572P1ZF','','','4','5',0,'AGRI PADA,CHANDOLKAR MARG','MUMBAI','mumbai','Maharashtra','27','400011','','1111111111','','','0','0','0','0','','undefined-undefined-44027','1416'),(326,'249','LAXMI SALES AGENCY','5','DR','0','27AABPG8430B1Z8','','','4','5',0,'GALA NO 2,HARI OM COMPD,','J.M.M RD,KHEANI RD','MUMBAI','Maharashtra','27','400084','','9867093128','','','0','0','0','0','',NULL,'4174'),(327,'249','LIFESTYLE STATIONERY','5','DR','0','27AEWPC2836C1ZJ','','','4','5',0,'PRABHADEVI DADAR','','Mumbai','Maharashtra','27','400025','','1111111111','BOM','','0','0','0','0','','undefined-undefined-44106','1484'),(328,'249','LION TARACHAND BAPA HOPITAL & RESEARCH CENTRE','5','DR','0','','','','4','5',0,'SION WEST','','','Maharashtra','27','','','7506069014','','','0','0','0','0','',NULL,'4186'),(329,'249','LOHMARG MUKHYALAY DAIRY','5','DR','0','','','','4','5',0,'RAILWAY POLICE QUARTER','PANTNAGAR GHATKOPAR','EAST','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44261','1735'),(330,'249','LOVELY DRY FRUIT','5','DR','0','27AAAPF1139K1ZZ','','','4','5',0,'KURLA','','Mumbai','Maharashtra','27','400070','','1111111111','NEFT','','0','0','0','0','','undefined-undefined-44008','1380'),(331,'249','M/S KRISHNA COLLECTION','5','DR','0','27AKLPC1366L1ZZ','','','4','5',0,'SHOP NO..3&4GOKULDHAM MARKET','MALAD (E) NR- SHOPPERS SPOTGEN','MUMBAI','Maharashtra','27','400097','','9253468542','','','0','0','0','0','',NULL,'4484'),(332,'249','MAGICDIL HEALTH LLP','5','DR','0','27ABEFM0732E1ZD','','','4','5',0,'CHEMBUR RAILWAY ST','CHEMBUR EAST','MUMBAI','Maharashtra','27','400071','','7208520196','','','0','0','0','0','',NULL,'259'),(333,'249','MAGICO FOODWORK','5','DR','0','','','','4','5',0,'SHOP NO 3,WATERFILED RD','BANDRA WEST','MUMBAI','Maharashtra','27','400027','','9967677808','ICICI','','0','0','0','0','','undefined-undefined-44116','1503'),(334,'249','MAHALAXMI TRADERS','5','CR','126790','27AHCPA4482F1ZN','','','4','5',0,'AT POST TULJAPUR','DIST OSMANABAD','mumbai','Maharashtra','27','413601','','1111111111','','','0','0','0','0','',NULL,'289'),(335,'249','MAHARASHTRA SUPER MARKET','5','DR','0','27ABOFM0213G1ZH','','ABOFM0213G','4','5',0,'PLOT NO 31/42,G M LINK RD','GOVANDI','mumbai','Maharashtra','27','400043','','1111111111','NAVI MUMBAI','GOVANDI','0','0','0','0','',NULL,'1566'),(336,'249','MALDE CAPACITORS MFG CO','5','DR','0','27AACPK5099B1ZS','','','4','5',0,'MANPADA RD','DOMBIVALI EAST','mumbai','Maharashtra','27','421204','','9322265111','UNION','','0','0','0','0','','undefined-undefined-44155','1543'),(337,'249','MAN ENTERPRISES','5','DR','0','','','','4','5',0,'MERIGOLD HOUSE PLOT NO A-34 CROSS ROAD','NO 2 MAROL MIDC ANDHERI EAST','MUMBAI','Maharashtra','27','400093','','9930340027','','','0','0','0','0','',NULL,'4318'),(338,'249','MANAS ENTERPRISES','5','DR','0','27AJGPH5487B1Z8','','','4','5',0,'RIGOLD HOUSE PLOMET NO A-34 CROSS ROAD NO-02','','Mumbai','Maharashtra','27','400093','','9867310378','','','0','0','0','0','',NULL,'4440'),(339,'249','MANGAL MISHRA','5','DR','0','','','','4','5',0,'CHEMBUR','','','Maharashtra','27','','','','GPAY IMPS','','0','0','0','0','','undefined-undefined-43979','1370'),(340,'249','MANI KAMAT','5','DR','0','','','','4','5',0,'CST','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'207'),(341,'249','MANJUSHRI CATTERES','5','DR','0','','','','4','5',0,'NEAR SHUSHRUT HOSPITAL CHEMBUR','','','Maharashtra','27','','','8928395589','','','0','0','0','0','','undefined-undefined-44159','1545'),(342,'249','MANOHAR LALS SUPER MARKET','5','DR','0','27AAAPT9186C1ZF','','','4','5',0,'COLLECTOR COLONY','CHEMBUR','Mumbai','Maharashtra','27','400071','','1111111111','IDFC','','0','0','0','0','','undefined-undefined-43813','1224'),(343,'249','MANOJ ENTERPRISES','11','DR','0','27BTEPS1995N1ZS','','','4','5',0,'18/11,HARHARWALA BLDG','N.M JOSHI MRG,MUMBAI','','Maharashtra','27','400011','','','','','0','0','0','0','','undefined-undefined-43877','1294'),(344,'249','MANSI MAHILA AUDYOGIK','5','DR','0','','','','4','5',0,'VIKHROLI PARK SIDE','','','Maharashtra','27','','','9221282157','','','0','0','0','0','',NULL,'5274'),(345,'249','MAX CORPORATIONS','5','DR','0','27AKVPP4150D1ZX','','','4','5',0,'411,KAILASH INDUSTRIAL COMPLEX, G WING.SAVAKARMARG,','VIKHAROLI (W)','MUMBAI','Maharashtra','27','400079','','9545512226','','','0','0','0','0','',NULL,'4796'),(346,'249','MAYUR BARIK','5','DR','0','','','','4','5',0,'KAJU PADA','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43942','1352'),(347,'249','MEENA INDUSTRIES','5','DR','7234','27AAKFM3322K1Z6','','','4','5',0,'GALA NO 21,KOHINOOR TEXTILE PRINTING','BEHIND SWASTIK DISA','GHATKOPAR WEST','Maharashtra','27','400071','','1111111111','KOTAK','','0','0','0','0','','undefined-undefined-43776','1172'),(348,'249','MEHAK AGENCY','5','DR','0','27CVSPK0407Q1ZY','','','4','5',0,'C/49,ASLAM COMPD,NR MANOJ','KUMAR STUDIO, NR OBEROI GARDEN','CHANDIVLI SAKINAKA','Maharashtra','27','400072','','1111111111','','','0','0','0','0','','undefined-undefined-43857','1284'),(349,'249','MEHTA AND CO','5','DR','0','27CFYPM4254B2Z4','','','4','5',0,'SHOP NO 5 KADRI MANSION BH','KISMAT LOUNDARY SION','MUMBAI','Maharashtra','27','400022','','9619997841','','','0','0','0','0','',NULL,'5716'),(350,'249','MICHAEL SCHOOL','5','DR','0','','','','4','5',0,'KAMANI','NEAR SHEETAL CENEMA','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'262'),(351,'249','MILIND DEDHIA','5','DR','0','','','','4','5',0,'KURLA','','','Maharashtra','27','','','','GPAY','','0','0','0','0','','undefined-undefined-43990','1374'),(352,'249','MILIND DEDHIA','5','DR','0','','','','4','5',0,'KURLA CHADWA NAGAR','','','Maharashtra','27','400070','','','','','0','0','0','0','','undefined-undefined-44681','1774'),(353,'249','MITHU EMPORIUM','5','DR','0','16AWKPB2403Q1ZI','','','4','5',0,'PRABHAT MARKET,27,H.G.B ROAD','AGARTALA,TRIPURA WEST','TRIPURA','Tripura','0','799001','','7005025215','','','0','0','0','0','',NULL,'4925'),(354,'249','MOMAYA CAPACITORS','5','DR','0','27AAAFM1710D1ZZ','','','4','5',0,'MANPADA RD','DOMBIVALI EAST','mumbai','Maharashtra','27','421204','','9322265111','UNION','','0','0','0','0','','undefined-undefined-44155','1542'),(355,'249','MONICA RESTAURANT','5','DR','0','27AYBPS6630F1ZD','','','4','5',0,'OPP KAILASH TOWER 90FT RD','PANT NAGAR GHATKOPAR E','','Maharashtra','27','','','','KOTAK','GHATKOPAR EAST','0','0','0','0','',NULL,'233'),(356,'249','MR ANIL VARMA','5','DR','0','','','','4','5',0,'MUMBAI','','','Maharashtra','27','','','','CENTRAL BANK','VIKHROLI','0','0','0','0','',NULL,'295'),(357,'249','MR.VIJAY','5','DR','0','','','','4','5',0,'MUMBAI','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43942','1347'),(358,'249','MULTI DESIGN & PRINT','5','DR','0','27APTPP6291G1Z5','','','4','5',0,'09 SHREE KRISHNA NIVAS BANDEKAR WADI JOGESHWARI EAST','MUMBAI','mumbai','Maharashtra','27','400060','','9257135843','','','0','0','0','0','',NULL,'4201'),(359,'249','MULUND SIDDHI CO OP SOC LTD','5','DR','0','','','','4','5',0,'MULUND','','','Maharashtra','27','','','','NEW INDIA','','0','0','0','0','',NULL,'1657'),(360,'249','Mayekar','5','DR','0','','','','4','5',0,'Dombivali','Mumbai','','Maharashtra','27','','','9820877140','','','0','0','0','0','',NULL,'6047'),(361,'249','Mona Beayty Salon','5','DR','0','','','','4','5',0,'Shop No 2 Laxmi Niwas Sitaram Jhadav Marg','Lower Parel','Mumbai','Maharashtra','27','400013','','9768459497','','','0','0','0','0','',NULL,'4819'),(362,'249','NAGINDAS AMARCHAND BHAGAT WELFARE TRUST','5','DR','0','','','','4','5',0,'GHATKOPAR','','','Maharashtra','27','','','','UCO BANK','GHATKOPAR','0','0','0','0','',NULL,'1246'),(363,'249','NAGRIK STORE','5','DR','0','','','','4','5',0,'GHATKOPAR','','','Maharashtra','27','','','','NEFT','','0','0','0','0','','undefined-undefined-44081','1452'),(364,'249','NAITIKK SALES','5','DR','204515','27AWEPS9245F1Z5','','','4','5',0,'655/9/1, GANGA DHAM UPPER','INDIRA NGR,BIDEWADI','PUNE','Maharashtra','27','411037','','9890170015','RTGS','CHEMBUR','0','0','0','0','',NULL,'249'),(365,'249','NALANDA PACKAGING INDUSTRIES','5','DR','0','27AAGFN5207J1Z7','','','4','5',0,'B 207, GOKUL ARCADE','SUBASH RD,VILE PARLE EAST','MUMBAI','Maharashtra','27','400057','','1111111111','','','0','0','0','0','',NULL,'240'),(366,'249','NARSINGH','5','DR','0','','','','4','5',0,'REF AJIT KAKA','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44087','1459'),(367,'249','NARYAN PAN BIDI','5','DR','0','','','','4','5',0,'CHURCH GATE','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'292'),(368,'249','NB MIRCHANDANI','5','DR','0','','','','4','5',0,'GURUNANAK SADAN,3RD FLR','MAHUL RD,CHEMBUR','MUMBAI','Maharashtra','27','400074','','9821648373','','','0','0','0','0','',NULL,'4307'),(369,'249','NBH CANTEEN','5','DR','0','','','','4','5',0,'BARC','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'272'),(370,'249','NEOGEN CHEMICALS LIMITED','5','DR','0','27AAACN5836E1ZJ','','','4','5',0,'1002 DEV CORPORA BUILDING 10TH FLOOR OPP. CADBURY COMPOUND OFF. POKHRAN ROAD NO.2  KHOPAT THANE WEST','','MUMBAI','Maharashtra','27','400071','','8850346529','','','0','0','0','0','',NULL,'4265'),(371,'249','NIDHI CATERS (SHAH & ANCHOR)','5','DR','0','','','','4','5',0,'SHAH & ANCHOR COLLEGE','GOVANDI','','Maharashtra','27','','','','CANARA BANK','GOVANDI','0','0','0','0','',NULL,'267'),(372,'249','NIDHI IMPEX','5','DR','0','27AODPD0004Q1Z7','','','4','5',0,'1ST FLOOR PLOT NO CS1491','D.N.ROAD CROWFORD MKT','MUMBAI','Maharashtra','27','400001','','9404215553','','','0','0','0','0','',NULL,'6046'),(373,'249','NIKHIL PALAV','5','DR','0','','','','4','5',0,'KAJU PADA','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43942','1350'),(374,'249','NITIN FIRE PROTECTION INDUSTRIES LTD','5','DR','0','27AAACN1967G1ZF','','','4','5',0,'5th Floor, 501, Delta, Technology Street, Hiranandani, Powai','mumbai','mumbai','Maharashtra','27','400076','','1111111111','IDBI','','0','0','0','0','','undefined-undefined-43793','1193'),(375,'249','NOVAS IMPEX','5','DR','0','27AADPT8979L1ZM','','','4','5',0,'MUMBAI','','','Maharashtra','27','400003','','9833697676','UNION BANK','MULUND','0','0','0','0','',NULL,'244'),(376,'249','NOVO MEDISCIENCS PVT LTD','5','DR','0','','','','4','5',0,'NR.CASH','','','Maharashtra','27','','','8779843484','','','0','0','0','0','',NULL,'4408'),(377,'249','NULIFE HOSPITAL','5','DR','0','','','','4','5',0,'A-1 HARE KRISHNA BUILDING L B S MARG,','NEAR TELEPHONE EXCHANGE GHATKOPER WEST','MUMBAI','Maharashtra','27','400086','','9821343551','','','0','0','0','0','',NULL,'4815'),(378,'249','OBTAIN IT CONSULTANCY LLP','5','DR','0','27AADFO8957F1ZV','','','4','5',0,'77/2296,PANT NAGAR','GHATKOPAR EAST','MUMBAI','Maharashtra','27','400075','','1111111111','IMPS','','0','0','0','0','','undefined-undefined-43991','1376'),(379,'249','OM ENTERPRISE','5','DR','0','27AJRPY2328M1ZB','','','4','5',0,'ROOM NO S MAHAKALI NAGAR MAROL','MILITARY ROAD ANDHERI EAST MUMBAI','mumbai','Maharashtra','27','400059','','8850346529','','','0','0','0','0','',NULL,'4308'),(380,'249','OM ENTERPRISES','5','DR','0','27AZGPD0217P1ZD','','','4','5',0,'SAFALYA BLDG,NR RATANJYOT','BLDG,VILE PARLE WST','mumbai','Maharashtra','27','400056','','9835657841','','','0','0','0','0','',NULL,'4506'),(381,'249','OSCAR MEDICAL STORES','5','DR','0','27AAAFO6064A1ZM','','','4','5',0,'S.R.M.& K.P. CARDIAC INST','NR GANGHI MKT,KING CIRCLE','MUMBAI','Maharashtra','27','400022','','9821082912','IDBI BANK','','0','0','0','0','1.15E+13',NULL,'4852'),(382,'249','OSWAL DRY FRUIT & GEN STORE','5','DR','0','27AQZPS3752L2ZQ','','','4','5',0,'GANGAGIRI, PLOT NO 47','VASHI SWC 17','NAVI MUMBAI','Maharashtra','27','400703','','','','','0','0','0','0','1.15E+13','undefined-undefined-44128','1520'),(383,'249','Online Packaging Pvt Ltd','5','DR','0','30AAACO6491Q1Z1','','','4','5',0,'71/72, Ii B Verna Electronic City','Goa','Goa','Maharashtra','27','403722','','','','','0','0','0','0','',NULL,'241'),(384,'249','P.G.EXIM PVT LTD','11','CR','601800','27AAFCP0224R1Z5','','','4','5',0,'212,216 RANG MAHAL SAMUEL STREET, VADGADI','MANDVI MASJID BUNDER (W)','MUMBAI','Maharashtra','27','400003','','1.54E+13','','','0','0','0','0','',NULL,'6540'),(385,'249','PARAKH PHARMACY','5','DR','0','','','','4','5',0,'GHATKOPAR','DEFAULT','','Maharashtra','27','','','9820118266','','','5000','1','0','0','',NULL,'124'),(386,'249','PARAS SUPER MARKET','5','DR','0','27AAZFP1287D1ZR','','','4','5',0,'ST1','','mumbai','Maharashtra','27','400071','','1111111111','APNA','','0','0','0','0','',NULL,'1720'),(387,'249','PATEL KIRANA','5','DR','0','','','','4','5',0,'VASHI NAKA','','','Maharashtra','27','','','','IMPS GPAY','','0','0','0','0','','undefined-undefined-43979','1369'),(388,'249','PAVITHRA HOSPITALITY (GOLF CLUB)','5','DR','0','27CGZPS6717F2ZJ','','','4','5',0,'THE BOMBAY PRESENDANCY GOLF CLUB UNION PARK CHEMBUR CG ROAD MUMBAI','','MUMBAI','Maharashtra','27','400074','','8169212123','CITY UNION BANK','','0','0','0','0','',NULL,'4807'),(389,'249','PENINSULA RESTAURANT','5','DR','0','','','','4','5',0,'SION OPP  CINE PLANET','','MUMBAI','Maharashtra','27','400022','','8425936976','','','0','0','0','0','',NULL,'4875'),(390,'249','PHARMO TIPS HEALTHCARE PVT LTD','5','DR','0','27AAJCA2719G1ZR','','','4','5',0,'Room No 102,1st Flr,house No 1518/0','Salamatpura,Naigaon,Bhiwandi','Thane','Maharashtra','27','421302','','8888264264','','','0','0','0','0','',NULL,'5696'),(391,'249','PICASSO GLOBAL LLP','5','DR','0','27AAWFP3318G1ZW','','','4','5',0,'D7-140 BHUMI WORLD','PIMPLAS BHIWANDI','THANE','Maharashtra','27','421302','','8262090909','','','0','0','0','0','',NULL,'4455'),(392,'249','POOJA ENTERPRISES','5','DR','0','27AXPPR1104C1ZP','','','4','5',0,'165,SHOP 6,PATRAKAR CHSL','TILAK NGR,CHEMBUR 89','Mumbai','Maharashtra','27','400089','','1111111111','KOTAK MAHINDRA','TILAK NGR','0','0','0','0','',NULL,'136'),(393,'249','PRABHAKAR RAJE','5','DR','0','','','','4','5',0,'KAJUPADA KURLA','','','Maharashtra','27','','','','IDBI','KAMOTHE','0','0','0','0','','undefined-undefined-43733','814'),(394,'249','PRADEEP JAISWAL','5','DR','0','','','','4','5',0,'AMIT  MARS REFERENCE','','','Maharashtra','27','','','','LAKSHMI VILAS','BOISAR','0','0','0','0','','undefined-undefined-43716','733'),(395,'249','PRAMOD SUPPLIERS','5','DR','1077123','27AACPD1470H1Z4','','','4','5',0,'45,GULALWADI,1ST FLOOR','MUMBAI','mumbai','Maharashtra','27','400004','','1111111111','IMPS','','0','0','0','0','1.15E+13',NULL,'1797'),(396,'249','PRASAM EXPORTS','5','DR','0','27AAFFP7571C2Z5','','','4','5',0,'508,BEZZOLA COMPLEX,SION TROMBAY','ROAD,CHEMBUR MUMBAI','mumbai','Maharashtra','27','400071','','9167223871','CANARA BANK','','0','0','0','0','',NULL,'4878'),(397,'249','PRASHANT CATERERS','5','DR','0','27AAJFP7855K3ZG','','','4','5',0,'CENTRE POINT INDL ESTATE','A1,OPP BAVLA MASJID,NR CURREY RD STN','LOWER PAREL','Maharashtra','27','400013','','877721761','','','0','0','0','0','',NULL,'1825'),(398,'249','PRASHANT CATERERS','5','DR','0','27AAJFP7855K3ZG','','','4','5',0,'GRD FLR,PREM COURT BLDG,','J.M RD,CHURCHGATE','MUMBAI','Maharashtra','27','400020','','8779721761','','','0','0','0','0','',NULL,'1824'),(399,'249','PRATIMA ICE CREAM','5','DR','0','','','','4','5',0,'NR SHEETALA MATA','','','Maharashtra','27','','','8433878495','SURYODAY BANK','','0','0','0','0','',NULL,'4477'),(400,'249','PRAYOSHA HOSPITALITY SERVICES','5','CR','4812','27AYLPM6231A1ZM','','','4','5',0,'2ND FLR ROOM NO 18 POLT 11 NARYAN SMRUTI CHAMILDAS ROAD','DADAR WEST MUMBAI CITY','Mumbai','Maharashtra','27','400014','','1111111111','','','0','0','0','0','',NULL,'284'),(401,'249','PRIME IDEAS','5','CR','1','27ABAFP3410C1ZV','','','4','5',0,'103,HEMKUNGBRSHMA KUMARI ROAD,JAWAHAR NAGAR,','GOREGAON W,MUMBAI SUBURBAN','MUMBAI','Maharashtra','27','400062','','9920617677','','','0','0','0','0','',NULL,'6543'),(402,'249','PUNAM DISTRIBUTORS','5','DR','1017382.66','','','','4','5',0,'KAJU PADA','','','Maharashtra','27','','','','ANDHRA','','0','0','0','0','','undefined-undefined-43911','1315'),(403,'249','PUNYAM DISTRIBUTOR','5','DR','0','27AAEHN7306Q1ZN','','','4','5',0,'CHEMBUR','','MUMBAI','Maharashtra','27','400089','','9820229967','KOTAK','','0','0','0','0','',NULL,'275'),(404,'249','Purple Mango Hospitality','5','DR','6495','','','','4','5',0,'mumbai','','','Maharashtra','27','','','9920523524','BOB','','0','0','0','0','',NULL,'6532'),(405,'249','R-LITE ELECTRICALS','5','DR','0','27AAOPJ2845C1ZR','','','4','5',0,'SHOP NO 2,MARYLAND BLDG','SION EAST','MUMBAI','Maharashtra','27','400022','','1111111111','','','0','0','0','0','','undefined-undefined-44079','1451'),(406,'249','R.K MARKETING','5','DR','0','27ACRPG0630R1Z5','','','4','5',0,'GOVANDI','','','Maharashtra','27','','','','NEFT','','0','0','0','0','','undefined-undefined-44036','1422'),(407,'249','R.K.ENTERPRISES','5','DR','0','27DSJPS0442G1ZM','','','4','5',0,'GR,FLR,HUTMENTS,P.DEMELLO RD,RLY COMPD,','BACKSIDE OF AROGYA BHAWAN,FORT','MUMBAI','Maharashtra','27','400001','','9172612192','SBI','','0','0','0','0','',NULL,'5712'),(408,'249','R.S.ENTERPRISES','11','DR','0','27BSXPS8433H2ZS','','','4','5',0,'ROOM NO 9/12,SURVEY NO 164,SUKH SAI NIKETAN,','DARGHA RD,KHINDIPADA,BHANDUP(WEST)','','Maharashtra','27','400027','','9769101760','','','0','0','0','0','2.15E+13',NULL,'4801'),(409,'249','RAHUL KHANNA','5','DR','0','','','','4','5',0,'TILAK NAGAR','','','Maharashtra','27','','','','G PAY','','0','0','0','0','','undefined-undefined-43974','1367'),(410,'249','RAJU GUPTA','5','DR','0','','','','4','5',0,'PANVEL STATION','AABPG6099C','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'213'),(411,'249','RAKESH KYROS','5','DR','0','','','','4','5',0,'CHEMBUR','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'1538'),(412,'249','RAMDEV TRADERS','5','DR','12525','27CGFPG5989K1ZP','','','4','5',0,'AVDHAN , H NO 1155 , MUMBAI AGRA HIGHWAY ,','DHULE','DHULE','Maharashtra','27','424001','','9420589888','','','0','0','0','0','',NULL,'6567'),(413,'249','RAMZAN STORE','5','DR','0','','','','4','5',0,'SHOP NO 12 VANI APARTMENT GOPINATH COMPOUND DR C G ROAD CHEMBUR (BASANT TOKIES )','','','Maharashtra','27','','','25215079  /','','','0','0','0','0','','undefined-undefined-43736','919'),(414,'249','RATAN FOOD PRODUCTS','5','DR','0','27AAQFR4726A2Z5','','','4','5',0,'602,VIKAS CENTRE,CHEMBUR','DEFAULT','mumbai','Maharashtra','27','400071','','1111111111','RTGS','','0','0','0','0','',NULL,'206'),(415,'249','RATAN REFRESHMENT','5','DR','0','','','','4','5',0,'DADAR','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43911','1316'),(416,'249','RATNA SUPER MARKET','5','DR','0','','','','4','5',0,'MAITRIPARK','','','Maharashtra','27','','','7304097220','','','0','0','0','0','',NULL,'4777'),(417,'249','RAVAL TRADING COMPANY','5','DR','0','27AABPR4334F1ZU','','','4','5',0,'NR MONO RAIL CHEMBUR','SITA ESTATE','MUMBAI','Maharashtra','27','400074','','9820605511','','','0','0','0','0','',NULL,'282'),(418,'249','REALOFFICE NEEDS','5','DR','0','27ARGPG7734E1ZT','','','4','5',0,'GRD FLR,296,WADIA ESTATE','NR SHARADA MANDIR,MUMBAI','','Maharashtra','27','400070','','989356823','','','0','0','0','0','',NULL,'4523'),(419,'249','RIHAN CATERERS','5','DR','0','','','','4','5',0,'PLOT NO 8K/11,RD NO 8,BAIGAN WADI','MUMBAI','','Maharashtra','27','400043','','','','','0','0','0','0','',NULL,'1635'),(420,'249','RIO ENTERPRISES','5','DR','0','27KCYPS2257H1ZM','','','4','5',0,'18,UPPER FLR,MALPA DONGRI NO 3','ANDHERI EAST','MUMBAI','Maharashtra','27','400059','','7738478420','','','0','0','0','0','',NULL,'4198'),(421,'249','RIYA ENTERPRISES','5','DR','0','27AZYPR5603BIZ2','','','4','5',0,'GRD FLR , R NO.666PATALI PADA','KOLSHET THANE','THANE','Maharashtra','27','400607','','9821546781','','','0','0','0','0','',NULL,'4426'),(422,'249','ROCK CATTERS','5','DR','0','','','','4','5',0,'VIVAKANAD PHARMA','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'269'),(423,'249','ROHIT CATERERS','5','DR','0','','','','4','5',0,'GHATKOPAR','','','Maharashtra','27','','','9819530134','','','0','0','0','0','','undefined-undefined-44112','1489'),(424,'249','ROOPAM CHEMIST','5','DR','0','27AAHFR1979C1Z2','','','4','5',0,'CHEMBUR NAKA','SION TROMBAY ROAD','MUMBAI','Maharashtra','27','400071','','1111111111','CHEMBUR BANK','','0','0','0','0','','undefined-undefined-43939','1344'),(425,'249','ROP ENTERPRISES','5','CR','11699','27AQMPG0878L1ZB','','','4','5',0,'Ground Floor Shop No.6, Plot No.3B , Kalapana Park','Sector 9 , Near Garam Masala Hotel , Airoli','Navi Mumbai','Maharashtra','27','400708','','9821241879','IMPS','','0','0','0','0','1.15E+13',NULL,'6524'),(426,'249','ROYAL FOOD PRODUCT','5','DR','0','27ABCFR1044A1ZT','','','4','5',0,'GROUND FLOOR SHOP NO 9 REHAB BUILDING NO 8','A WING RANI SATI ROAD MALAD EAST DHANJIWADI','MUMBAI','Maharashtra','27','400097','','1111111111','','','0','0','0','0','',NULL,'6196'),(427,'249','RUCHITA HOSPITALITY SERVICES','5','DR','0','27AAOFR4901M1ZQ','','','4','5',0,'SUSHRUT HOSP','','MUMBAI','Maharashtra','27','','','8425962818','','','0','0','0','0','',NULL,'5834'),(428,'249','RUPAL KANAKIA','5','DR','0','','','','4','5',0,'VILE PARLE','','','Maharashtra','27','','','9769860861','','','0','0','0','0','',NULL,'3902'),(429,'249','RUPAL SYNDICATE','5','DR','28892','27AAEPD8880H1ZI','','','4','5',0,'SHOP NO 26 PLOT NO 104,SATI KRUPA SHOPPING','CENTRE GARODIYA NAGAR GHATKOPAR E','MUMBAI','Maharashtra','27','400089','','1111111111','','','0','0','0','0','',NULL,'6485'),(430,'249','Riddhi Vinayak Hospital','5','DR','6072','','','','4','5',0,'559/1,Riddhi Vinayak Lane,S.v Rd,','Malad West','Mumbai','Maharashtra','27','400064','','9633142442','','','0','0','0','0','',NULL,'6515'),(431,'249','Rohit Marketing','5','DR','0','27AKPPC6596A1Z0','','','4','5',0,'Gurunanak Indl Estate','Kurla','Mumbai','Maharashtra','27','400070','','8779721761','','','0','0','0','0','',NULL,'6350'),(432,'249','Royal Beauty Collection','5','DR','0','','','','4','5',0,'Ws','','','Maharashtra','27','','','1234567891','DMK JAOLI','','0','0','0','0','',NULL,'4524'),(433,'249','S N REDDY','5','DR','0','','','','4','5',0,'VASHI NAKA','','','Maharashtra','27','','','','G PAY','','0','0','0','0','','undefined-undefined-43974','1366'),(434,'249','S.A HAMEED PERFUMERS','5','DR','0','27AAUPH0869A1ZN','','','4','5',0,'B-13 ARJUN CENTRE ESTATE P.V LTD PLOTNO 231GOVANDI STA','GOVANDI','MUMBAI','Maharashtra','27','400088','','7039484537','IMPS','','0','0','0','0','',NULL,'5688'),(435,'249','S.S ENGINEERS','5','DR','0','27ABVPY9116F1ZV','','','4','5',0,'MAROL  MUMBAI','','Mumbai','Maharashtra','27','400047','','1111111111','','','0','0','0','0','','undefined-undefined-43793','1192'),(436,'249','SAGAR CREATIONS & CO','5','DR','0','27ANDPJ8183F1ZU','','','4','5',0,'1305,13TH FLOOR , DEV CORPORA','','THANE','Maharashtra','27','400601','','9967168160','','','0','0','0','0','',NULL,'4921'),(437,'249','SAHAJANAND TRADERS','5','DR','0','27AIGPA8840E1ZG','','','4','5',0,'1 ST FLR 69B ROOM 39 KUTCHI NIVAS OLD CHAEL MAZGAON MUMBAI','','Mumbai','Maharashtra','27','400010','','1111111111','','','0','0','0','0','','undefined-undefined-43794','1194'),(438,'249','SAI ENTERPRISES','5','DR','0','27APNPA3195C1Z1','','','4','5',0,'W/S ROHAN','DEFAULT','Mumbai','Maharashtra','27','400070','','1111111111','','','0','0','0','0','',NULL,'158'),(439,'249','SANCHI  FOOD HOSPITALITY','5','DR','0','','','','4','5',0,'NR SURANA HOSPITAL','','','Maharashtra','27','','','7021122926','','','0','0','0','0','',NULL,'246'),(440,'249','SANCHI ENTERPRISES','5','DR','0','','','','4','5',0,'MUMBAI','','','Maharashtra','27','','','','GPAY','','0','0','0','0','','undefined-undefined-44092','1469'),(445,'249','SEARO PVT LTD','5','DR','0','27AAZCS8608Q1Z0','','','4','5',0,'CHAWL NO 337,R NO 4077','TAGORE NGR GRP NO 3, OPP BUS STOP','VIKHROLI EAST','Maharashtra','27','400083','','9967400343','INDUSIND','GKPR','0','0','0','0','',NULL,'291'),(447,'249','SHAFIULLAH ENTERPRISES','5','DR','0','','','','4','5',0,'DEFAULT','DEFAULT','','Maharashtra','27','','','','PUNJAB NATIONAL','','0','0','0','0','',NULL,'225'),(448,'249','SHALOM MEGA STORES','5','DR','0','27BSEPA6242D1Z7','','','4','5',0,'SHOP NO 16&17, PARAS NIKETAN','CHHEDANAGAR, CHEMBUR (W)','mumbai','Maharashtra','27','400089','','9322294040','TMB BANK','','0','0','0','0','',NULL,'4608'),(449,'249','SHEETAL ENTERPRISES','5','DR','100007','27ANZPM5399Q2ZD','','','4','5',0,'Gala No 17,Wadia Compd,Zakaria Bunder Rd','Cotton Green','MUMBAI','Maharashtra','27','400033','','9030295999','','','0','0','0','0','',NULL,'4962'),(450,'249','SHEETAL ENTERPRISES','11','DR','0','','','','4','5',0,'KAJU PADA','','','Maharashtra','27','','','1111111111','','','0','0','0','0','','undefined-undefined-43911','1317'),(451,'249','SHIVAM DAIRY FOODS','5','DR','0','','','','4','5',0,'VIKROLI','','','Maharashtra','27','','','','AXIS BANK','POWAI','0','0','0','0','','undefined-undefined-43797','1196'),(452,'249','SHIVAM DRY SNACKS','5','DR','0','27BBMPP9721M1ZU','','','4','5',0,'PL RD,CHEMBUR','DEFAULT','Mumbai','Maharashtra','27','400071','','1111111111','KNS BANK','GOVANDI','0','0','0','0','2.15E+13',NULL,'152'),(453,'249','SHIVAM DRY SNACKS','5','DR','0','27BBMPP9721M1ZU','','','4','5',0,'PL ROAD OPP PRASHANT','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'257'),(454,'249','SHIVRAJ','5','DR','0','','','','4','5',0,'R ODEON MALL','GHATKOPAR EAST','','Maharashtra','27','','','','ICICI','','0','0','0','0','','undefined-undefined-43811','1218'),(455,'249','SHOURYA ENTERPRISES','5','DR','0','27BCHPS2430N1Z8','','','4','5',0,'KALYANJI COMPOUND R.C MARG NEAR BANK OF INDIA','CHEMBUR','MUMBAI','Maharashtra','27','400089','','9321225246','MUMBAI','','0','0','0','0','',NULL,'5643'),(456,'249','SHREE ENTERPRISES','5','DR','0','27CIZPK2623J1ZP','','','4','5',0,'6,PRATHMESH CHS,RETI BANDER RD','MOTHAGAON','','Maharashtra','27','421202','','1111111111','','','0','0','0','0','',NULL,'164'),(457,'249','SHREE MAHAVEER CORPORATION','11','DR','0','','','','4','5',0,'05 MILAN INDUSTRIAL ESTATE GRD FLOOR','OPP ABUDAYA NAGAR CO OP SOCIETY','','Maharashtra','27','','','9664321829','','','0','0','0','0','',NULL,'6516'),(458,'249','SHREEJI ENTERPRISES','5','DR','90401','27ARBPP2139H1ZU','','','4','5',0,'SHOP NOA1 ,1ST FLR KONDIVITA','ANDHERI EAST','MUMBAI','Maharashtra','27','400069','','9892684848','GP PARSIK','','0','0','0','0','2.15E+13',NULL,'6401'),(459,'249','SHREEJI FOODS NX','5','DR','0','','','','4','5',0,'MUMBAI','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43938','1343'),(460,'249','SHREEJI TRADERS','5','DR','0','27AVMPP9761C1Z3','','','4','5',0,'HOUSE NO 532 ABOVE PRITI NOVELTY','GODUNDAR ROAD PATLI PADA,THANE','mumbai','Maharashtra','27','400601','','9621548352','','','0','0','0','0','',NULL,'4427'),(461,'249','SHREYNSHI ENTERPRISES','5','DR','0','27ADTFS5699F1Z4','','','4','5',0,'NEW MANIKLAL','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44272','1747'),(462,'249','SHRI JAGADGURU VALLABHACHARYJI JANKALYAN TRUS','5','DR','0','','','','4','5',0,'GHATKOPAR','','','Maharashtra','27','','','','IDBI','GHATKOPAR','0','0','0','0','','undefined-undefined-43825','1245'),(463,'249','SHRI MAMAL MATAJI BHAVIK TRUST','5','DR','0','','','','4','5',0,'Aram Building Gokhle Rd. North','Dadar West','Mumbai','Maharashtra','27','400028','','9820756010','BOB','','0','0','0','0','',NULL,'6534'),(464,'249','SHRI RAM ENTERPRISE','5','DR','0','','','','4','5',0,'18/20 IMRANI CHAWL NEAR MUNCIPAL SWDESHI MILL ROAD SION','','','Maharashtra','27','','','7710034885','','','0','0','0','0','',NULL,'6402'),(465,'249','SHRI RAM ENTERPRISES','11','DR','0','','','','4','5',0,'18/20 IMRANI CHAWL NEAR MUNCIPAL SWDESHI MILL ROAD SION','','','Maharashtra','27','','','7710034885','','','0','0','0','0','',NULL,'5574'),(466,'249','SHRI VARDHMAN STHA JAIN SANGH','5','DR','1845','','','','4','5',0,'148/151 GARODIA NAGAR 1 ST FLOOR KASHMIRA KUNJ','HSG SOCIETY OPP BANK OF RAJSTHAN GHTKOPAR (E)','','Maharashtra','27','','','9699170888','IOB','','0','0','0','0','',NULL,'5679'),(467,'249','SHRIDEVI CATERERS','5','DR','260480','27AGVPS5882P1ZX','','','4','5',0,'258,1ST FLR,SECTOR 5,MAHAVIR SANGAM','CHS,GHANSOLI,NAVI MUMBAI','NAVI MUMBAI','Maharashtra','27','400701','','9820588456','IMPS','','0','0','0','0','',NULL,'5449'),(468,'249','SHRIDEVI CATERERS','5','CR','58477','27AGVPS5882P1ZX','','','4','5',0,'SECTOR-6 ROOM NO 505 MINIR TOWER AIROLI','THANE','MUMBAI','Maharashtra','27','400708','','9820588456','','','0','0','0','0','',NULL,'6351'),(469,'249','SHRIJI  ENTERPRISES','11','DR','781.62','','','','4','5',0,'WS','','','Maharashtra','27','','','123456789','','','0','0','0','0','',NULL,'4950'),(470,'249','SHUBH STATIONERY & XEROX','5','DR','0','27AJTPV6527B1ZQ','','','4','5',0,'GROUND FLR, GALA NO D/3,PL26,SIDDHAKALA CHS LTD,','SAVARKAR NAGAR,JAKEGRAM THANE,THANE','MUMBAI','Maharashtra','27','400601','','22-2587722','','','0','0','0','0','',NULL,'4822'),(471,'249','SHUBHAM CATERING','5','DR','0','','','','4','5',0,'SOMAIYA HOSPITAL','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'226'),(472,'249','SHUBHAM ENTERPRISES','5','DR','0','27ACHPK7432K1ZB','','','4','5',0,'SHOP NO 33,K/4 BAIGAN WADI','GOVANDI','MUMBAI','Maharashtra','27','400043','','9167633697','','','0','0','0','0','',NULL,'1799'),(473,'249','SHUBHANGI CAATERING SERVICES','5','DR','0','27AEQPG1997L1ZQ','','','4','5',0,'3/18,SADGURU KRIPA BLDG','S.B MARG,MATUNGA WEST','MUMBAI','Maharashtra','27','400016','','1111111111','','','0','0','0','0','',NULL,'254'),(474,'249','SHWETA WHOLESALE PRIVATE LIMITED','11','CR','0','07ABHCS2087G1Z6','','','4','5',0,'21/31 , GODOWN-1 , NEAR PALAM GREEN HOUSE ,','AABADI OF VILLAGE BAKOLI NORTH DELHI','DELHI','Delhi','0','110039','','1234567890','','','0','0','0','0','',NULL,'6579'),(475,'249','SIDDHESHWAR KIRANA','5','DR','0','','','','4','5',0,'@123','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'1717'),(476,'249','SIDDHI ASSOCIATE','5','DR','0','27ABQPL9037K1ZY','','','4','5',0,'SR NO 192/FALT NO 4,SHRI HARI','CORNER,PUNE','PUNE','Maharashtra','27','411009','','1111111111','','','0','0','0','0','','undefined-undefined-43795','1195'),(477,'249','SIDHAKALLA VISWASTH MANDAL','5','DR','0','','','','4','5',0,'GHATKOPER EAST','','','Maharashtra','27','','','9833427296','','','0','0','0','0','',NULL,'4664'),(478,'249','SITABEN SHAH MEMORIAL TRUST','5','DR','0','','','','4','5',0,'FORT','','','Maharashtra','27','','','9920157127','','','0','0','0','0','',NULL,'3588'),(479,'249','SNOWONS ENTERPRISES','5','DR','0','27CEPPK2072B2ZL','','','4','5',0,'57/527,MATA RAMABAI NGR','GHATKOPAR EAST','MUMBAI','Maharashtra','27','400075','','7045571250','','','0','0','0','0','',NULL,'1831'),(480,'249','SOCIETY GRAIN STORE','5','DR','0','27AACPD7377HN1ZM','','','4','5',0,'BARC','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'141'),(481,'249','SOLANKI DINESH NARAYAN','5','DR','0','','','','4','5',0,'MUMBAI','','','Maharashtra','27','','','','IMPS','','0','0','0','0','',NULL,'1368'),(482,'249','SOMAIYA HOSPITAL','5','DR','0','','','','4','5',0,'CHUNABHATTI','9619619036','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'140'),(483,'249','SONIA MARKETING','5','DR','0','27AFLPB7141P1Z2','','','4','5',0,'NIRMALA APARTMENT SHOP 6','KHEMANI OPP YATRI NIWAS','ULHAS NAGAR','Maharashtra','27','421002','','1111111111','','','0','0','0','0','','undefined-undefined-43857','1281'),(484,'249','SPORTSMED MUMBAI PVT LTD','5','DR','0','27AAFFF3587N1ZT','','','4','5',0,'2ND FLR,PAREL PREMISES,OPP MOTILAL','OSWAL BLDG,PRABHADEVI','MUMBAI','Maharashtra','27','400008','','9664442708','','','0','0','0','0','',NULL,'4706'),(485,'249','STAR CATERERS','5','DR','13422','','','','4','5',0,'DEFAULT','DEFAULT','','Maharashtra','27','','','','KOTAK MAHINDRA','GHATKOPAR','0','0','0','0','',NULL,'159'),(486,'249','SUJYOTI FOODS LLP','5','DR','0','27ACSFS6752K1Z8','','','4','5',0,'OPP Airtel Gallery,tilak Road','Ghatkopar','Mumbai','Maharashtra','27','400077','','2250156002','IMPS','GHTKOPR','0','0','0','0','',NULL,'239'),(487,'249','SUMITRA SANSTHA','5','DR','0','','','','4','5',0,'CHUNABHATTI','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'162'),(488,'249','SUNANDA TRADING','5','DR','704965','27BKHPS7927Q1Z1','','','4','5',0,'HOUSE NO. 1773 , KARALE BLDG','TALUKA AKOLE , AHILYA NAGAR','AKOLE','Maharashtra','27','422601','','9820788144','','','0','0','0','0','',NULL,'147'),(489,'249','SUNDAR VILAS','5','DR','0','','','','4','5',0,'90 FEET ROAD, KUMBARWADA','DHARAVI','','Maharashtra','27','','','24092667','','','0','0','0','0','',NULL,'4692'),(490,'249','SUNLIGHT ENTERPRISES','5','DR','0','27AEQFS1657D1ZR','','','4','5',0,'OPP MULTAN GARAGE, 2ND FLOOR, A-201,','HARMONY COMPLEX , KHARDI ROAD, MUMBRA','THANE','Maharashtra','27','400612','','2134563125','','','0','0','0','0','',NULL,'6488'),(491,'249','SUNRISE HOSPITALITY','5','DR','0','27ADKFS6201Q1Z1','','','4','5',0,'CASTALIA SHOPPING,HIRANANDANI ESTAT','E,THANE MUMBAI 400607','mumbai','Maharashtra','27','400607','','1111111111','AXIS BANK','','0','0','0','0','',NULL,'181'),(492,'249','SUNSHINE CATERERS PRIVATE LIMITED','5','DR','0','27AAECR2970D1ZG','','','4','5',0,'501,SAFALYA BLDG, NR JAI GOPAL INDUSTRIES','DADAR WEST','MUMBAI `','Maharashtra','27','400028','','1111111111','RTGS','MUMBAI','0','0','0','0','',NULL,'247'),(493,'249','SWAMI VIVEKANAND (PHARMA)','5','DR','0','','','','4','5',0,'VIVEKANAND COLLEGE PHARMACY','','','Maharashtra','27','','','9773566197','','','0','0','0','0','',NULL,'264'),(494,'249','SWAMI VIVEKANAND PRIMARY SCHOOL','5','DR','0','27AAATV2239C1ZP','','','4','5',0,'DEFAULT','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'149'),(495,'249','SWARA ENTERPRISE','5','DR','0','27AAWPD5819L1Z2','','','4','5',0,'FLAT NO 14, SHRI GANESH RESIDENCY','LINGAYAT COLONY, DEOLALI GAON','NASHIK','Maharashtra','27','422101','','1111111111','','','0','0','0','0','',NULL,'6406'),(496,'249','Sachin Challak','5','DR','0','','','','4','5',0,'Ws','','','Maharashtra','27','','','1234567890','CANARA BANK','','0','0','0','0','',NULL,'4697'),(497,'249','Sheetal Agencies','5','DR','425431','27ASSPM7996B1ZZ','','','4','5',0,'Flr No C1,Sneh Bldg,Thokle Marg,Ambedkar Ngr','Worli','Mumbai','Maharashtra','27','400018','','9687796510','','','0','0','0','0','',NULL,'6501'),(498,'249','Shri Venkateshwara Traders','5','DR','0','27AEWFS0037F1ZT','','','4','5',0,'Nr S.B.I,Grd Flr,Sr No 211,E3','Shree Ram Colony,Bhosari,Pimpri','Pune','Maharashtra','27','411039','','9860606013','','','0','0','0','0','',NULL,'5979'),(499,'249','Siddhivinayak Impex','5','DR','0','27AMGPP7368C1ZS','','','4','5',0,'Grd Flr,Shop No 4,46/48,Hira Niwas','Modi Street, Fort','Mumbai','Maharashtra','27','400001','','9404215553','','','0','0','0','0','',NULL,'5989'),(500,'249','Sunita Agency','5','DR','0','','','','4','5',0,'ws','','','Maharashtra','27','','','1234567890','DMK','','0','0','0','0','',NULL,'4702'),(501,'249','TAJ WELLINGTON MEWS','5','DR','12863','27AAACT3957G6Z2','','','4','5',0,'PLOT NO 33,TAJ WELLINGTON MEWS,NATHALAL PARIKH MARG,','COLABA','MUMBAI','Maharashtra','27','400001','','1111111111','','','0','0','0','0','',NULL,'4933'),(502,'249','TANOOR CATERERS','5','DR','0','','','','4','5',0,'JAMNALAL INST','CHURCHGATE','','Maharashtra','27','','','8652542680','','','0','0','0','0','',NULL,'5790'),(503,'249','TARKESHWAR SANDWICH','5','DR','0','','','','4','5',0,'REF VISHALBHAI','','','Maharashtra','27','','','','IMPS','','0','0','0','0','','undefined-undefined-44113','1490'),(504,'249','TECHWORKS PVT LTD','5','DR','0','27ACKPB4758J1ZC','','','4','5',0,'SAKINAKA','DEFAULT','Mumbai','Maharashtra','27','400072','','1111111111','','','0','0','0','0','',NULL,'146'),(505,'249','TERRARAY SUPPLIES LLP','5','DR','0','24AAWFT3271A1Z6','','','4','5',0,'CHINUBHAI HOUSE , AMRUTBAUG COLONY, SARDAR','PATEL STADIUM RD,NR HINDU COLONY,NAVRANGPURA','AHMEDABAD','Gujarat','0','380014','','9619997841','','','0','0','0','0','',NULL,'6581'),(506,'249','THAI TRADE CENTER MUMBAI','5','DR','0','','','','4','5',0,'EXPRESS TOWERS 3RD FLOOR','NARIMAN POINT','MUMBAI','Maharashtra','27','400021','','9819591012','','','0','0','0','0','',NULL,'1772'),(507,'249','THE CENTRAL RAILWAY CO.OP.SOCIETY LTD','5','DR','0','','','','4','5',0,'665A,N.M.JOSHI MARG,BYCULLA, MUMBAI','','','Maharashtra','27','','','7039476898','','','0','0','0','0','',NULL,'6318'),(508,'249','THE CORPORATE HOUSEKEEPING SOLUTION','5','DR','0','27FWTPS5910P1ZC','','','4','5',0,'GROUND FLOOR,C 19','KAILASH ENCLAVE,LBS RD, GHATKOPAR WEST','MUMBAI','Maharashtra','27','400086','','1111111111','','','0','0','0','0','','undefined-undefined-44073','1449'),(509,'249','THEOBROMA FOOD PVT LTD','5','DR','0','27AACCT0588K1ZZ','','','4','5',0,'32/33,A DEONAR VILLAGE RD','OPP METAL BOX, GOVANDI (EAST)','Mumbai','Maharashtra','27','400088','','8572684544','','','0','0','0','0','',NULL,'4385'),(510,'249','TRACE VFX SOLUTIONS PVT LTD','5','DR','0','','','','4','5',0,'UJAGAR SILK MILLS,OPP DEONAR DEPO','MUMBAI 88','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'139'),(511,'249','TRISTAR MANAGEMENT SERVICES PVT LTD','5','DR','0','27AADCT2068D1ZI','','AADCT2068D','4','5',0,'UNIT NO. 812 , 8TH FLOOR , GHANSHYAM ENCLAVE , GANDHI NAGAR','LONK ROAD , KANDIWALI WEST','MUMBAI','Maharashtra','27','400067','','1236549870','YES BANK','','0','0','0','0','',NULL,'6510'),(512,'249','UNIQUE ENTERPRISES','5','DR','0','27EDRPK0896I1ZN','','','4','5',0,'LTT TERMINUS','DEFAULT','Mumbai','Maharashtra','27','400070','','1111111111','AXIS BANK','BHUSAWAL','0','0','0','0','',NULL,'156'),(513,'249','UNIQUE FRAGRANCES','5','DR','0','27AAAFU1982B1ZD','','','4','5',0,'Plot No-D-9/8, TTC Industrial Area','MIDC, Turbhe','Navi Mumbai','Maharashtra','27','400705','','6584932432','NEFT','','0','0','0','0','','undefined-undefined-43998','1379'),(514,'249','VALYOU SUPER MART','5','DR','0','27AYSPP5731D1Z3','','','4','5',0,'SHOP NO 10,TRISHUL GOLD COAST','PLOT NO 13,SECTOR 9,GHANSOLI','NAVI MUMBAI','Maharashtra','27','400701','','','PMC','GKTPR','0','0','0','0','','undefined-undefined-43728','758'),(515,'249','VEER','5','DR','0','','','','4','5',0,'CHEMBUR','','','Maharashtra','27','','','9324711302','','','0','0','0','0','',NULL,'1821'),(516,'249','VEER FOUNDATION','5','DR','0','','','','4','5',0,'GHATKOPAR','KUKREJA TOWER','MUMBAI','Maharashtra','27','','','9820042336','IDBI','','0','0','0','0','',NULL,'4260'),(517,'249','VERIEFY BOOK CENTRE','11','DR','0','','','','4','5',0,'A/16 SHOPPING CENTER','RLY STATION GHATKOPER W','','Maharashtra','27','','','8108756674','','','0','0','0','0','',NULL,'4473'),(518,'249','VIBHA HOSPITALITY SERVICE','5','DR','0','','','','4','5',0,'SOMAIYA HOSPITAL','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'227'),(519,'249','VIDYA CATERERS','5','DR','0','','','','4','5',0,'WS','WS','','Maharashtra','27','','','983335425','','','0','0','0','0','',NULL,'592'),(521,'249','VIHAR HOSPITALITY','5','DR','0','27AANFV8459K1Z6','','','4','5',0,'A/10,INDIRA NGR,BANDRA EAST','DEFAULT','Mumbai','Maharashtra','27','400051','','1111111111','VIJAYA','WADALA','0','0','0','0','',NULL,'231'),(522,'249','VIKAS GUPTA','5','DR','0','','','','4','5',0,'MUKTI NAGAR','CHEMBUR','','Maharashtra','27','','','','GPAY','','0','0','0','0','','undefined-undefined-43992','1377'),(523,'249','VINOD STORE','5','DR','0','','','','4','5',0,'W/S','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'155'),(524,'249','VIPUL BHATIA','5','DR','0','','','','4','5',0,'GHATKOPAR','','','Maharashtra','27','','','','DECCAN MERCHANT','','0','0','0','0','',NULL,'1674'),(525,'249','VISION STUDIO INDIA LLP','5','DR','0','27AAMFV1043N1ZR','','','4','5',0,'BORIVALI','','mumbai','Maharashtra','27','400092','','1111111111','','','0','0','0','0','','undefined-undefined-43749','1007'),(526,'249','VJAY LUNCH HOME','5','DR','0','','','','4','5',0,'N.R OCTROL CHEEK NAKA MANKURD','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'163'),(527,'249','VRD RETAIL PVT LTD','5','DR','0','27AAACI1566J1ZI','','','4','5',0,'SHOP NO 5A, VIKRANT CIRCLE','GHATKOPAR EAST','MUMBAI','Maharashtra','27','400077','','1111111111','IDBI BANK','MUMBAI','0','0','0','0','2.15E+13',NULL,'520'),(528,'249','Vallabh Marketing','5','DR','325001','27AEXPJ1215M1Z3','','','4','5',0,'Jankalyan Bhavan,Maurya Compd,Gaondevi','Rd,Bhandup West','Mumbai','Maharashtra','27','400078','','9322914526','','','0','0','0','0','',NULL,'6569'),(529,'249','WONDER CATERING','5','DR','0','27AGYPV0791M1Z7','','','4','5',0,'SHOP NO 2/3A,EKTA CHS LTD','KARVE RD,KANJURMARG EAST','MUMBAI','Maharashtra','27','400042','','','','','0','0','0','0','',NULL,'273'),(532,'249','YASH MARKETING','11','DR','16813798.4','27ADZPD8058M1ZM','','','4','5',0,'PESTOM SAGAR ROAD 3','','','Maharashtra','27','400089','','8369206130','','','0','0','0','0','',NULL,'4908'),(533,'249','YOGI HOTEL','5','DR','0','27AAAFY3119J1Z3','','','4','5',0,'ST ROAD','CHEMBUR','Mumbai','Maharashtra','27','400071','','1111111111','IDBI','','0','0','0','0','',NULL,'126'),(534,'249','YUKTI ENTERPRISE','5','DR','0','27FCIPK6936A1ZJ','','','4','5',0,'PARAS GOPAL INDUSTRIES,OPP','BHUMI PLAZA,DADAR WEST','mumbai','Maharashtra','27','400027','','1111111111','RTGS','MUMBAI','0','0','0','0','',NULL,'286'),(535,'249','ZOMATO','5','DR','0','','','','4','5',0,'ZOMATO','','','Maharashtra','27','','','','IMPS','','0','0','0','0','','undefined-undefined-44024','1415'),(536,'249','kappree','5','DR','0','','','','4','5',0,'meghraj appartment shop no 1','YOGESWARY EAST','','Maharashtra','27','','','9004171369','','','0','0','0','0','',NULL,'4766'),(537,'249','lea cafe','5','DR','0','27AAEFK0595L1ZZ','','','4','5',0,'opp bmc office nr natraj cinema','chembur','Mumbai','Maharashtra','27','400071','','1111111111','','','0','0','0','0','',NULL,'258'),(538,'249','mahalaxmi annapurn kandra','5','DR','0','','','','4','5',0,'deonar','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'271'),(539,'249','mumbai natural kulfee','5','DR','0','','','','4','5',0,'Petroaem Pum','deonar','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'270'),(540,'249','ramesh traders','5','DR','0','','','','4','5',0,'Chembur','chembur','','Maharashtra','27','','','9323182353','','','0','0','0','0','',NULL,'6175'),(541,'249','shree gaurishankar saraf','5','DR','0','','','','4','5',0,'hivam north south road number 2.landmark mithibai clg','juhu','','Maharashtra','27','','','1111111111','','','0','0','0','0','',NULL,'6490'),(542,'249','siraj hair beauty saloon','5','DR','0','','','','4','5',0,'ws','','','Maharashtra','27','','','1234567890','YES','','0','0','0','0','',NULL,'4560'),(543,'249','vikram bhavan canteen','5','DR','0','','','','4','5',0,'barc','','','Maharashtra','27','','','9819081841','SBI','ANUSHAKTI NAGAR','0','0','0','0','',NULL,'285'),(544,'249','CATERING VENDOR PF 5','5','DR','0','','','','5','6',0,'DADAR 9619337910','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'170'),(545,'249','KASHYAP PF 4','5','DR','0','','','','5','6',0,'DADAR 9324308387','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'172'),(546,'249','KHILONA PF 7/8','5','DR','0','','','','5','6',0,'DADAR 7666060448','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'175'),(547,'249','PRADEEP PF 4','5','DR','0','','','','5','6',0,'DADAR 7410003348','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'173'),(548,'249','PRAKASH LALA PF5','5','DR','0','','','','5','6',0,'DADAR 9619337910','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'169'),(549,'249','RUKMANI PF 4','5','DR','0','','','','5','6',0,'DADAR 9619337910','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'171'),(550,'249','SANJAY JUICE PF 7/8','5','DR','0','27ACSPM6285F1Z0','','','5','6',0,'DADAR 7400105306','DEFAULT','mumbai','Maharashtra','27','400014','','1111111111','','','0','0','0','0','',NULL,'174'),(551,'249','TRIVENI PF 5','5','DR','0','','','','5','6',0,'DADAR 8108059114','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'168'),(552,'249','A.H WHEELER & CO.','5','DR','9676','','','','6','7',0,'PF 1/2 KALYAN SIDE','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44270','1745'),(553,'249','A.H WHEELER (MATUNGA) PF 1/2','5','DR','34921','','','','6','7',0,'PF 1/2','','','Maharashtra','27','','','9111111111','IMPS','','0','0','0','0','','undefined-undefined-44287','1768'),(554,'249','CHANTULAL KHOMCHA MATUNGA','5','CR','5435','','','','6','7',0,'MATUNGA STN','','','Maharashtra','27','','','8446355817','IMPS','','0','0','0','0','',NULL,'129'),(555,'249','CHANTULAL T.S MATUNGA','5','DR','33739','','','','6','7',0,'MATUNGA STN','','','Maharashtra','27','','','8652177248','IMPS','','0','0','0','0','',NULL,'128'),(556,'249','MOON LIGHT STORE','5','DR','0','','','','6','7',0,'DAMODAR PARK','GAVDEVI  NEXT TO NAGORI','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43742','973'),(557,'249','S.S JOG','5','DR','0','','','','7','8',0,'KANJURMARG 7977019143','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'176'),(558,'249','A M SHINDE PF 2','5','DR','0','','','','8','9',0,'GHATKOPAR 9819004041','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'195'),(559,'249','A1 MEDICAL','5','DR','0','','','','8','9',0,'NR FATIMA MILK CENTRE','KIROL VILLAGE','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44052','1433'),(560,'249','AAGAM FOOD N MORE','5','DR','0','','','','8','9',0,'NEAR LADHUBHAI','','','Maharashtra','27','','','9821356124','HDFC','','0','0','0','0','','undefined-undefined-44171','1608'),(561,'249','AARAY  SARITA','5','DR','0','','','','8','9',0,'NEAR 141','STATION ROAD','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43776','1174'),(562,'249','AAREY 1519','5','DR','0','','','','8','9',0,'NEAR JOLLY JIMKHANA','','','Maharashtra','27','','','','SBI','','0','0','0','0','','undefined-undefined-43714','726'),(563,'249','AAREY 1595','5','DR','0','','','','8','9',0,'NR JOLLY GYMKHANA','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'684'),(564,'249','AAREY CENTER 141','5','DR','0','','','','8','9',0,'OPP BHARAT CAFFE','STATION ROAD','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43776','1173'),(565,'249','AAREY CENTRE 1833','5','DR','0','','','','8','9',0,'BEHIND RAMESHWAR DUGDHALAYA','GHATKOPAR','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'299'),(566,'249','AAREY SARITA 66','5','DR','0','','','','8','9',0,'BATA SHOES','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'663'),(567,'249','AAREY Z 1855','5','DR','0','','','','8','9',0,'OPP PARAS ST','','','Maharashtra','27','400077','','9022779629','INDIAN','','0','0','0','0','','undefined-undefined-44123','1512'),(568,'249','ADINATH KIRANA','5','DR','0','','','','8','9',0,'GOVN DEVI','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43729','759'),(569,'249','AGARWAL JUICE','5','DR','0','','','','8','9',0,'NR..CENTRAL STORES...9967161487','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44171','1607'),(570,'249','AMBIKA MEDICAL','5','DR','0','','','','8','9',0,'GARODIYA NAGER','OPP OM DEPERMENT','','Maharashtra','27','','','3456677','','','0','0','0','0','',NULL,'5386'),(571,'249','AMRUT GRAIN STORE','5','DR','0','27AABPG4583B1Z2','','','8','9',0,'CHHEDA NAGAR','','mumbai','Maharashtra','27','400077','','1111111111','INDIAN OVER','','0','0','0','0','','undefined-undefined-44142','1533'),(572,'249','ANAND JUICE CENTER','5','DR','0','','','','8','9',0,'OPP CHANDAN STORE','','','Maharashtra','27','','','','JANKALYAN','','0','0','0','0','','undefined-undefined-43733','766'),(573,'249','ANAPURNA DAIRY','5','DR','0','','','','8','9',0,'VIDAYVIHAR STATION W','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43770','1156'),(574,'249','ANJALI STORE','5','DR','0','','','','8','9',0,'SHOP NO. 9 EGAL CO-OP SOCIETY','SUCHITA BUSINNES PARK','','Maharashtra','27','','','9819987553','','','0','0','0','0','',NULL,'6022'),(575,'249','AVARYA FINE FOODS','5','DR','0','27AAZFA1446R1ZK','','','8','9',0,'LBS MARG,NR SHREYAS CINEMA','GHATKOPAR WEST','mumbai','Maharashtra','27','400086','','1111111111','AXIS','GHATKOPAR','0','0','0','0','1.15E+13',NULL,'681'),(577,'249','BALRAM SHARMA PF 1','5','DR','0','','','','8','9',0,'GHATKOPAR 8655782456','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'177'),(578,'249','BHATLA\'S KITCHEN','5','DR','0','27AJIPB4482A1ZL','','','8','9',0,'NEAR RAVI PETROL PUMP','PESTOM SAGAR RD NO4','MUMBAI','Maharashtra','27','','','9324165360','HDFC BANK','CHEMBUR','0','0','0','0','','undefined-undefined-44652','1226'),(579,'249','BRIJVASI SWEET','5','DR','0','','','','8','9',0,'NE SHIVANI PHARMASI..9821952941','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44171','1606'),(587,'249','CASH [C.S]','5','DR','0','','','','8','9',0,'NER ANAD JUIC','','','Maharashtra','27','','','983355426','','','0','0','0','0','','undefined-undefined-43758','1057'),(589,'249','CHAMUNDA STORE','5','DR','0','27AFFPC0085B1Z3','','','8','9',0,'NAIDU COLONY','PANT NGR CIRCLE','MUMBAI','Maharashtra','27','400077','','1111111111','THE DECCAN BANK','','0','0','0','0','','undefined-undefined-43837','1262'),(596,'249','D P TRIPATHI PF 1','5','DR','0','','','','8','9',0,'GHATKOPAR 9967594160','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'194'),(597,'249','DEDHIYA  BROTHER','5','DR','0','','','','8','9',0,'KIROL VILLAGE OPP MILIND STORES','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43770','1155'),(598,'249','DEEPA RESTAURANT','5','DR','0','27APLPS2987L2ZV','','','8','9',0,'NEAR SHREYAS NAKA LBS MARG','GHATKOPAR WEST','','Maharashtra','27','','','9769384735','','','0','0','0','0','',NULL,'234'),(599,'249','DEEPAK MEDICAL','5','DR','0','27AAGPS7815R1ZR','','','8','9',0,'GOPAL LANE','','Mumbai','Maharashtra','27','400086','','8083038080','','','0','0','0','0','',NULL,'680'),(600,'249','DEEPAK MEDICAL & GEN STORE','5','DR','0','27AARFD2720P1ZY','','','8','9',0,'KAPOL WADI','GHATKOPAR WEST','Mumbai','Maharashtra','27','400077','','9820356540','','','0','0','0','0','','undefined-undefined-44122','1510'),(601,'249','DHEDHIYA BROTHERS','5','DR','0','','','','8','9',0,'KIROLE VILLAGE NEXT TO PANKAJ','VIDHAYAVIHAR','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43721','741'),(602,'249','EKAL ENTERPRISES','5','DR','0','27AHZPD3764C1Z4','','','8','9',0,'KIROL VILLAGE, VIDHYAVIHAR WEST','OPP NEELKANTH KINGDOM','','Maharashtra','27','','','','ICICI','KURLA','0','0','0','0','','undefined-undefined-43708','694'),(603,'249','EVERGREEN FOODS','5','DR','0','27AAEFE1075D1ZT','','','8','9',0,'SHOP NO 3,VALUE PLATINUM','RAJAWADI RD,GHATKOPAR EAST','MUMBAI','Maharashtra','27','400077','','8976706666','','','0','0','0','0','1.15E+13','undefined-undefined-43994','1378'),(604,'249','FATIMA MILK CENTER','5','DR','0','','','','8','9',0,'AMAR GRAIN STORE','GHATKOPAR','','Maharashtra','27','','','','MUMBAI DISTRICT','GHATKOPAR','0','0','0','0','','undefined-undefined-43714','723'),(605,'249','FOOD POINT','5','DR','0','27AALPY1639G1Z9','','','8','9',0,'OPP SHIVAM DRYFRUIT GOPAL GTALI','','Mumbai','Maharashtra','27','400077','','1111111111','CORPORATION BANK','','0','0','0','0','','undefined-undefined-43738','959'),(606,'249','GAJANAN PF 2','5','DR','0','','','','8','9',0,'GHATKOPAR','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'200'),(607,'249','GALA STORE','5','DR','0','','','','8','9',0,'NEXT TO KALPTARU KHALI VILLAGE','GHATKOPAR','','Maharashtra','27','','','','BOI','GKPR','0','0','0','0','','undefined-undefined-43721','743'),(608,'249','GANESH PHARMACY','5','DR','0','','','','8','9',0,'OPP CURE MEDICAL','','MUMBAI','Maharashtra','27','400077','','9898989898','SARASWAT','','0','0','0','0','',NULL,'5392'),(609,'249','GAUTAM DUGDHALAYA','5','DR','0','27AGCPP4385R1ZJ','','','8','9',0,'SHOP NO 3 SIDDHI APARTMENT CAMA LANE','GHATKOPR','MUMBAI','Maharashtra','27','400086','','1111111111','SHRI ARIHANT','GHATKOPAR','0','0','0','0','',NULL,'585'),(611,'249','GHATKOPAR AYURVED BHANDAR','5','DR','0','27AAEFG0342H1ZR','','','8','9',0,'SH05 NEW ASHISH APT,OPP POPULAR HOTAL HINGWALA LANE GHATKOPER','','MUMBAI','Maharashtra','27','400075','','9967036295','BOB','','0','0','0','0','',NULL,'5387'),(613,'249','GHELANI STORES','5','DR','0','27AAGPS2642Q1Z2','','','8','9',0,'HINGWALA LANE,','GHATKOPAR (E)','MUMBAI','Maharashtra','27','400077','','9702939030','KOTAK','','0','0','0','0','','undefined-undefined-43938','1342'),(614,'249','HANUMAN STOTES','5','DR','0','','','','8','9',0,'KIROL VILLAGE','NEXT TO PANKAJ STORES','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'1025'),(615,'249','HARMONY AGENCY','5','DR','0','27AFOPJ1182P1ZU','','','8','9',0,'RAMABAI COLONY, GHATKOPAR','','','Maharashtra','27','','','','SOUTH INDIAN BANK','GHATKOPAR','0','0','0','0','','undefined-undefined-43738','938'),(616,'249','JAIN DAIRY FARM','5','DR','0','27AABPS9453Q1ZS','','','8','9',0,'SHOP NO 7,CHIMAN NIWAS,GOPAL LANE','GHATKOPAR (WEST)','mumbai','Maharashtra','27','400086','','9821388899','','','0','0','0','0','','undefined-undefined-44274','1751'),(617,'249','JAY BHARAT STORE (PHARMACY)','5','DR','0','27AAPFJ3196D1Z3','','','8','9',0,'GR FLR SHOP NO 2 NAVROJI LANE','','Mumbai','Maharashtra','27','400086','','7304443030','BOB','GKTPR','0','0','0','0','','undefined-undefined-43738','957'),(618,'249','JAY KRISHNA BANDAR','5','DR','0','27AOMPG6147C1Z0','','','8','9',0,'NEAR CAMA LANE','GHATKOPAR','Mumbai','Maharashtra','27','400077','','1111111111','JANKALYAN','GHATKOPAR','0','0','0','0','',NULL,'580'),(619,'249','JAY KRISHNA BHANDAR','5','DR','0','27AOMPG6147C1Z0','','','8','9',0,'NER CHANDAN STORE','','','Maharashtra','27','','','','JANKALYAN','','0','0','0','0','','undefined-undefined-43864','1287'),(620,'249','JJC ROYALE JAGDUSHA','5','DR','0','27AABAJ4071G1ZT','','','8','9',0,'GHATKOPAR EAST','','Mumbai','Maharashtra','27','400086','','1111111111','DENA BANK','','0','0','0','0','','undefined-undefined-43819','1235'),(621,'249','JYOTI GEN STORE','5','DR','0','27APNPC4665F1ZS','','','8','9',0,'KAMA LANE NEXT TO S S ND T COOLAGE','GHATKOPAR','Mumbai','Maharashtra','27','400086','','9820747442','BOB','GKPR','0','0','0','0','',NULL,'531'),(622,'249','KALPATARU','5','DR','0','','','','8','9',0,'VIDHAYAVIHAR(KHALI VILLAGE','GHATKOPAR','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'648'),(623,'249','KHANDELWAL & SONS','5','DR','0','27ADQPK1957M1ZU','','','8','9',0,'71 HIRACHAND DESAI ROAD MUNICIPAL COMPLEX SARVODAY STATION ROAD','GHATKOPAR (W)','Mumbai','Maharashtra','27','400086','','9967634402','SBI','GKTPR','0','0','0','0','',NULL,'583'),(624,'249','KRISHANA MEDICAL AND GENERAL STORE','5','DR','0','','','','8','9',0,'SHOPNO 07,B NO122, CTS5662 PANT NAGAR, MHADA COLONY, MUMBAI GHATKOPER','','','Maharashtra','27','','','7045274298','IDBI','','0','0','0','0','',NULL,'5388'),(626,'249','LADHUBHAI THOBHAN','5','DR','0','27AADPG1207A1ZN','','','8','9',0,'S.N.D.T COOLAGE','GHATKOPAR (W)','','Maharashtra','27','','','022-25162190','BOB','G K','0','0','0','0','',NULL,'316'),(627,'249','LAKHANI GEN STORE','5','DR','0','','','','8','9',0,'GKHOOT GALI','GHATKOPAR','','Maharashtra','27','','','','KNS','GKPR','0','0','0','0','',NULL,'594'),(628,'249','LAKHANI SUPER MARKET','5','DR','0','','','','8','9',0,'GKHOT GALI','GHATKOPAR','','Maharashtra','27','','','','KNS','GKPR','0','0','0','0','',NULL,'593'),(629,'249','LAXMI GEN STORE','5','DR','0','','','','8','9',0,'DAMODAR PARK GAVDEVI','GHATKOPAR','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'590'),(630,'249','LAXMI GEN STORE','5','DR','0','','','','8','9',0,'HANSOTI LANE','GHATKOPAR','','Maharashtra','27','','','','JANKALYAN','GKTPR','0','0','0','0','',NULL,'319'),(631,'249','LAXMI GRAIN STORE','5','DR','0','','','','8','9',0,'MANEKLAL NEAR BUS STOP','MANEKLAL 1ST BUS STOP','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43718','735'),(632,'249','LAXMI STORE','5','DR','0','','','','8','9',0,'HANSOTI LANE','GHATKOPAR','','Maharashtra','27','','','','JANAKALYAN','GKOPAR','0','0','0','0','',NULL,'298'),(633,'249','LAXMI TEA & FARSAN','5','DR','0','27AAQHM2606G1Z4','','','8','9',0,'GHATKOPAR ST NEAR NOBAL CHEMIST','GHATKOPAR','Mumabi','Maharashtra','27','400086','','1111111111','CANARA BANK','GHATKOPAR','0','0','0','0','',NULL,'595'),(634,'249','LEO 89','5','DR','0','','','','8','9',0,'CHEMBUR','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'582'),(635,'249','MAHALAXMI GEN STORE','5','DR','0','','','','8','9',0,'NEARNOORI BEAKERY','GHATKOPAR','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'612'),(636,'249','MAHANAGAR','5','DR','0','27AKAPK8208L1ZZ','','','8','9',0,'OPPNEO WELCOME HOTEL J V ROAD','GHATKOPAR','Mumbai','Maharashtra','27','400086','','1111111111','','','0','0','0','0','',NULL,'530'),(637,'249','MAHANAGAR  MEDICAL GENERAL STORE','5','DR','0','27ALLPK0025B1ZO','','','8','9',0,'SHOP NO 08 OPP FISH MARKET, STATION ROAD, PHANTNAGAR GHATKOPER','','MUMBAI','Maharashtra','27','400077','','9820409103','SBI','','0','0','0','0','',NULL,'5391'),(638,'249','MAHARASHTRA G/ S','5','DR','0','','','','8','9',0,'KAHALI VILLAGE','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43735','898'),(639,'249','MALANI STORE','5','DR','0','','','','8','9',0,'PASTAM SAGAR ROAD NO 4','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43744','976'),(640,'249','MAULI MEDICAL','5','DR','0','','','','8','9',0,'KIROL VILLAGE NEAR DEDIYA STORES','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'1024'),(641,'249','MEHTA BROTHERS','5','DR','0','','','','8','9',0,'NR HEENA GENERAL STORE','','','Maharashtra','27','','','467889','','','0','0','0','0','',NULL,'5393'),(642,'249','METRO CHEMIST  GENERAL STORE','5','DR','0','','','','8','9',0,'SHOP NO 2, WING ,PRARTHANA CHS LTD BLDG NO 81 PANTNAGER, GHATKOPER EAST','OPP FLORA MEDICAL','','Maharashtra','27','','','8452903790','','','0','0','0','0','',NULL,'5395'),(643,'249','MILIND STORE','5','DR','0','','','','8','9',0,'KIROLE VILLAGE OPP DEADEYA STORE','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43780','1178'),(644,'249','MUMMA\'S YUMMY','5','DR','0','','','','8','9',0,'SHOP NO 8,SHIV KRUPA SADAN,','KARANI LANE,GHATKOPAR WEST','','Maharashtra','27','','','7208830624','ICICI','','0','0','0','0','',NULL,'4019'),(645,'249','NAYANA ENTERPRISE','5','DR','0','','','','8','9',0,'GHATKOPAR','','','Maharashtra','27','','','','CORPORATION','GHT','0','0','0','0','','undefined-undefined-43875','1290'),(646,'249','NEW MUNDRA SWEET','5','DR','0','','','','8','9',0,'NR WELCOME S/M','','','Maharashtra','27','','','9821426930','','','0','0','0','0','','undefined-undefined-44165','1583'),(647,'249','PANDY DUGDHALYA','5','DR','0','','','','8','9',0,'GAVDEVI','GHATKOPAR','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'588'),(649,'249','PARAS TEA MART','5','DR','0','27AAEPS9108H4ZD','','','8','9',0,'OPP GHATKOPAR RAILWAY STATION','','Mumbai','Maharashtra','27','400086','','9324795105','CANARA','GKPR','0','0','0','0','','undefined-undefined-43776','1175'),(650,'249','PRADISE MEDICO GENERAL STORE','5','DR','0','27BHGPJ7058H1Z3','','','8','9',0,'SHOP NO 1 JAY KRISHANA BLDG PL PANTNAGAR , GHATKOPER','ghatkoper','MUMBAI','Maharashtra','27','400075','','7715915928','','','0','0','0','0','',NULL,'5390'),(651,'249','R R FAST FOOD','5','DR','0','','','','8','9',0,'GOREGAON','','','Maharashtra','27','','','9022779629','SYNDICATE BANK','','0','0','0','0','',NULL,'1658'),(653,'249','RAJAWADI CANTEEN','5','DR','0','','','','8','9',0,'RAJAWADI HOSPITAL','','','Maharashtra','27','','','8097390290','','','0','0','0','0','','undefined-undefined-44270','1746'),(654,'249','RAJAWADI STALL','5','DR','0','','','','8','9',0,'RAJAWADI HOSPITAL','','','Maharashtra','27','','','9892389218','','','0','0','0','0','','undefined-undefined-44280','1761'),(655,'249','RAJKAMAL SWEETS','5','DR','0','','','','8','9',0,'NR AGARWAL JUICE CENTER','','','Maharashtra','27','','','7977015677','','','0','0','0','0','','undefined-undefined-44189','1643'),(656,'249','RAMESHWAR DUGDHALAY','5','DR','0','','','','8','9',0,'KAMA LANE','GHATKOPAR','','Maharashtra','27','','','','JANKALYAN','CHEMBUR','0','0','0','0','',NULL,'297'),(657,'249','RAMNIK STORE','5','DR','0','','','','8','9',0,'STATION ROAD','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'664'),(658,'249','RATNA SUPER MARKET','5','DR','0','27ABEFP6888L1ZC','','','8','9',0,'ASHOK BULDING OPP- PURNIMA BULDING 60 FEET ROAD','GHATKOPER EAST','MUMBAI','Maharashtra','27','400071','','9920123522','KOTAK BANK','','0','0','0','0','',NULL,'6393'),(659,'249','RAYSHI BACHUBHAI & COMPANY','5','DR','0','27AAAFR8617A1ZG','','','8','9',0,'OPP CAMA LANE M G ROAD GHATKOPAR','GHATKOPAR','mumbai','Maharashtra','27','400077','','1111111111','UNION','GKTPR','0','0','0','0','',NULL,'576'),(660,'249','REKHA GENERAL STORE','5','DR','0','27AACPD3469Q1ZA','','','8','9',0,'RAJAWADI GHATKOPAR','','mumbai','Maharashtra','27','400077','','1111111111','','','0','0','0','0','','undefined-undefined-44106','1483'),(661,'249','REKHA GENERAL STORES','5','DR','0','27AACPD3469Q1ZA','','','8','9',0,'SHIV NIWAS RAJAWADI','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44104','1482'),(665,'249','SANTOSH BHELPURI','5','DR','0','','','','8','9',0,'NEXT TO KHANDALWAL','GHATKOPAR','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'662'),(666,'249','SATYAM DRY FRUIT','5','DR','0','','','','8','9',0,'GOPAL LANE','','','Maharashtra','27','','','','ICICI','','0','0','0','0','','undefined-undefined-43735','897'),(667,'249','SATYAM DRYFRUIT','5','DR','0','','','','8','9',0,'OPP DEPAK MEDICAL GOPAL GALI','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43718','737'),(668,'249','SHAH DEVISHI JESANG','5','DR','0','','','','8','9',0,'KAMA LANE OPP LADHU BHAI','','','Maharashtra','27','','','','BOB','GKTPR','0','0','0','0','','undefined-undefined-43735','900'),(670,'249','SHAH RAGHAVJ MONJI','5','DR','0','27AAPPS4910G1ZF','','','8','9',0,'NR UDAY THEATRE','','','Maharashtra','27','','','9819080220','','','0','0','0','0','','undefined-undefined-44171','1609'),(671,'249','SHAH VELJI','5','DR','0','','','','8','9',0,'OPP LADHUBHAI','','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'321'),(672,'249','SHEETY P/B','5','DR','0','','','','8','9',0,'NEAR PANDY DUGHDHALYA','GHATKOPAR','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'591'),(673,'249','SHIDDHI MEDICAL','5','DR','0','','','','8','9',0,'KHALAI VILLAGE','NEAR KALPTERU GRAIN STORE','','Maharashtra','27','','','9784485237','','','0','0','0','0','','undefined-undefined-43748','1003'),(674,'249','SHINDE','5','DR','0','','','','8','9',0,'GHATKOPAR','DEFAULT','','Maharashtra','27','','','','','','0','0','0','0','',NULL,'201'),(675,'249','SHIVAM DRYFRUIT','5','DR','0','','','','8','9',0,'NR SATYAM DRY FRUIT','GOPAL GALLI','','Maharashtra','27','','','','CORPORATION','GHATKOPAR','0','0','0','0','','undefined-undefined-43738','958'),(676,'249','SHIVRAJ','5','DR','0','27ADLFS4359N1Z8','','','8','9',0,'SHOP NO 2 TRAFFIC LITE BLDG NEAR BANK OF BARODA M G ROAD','GHATKOPAR','MUMBAI','Maharashtra','27','400077','','8898903483','ICICI','GKTPR','2500','1','0','0','1.15E+13',NULL,'584'),(677,'249','SHREE GANESH CHEMIST','5','DR','0','27AGIPA1255H2ZP','','','8','9',0,'GAVDEVI NEAR SHATI NIKETAN HOSPITAL','GHATKOPAR','Mumbai','Maharashtra','27','400077','','1111111111','','','0','0','0','0','',NULL,'669'),(678,'249','SHREE LAXMI STORE','5','DR','0','','','','8','9',0,'AIROL VILLAGE','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43735','899'),(679,'249','SHREE RAM JUICE CENTER','5','DR','0','','','','8','9',0,'OPP HINDUSHABA HOSPTEL','','','Maharashtra','27','','','','ABHYUDAYA','GHATKOPAR','0','0','0','0','','undefined-undefined-43733','765'),(682,'249','SHYAM BIHARI DAIRY','5','DR','0','','','','8','9',0,'BEHIND MANEKLAL BUS STOP','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43709','706'),(683,'249','SMILE N BAKE','5','DR','0','','','','8','9',0,'NAVROJI LANE','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43714','724'),(685,'249','TIP TOP SNACKS','5','DR','0','27ETMPR5807M1ZT','','','8','9',0,'NR FOOD POINT','','Mumbai','Maharashtra','27','400071','','8652222111','IMPS','GHATKOPAR','0','0','0','0','','undefined-undefined-44163','1564'),(686,'249','UDAY STORES','5','DR','0','27AABPP7971N1ZY','','','8','9',0,'SHREE MAHALAXMI APARTMENT SHOP NO 3 CAMA LANE','GHATKOPAR W','Mumbai','Maharashtra','27','400077','','1111111111','JANKALYAN','GKPR','0','0','0','0','',NULL,'586'),(687,'249','VINAYAK FOODS','5','DR','0','','','','8','9',0,'BEHIND R ODEON MALL','','','Maharashtra','27','','','','SHRI ARIHANT','','0','0','0','0','','undefined-undefined-43989','1372'),(688,'249','VORA FACTORY OUTLET','5','DR','0','','','','8','9',0,'NR SATYAM D/F','','','Maharashtra','27','','','8433556555','CORPORATION','','0','0','0','0','','undefined-undefined-44168','1594'),(689,'249','WELCOME SUPER MARKET','5','DR','0','27AACFW3808N1ZR','','','8','9',0,'GHATKOPAR','GHATKOPAR','Mumbai','Maharashtra','27','400071','','1111111111','HDFC','GKPR','0','0','0','0','',NULL,'581'),(690,'249','WILLFRED','5','DR','0','','','','8','9',0,'VIDHAYAVIHAR KIROL VILLAGE','','','Maharashtra','27','','','9920770907','CANARA','VIDYA VIHAR','0','0','0','0','','undefined-undefined-43738','953'),(691,'249','aarey  140','5','DR','0','','','','8','9',0,'opp  bharat cafe hotel','','','Maharashtra','27','','','9029583587','','','0','0','0','0','','undefined-undefined-44200','1652'),(692,'249','amar grain st','5','DR','0','','','','8','9',0,'nr bread st','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43714','722'),(693,'249','bread st','5','DR','0','','','','8','9',0,'kirol village','','','Maharashtra','27','','','','CANARA','VIDYAVIHAR','0','0','0','0','','undefined-undefined-43714','721'),(695,'249','mundra mithai ghar','5','DR','0','','','','8','9',0,'opp new mundra','','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-44185','1638'),(696,'249','vinkyak store','5','DR','0','','','','8','9',0,'near odian tokies','ghatkopar','','Maharashtra','27','','','','','','0','0','0','0','','undefined-undefined-43713','714');
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `PG_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` int DEFAULT '0',
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `INV_ARR` text,
  `INV_NO` text,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN_QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FREE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROFIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `WEIGHT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PRICE_PER` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DMG_MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REMARK` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_ARR` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UPDATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SECURITY_KEY` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AREA` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_MAN` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GROUP_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PARTY_CODE` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FINAL_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BATCH_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `MFG_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `EXP_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int DEFAULT '0',
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int DEFAULT '0',
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int DEFAULT '0',
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SMAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYNC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text,
  `UPDATED_VALUE` text,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text,
  `DIACM` text,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int DEFAULT '0',
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int DEFAULT '0',
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-05-16 07:11:45','2026-05-16 07:11:45');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UOM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int DEFAULT '0',
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
INSERT INTO `USER_PREF` VALUES (1,'249',NULL,NULL,'SalesReverseCalculation','1',397,NULL,NULL,NULL,'397','397',NULL,0,'2026-05-16 07:16:57','2026-05-16 07:16:57'),(2,'249',NULL,NULL,'SalesZeroStock','1',397,NULL,NULL,NULL,'397','397',NULL,0,'2026-05-16 07:16:57','2026-05-16 07:16:57'),(3,'249',NULL,NULL,'salesTemplateName','print-A4 Paper.hbs',397,NULL,NULL,NULL,'397','397',NULL,0,'2026-05-16 07:16:57','2026-05-16 07:16:57'),(4,'249',NULL,NULL,'SalesPurchaseDecimal4','1',397,NULL,NULL,NULL,'397','397',NULL,0,'2026-05-16 07:16:57','2026-05-16 07:16:57');
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `WEB_ID` int NOT NULL DEFAULT '0',
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-05-16 07:11:50');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-14  8:00:40
