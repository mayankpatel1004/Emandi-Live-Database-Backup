-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: emxlTU0qdP
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `emxlTU0qdP`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `emxlTU0qdP` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `emxlTU0qdP`;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AREA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
INSERT INTO `AREA` VALUES (1,'234',NULL,NULL,'1','DEFAULT',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(2,'234',NULL,NULL,'Surat','Surat',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(3,'234',NULL,NULL,'Karnataka','Karnataka',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(4,'234',NULL,NULL,'DEFAULT','UP',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(5,'234',NULL,NULL,'UP','Gujrat',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(6,'234',NULL,NULL,'Gujrat','Bhiwandi',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(7,'234',NULL,NULL,'Bhiwandi','Khalilabad',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(8,'234',NULL,NULL,'Khalilabad','Malad (E)',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(9,'234',NULL,NULL,'Malad (E)','Kandivali (W)',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(10,'234',NULL,NULL,'Kandivali (W)','Bhyandar (W)',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(11,'234',NULL,NULL,'Bhyandar (W)','Varanasi',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(12,'234',NULL,NULL,'Varanasi','Mumbra',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(13,'234',NULL,NULL,'Mumbra','Ayodhya',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(14,'234',NULL,NULL,'Ayodhya','Delhi',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(15,'234',NULL,NULL,'Delhi','Pune',NULL,'362','362',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45');
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CONFIG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text,
  `MASTER` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'234','0','emxlTU0qdP',234,'','','','2026-04-28 05:59:59','2026-04-28 05:59:59','','','','','','','','','2026-04-28 05:59:59','362','362','',0,'2026-04-28 05:59:59','2026-04-28 05:59:59');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` varchar(255) DEFAULT 'No',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (234,NULL,NULL,'1','Mahakal Enterprises','2026-04-01','2027-03-31','undefined','undefined','undefined','undefined','8082391869','','','','','','','','','','','','','','',NULL,'0',NULL,'1.0.0621','undefined','undefined','','santoshy@yopmail.com','','undefined',NULL,'1',NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-04-28 05:59:59','2026-05-02 09:22:27',NULL,'','','MahakalEnt','Yes');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `CREATED_TS` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `BATCH_ID` int DEFAULT '0',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
INSERT INTO `DERIVED_BATCH_STOCK` VALUES (1,'0',NULL,NULL,13,107,'-720',NULL,'362','362',NULL,0,'2026-05-02 09:14:23','2026-05-02 09:16:56'),(2,'0',NULL,NULL,14,108,'-1800',NULL,'362','362',NULL,0,'2026-05-02 09:15:02','2026-05-04 09:56:38'),(3,'0',NULL,NULL,84,109,'-180',NULL,'362','362',NULL,0,'2026-05-04 10:07:52','2026-05-04 10:16:49');
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DISP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `DELETED` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int DEFAULT '0',
  `TAX_ID` int DEFAULT '0',
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INV_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'234',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'234',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'234',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'234',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'234',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'234',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'234',NULL,NULL,'22','','ME/26-27/','','14','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(8,'234',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(9,'234',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(10,'234',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(11,'234',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(12,'234',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(13,'234',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(14,'234',NULL,NULL,'1','','','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(15,'234',NULL,NULL,'22','','ME/26-27/','','14','SALES','',NULL,'0','0',NULL,0,NULL,NULL),(16,'234',NULL,NULL,'22','','ME/26-27/','','14','SALES','',NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LEDGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `MAC_ID` int DEFAULT '0',
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int DEFAULT '0',
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int DEFAULT '0',
  `ROOT_PARENT_ID` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text,
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `SAC_ID` int NOT NULL DEFAULT '0',
  `REMOTE_ID` int NOT NULL DEFAULT '0',
  `PENDING_AMT` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `PROD_ID` int NOT NULL DEFAULT '0',
  `PACK` int NOT NULL DEFAULT '0',
  `PROD_BATCH_ID` int NOT NULL DEFAULT '0',
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int NOT NULL DEFAULT '0',
  `PUR_RET_QTY` int NOT NULL DEFAULT '0',
  `PUR_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `PUR_TOTAL` int NOT NULL DEFAULT '0',
  `SALE_QTY` int DEFAULT '0',
  `SALE_RET_QTY` int DEFAULT '0',
  `SALE_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `SALE_TOTAL` int NOT NULL DEFAULT '0',
  `OP_STOCK` int NOT NULL DEFAULT '0',
  `CLOSING_STOCK` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
INSERT INTO `OP_CL_STOCK` VALUES (1,234,13,0,107,'2026-05-02',0,0,0,0,2192,0,0,2192,0,-2192),(2,234,14,0,108,'2026-05-04',0,0,0,0,2576,0,0,2576,0,-2576);
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'234',NULL,NULL,'081',NULL,'','APSA Roghan Sukoon 50ml','APSA Roghan Sukoon 50ml','30039012','50','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(2,'234',NULL,NULL,'082',NULL,'','APSA Roghan Sukoon 100ml','APSA Roghan Sukoon 100ml','30039012','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(3,'234',NULL,NULL,'084',NULL,'','APSA Roghan Sukoon 500ml','APSA Roghan Sukoon 500ml','30039012','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(4,'234',NULL,NULL,'103',NULL,'','RAH Icco Noorani Tel 500ml','RAH Icco Noorani Tel 500ml','30039011','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(5,'234',NULL,NULL,'121',NULL,'','Rahat Rooh 100ml','Rahat Rooh 100ml','30039011','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(6,'234',NULL,NULL,'122',NULL,'','Rahat Rooh 200ml','Rahat Rooh 200ml','30039011','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(7,'234',NULL,NULL,'123',NULL,'','Rahat Rooh 300ml','Rahat Rooh 300ml','30039011','300','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(8,'234',NULL,NULL,'124',NULL,'','Rahat Rooh 500ml','Rahat Rooh 500ml','30039011','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'3','3','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(9,'234',NULL,NULL,'001',NULL,'','TULSI OIL 100ML','TULSI OIL 100ML','30049011','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(10,'234',NULL,NULL,'002',NULL,'','TULSI OIL 200ML','TULSI OIL 200ML','30049011','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(11,'234',NULL,NULL,'003',NULL,'','TULSI OIL 500ML','TULSI OIL 500ML','30049011','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(12,'234',NULL,NULL,'011',NULL,'','RED SUKOON MASSAGE OIL 50 ML','RED SUKOON MASSAGE OIL 50 ML','30049012','50','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(13,'234',NULL,NULL,'012',NULL,'','RED SUKOON MASSAGE OIL 100 ML','RED SUKOON MASSAGE OIL 100 ML','30049012','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(14,'234',NULL,NULL,'013',NULL,'','RED SUKOON MASSAGE OIL 200 ML','RED SUKOON MASSAGE OIL 200 ML','30049012','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(15,'234',NULL,NULL,'014',NULL,'','RED SUKOON MASSAGE OIL 500 ML','RED SUKOON MASSAGE OIL 500 ML','30049012','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(16,'234',NULL,NULL,'015',NULL,'','KALONJI (BLACK SEED) OIL 100 ML','KALONJI (BLACK SEED) OIL 100 ML','30049011','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(17,'234',NULL,NULL,'016',NULL,'','Sukoon Massage Oil 50ml','Sukoon Massage Oil 50ml','30049012','50','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(18,'234',NULL,NULL,'017',NULL,'','Sukoon Massage Oil 100ml','Sukoon Massage Oil 100ml','30049012','100','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(19,'234',NULL,NULL,'018',NULL,'','Sukoon Massage Oil 200ml','Sukoon Massage Oil 200ml','30049012','200','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(20,'234',NULL,NULL,'031',NULL,'','Yogiraj Gouthve Vati','Yogiraj Gouthve Vati','300490','0','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(21,'234',NULL,NULL,'032',NULL,'','Yogiraj Gouth Balm 20gm','Yogiraj Gouth Balm 20gm','300490','0','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(22,'234',NULL,NULL,'033',NULL,'','Yogiraj Gouth Vati R-100 Gold','Yogiraj Gouth Vati R-100 Gold','300490','0','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(23,'234',NULL,NULL,'034',NULL,'','Yogiraj Gouth Vati R-100','Yogiraj Gouth Vati R-100','300490','0','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(24,'234',NULL,NULL,'035',NULL,'','Yogiraj Gouth Pain Relif Gel 30gm','Yogiraj Gouth Pain Relif Gel 30gm','300490','0','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(25,'234',NULL,NULL,'036',NULL,'','Yogiraj Kabraj Churan 100gm','Yogiraj Kabraj Churan 100gm','3001490','0','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(26,'234',NULL,NULL,'037',NULL,'','Yogiraj Kabraj Tablet 30TAB','Yogiraj Kabraj Tablet 30TAB','300490','0','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(27,'234',NULL,NULL,'038',NULL,'','Yogiraj Shilajie Resin 20gm','Yogiraj Shilajie Resin 20gm','300490','0','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(28,'234',NULL,NULL,'061',NULL,'','Bath Soap 100gm','Bath Soap 100gm','34011110','0','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(29,'234',NULL,NULL,'083',NULL,'','APSA Roghan Sukoon 200ml','APSA Roghan Sukoon 200ml','30039012','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(30,'234',NULL,NULL,'101',NULL,'','RAH Icco Noorani Tel 110ml','RAH Icco Noorani Tel 110ml','30039011','110','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(31,'234',NULL,NULL,'102',NULL,'','RAH Icco Noorani Tel 210ml','RAH Icco Noorani Tel 210ml','30039011','210','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(32,'234',NULL,NULL,'141',NULL,'','Roghan Sukoon Oil 50ml','Roghan Sukoon Oil 50ml','30049099','50','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(33,'234',NULL,NULL,'142',NULL,'','Roghan Sukoon Oil 100ml','Roghan Sukoon Oil 100ml','30049099','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(34,'234',NULL,NULL,'143',NULL,'','Roghan Sukoon Oil 200ml','Roghan Sukoon Oil 200ml','30049099','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(35,'234',NULL,NULL,'144',NULL,'','Roghan Sukoon Oil 500ml','Roghan Sukoon Oil 500ml','30049099','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(36,'234',NULL,NULL,'151',NULL,'','G.Rogan Dimage 100ml','G.Rogan Dimage 100ml','30039011','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(37,'234',NULL,NULL,'152',NULL,'','G. Roghan Dimage 200ml','G. Roghan Dimage 200ml','30039011','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(38,'234',NULL,NULL,'153',NULL,'','G. Roghan Dimage 400ml','G. Roghan Dimage 400ml','30039011','400','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(39,'234',NULL,NULL,'39',NULL,'','Yogiraj Gouth Oil 120ml','Yogiraj Gouth Oil 120ml','3004','120','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(40,'234',NULL,NULL,'40',NULL,'','Yogiraj Gouth Oil 60ml','Yogiraj Gouth Oil 60ml','3004','60','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(41,'234',NULL,NULL,'41',NULL,'','Yogiraj Bawasir Vati','Yogiraj Bawasir Vati','3004','50','2',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(42,'234',NULL,NULL,'69',NULL,'','Kalonji (Black Seed) Oil -50 ml','Kalonji (Black Seed) Oil -50 ml','15159099','50','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(43,'234',NULL,NULL,'601',NULL,'','Noorani Tel - 210ml','Noorani Tel - 210ml','30039011','210','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(44,'234',NULL,NULL,'602',NULL,'','Noorani Tel - 30ml','Noorani Tel - 30ml','30039011','30','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(45,'234',NULL,NULL,'603',NULL,'','Noorani Tel - 500ml','Noorani Tel - 500ml','30039011','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(46,'234',NULL,NULL,'700',NULL,'','Kalonji (BLACK SEED OIL) 200 ML','Kalonji (BLACK SEED OIL) 200 ML','15159099','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(47,'234',NULL,NULL,'800',NULL,'','Sukoon Pain Balm 20 GM','Sukoon Pain Balm 20 GM','30049012','20','2',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(48,'234',NULL,NULL,'801',NULL,'','Sukoon Pain Balm 40 GM','Sukoon Pain Balm 40 GM','30049012','40','2',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(49,'234',NULL,NULL,'802',NULL,'','Sukoon Pain Balm 100 GM','Sukoon Pain Balm 100 GM','30049012','100','2',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(50,'234',NULL,NULL,'900',NULL,'','Dhanwantri Lucorenil Syrup (200 ML)','Dhanwantri Lucorenil Syrup (200 ML)','3004','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(51,'234',NULL,NULL,'902',NULL,'','Dhanwantri Paras Malham 30 GM','Dhanwantri Paras Malham 30 GM','3004','30','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(52,'234',NULL,NULL,'42',NULL,'','Yogiraj Gouth Oil -30 ML','Yogiraj Gouth Oil -30 ML','300490','30','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(53,'234',NULL,NULL,'1002',NULL,'','Sukoon Massage Oil -500 ML','Sukoon Massage Oil -500 ML','30049012','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(54,'234',NULL,NULL,'1101',NULL,'','Aseer Hair Gain Tonic - 50ml','Aseer Hair Gain Tonic - 50ml','30049012','50','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(55,'234',NULL,NULL,'1102',NULL,'','Sukoon Herbal Hair Tonic-100 Ml','Sukoon Herbal Hair Tonic-100 Ml','30049012','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(56,'234',NULL,NULL,'161',NULL,'','Nageena Sukoon-50 ML','Nageena Sukoon-50 ML','30039011','50','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(57,'234',NULL,NULL,'162',NULL,'','Nageena Sukoon-100 ML','Nageena Sukoon-100 ML','30039011','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(58,'234',NULL,NULL,'163',NULL,'','Nageena Sukoon-200 ML','Nageena Sukoon-200 ML','30039011','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(59,'234',NULL,NULL,'164',NULL,'','Nageena Sukoon-500 ML','Nageena Sukoon-500 ML','30039011','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(60,'234',NULL,NULL,'860',NULL,'','Kesuda Almond Hair Oil-50 ML','Kesuda Almond Hair Oil-50 ML','3305','50','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(61,'234',NULL,NULL,'861',NULL,'','Kesuda Almond Hair Oil-100 ML','Kesuda Almond Hair Oil-100 ML','3305','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(62,'234',NULL,NULL,'862',NULL,'','Kesuda Almond Hair Oil-200 ML','Kesuda Almond Hair Oil-200 ML','3305','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(63,'234',NULL,NULL,'863',NULL,'','Kesuda Almond Hair Oil-300 ML','Kesuda Almond Hair Oil-300 ML','3305','300','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(64,'234',NULL,NULL,'864',NULL,'','Kesuda Almond Hair Oil-500 ML','Kesuda Almond Hair Oil-500 ML','3305','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(65,'234',NULL,NULL,'1000',NULL,'','KOLAD BASS OIL-50ML','KOLAD BASS OIL-50ML','8003','50','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(66,'234',NULL,NULL,'1001',NULL,'','KOLAD BASS OIL-100ML','KOLAD BASS OIL-100ML','8003','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(67,'234',NULL,NULL,'402',NULL,'','Bholanath Dadona Ointment 15GM','Bholanath Dadona Ointment 15GM','300490','15','2',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(68,'234',NULL,NULL,'46',NULL,'','Yogiraj Gouth Churan Pouch','Yogiraj Gouth Churan Pouch','300490','0','3',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(69,'234',NULL,NULL,'5452',NULL,'','Icco Noorani Tel -60ML','Icco Noorani Tel -60ML','30039011','60','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(70,'234',NULL,NULL,'70',NULL,'','Zoyo Alovera Shampoo-400 ML','Zoyo Alovera Shampoo-400 ML','33051090','400','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(71,'234',NULL,NULL,'71',NULL,'','Zoyo Alovera Shampoo-800 ML','Zoyo Alovera Shampoo-800 ML','33051090','800','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(72,'234',NULL,NULL,'72',NULL,'','Zoyo Papaya Soap-115  GM','Zoyo Papaya Soap-115  GM','34011110','115','2',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(73,'234',NULL,NULL,'73',NULL,'','Dhanwantri Divy Oil-200 ML','Dhanwantri Divy Oil-200 ML','3004','200','5',NULL,'1','OTHERS','1','1','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(74,'234',NULL,NULL,'74',NULL,'','Dhanwantri Divy Oil-100 ML','Dhanwantri Divy Oil-100 ML','3004','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(75,'234',NULL,NULL,'75',NULL,'','Dhanwantri Divy Oil-60 ML','Dhanwantri Divy Oil-60 ML','3004','60','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(76,'234',NULL,NULL,'76',NULL,'','Zoyo Onion Shampoo-200ML','Zoyo Onion Shampoo-200ML','33051090','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(77,'234',NULL,NULL,'77',NULL,'','Zoyo Onion Hair Oil-100 ML','Zoyo Onion Hair Oil-100 ML','33059019','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(78,'234',NULL,NULL,'201',NULL,'','Jaborandi Hair Oil 100ML','Jaborandi Hair Oil 100ML','30049011','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(79,'234',NULL,NULL,'202',NULL,'','Jaborandi Hair Oil 200ML','Jaborandi Hair Oil 200ML','30049011','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(80,'234',NULL,NULL,'203',NULL,'','Jaborandi Hair Oil 500ML','Jaborandi Hair Oil 500ML','30049011','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(81,'234',NULL,NULL,'039',NULL,'','YOGIRAJ HIMKOOL THANDA OIL 100 ML','YOGIRAJ HIMKOOL THANDA OIL 100 ML','300490','100','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(82,'234',NULL,NULL,'040',NULL,'','YOGIRAJ HIMKOOL THANDA OIL 200 ML','YOGIRAJ HIMKOOL THANDA OIL 200 ML','300490','200','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(83,'234',NULL,NULL,'041',NULL,'','YOGIRAJ HIMKOOL THANDA OIL 500 ML','YOGIRAJ HIMKOOL THANDA OIL 500 ML','300490','500','5',NULL,'1','OTHERS','7','7','1',NULL,NULL,'2','2','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'7','0','0','0','1','0','0','0','OTHERS',NULL,NULL,NULL,NULL,'NO',NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(84,'234',NULL,NULL,'600','','',NULL,'Noorani Tel -110ml','30039011','110','5','0','1','','7','7','1',NULL,NULL,'2','2',NULL,'0',NULL,'1','1','',NULL,NULL,NULL,'7','0','','','','','','0','',NULL,NULL,'','Goods','',NULL,'362','362',NULL,0,'2026-05-04 10:07:05','2026-05-04 10:07:05');
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'234',NULL,NULL,'OTHERS','1',NULL,NULL,NULL,NULL,NULL,'362','362',NULL,0,'2026-04-28 06:12:12','2026-04-28 06:12:12');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'234',NULL,NULL,'1','1777356732864','','2001-01-01','081','0','0','0','80','0','0','71.43','0','-71.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(2,'234',NULL,NULL,'2','1777356732868','','2001-01-01','082','0','0','0','145','0','0','129.46','0','-129.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(3,'234',NULL,NULL,'3','1777356732871','','2001-01-01','084','0','0','0','600','0','0','535.71','0','-535.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(4,'234',NULL,NULL,'4','1777356732873','','2001-01-01','103','0','0','0','595','0','0','531.25','0','-531.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(5,'234',NULL,NULL,'5','1777356732875','','2001-01-01','121','0','0','0','99','0','0','56.57','0','-56.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(6,'234',NULL,NULL,'6','1777356732877','','2001-01-01','122','0','0','0','175','0','0','100','0','-100.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(7,'234',NULL,NULL,'7','1777356732879','','2001-01-01','123','0','0','0','250','0','0','142.86','0','-142.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(8,'234',NULL,NULL,'8','1777356732881','','2001-01-01','124','0','0','0','385','0','0','220','0','-220.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(9,'234',NULL,NULL,'9','1777356732883','','2001-01-01','001','0','0','0','85','0','0','44.19','0','-44.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(10,'234',NULL,NULL,'10','1777356732884','','2001-01-01','002','0','0','0','150','0','0','77.33','0','-77.33','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(11,'234',NULL,NULL,'11','1777356732886','','2001-01-01','003','0','0','0','325','0','0','168.48','0','-168.48','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(12,'234',NULL,NULL,'12','1777356732888','','2001-01-01','011','0','0','0','80','0','0','23','0','-23.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(13,'234',NULL,NULL,'13','1777356732890','','2001-01-01','012','0','0','0','136','0','0','39.15','0','-39.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:12',NULL),(14,'234',NULL,NULL,'14','1777356732892','','2001-01-01','013','0','0','0','244','0','0','70.2','0','-70.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(15,'234',NULL,NULL,'15','1777356732894','','2001-01-01','014','0','0','0','572','0','0','159.3','0','-159.30','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(16,'234',NULL,NULL,'16','1777356732895','','2001-01-01','015','0','0','0','300','0','0','110','0','-110.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(17,'234',NULL,NULL,'17','1777356732897','','2001-01-01','016','0','0','0','80','0','0','26','0','-26.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(18,'234',NULL,NULL,'18','1777356732899','','2001-01-01','017','0','0','0','136','0','0','46','0','-46.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(19,'234',NULL,NULL,'19','1777356732901','','2001-01-01','018','0','0','0','244','0','0','80','0','-80.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(20,'234',NULL,NULL,'20','1777356732903','','2001-01-01','031','0','0','0','272','0','0','77.68','0','-77.68','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(21,'234',NULL,NULL,'21','1777356732905','','2001-01-01','032','0','0','0','93','0','0','35.71','0','-35.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(22,'234',NULL,NULL,'22','1777356732906','','2001-01-01','033','0','0','0','272','0','0','84.82','0','-84.82','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(23,'234',NULL,NULL,'23','1777356732908','','2001-01-01','034','0','0','0','197','0','0','66.96','0','-66.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(24,'234',NULL,NULL,'24','1777356732910','','2001-01-01','035','0','0','0','131','0','0','50','0','-50.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(25,'234',NULL,NULL,'25','1777356732912','','2001-01-01','036','0','0','0','150','0','0','71.43','0','-71.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(26,'234',NULL,NULL,'26','1777356732913','','2001-01-01','037','0','0','0','103','0','0','49.11','0','-49.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(27,'234',NULL,NULL,'27','1777356732915','','2001-01-01','038','0','0','0','1313','0','0','625','0','-625.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(28,'234',NULL,NULL,'28','1777356732917','','2001-01-01','061','0','0','0','120','0','0','50.85','0','-50.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(29,'234',NULL,NULL,'29','1777356732919','','2001-01-01','083','0','0','0','260','0','0','232.15','0','-232.15','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(30,'234',NULL,NULL,'30','1777356732921','','2001-01-01','101','0','0','0','155','0','0','138.39','0','-138.39','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(31,'234',NULL,NULL,'31','1777356732923','','2001-01-01','102','0','0','0','285','0','0','254.46','0','-254.46','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(32,'234',NULL,NULL,'32','1777356732925','','2001-01-01','141','0','0','0','80','0','0','25','0','-25.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(33,'234',NULL,NULL,'33','1777356732926','','2001-01-01','142','0','0','0','145','0','0','45.31','0','-45.31','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(34,'234',NULL,NULL,'34','1777356732928','','2001-01-01','143','0','0','0','260','0','0','81.25','0','-81.25','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(35,'234',NULL,NULL,'35','1777356732930','','2001-01-01','144','0','0','0','610','0','0','187.5','0','-187.50','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(36,'234',NULL,NULL,'36','1777356732932','','2001-01-01','151','0','0','0','85','0','0','41.74','0','-41.74','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(37,'234',NULL,NULL,'37','1777356732934','','2001-01-01','152','0','0','0','155','0','0','76.12','0','-76.12','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(38,'234',NULL,NULL,'38','1777356732935','','2001-01-01','153','0','0','0','285','0','0','139.96','0','-139.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(39,'234',NULL,NULL,'39','1777356732937','','2001-01-01','39','0','0','0','263','0','0','100.4','0','-100.40','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(40,'234',NULL,NULL,'40','1777356732939','','2001-01-01','40','0','0','0','141','0','0','53.57','0','-53.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(41,'234',NULL,NULL,'41','1777356732941','','2001-01-01','41','0','0','0','150','0','0','57.14','0','-57.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(42,'234',NULL,NULL,'42','1777356732943','','2001-01-01','69','0','0','0','175','0','0','65','0','-65.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(43,'234',NULL,NULL,'43','1777356732944','','2001-01-01','601','0','0','-450','285','0','124.85','109.42','0','-109.42','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(44,'234',NULL,NULL,'44','1777356732946','','2001-01-01','602','0','0','0','55','0','0','21.21','0','-21.21','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(45,'234',NULL,NULL,'45','1777356732948','','2001-01-01','603','0','0','0','595','0','0','229.02','0','-229.02','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(46,'234',NULL,NULL,'46','1777356732949','','2001-01-01','700','0','0','0','580','0','0','215','0','-215.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(47,'234',NULL,NULL,'47','1777356732951','','2001-01-01','800','0','0','0','0','0','0','18','0','-18.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(48,'234',NULL,NULL,'48','1777356732953','','2001-01-01','801','0','0','0','0','0','0','29','0','-29.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(49,'234',NULL,NULL,'49','1777356732954','','2001-01-01','802','0','0','0','0','0','0','58','0','-58.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(50,'234',NULL,NULL,'50','1777356732956','','2001-01-01','900','0','0','0','169','0','0','72','0','-72.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(51,'234',NULL,NULL,'51','1777356732958','','2001-01-01','902','0','0','0','122','0','0','52','0','-52.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(52,'234',NULL,NULL,'52','1777356732960','','2001-01-01','42','0','0','0','84','0','0','32.14','0','-32.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(53,'234',NULL,NULL,'53','1777356732962','','2001-01-01','1002','0','0','-56','572','0','205.52','189','0','-189.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(54,'234',NULL,NULL,'54','1777356732964','','2001-01-01','1101','0','0','0','250','0','0','100','0','-100.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(55,'234',NULL,NULL,'55','1777356732965','','2001-01-01','1102','0','0','0','140','0','0','56','0','-56.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(56,'234',NULL,NULL,'56','1777356732967','','2001-01-01','161','0','0','0','80','0','0','38.1','0','-38.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(57,'234',NULL,NULL,'57','1777356732969','','2001-01-01','162','0','0','0','145','0','0','69.05','0','-69.05','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(58,'234',NULL,NULL,'58','1777356732970','','2001-01-01','163','0','0','0','260','0','0','123.81','0','-123.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(59,'234',NULL,NULL,'59','1777356732972','','2001-01-01','164','0','0','0','605','0','0','288.1','0','-288.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(60,'234',NULL,NULL,'60','1777356732974','','2001-01-01','860','0','0','0','36','0','0','10.8','0','-10.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(61,'234',NULL,NULL,'61','1777356732976','','2001-01-01','861','0','0','0','71','0','0','21.26','0','-21.26','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(62,'234',NULL,NULL,'62','1777356732978','','2001-01-01','862','0','0','0','142','0','0','42.11','0','-42.11','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(63,'234',NULL,NULL,'63','1777356732979','','2001-01-01','863','0','0','0','178','0','0','51.06','0','-51.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(64,'234',NULL,NULL,'64','1777356732981','','2001-01-01','864','0','0','0','267','0','0','75.85','0','-75.85','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(65,'234',NULL,NULL,'65','1777356732983','','2001-01-01','1000','0','0','0','150','0','0','22','0','-22.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(66,'234',NULL,NULL,'66','1777356732984','','2001-01-01','1001','0','0','0','245','0','0','44','0','-44.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(67,'234',NULL,NULL,'67','1777356732986','','2001-01-01','402','0','0','0','65','0','0','28.96','0','-28.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(68,'234',NULL,NULL,'68','1777356732988','','2001-01-01','46','0','0','0','154','0','0','146.67','0','-146.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(69,'234',NULL,NULL,'69','1777356732990','','2001-01-01','5452','0','0','0','89.06','0','0','89.06','0','-89.06','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(70,'234',NULL,NULL,'43','1777356732991','','2001-01-01','601','0','0','0','267.19','0','0','267.19','0','-267.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(71,'234',NULL,NULL,'45','1777356732993','','2001-01-01','603','0','0','-144','558','0','244.45','557.81','0','-557.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(72,'234',NULL,NULL,'70','1777356732995','','2001-01-01','70','0','0','0','170','0','0','42','0','-42.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(73,'234',NULL,NULL,'71','1777356732996','','2001-01-01','71','0','0','0','270','0','0','76','0','-76.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(74,'234',NULL,NULL,'72','1777356732998','','2001-01-01','72','0','0','0','110','0','0','23.81','0','-23.81','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(75,'234',NULL,NULL,'73','1777356732999','','2001-01-01','73','0','0','0','395','0','0','376.19','0','-376.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(76,'234',NULL,NULL,'74','1777356733001','','2001-01-01','74','0','0','0','205','0','0','195.24','0','-195.24','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(77,'234',NULL,NULL,'75','1777356733003','','2001-01-01','75','0','0','0','135','0','0','128.57','0','-128.57','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(78,'234',NULL,NULL,'76','1777356733004','','2001-01-01','76','0','0','0','0','0','0','52.38','0','-52.38','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(79,'234',NULL,NULL,'77','1777356733006','','2001-01-01','77','0','0','0','0','0','0','57.14','0','-57.14','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(80,'234',NULL,NULL,'69','1777356733008','','2001-01-01','5452','0','0','-270','95','0','41.61','35','0','-35.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(81,'234',NULL,NULL,'44','1777356733010','','2001-01-01','602','0','0','0','51','0','0','21','0','-21.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(82,'234',NULL,NULL,'78','1777356733011','','2001-01-01','201','0','0','0','180','0','0','180','0','-180.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(83,'234',NULL,NULL,'79','1777356733013','','2001-01-01','202','0','0','0','272','0','0','272','0','-272.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(84,'234',NULL,NULL,'80','1777356733015','','2001-01-01','203','0','0','0','475','0','0','475','0','-475.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(85,'234',NULL,NULL,'57','1777356733017','','2001-01-01','162','0','0','0','136','0','0','64.76','0','-64.76','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(86,'234',NULL,NULL,'58','1777356733019','','2001-01-01','163','0','0','0','244','0','0','116.19','0','-116.19','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(87,'234',NULL,NULL,'59','1777356733021','','2001-01-01','164','0','0','0','568','0','0','270.47','0','-270.47','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(88,'234',NULL,NULL,'80','1777356733022','','2001-01-01','203','0','0','0','445','0','0','445','0','-445.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(89,'234',NULL,NULL,'28','1777356733024','','2001-01-01','061','0','0','0','120','0','0','58.1','0','-58.10','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(90,'234',NULL,NULL,'71','1777356733026','','2001-01-01','71','0','0','0','270','0','0','66.67','0','-66.67','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(91,'234',NULL,NULL,'72','1777356733028','','2001-01-01','72','0','0','0','110','0','0','22.86','0','-22.86','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(92,'234',NULL,NULL,'39','1777356733029','','2001-01-01','39','0','0','0','260','0','0','100','0','-100.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(93,'234',NULL,NULL,'78','1777356733031','','2001-01-01','201','0','0','0','169','0','0','169','0','-169.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(94,'234',NULL,NULL,'12','1777356733033','','2001-01-01','011','0','0','0','85','0','0','23','0','-23.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(95,'234',NULL,NULL,'47','1777356733035','','2001-01-01','800','0','0','0','57','0','0','20','0','-20.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(96,'234',NULL,NULL,'48','1777356733037','','2001-01-01','801','0','0','0','87','0','0','30','0','-30.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(97,'234',NULL,NULL,'49','1777356733039','','2001-01-01','802','0','0','0','177','0','0','62','0','-62.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(98,'234',NULL,NULL,'22','1777356733040','','2001-01-01','033','0','0','0','270','0','0','85.71','0','-85.71','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(99,'234',NULL,NULL,'81','1777356733042','','2001-01-01','039','0','0','-288','99','0','47.14','42.43','0','-42.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(100,'234',NULL,NULL,'82','1777356733043','','2001-01-01','040','0','0','-288','199','0','94.76','85.29','0','-85.29','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(101,'234',NULL,NULL,'83','1777356733045','','2001-01-01','041','0','0','-180','400','0','190.47','171.43','0','-171.43','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(102,'234',NULL,NULL,'12','1777356733047','','2001-01-01','011','0','0','0','85','0','0','23.8','0','-23.80','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(103,'234',NULL,NULL,'23','1777356733049','','2001-01-01','034','0','0','0','195','0','0','66.96','0','-66.96','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(104,'234',NULL,NULL,'12','1777356733051','','2001-01-01','011','0','0','0','90','0','0','25.2','0','-25.20','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(105,'234',NULL,NULL,'13','1777356733052','','2001-01-01','012','0','0','0','150','0','0','42','0','-42.00','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(106,'234',NULL,NULL,'15','1777356733054','','2001-01-01','014','0','0','-392','620','0','177.14','173.6','0','-173.60','0',NULL,NULL,NULL,NULL,NULL,'0','0',NULL,0,'2026-04-28 06:12:13',NULL),(107,'234',NULL,NULL,'13','60761533','','','012','0','0','-720','150','42.85','42.85','150','0','-107.15','0',NULL,NULL,NULL,NULL,NULL,'362','0',NULL,0,'2026-05-02 09:14:23',NULL),(108,'234',NULL,NULL,'14','27192076','','','','0','0','-1800','260','74.28','76.76','260','0','-185.72','0',NULL,NULL,NULL,NULL,NULL,'362','0',NULL,0,'2026-05-02 09:15:02',NULL),(109,'234',NULL,NULL,'84','89271818','2026-05-04','2026-05-04','600','0','0','-180','155','0','67.90','59','0','0','0',NULL,NULL,NULL,NULL,NULL,'undefined','0',NULL,0,'2026-05-04 10:07:52',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int DEFAULT '0',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int DEFAULT '0',
  `M_ROUND_OFF` int DEFAULT '0',
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text,
  `INV_NO` text,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `PROD_ID` int NOT NULL,
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PACK` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BOX` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN_QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `FREE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `CESS_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `WEIGHT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PRICE_PER` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SALE_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DMG_MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CLOUD_SYNC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `INV_ARR` text COLLATE utf8mb4_general_ci,
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_BY` int DEFAULT NULL,
  `UPDATED_BY` int DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_TS` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SUPPLIER_ID` int DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8mb4_general_ci,
  `GROUP_ID` int DEFAULT NULL,
  `FINAL_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BATCH_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TCS_TAX` varchar(100) COLLATE utf8mb4_general_ci DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `BROKER_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REGISTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=363 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (362,'234','0','emxlTU0qdP','MahakalEnt','emxlTU0qdP','santoshy@yopmail.com',NULL,'FR3Fv8287yPw','Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','','362','1','',0,'2026-04-28 05:59:59','2026-05-02 09:22:27');
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REMARKS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int DEFAULT '0',
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-04-28 05:59:54',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text,
  `MAC_ID` int DEFAULT '0',
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text,
  `S_ADD2` text,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'234',NULL,NULL,'Cash',14,'19373179.61','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'-3226070',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(2,'234',NULL,NULL,'Additional Tax(GST)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(3,'234',NULL,NULL,'Advertisement & Publicity',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(4,'234',NULL,NULL,'Bad Debts Written Off',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(5,'234',NULL,NULL,'Bank Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(6,'234',NULL,NULL,'Bonus',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(7,'234',NULL,NULL,'Books & Periodicals',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(8,'234',NULL,NULL,'Brokerage',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(9,'234',NULL,NULL,'C Form Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(10,'234',NULL,NULL,'C Form Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(11,'234',NULL,NULL,'Capital Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(12,'234',NULL,NULL,'Central Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(13,'234',NULL,NULL,'CGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(14,'234',NULL,NULL,'Charity & Donations',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(15,'234',NULL,NULL,'Commissions on Sales',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(16,'234',NULL,NULL,'Computers',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(17,'234',NULL,NULL,'Conveyance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(18,'234',NULL,NULL,'CST Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(19,'234',NULL,NULL,'Development Taxes',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(20,'234',NULL,NULL,'Edu. Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(21,'234',NULL,NULL,'Edu. Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(22,'234',NULL,NULL,'Edu. Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(23,'234',NULL,NULL,'Edu. Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(24,'234',NULL,NULL,'Excise Duties',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(25,'234',NULL,NULL,'IGST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(26,'234',NULL,NULL,'SGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(27,'234',NULL,NULL,'Legal Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(28,'234',NULL,NULL,'Market Fees',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(29,'234',NULL,NULL,'National VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(30,'234',NULL,NULL,'RDF',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(31,'234',NULL,NULL,'Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(32,'234',NULL,NULL,'SHE Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(33,'234',NULL,NULL,'SHE Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(34,'234',NULL,NULL,'SHE Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(35,'234',NULL,NULL,'SHE Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(36,'234',NULL,NULL,'Surcharge On VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(37,'234',NULL,NULL,'TDS (Advertisment)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(38,'234',NULL,NULL,'TDS (Commission)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(39,'234',NULL,NULL,'TDS (Contractor)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(40,'234',NULL,NULL,'TDS (Interest)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(41,'234',NULL,NULL,'TDS (Rent)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(42,'234',NULL,NULL,'TDS (Salery)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(43,'234',NULL,NULL,'VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(44,'234',NULL,NULL,'Telephone Expenses',19,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(45,'234',NULL,NULL,'Customer Entertainment Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(46,'234',NULL,NULL,'Depriciation A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(47,'234',NULL,NULL,'Discount',20,'77329.8','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(48,'234',NULL,NULL,'Freight & Forwarding Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(49,'234',NULL,NULL,'Interest Payable A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(50,'234',NULL,NULL,'Job Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(51,'234',NULL,NULL,'Labour',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(52,'234',NULL,NULL,'Legal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(53,'234',NULL,NULL,'Misc. Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(54,'234',NULL,NULL,'Miscellaneous Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'54',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(55,'234',NULL,NULL,'Office Maintenance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(56,'234',NULL,NULL,'Office Rent',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'56',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-12000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(57,'234',NULL,NULL,'Office Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'57',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(58,'234',NULL,NULL,'Postal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'58',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(59,'234',NULL,NULL,'Printing & Stationery',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'59',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(60,'234',NULL,NULL,'Rounded Off - Sales',20,'0','CR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'60',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(61,'234',NULL,NULL,'Salery',20,'20000','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'61',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-34000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(62,'234',NULL,NULL,'Sales Promotion Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'62',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(63,'234',NULL,NULL,'Sewing Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'63',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(64,'234',NULL,NULL,'Staff Welfare Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'64',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(65,'234',NULL,NULL,'Stitching',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'65',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(66,'234',NULL,NULL,'Travelling Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'66',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(67,'234',NULL,NULL,'Water & Electricity Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'67',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(68,'234',NULL,NULL,'Earnest Money',29,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'68',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(69,'234',NULL,NULL,'Furnituer & Fixture',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'69',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(70,'234',NULL,NULL,'Office Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'70',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(71,'234',NULL,NULL,'Plants & Machinery',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'71',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(72,'234',NULL,NULL,'CST Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'72',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(73,'234',NULL,NULL,'Interstate Retail Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'73',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(74,'234',NULL,NULL,'Local B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'74',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(75,'234',NULL,NULL,'Sales',27,'58302987.77','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'75',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(76,'234',NULL,NULL,'Sales Retail 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'76',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(77,'234',NULL,NULL,'Sales Retail 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'77',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(78,'234',NULL,NULL,'Sales VAT 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'78',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(79,'234',NULL,NULL,'Sales VAT 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'79',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(80,'234',NULL,NULL,'Dammi',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'80',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(81,'234',NULL,NULL,'Income From National VAT',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'81',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(82,'234',NULL,NULL,'Interest Receivable A/c',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'82',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(83,'234',NULL,NULL,'Rate Adjustment',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'83',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(84,'234',NULL,NULL,'Mall Khata A/c',30,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'84',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(85,'234',NULL,NULL,'Profit & Loss',9,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'85',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(86,'234',NULL,NULL,'Purchase',25,'53645913.6','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'86',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(87,'234',NULL,NULL,'Purchase Retail 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'87',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(88,'234',NULL,NULL,'Purchase Retail 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'88',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(89,'234',NULL,NULL,'Purchase VAT 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'89',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(90,'234',NULL,NULL,'Purchase VAT 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'90',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(91,'234',NULL,NULL,'Replacement',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'91',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(92,'234',NULL,NULL,'Stock',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'92',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(93,'234',NULL,NULL,'Salery & Bonus Payable',24,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'93',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(94,'234',NULL,NULL,'Interstate B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'94',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(95,'234',NULL,NULL,'CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'95',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(96,'234',NULL,NULL,'Additional CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'96',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(97,'234',NULL,NULL,'SCHEME-1',20,'35711.8406','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'97',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(98,'234',NULL,NULL,'SCHEME-2',20,'1324.16','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'98',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-04-28 05:59:56','2026-04-28 05:59:56'),(99,'234',NULL,NULL,'Sonam Enterprises',5,'0','DR','Goyal Residency-B','Kasarwadi Pune-411034','Pune','21','411034',NULL,'9975197133','',NULL,'27','27AJHPM1599A1Z7','','',NULL,NULL,'','15',NULL,NULL,NULL,NULL,'99',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','185',NULL,'0','0',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(100,'234',NULL,NULL,'Shri Jee Agencies',5,'0','DR','7789,Ground Floor,Kaccha Pakka Quater,Shakti Nagar','','Delhi','Delhi','110007',NULL,'9899993557','',NULL,'0','07AEUPG5762P1ZL','','',NULL,NULL,'','14',NULL,NULL,NULL,NULL,'100',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','164',NULL,'0','0',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(101,'234',NULL,NULL,'Shree Ramdev Sales',5,'0','DR','S.NO-79/15/2,Kokane Nagarshivratha Colony,NR Pachpir Chowk','','Pune','21','411018',NULL,'8290623183','',NULL,'27','27AVEPC1360Q1ZG','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'101',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','166',NULL,'0','0',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(102,'234',NULL,NULL,'Shree Paramhans Ayurvedic Agencies',5,'0','DR','Z Behind Satguru Saraf Rikabganj','Faizabad-224001','Faizabad','Uttar Pradesh','224001',NULL,'5278223640','',NULL,'0','09AMSPK2693P1ZY','','',NULL,NULL,'','13',NULL,NULL,NULL,NULL,'102',NULL,NULL,NULL,NULL,NULL,'12715020000064','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','194',NULL,'0','0',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(103,'234',NULL,NULL,'Sanghavi Ayurved',5,'0','DR','shop no-5 below Rajhans hotel, Chembur station Chembur E','','Mumbai','21','400071',NULL,'9967036295','',NULL,'27','27AACHC6064Q1ZV','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'103',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','177',NULL,'0','0',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(104,'234',NULL,NULL,'Salim Liyakat Shaikh',5,'0','DR','A-305 Aman Complex 3d Flr. Dargha Rd. Amrut Ngr.','Nr. Memon Colony Khadi Mumbra Thane-400612','Thane','21','400612',NULL,'8108725121','',NULL,'27','','364170368961','',NULL,NULL,'','12',NULL,NULL,NULL,NULL,'104',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','189',NULL,'0','0',NULL,0,'2026-04-28 06:11:45','2026-04-28 06:11:45'),(105,'234',NULL,NULL,'Sai Distributors',5,'0','DR','Chitrakut Society,Opp Ma Vidya Mandir School,Singh Estate,x road,Samta Nagar,Kanivali East','','Mumbai','21','400101',NULL,'9822263668','',NULL,'27','27AAJPS5598L2ZN','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'105',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','153',NULL,'0','0',NULL,0,'2026-04-28 06:11:46','2026-04-28 06:11:46'),(106,'234',NULL,NULL,'Sahu Enterprises',5,'0','DR','Joy Jagannath Chawl Tat Nagar Near Vikas Hotel ,Govandi (w)','','Mumbai','21','400075',NULL,'9819329693','',NULL,'27','27AUPPS4193M1ZM','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'106',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','162',NULL,'0','0',NULL,0,'2026-04-28 06:11:46','2026-04-28 06:11:46'),(107,'234',NULL,NULL,'Sahadev Balinath Goswami',5,'0','DR','29/A/204 2nd Floor Ganesh Housing Society Sangharsh Nagar','Nr. Chandivali Farm Rd. Andheri (E) Mumbai-400072','Mumbai','21','400072',NULL,'8936022323','',NULL,'27','','857479100054','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'107',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','188',NULL,'0','0',NULL,0,'2026-04-28 06:11:46','2026-04-28 06:11:46'),(108,'234',NULL,NULL,'S.S Enterprises',5,'0','DR','Aminabad Uttar Pradesh','','','Uttar Pradesh','226018',NULL,'9335283675','',NULL,'0','09GPFPS2248C1ZR','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,'108',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','158',NULL,'0','0',NULL,0,'2026-04-28 06:11:46','2026-04-28 06:11:46'),(109,'234',NULL,NULL,'S.B. Traders',5,'0','DR','CK 46/46-47, Bhikha Shah Gali','Sarai Harha, Varanasi-221001','Varanasi','Uttar Pradesh','221001',NULL,'8604413442','',NULL,'0','09CQBPB0314H1ZH','','',NULL,NULL,'','11',NULL,NULL,NULL,NULL,'109',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','193',NULL,'0','0',NULL,0,'2026-04-28 06:11:46','2026-04-28 06:11:46'),(110,'234',NULL,NULL,'S K TRADERS',5,'0','DR','Pahariya  Nera BSNL','Office Varanasi-221007','Varanasi','Uttar Pradesh','221007',NULL,'7985296453','',NULL,'0','09AOLPY7716E1ZC','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,'110',NULL,NULL,NULL,NULL,NULL,'22723630000119','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','180',NULL,'0','0',NULL,0,'2026-04-28 06:11:46','2026-04-28 06:11:46'),(111,'234',NULL,NULL,'Rywin Pharma',5,'0','DR','Shop No-7,Ground Floor Sale Tower F,Ghatkopar','','Mumbai','21','400075',NULL,'9819531008','',NULL,'27','27AARFR1328P1ZI','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'111',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','151',NULL,'0','0',NULL,0,'2026-04-28 06:11:46','2026-04-28 06:11:46'),(112,'234',NULL,NULL,'Rudra Agency',5,'0','DR','Room No.2 &3 Sahakar Apt. Narayan Nagar','Nr. Modern Dairy Bhyandar (W)-401101','Bhyandar','21','401101',NULL,'9322277015','rudraagency1969@gmail.com',NULL,'27','27AEBPM1277Q3ZY','','',NULL,NULL,'','10',NULL,NULL,NULL,NULL,'112',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','195',NULL,'0','0',NULL,0,'2026-04-28 06:11:46','2026-04-28 06:11:46'),(113,'234',NULL,NULL,'Raj Agency',5,'0','DR','Plot No- 35, Dawood Nagar, Surat','','Surat','Gujarat','394210',NULL,'8401077300','',NULL,'0','24ABSPH3476Q1ZV','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,'113',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','149',NULL,'0','0',NULL,0,'2026-04-28 06:11:46','2026-04-28 06:11:46'),(114,'234',NULL,NULL,'R.D Enterprises',5,'0','DR','Ground Floor Plot No.43/A/16, Sai Baba Nagar Shivaji Nagar','Rd. No.6 Nr. Shalimar Hotel Govandi Mumbai-400043','Mumbai','21','400043',NULL,'8384005446','',NULL,'27','27ATFPD4225Q1ZG','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'114',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','197',NULL,'0','0',NULL,0,'2026-04-28 06:11:46','2026-04-28 06:11:46'),(115,'234',NULL,NULL,'Priya Enterprises',5,'0','DR','Room no 26,Hawabai Chal, near Sai Pooja Restaurant,Subhash Nagar','JMT Road, Ghatkopar West Mumbai 400084','Mumbai','21','400084',NULL,'7304766538','',NULL,'27','27AXZPA3127A1ZP','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'115',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','181',NULL,'0','0',NULL,0,'2026-04-28 06:11:47','2026-04-28 06:11:47'),(116,'234',NULL,NULL,'Phulwari Enterprises',5,'0','DR','1/25/63 Salempura Vranasi , A/26/0 Hasanpura  Varanasi','Varanasi-221001','Varanasi','Uttar Pradesh','221001',NULL,'9839140219','',NULL,'0','09ABZPH6597B1ZZ','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,'116',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','168',NULL,'0','0',NULL,0,'2026-04-28 06:11:47','2026-04-28 06:11:47'),(117,'234',NULL,NULL,'Parvez Anwar Ahmed Khan',5,'0','DR','Baiganwadi Govandi','','','21','',NULL,'9322751261','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'117',NULL,NULL,NULL,NULL,NULL,'','GZYPK9667N','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','186',NULL,'0','0',NULL,0,'2026-04-28 06:11:47','2026-04-28 06:11:47'),(118,'234',NULL,NULL,'Panna Sales Agency',5,'0','DR','126, Suramya Society,Rajpipla rd,Ankaleshwar','','Ankaleashwar','Gujarat','393002',NULL,'9879558470','',NULL,'0','24AEKPJ1074R1Z3','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,'118',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','170',NULL,'0','0',NULL,0,'2026-04-28 06:11:47','2026-04-28 06:11:47'),(119,'234',NULL,NULL,'NSD Enterprise',5,'0','DR','BLDG NO-A-5 Gala-1 and2 Bhumi World Industrial Park Pimplas Bhiwandi','','Mumbai','21','421302',NULL,'9987830150','',NULL,'27','27AASFN5584G1ZM','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'119',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','157',NULL,'0','0',NULL,0,'2026-04-28 06:11:47','2026-04-28 06:11:47'),(120,'234',NULL,NULL,'Milin Trading Co.',5,'0','DR','Pritesh Complex, Building  No. B-2, Gala No.105 Val Village, Dapode Road, Bhiwandi, Maharashtra','','','21','421302',NULL,'8591275060','',NULL,'27','27AABPJ0995L1ZE','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'120',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','148',NULL,'0','0',NULL,0,'2026-04-28 06:11:47','2026-04-28 06:11:47'),(121,'234',NULL,NULL,'Mahavir Enterprises',5,'0','DR','441 Omkar Darshan Bldg. Sector-22 Near Jain Temple','Turbhe Village Navi Mumbai-400705','Navi Mumbai','21','400705',NULL,'9322222428','',NULL,'27','27AJUPJ0221D1ZI','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'121',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','196',NULL,'0','0',NULL,0,'2026-04-28 06:11:47','2026-04-28 06:11:47'),(122,'234',NULL,NULL,'Mahavir Agency',5,'0','DR','115/916,Rising CHS,Motilal Nagar No.1 Opp Trikoni Maidan, Goregoan West ,Mumbai','','','21','400104',NULL,'9821047611','',NULL,'27','27AABPJ9899D1ZA','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'122',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','154',NULL,'0','0',NULL,0,'2026-04-28 06:11:47','2026-04-28 06:11:47'),(123,'234',NULL,NULL,'M/S. Krishna Aurved Bhandar',5,'0','DR','shop no-3 Anand Bhavan, Jungle Mangal road Mumbai Bhandup w','','Mumbai','21','400078',NULL,'9920998620','',NULL,'27','27AAQPA2987C2ZM','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'123',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','176',NULL,'0','0',NULL,0,'2026-04-28 06:11:47','2026-04-28 06:11:47'),(124,'234',NULL,NULL,'M/S Ramesh Aushadhalaya',5,'0','DR','Maa Kali Mandir Road Ramkola  Kushinagar','','Kushinagar','Uttar Pradesh','274305',NULL,'9918999561','',NULL,'0','09AGFPS6695A1Z1','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,'124',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','179',NULL,'0','0',NULL,0,'2026-04-28 06:11:47','2026-04-28 06:11:47'),(125,'234',NULL,NULL,'Jitu Trade Link',5,'0','DR','Gala No-16/A,1st Floor,Khetani Indrustrials Premises CO-OP Society Kurla West','','Mumbai','21','400010',NULL,'9920959331','',NULL,'27','27AAQFJ0119F1ZH','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'125',NULL,NULL,NULL,NULL,NULL,'11520010000202','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','146',NULL,'0','0',NULL,0,'2026-04-28 06:11:48','2026-04-28 06:11:48'),(126,'234',NULL,NULL,'Jai Ram Enterprises',5,'0','DR','194, Ground Floor Sangam Nagar Salt Pan Road','Wadala (E) Mumbai-400037','Mumbai','21','400037',NULL,'8652017456','',NULL,'27','27DGXPK2947A1Z3','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'126',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','202',NULL,'0','0',NULL,0,'2026-04-28 06:11:48','2026-04-28 06:11:48'),(127,'234',NULL,NULL,'J.M Enterprises',5,'0','DR','1489, Bandu Jadhav Bldg. Gala No.20','Bhandri Rd. Narpoli Bhiwandi Thane-421302','Bhiwandi','21','421302',NULL,'9353897958','',NULL,'27','27APKPM7666P1ZT','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,'127',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','203',NULL,'0','0',NULL,0,'2026-04-28 06:11:48','2026-04-28 06:11:48'),(128,'234',NULL,NULL,'Hemant Agencies',5,'0','DR','Sector No.8 Charkop','Kandivali (W) Mumbai-400067','Mumbai','21','400067',NULL,'8209163385','',NULL,'27','27AHQPC6972Q1ZD','','',NULL,NULL,'','9',NULL,NULL,NULL,NULL,'128',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','191',NULL,'0','0',NULL,0,'2026-04-28 06:11:48','2026-04-28 06:11:48'),(129,'234',NULL,NULL,'Gupta Enterprises',5,'0','DR','Shree Mangal Krupa Bldg. Gala No.2 Shivaji Nagar','Kurar Village Malad (E) Mumbai-400097','Mumbai','21','400097',NULL,'8286731591','',NULL,'27','27AUJPG3952G1ZK','','',NULL,NULL,'','8',NULL,NULL,NULL,NULL,'129',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','192',NULL,'0','0',NULL,0,'2026-04-28 06:11:48','2026-04-28 06:11:48'),(130,'234',NULL,NULL,'Gunjan Stores',5,'0','DR','GROUND FLOOR, G-16, NEW ANANT BHAVAN','NARSHI NATHA STREET, MASJID BUNDER,-400009','Mumbai','21','400009',NULL,'8652030504','',NULL,'27','27AAHPM2742E1ZV','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'130',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','198',NULL,'0','0',NULL,0,'2026-04-28 06:11:48','2026-04-28 06:11:48'),(131,'234',NULL,NULL,'Falahi Traders',5,'0','DR','R1, Games Chawl, V.B.Nagar, Pipe Road, Kurla(west) Mumbai-400070','','Mumbai','21','400070',NULL,'9082268448','falahitraders2019@gmail.com',NULL,'27','27BKUPK8048M1Z6','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'131',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','156',NULL,'0','0',NULL,0,'2026-04-28 06:11:48','2026-04-28 06:11:48'),(132,'234',NULL,NULL,'Dr. KM.Health Care',5,'0','DR','Moti Nagar,1st Floor,Sant Kabir Nagar,Khalilabad,U.P','','','Uttar Pradesh','272175',NULL,'7860872127','',NULL,'0','09JVJPK3768Q1ZC','','',NULL,NULL,'','7',NULL,NULL,NULL,NULL,'132',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','150',NULL,'0','0',NULL,0,'2026-04-28 06:11:48','2026-04-28 06:11:48'),(133,'234',NULL,NULL,'Divyanshu Traders',5,'0','DR','Village Jalhupur, Jalhupur Post Varanasi','Varanasi-221104','Varanasi','Uttar Pradesh','221104',NULL,'9129972074','',NULL,'0','09EHUPS1702L1ZN','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,'133',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','178',NULL,'0','0',NULL,0,'2026-04-28 06:11:48','2026-04-28 06:11:48'),(134,'234',NULL,NULL,'Dhanlaxmi Traders',5,'0','DR','Habade Shopping Center Shop No.B-12,Brahman Alley','Parnaka Bhiwandi Thane-421302','Thane','21','421302',NULL,'8830633196','',NULL,'27','27AFHPB0126L1ZR','','',NULL,NULL,'','6',NULL,NULL,NULL,NULL,'134',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','199',NULL,'0','0',NULL,0,'2026-04-28 06:11:48','2026-04-28 06:11:48'),(135,'234',NULL,NULL,'Deep Medical Store',5,'0','DR','2,3 Devka Niwas, MG Road Ghatkopar West','','Mumbai','21','400086',NULL,'9820356540','',NULL,'27','27AARFD2720P1ZY','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'135',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','175',NULL,'0','0',NULL,0,'2026-04-28 06:11:49','2026-04-28 06:11:49'),(136,'234',NULL,NULL,'Chandan Agency',5,'0','DR','H NO.GK 01/2650,Near Lagipada T/F,Vasai East,Pakghar,Mumbai-401208','','','21','401208',NULL,'9284335189','',NULL,'27','27BLFPP0496J1ZO','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'136',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','155',NULL,'0','0',NULL,0,'2026-04-28 06:11:49','2026-04-28 06:11:49'),(137,'234',NULL,NULL,'Bhavin Trading Co',5,'0','DR','Plot No.12, Bhagwati Niwas, GIDC Colony','Umbergaon Valsad Gujrat-396171','Gujrat','Gujarat','396171',NULL,'7046917709','',NULL,'0','24ACHPB9773E1ZN','','',NULL,NULL,'','5',NULL,NULL,NULL,NULL,'137',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','200',NULL,'0','0',NULL,0,'2026-04-28 06:11:49','2026-04-28 06:11:49'),(138,'234',NULL,NULL,'Asiya Unani Ayurvedic & General Store',5,'0','DR','Shop NO-6, 241C Gujariya Building, Maulana Azaad Road, Madanpura, Mumbai','','','21','400008',NULL,'9967449588','',NULL,'27','27AANFA1511B1Z3','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'138',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','159',NULL,'0','0',NULL,0,'2026-04-28 06:11:49','2026-04-28 06:11:49'),(139,'234',NULL,NULL,'Anand Trading Company',5,'0','DR','Maya Bazar Faizabad Ayodhaya','','Uttar Pradesh','Uttar Pradesh','224161',NULL,'9415719466','',NULL,'0','09AQZPK2778G1Z0','','',NULL,NULL,'','4',NULL,NULL,NULL,NULL,'139',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','160',NULL,'0','0',NULL,0,'2026-04-28 06:11:49','2026-04-28 06:11:49'),(140,'234',NULL,NULL,'Anand Enterprises',5,'0','DR','Pankil APT,Nalasopara East','','','21','401209',NULL,'9423365512','',NULL,'27','27ADAPT0588R1ZQ','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'140',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','152',NULL,'0','0',NULL,0,'2026-04-28 06:11:49','2026-04-28 06:11:49'),(141,'234',NULL,NULL,'Adinath Traders',5,'0','DR','88,PT Annaiyappa Main Rd, 2, 1st Loor, Thigalarpet CR  Bangalore 560002','','Bangalore','Karnataka','560002',NULL,'9844418046','',NULL,'0','29AAVPV1220E1ZH','','',NULL,NULL,'','3',NULL,NULL,NULL,NULL,'141',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','173',NULL,'0','0',NULL,0,'2026-04-28 06:11:49','2026-04-28 06:11:49'),(142,'234',NULL,NULL,'Abhinandan Agency',5,'0','DR','3,Bahuchar Apt-1,Saurastra Colony,Trikam Nagar-2,L.H.Road,SURAT','','Surat','Gujarat','395010',NULL,'9374034108','',NULL,'0','24ACCPD5563D1Z4','','',NULL,NULL,'','2',NULL,NULL,NULL,NULL,'142',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','147',NULL,'0','0',NULL,0,'2026-04-28 06:11:49','2026-04-28 06:11:49'),(143,'234',NULL,NULL,'Yogiraj Aryuvedic',11,'0','CR','Kanpur','','','Uttar Pradesh','',NULL,'0000000000','',NULL,'0','09ANRPS3728B2Z1','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'143',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','145',NULL,'0','0',NULL,0,'2026-04-28 06:11:49','2026-04-28 06:11:49'),(144,'234',NULL,NULL,'Sai Distributors',11,'0','CR','Chitrakut Society,opp Maa Vidya M Andir School,Singh Estate X Road No-2,Samta NagarKandivali East','','Mumbai','21','400101',NULL,'9322263668','',NULL,'27','27AAJPS5598L2ZN','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'144',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','167',NULL,'0','0',NULL,0,'2026-04-28 06:11:49','2026-04-28 06:11:49'),(145,'234',NULL,NULL,'Sahu Enterprises',11,'0','CR','Joy Jagannath Chawl,Tat Nagar','Near Vikas Hotel,Govandi West','Mumbai','21','400075',NULL,'9819329693','',NULL,'27','27AUPPS4193M1ZM','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'145',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','142',NULL,'0','0',NULL,0,'2026-04-28 06:11:50','2026-04-28 06:11:50'),(146,'234',NULL,NULL,'SA Trading CO',11,'0','CR','Office No-5 Anabhau Sathe Nagar Mankhurd Link Road','','mumbai','21','400043',NULL,'9819626140','',NULL,'27','27BARPS5076A1ZD','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'146',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','172',NULL,'0','0',NULL,0,'2026-04-28 06:11:50','2026-04-28 06:11:50'),(147,'234',NULL,NULL,'S.A. HAMEED PERFUMERS.',11,'0','CR','Govandi (E)','','','21','',NULL,'9821164792','',NULL,'27','27AAUPH0869A1ZN','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'147',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','184',NULL,'0','0',NULL,0,'2026-04-28 06:11:50','2026-04-28 06:11:50'),(148,'234',NULL,NULL,'Ribock Industries',11,'0','CR','Ranpar,jetpar Rd Morbi','','','Gujarat','363642',NULL,'9725267277','',NULL,'0','24AATFR0804Q1ZP','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'148',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','174',NULL,'0','0',NULL,0,'2026-04-28 06:11:50','2026-04-28 06:11:50'),(149,'234',NULL,NULL,'R.S.Homoeo Stores',11,'0','CR','C.K.65/136-A Badi Piyari,Varanasi','','Varanasi','Uttar Pradesh','221001',NULL,'9580447001','rudrashivay1304@gmail.com',NULL,'0','09ALGPV1931L1ZM','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'149',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','187',NULL,'0','0',NULL,0,'2026-04-28 06:11:50','2026-04-28 06:11:50'),(150,'234',NULL,NULL,'Purchase Adjustment',11,'0','CR','Mulund','','','21','',NULL,'0000000000','',NULL,'27','','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'150',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','201',NULL,'0','0',NULL,0,'2026-04-28 06:11:50','2026-04-28 06:11:50'),(151,'234',NULL,NULL,'Mahida & Sons',11,'0','CR','52,Tandel Street South,3rd Floor','R N 9, Mumbai-400009','MumbaI','21','400009',NULL,'9819030272','',NULL,'27','27AGKPM9903C1ZB','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'151',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','143',NULL,'0','0',NULL,0,'2026-04-28 06:11:50','2026-04-28 06:11:50'),(152,'234',NULL,NULL,'MILAN TRADING CO.',11,'0','CR','GALA NO 104 & 105, BUILDING NO B-2, 1ST FLOOR','PRITESH COMPLEX, VAL VILLAGE BHIWANDI, DIST.- THANE-421302','Thane','21','421302',NULL,'8591275060','milantco365@gmail.com',NULL,'27','27AABPJ0995L1ZE','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'152',NULL,NULL,NULL,NULL,NULL,'21521112000931','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','182',NULL,'0','0',NULL,0,'2026-04-28 06:11:50','2026-04-28 06:11:50'),(153,'234',NULL,NULL,'M.A TRADERS',11,'0','CR','Varansi','','','Uttar Pradesh','',NULL,'9881904865','',NULL,'0','09BGTPA2994R1ZB','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'153',NULL,NULL,NULL,NULL,NULL,'12719038000082','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','183',NULL,'0','0',NULL,0,'2026-04-28 06:11:50','2026-04-28 06:11:50'),(154,'234',NULL,NULL,'Kolad Remedies',11,'0','CR','2nd Floor,room No-B-1,Khan Manzil Hazrat Abbas Street ,Israil Mohalla','','Mumbai','21','400009',NULL,'9322266791','',NULL,'27','27AAOVP3048R1ZY','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'154',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','169',NULL,'0','0',NULL,0,'2026-04-28 06:11:50','2026-04-28 06:11:50'),(155,'234',NULL,NULL,'Jitu Trade Link',11,'0','CR','Gala No 16/A 1st Floor Khetani Industrial Premises CO-OP Society Limited','106/7-Magan Nathuram Rd Sonapur Lane Bail Bazar KURLA (w)','Mumbai','21','400070',NULL,'992059331','',NULL,'27','27AAQFJ0119F1ZH','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'155',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','163',NULL,'0','0',NULL,0,'2026-04-28 06:11:51','2026-04-28 06:11:51'),(156,'234',NULL,NULL,'Dhanwantri Natural Herbs Care Private Limited',11,'0','CR','H.O. -117/H-1/100 Pandu Nagar Kanpur','Aarazi No-00375 Gata No1035 Maharajapur, Tatiyaganj Kanpur-209217','Kanpur','Uttar Pradesh','',NULL,'8874763777','dhanwantrinaturalherbscare@gmail.com',NULL,'0','09AAGCD2509Q1Z8','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'156',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','161',NULL,'0','0',NULL,0,'2026-04-28 06:11:51','2026-04-28 06:11:51'),(157,'234',NULL,NULL,'Bholanath Kashi Garmudyog',11,'0','CR','Vill-Kabirpura Sahupuri Chandauli','','Chandauli','Uttar Pradesh','',NULL,'9936912108','',NULL,'0','09BNGPS8627B1ZQ','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'157',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','171',NULL,'0','0',NULL,0,'2026-04-28 06:11:51','2026-04-28 06:11:51'),(158,'234',NULL,NULL,'BAWA TRADERS',11,'0','CR','Gala No. 19-172, Khuraiya Estate E Santacruz East','Bhd Ravi Cafe Kalina Mumbai-400055','Mumbai','21','400055',NULL,'0000000000','shoaibmahida99@gmail.com',NULL,'27','27EBHPM5758K1ZY','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'158',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','190',NULL,'0','0',NULL,0,'2026-04-28 06:11:51','2026-04-28 06:11:51'),(159,'234',NULL,NULL,'Aveeto Cosmotech',11,'0','CR','173/Sukhram Textile Park At Parab Ta. Kamrej Dist Surat','','Surat','Gujarat','394325',NULL,'9274270282','',NULL,'0','24AQWPS1315G1ZO','','',NULL,NULL,'','1',NULL,NULL,NULL,NULL,'159',NULL,NULL,NULL,NULL,NULL,'','','0','0',NULL,'0','0',0,NULL,0,NULL,NULL,NULL,NULL,'0',NULL,'0.00',NULL,'0','0',NULL,'0','165',NULL,'0','0',NULL,0,'2026-04-28 06:11:51','2026-04-28 06:11:51');
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int NOT NULL DEFAULT '0',
  `ADDRESS1` text,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `REMOTE_ID` varchar(255) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `PG_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` int DEFAULT '0',
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
INSERT INTO `SALES` VALUES (1,'234',NULL,NULL,'2026-05-02',3,1,'','',119,'BLDG NO-A-5 Gala-1 and2 Bhumi World Industrial Park Pimplas Bhiwandi  Mumbai 27AASFN5584G1ZM ',NULL,'ME/26-27/00022',1,'ME/26-27/','00022','',0,'14','7','180513.280','0','0','0','0','9025.66','4512.83','4512.83','0','0','0','+0.06','189539','189538.94','2192/0','484000.00','180513.28','','0.00','0','0',NULL,'0',NULL,NULL,'',NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','362','362',NULL,0,0,'2026-05-02 09:16:56','2026-05-02 09:16:56'),(2,'234',NULL,NULL,'2026-05-04',3,1,'','',125,'Gala No-16/A,1st Floor,Khetani Indrustrials Premises CO-OP Society Kurla West  Mumbai 27AAQFJ0119F1ZH 11520010000202',NULL,'ME/26-27/00023',2,'ME/26-27/','00023','',0,'14','7','66776.320','0','0','0','0','3338.82','1669.41','1669.41','0','0','0','-0.14','70115','70115.14','776/0','172000.00','66776.32','','0.00','0','0',NULL,'0',NULL,NULL,'',NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0.00','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','362','362',NULL,0,0,'2026-05-04 09:56:38','2026-05-04 09:56:38'),(3,'234',NULL,NULL,'2026-05-04',4,2,'','',142,'3,Bahuchar Apt-1,Saurastra Colony,Trikam Nagar-2,L.H.Road,SURAT  Surat 24ACCPD5563D1Z4 ',NULL,'ME/26-27/00024',3,'ME/26-27/','00024','',0,'14','7','189991.800','0','0','0','0','9499.6','0','0','9499.6','0','0','-0.40','199491','199491.40','1800/0','378900.00','189991.8','','0.00','0','0',NULL,'0',NULL,NULL,'',NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0.00','0',0,NULL,0,'0','','O','1','INV','1','20','self','','kkkkjj','ME/26-27/00024','2026-05-13','1',NULL,'2026-05-13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','362','362','1',0,0,'2026-05-04 10:06:59','2026-05-04 10:16:49');
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `INV_ARR` text,
  `INV_NO` text,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
INSERT INTO `SALES_ITEM` VALUES (1,'234',NULL,NULL,13,107,1,7,'42.85',150.0000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'720.00','0720','0','0',NULL,NULL,'0',0,'0','0','0','0','30852.00',0.0000,0.0000,'1542.60','771.3','771.3','0',0,'0',0,'0',NULL,NULL,'','',0,'150',NULL,'100',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-02 09:16:56','2026-05-02 09:16:56'),(2,'234',NULL,NULL,15,106,1,7,'177.14',173.6000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'392.00','392','0','0',NULL,NULL,'0',0,'0','0','0','0','69438.88',0.0000,0.0000,'3471.94','1735.97','1735.97','0',0,'0',0,'0',NULL,NULL,'','',0,'620',NULL,'500',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-02 09:16:56','2026-05-02 09:16:56'),(3,'234',NULL,NULL,14,108,1,7,'74.28',260.0000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'1080.00','01080','0','0',NULL,NULL,'0',0,'0','0','0','0','80222.40',0.0000,0.0000,'4011.12','2005.56','2005.56','0',0,'0',0,'0',NULL,NULL,'','',0,'260',NULL,'200',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-02 09:16:56','2026-05-02 09:16:56'),(4,'234',NULL,NULL,14,108,2,7,'76.76',260.0000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'720.00','0720','0','0',NULL,NULL,'0',0,'0','0','0','0','55267.20',0.0000,0.0000,'2763.36','1381.68','1381.68','0',0,'0',0,'0',NULL,NULL,'','',0,'260',NULL,'200',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-04 09:56:38','2026-05-04 09:56:38'),(5,'234',NULL,NULL,53,53,2,7,'205.52',189.0000,0,'5.00','2.5','2.5','0','0','0',1,NULL,'56.00','56','0','0',NULL,NULL,'0',0,'0','0','0','0','11509.12',0.0000,0.0000,'575.46','287.73','287.73','0',0,'0',0,'0',NULL,NULL,'','',0,'572',NULL,'500',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-04 09:56:38','2026-05-04 09:56:38'),(6,'234',NULL,NULL,69,80,3,7,'41.61',35.0000,0,'5.00','0','0','5.00','0','0',1,NULL,'270.00','0270','0','0',NULL,NULL,'0',0,'0','0','0','0','11234.70',0.0000,0.0000,'561.74','0','0','561.74',0,'0',0,'0',NULL,NULL,'','',0,'95',NULL,'60',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,1,'2026-05-04 10:06:59','2026-05-04 10:06:59'),(8,'234',NULL,NULL,83,101,3,7,'190.47',171.4300,0,'5.00','0','0','5.00','0','0',1,NULL,'180.00','0180','0','0',NULL,NULL,'0',0,'0','0','0','0','34284.60',0.0000,0.0000,'1714.23','0','0','1714.23',0,'0',0,'0',NULL,NULL,'','',0,'400',NULL,'500',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,1,'2026-05-04 10:06:59','2026-05-04 10:06:59'),(9,'234',NULL,NULL,81,99,3,7,'47.14',42.4300,0,'5.00','0','0','5.00','0','0',1,NULL,'288.00','288','0','0',NULL,NULL,'0',0,'0','0','0','0','13576.32',0.0000,0.0000,'678.82','0','0','678.82',0,'0',0,'0',NULL,NULL,'','',0,'99',NULL,'100',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,1,'2026-05-04 10:06:59','2026-05-04 10:06:59'),(10,'234',NULL,NULL,82,100,3,7,'94.76',85.2900,0,'5.00','0','0','5.00','0','0',1,NULL,'288.00','0288','0','0',NULL,NULL,'0',0,'0','0','0','0','27290.88',0.0000,0.0000,'1364.54','0','0','1364.54',0,'0',0,'0',NULL,NULL,'','',0,'199',NULL,'200',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,1,'2026-05-04 10:06:59','2026-05-04 10:06:59'),(11,'234',NULL,NULL,83,101,3,7,'190.47',171.4300,0,'5.00','0','0','5.00','0','0',1,NULL,'180.00','0180','0','0',NULL,NULL,'0',0,'0','0','0','0','34284.60',0.0000,0.0000,'1714.23','0','0','1714.23',0,'0',0,'0',NULL,NULL,'','',0,'400',NULL,'500',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,1,'2026-05-04 10:16:00','2026-05-04 10:16:00'),(12,'234',NULL,NULL,43,43,3,7,'124.85',109.4200,0,'5.00','0','0','5.00','0','0',1,NULL,'450.00','0450','0','0',NULL,NULL,'0',0,'0','0','0','0','56182.50',0.0000,0.0000,'2809.13','0','0','2809.13',0,'0',0,'0',NULL,NULL,'','',0,'285',NULL,'210',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,1,'2026-05-04 10:15:59','2026-05-04 10:15:59'),(13,'234',NULL,NULL,84,109,3,7,'67.90',59.0000,0,'5.00','0','0','5.00','','',1,NULL,'180.00','0180','0','0',NULL,NULL,'0',0,'0','0','0','0','12222.00',0.0000,0.0000,'611.10','0','0','611.10',0,'0',0,'0',NULL,NULL,'','',0,'155',NULL,'110',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,1,'2026-05-04 10:16:00','2026-05-04 10:16:00'),(14,'234',NULL,NULL,69,80,3,7,'41.61',35.0000,0,'5.00','0','0','5.00','0','0',1,NULL,'270.00','0270','0','0',NULL,NULL,'0',0,'0','0','0','0','11234.70',0.0000,0.0000,'561.74','0','0','561.74',0,'0',0,'0',NULL,NULL,'','',0,'95',NULL,'60',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,1,'2026-05-04 10:16:00','2026-05-04 10:16:00'),(15,'234',NULL,NULL,82,100,3,7,'94.76',85.2900,0,'5.00','0','0','5.00','0','0',1,NULL,'288.00','0288','0','0',NULL,NULL,'0',0,'0','0','0','0','27290.88',0.0000,0.0000,'1364.54','0','0','1364.54',0,'0',0,'0',NULL,NULL,'','',0,'199',NULL,'200',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,1,'2026-05-04 10:16:00','2026-05-04 10:16:00'),(16,'234',NULL,NULL,81,99,3,7,'47.14',42.4300,0,'5.00','0','0','5.00','0','0',1,NULL,'288.00','288','0','0',NULL,NULL,'0',0,'0','0','0','0','13576.32',0.0000,0.0000,'678.82','0','0','678.82',0,'0',0,'0',NULL,NULL,'','',0,'99',NULL,'100',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,1,'2026-05-04 10:16:00','2026-05-04 10:16:00'),(17,'234',NULL,NULL,81,99,3,7,'47.14',42.4300,0,'5.00','0','0','5.00','0','0',1,NULL,'288.00','288','0','0',NULL,NULL,'0',0,'0','0','0','0','13576.32',0.0000,0.0000,'678.82','0','0','678.82',0,'0',0,'0',NULL,NULL,'','',0,'99',NULL,'100',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-04 10:16:49','2026-05-04 10:16:49'),(18,'234',NULL,NULL,45,71,3,7,'244.45',557.8100,0,'5.00','0','0','5.00','0','0',1,NULL,'144.00','0144','0','0',NULL,NULL,'0',0,'0','0','0','0','35200.80',0.0000,0.0000,'1760.04','0','0','1760.04',0,'0',0,'0',NULL,NULL,'','',0,'558',NULL,'500',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-04 10:16:49','2026-05-04 10:16:49'),(19,'234',NULL,NULL,83,101,3,7,'190.47',171.4300,0,'5.00','0','0','5.00','0','0',1,NULL,'180.00','0180','0','0',NULL,NULL,'0',0,'0','0','0','0','34284.60',0.0000,0.0000,'1714.23','0','0','1714.23',0,'0',0,'0',NULL,NULL,'','',0,'400',NULL,'500',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-04 10:16:49','2026-05-04 10:16:49'),(20,'234',NULL,NULL,43,43,3,7,'124.85',109.4200,0,'5.00','0','0','5.00','0','0',1,NULL,'450.00','0450','0','0',NULL,NULL,'0',0,'0','0','0','0','56182.50',0.0000,0.0000,'2809.13','0','0','2809.13',0,'0',0,'0',NULL,NULL,'','',0,'285',NULL,'210',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-04 10:16:49','2026-05-04 10:16:49'),(21,'234',NULL,NULL,84,109,3,7,'67.90',59.0000,0,'5.00','0','0','5.00','','',1,NULL,'180.00','0180','0','0',NULL,NULL,'0',0,'0','0','0','0','12222.00',0.0000,0.0000,'611.10','0','0','611.10',0,'0',0,'0',NULL,NULL,'','',0,'155',NULL,'110',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-04 10:16:49','2026-05-04 10:16:49'),(22,'234',NULL,NULL,69,80,3,7,'41.61',35.0000,0,'5.00','0','0','5.00','0','0',1,NULL,'270.00','0270','0','0',NULL,NULL,'0',0,'0','0','0','0','11234.70',0.0000,0.0000,'561.74','0','0','561.74',0,'0',0,'0',NULL,NULL,'','',0,'95',NULL,'60',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-04 10:16:49','2026-05-04 10:16:49'),(23,'234',NULL,NULL,82,100,3,7,'94.76',85.2900,0,'5.00','0','0','5.00','0','0',1,NULL,'288.00','0288','0','0',NULL,NULL,'0',0,'0','0','0','0','27290.88',0.0000,0.0000,'1364.54','0','0','1364.54',0,'0',0,'0',NULL,NULL,'','',0,'199',NULL,'200',7,'7','0','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'362','362',NULL,0,'2026-05-04 10:16:49','2026-05-04 10:16:49');
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN_QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FREE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROFIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `WEIGHT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PRICE_PER` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DMG_MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REMARK` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_ARR` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UPDATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SECURITY_KEY` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AREA` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_MAN` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GROUP_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PARTY_CODE` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FINAL_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BATCH_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `MFG_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `EXP_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int DEFAULT '0',
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int DEFAULT '0',
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int DEFAULT '0',
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SMAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYNC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text,
  `UPDATED_VALUE` text,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text,
  `DIACM` text,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int DEFAULT '0',
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int DEFAULT '0',
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-04-28 05:59:54','2026-04-28 05:59:54');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UOM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int DEFAULT '0',
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
INSERT INTO `USER_PREF` VALUES (1,'234',NULL,NULL,'SalesZeroStock','1',362,NULL,NULL,NULL,'362','362',NULL,0,'2026-04-28 06:13:00','2026-04-28 06:13:00'),(2,'234',NULL,NULL,'SalesPurchaseDecimal4','1',362,NULL,NULL,NULL,'362','362',NULL,0,'2026-04-28 06:13:00','2026-04-28 06:13:00');
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `WEB_ID` int NOT NULL DEFAULT '0',
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-04-28 05:59:59');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-20  8:00:20
