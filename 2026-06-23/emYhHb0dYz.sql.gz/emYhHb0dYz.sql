-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: emYhHb0dYz
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `emYhHb0dYz`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `emYhHb0dYz` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `emYhHb0dYz`;

--
-- Table structure for table `AREA`
--

DROP TABLE IF EXISTS `AREA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AREA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AREA`
--

LOCK TABLES `AREA` WRITE;
/*!40000 ALTER TABLE `AREA` DISABLE KEYS */;
INSERT INTO `AREA` VALUES (1,'257',NULL,NULL,'KALYAN WEST','KALYAN WEST',NULL,'405','405',NULL,0,'2026-06-09 12:45:48','2026-06-09 12:45:48');
/*!40000 ALTER TABLE `AREA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AUTH`
--

DROP TABLE IF EXISTS `AUTH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `AUTH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOGIN_PAGE` varchar(255) DEFAULT NULL,
  `OTP_PAGE` varchar(255) DEFAULT NULL,
  `TOKEN` text,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `OLD_DISTRIBUTOR` varchar(255) DEFAULT NULL,
  `IS_EXISTING_DIST` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AUTH`
--

LOCK TABLES `AUTH` WRITE;
/*!40000 ALTER TABLE `AUTH` DISABLE KEYS */;
/*!40000 ALTER TABLE `AUTH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CLIENTS`
--

DROP TABLE IF EXISTS `CLIENTS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CLIENTS` (
  `MACID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `IP` varchar(255) DEFAULT NULL,
  `NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`MACID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CLIENTS`
--

LOCK TABLES `CLIENTS` WRITE;
/*!40000 ALTER TABLE `CLIENTS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CLIENTS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CPID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_DES` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_DETAILS`
--

LOCK TABLES `COMBI_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `COMBI_PACK_DETAILS`
--

DROP TABLE IF EXISTS `COMBI_PACK_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `COMBI_PACK_DETAILS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMBI_PROD_ID` varchar(255) DEFAULT NULL,
  `SR` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `COMBI_PACK_DETAILS`
--

LOCK TABLES `COMBI_PACK_DETAILS` WRITE;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` DISABLE KEYS */;
/*!40000 ALTER TABLE `COMBI_PACK_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CONFIG`
--

DROP TABLE IF EXISTS `CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CONFIG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `KEY` varchar(255) DEFAULT NULL,
  `VALUE` text,
  `MASTER` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CONFIG`
--

LOCK TABLES `CONFIG` WRITE;
/*!40000 ALTER TABLE `CONFIG` DISABLE KEYS */;
/*!40000 ALTER TABLE `CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_FY_MAPPING`
--

DROP TABLE IF EXISTS `CO_FY_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_FY_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `CO_ID` bigint DEFAULT NULL,
  `DB_NAME` varchar(255) DEFAULT NULL,
  `FY_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY_YEAR` varchar(255) DEFAULT NULL,
  `FY_START` varchar(255) DEFAULT NULL,
  `FY_END` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_FY_MAPPING`
--

LOCK TABLES `CO_FY_MAPPING` WRITE;
/*!40000 ALTER TABLE `CO_FY_MAPPING` DISABLE KEYS */;
INSERT INTO `CO_FY_MAPPING` VALUES (1,'257','0','emYhHb0dYz',257,'','','','2026-06-09 12:18:12','2026-06-09 12:18:12','','','','','','','','','2026-06-09 12:18:12','405','405','',0,'2026-06-09 12:18:12','2026-06-09 12:18:12');
/*!40000 ALTER TABLE `CO_FY_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME`
--

DROP TABLE IF EXISTS `CO_NAME`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COMP_NAME` varchar(255) DEFAULT NULL,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `ADD1` text,
  `ADD2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PHONE1` varchar(255) DEFAULT NULL,
  `PHONE2` varchar(255) DEFAULT NULL,
  `SH_ADD1` text,
  `SH_ADD2` varchar(255) DEFAULT NULL,
  `SH_CITY` varchar(255) DEFAULT NULL,
  `SH_STATE` varchar(255) DEFAULT NULL,
  `SH_STATE_CODE` varchar(255) DEFAULT NULL,
  `SH_PHONE1` varchar(255) DEFAULT NULL,
  `SH_PHONE2` varchar(255) DEFAULT NULL,
  `VAT` varchar(255) DEFAULT NULL,
  `CST` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DLNO1` varchar(255) DEFAULT NULL,
  `DLNO2` varchar(255) DEFAULT NULL,
  `FLNO` varchar(255) DEFAULT NULL,
  `APP` varchar(255) DEFAULT NULL,
  `SAME_ADDRESS` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `EMAIL_ID` varchar(255) DEFAULT NULL,
  `CIN_NO` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `CLONE_REF_ID` varchar(255) DEFAULT NULL,
  `CLONE_TYPE` varchar(255) DEFAULT NULL,
  `SHOW_CLONE_COMPANY` varchar(255) DEFAULT NULL,
  `DEALS_WITH` varchar(255) DEFAULT NULL,
  `LOGO_PATH` varchar(255) DEFAULT NULL,
  `SIGN_PATH` varchar(255) DEFAULT NULL,
  `PAN_NO` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT_STORE_ID` varchar(255) DEFAULT NULL,
  `PARENT_DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `PARENT` varchar(255) DEFAULT NULL,
  `STORE_URL` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT NULL,
  `CL_STOCK` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `IS_ACTIVE` varchar(255) DEFAULT 'No',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=258 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME`
--

LOCK TABLES `CO_NAME` WRITE;
/*!40000 ALTER TABLE `CO_NAME` DISABLE KEYS */;
INSERT INTO `CO_NAME` VALUES (257,NULL,NULL,NULL,'A.K. ENTERPRISES','2026-04-01','2027-03-31','SHOP NO.B/8,MORYA APT. MUMBRADEVI COLONY RD.','NEAR NEW BALAJI HOSPITAL DIVA (E)','THANE','21','9326731237','','','','','','','','','','','','','','',NULL,'0',NULL,'1.0.0621','21','27AXDPG8909N1ZY','','santoshy@yopmail.com','','400612',NULL,'1',NULL,'','','','',NULL,NULL,NULL,NULL,NULL,'','0',NULL,'1','1',NULL,0,'2026-06-09 12:18:12','2026-06-09 12:18:12',NULL,'','','AK','Yes');
/*!40000 ALTER TABLE `CO_NAME` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CO_NAME_EMAIL_STATUS`
--

DROP TABLE IF EXISTS `CO_NAME_EMAIL_STATUS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CO_NAME_EMAIL_STATUS` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  `SUBJECT` varchar(255) DEFAULT NULL,
  `SUCCESS_FAILURE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `CREATED_TS` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CO_NAME_EMAIL_STATUS`
--

LOCK TABLES `CO_NAME_EMAIL_STATUS` WRITE;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` DISABLE KEYS */;
/*!40000 ALTER TABLE `CO_NAME_EMAIL_STATUS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DERIVED_BATCH_STOCK`
--

DROP TABLE IF EXISTS `DERIVED_BATCH_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DERIVED_BATCH_STOCK` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `BATCH_ID` int DEFAULT '0',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DERIVED_BATCH_STOCK`
--

LOCK TABLES `DERIVED_BATCH_STOCK` WRITE;
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` DISABLE KEYS */;
INSERT INTO `DERIVED_BATCH_STOCK` VALUES (1,'0',NULL,NULL,1,1,'-216',NULL,'405','405',NULL,0,'2026-06-10 04:54:40','2026-06-20 12:26:05'),(2,'0',NULL,NULL,2,2,'-360',NULL,'405','405',NULL,0,'2026-06-10 04:56:34','2026-06-10 04:59:54');
/*!40000 ALTER TABLE `DERIVED_BATCH_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DISP`
--

DROP TABLE IF EXISTS `DISP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `DISP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `DESP_ID` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(26) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DISP`
--

LOCK TABLES `DISP` WRITE;
/*!40000 ALTER TABLE `DISP` DISABLE KEYS */;
/*!40000 ALTER TABLE `DISP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EMANDI_STATUS_MASTER`
--

DROP TABLE IF EXISTS `EMANDI_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `EMANDI_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EMANDI_STATUS_MASTER`
--

LOCK TABLES `EMANDI_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `EMANDI_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','0','1','',NULL,NULL,'',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'1','Ready to Pickup','2','1','2','0','0','',NULL,NULL,'',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'1','Delivered','3','1','4','0','0','',NULL,NULL,'',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'1','Cancelled','4','1','6','0','0','',NULL,NULL,'',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(5,'1',NULL,'1','Transit','5','1','3','0','0','',NULL,NULL,'',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(6,'1',NULL,'1','Rescheduled','7','1','5','0','0','',NULL,NULL,'',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `EMANDI_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FLASH_MESSAGE`
--

DROP TABLE IF EXISTS `FLASH_MESSAGE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FLASH_MESSAGE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `MESSAGE` text,
  `DELETED` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FLASH_MESSAGE`
--

LOCK TABLES `FLASH_MESSAGE` WRITE;
/*!40000 ALTER TABLE `FLASH_MESSAGE` DISABLE KEYS */;
/*!40000 ALTER TABLE `FLASH_MESSAGE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

DROP TABLE IF EXISTS `FY_CLOSE_OUTSTANDING_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FY_CLOSE_OUTSTANDING_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `REF_DATE` varchar(255) DEFAULT NULL,
  `REF_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` varchar(255) DEFAULT NULL,
  `MAC_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `REMOTE_ACC_ID` varchar(25) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `ACC_NAME` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FY_CLOSE_OUTSTANDING_IMPORT`
--

LOCK TABLES `FY_CLOSE_OUTSTANDING_IMPORT` WRITE;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `FY_CLOSE_OUTSTANDING_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL`
--

DROP TABLE IF EXISTS `GL`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT '0',
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT '0',
  `ACC_TO` varchar(255) DEFAULT '0',
  `SRC_ENTRY` varchar(255) DEFAULT '0',
  `TXN_DATE` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `RECEIPT_NO` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `AGAINST_INVOICE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL`
--

LOCK TABLES `GL` WRITE;
/*!40000 ALTER TABLE `GL` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GL_PUR_SALE_REF`
--

DROP TABLE IF EXISTS `GL_PUR_SALE_REF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GL_PUR_SALE_REF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL COMMENT 'Remarks3=chqrecv',
  `WEB_ID` varchar(255) DEFAULT NULL,
  `GL_REF` varchar(255) DEFAULT NULL,
  `SEL_PARTY_ACC_ID` varchar(255) DEFAULT NULL,
  `SEL_BANK_ACC_ID` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `ACC_TO` varchar(255) DEFAULT NULL,
  `SRC_ENTRY` varchar(255) DEFAULT NULL,
  `TXN_DATE` varchar(255) DEFAULT NULL COMMENT 'Pay Date',
  `SALES_ID` varchar(255) DEFAULT '0',
  `PURCHASE_ID` varchar(255) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT '0.00',
  `DIS_AMT` varchar(255) DEFAULT '0.00',
  `DRAWEE_BANK_NAME` varchar(255) DEFAULT NULL,
  `DRAWEE_BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CHQ_NO` varchar(255) DEFAULT NULL,
  `CHQ_DATE` varchar(255) DEFAULT NULL,
  `CHQ_CLEARING_DAY` varchar(255) DEFAULT NULL COMMENT 'for cash entry, remarks1',
  `REMARKS1` varchar(255) DEFAULT NULL,
  `REMARKS2` varchar(255) DEFAULT NULL COMMENT 'collectiontab or invoicewisecollection entry',
  `INVOICE_ARRAY` text,
  `CAS` varchar(255) DEFAULT NULL,
  `CHQ_RET_AGAINST_REF_ID` varchar(255) DEFAULT NULL,
  `CHQ_RETURN_DATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'InvoiceNos',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GL_PUR_SALE_REF`
--

LOCK TABLES `GL_PUR_SALE_REF` WRITE;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` DISABLE KEYS */;
/*!40000 ALTER TABLE `GL_PUR_SALE_REF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER`
--

DROP TABLE IF EXISTS `GST_VOUCHER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_DATE` varchar(255) DEFAULT NULL,
  `ENTRY` varchar(255) DEFAULT '0',
  `SUB_ACC_ID` varchar(255) DEFAULT '0',
  `TYPE` varchar(255) DEFAULT '0',
  `ON_ACCOUNT_ID` varchar(255) DEFAULT '0',
  `VOUCHER_NO` varchar(255) DEFAULT '0',
  `BILL_NO` varchar(255) DEFAULT '0',
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `NET_VALUE` varchar(255) DEFAULT '0.00',
  `TOTAL_CHARGES` varchar(255) DEFAULT '0.00',
  `TAX_ON_CHARGES` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER`
--

LOCK TABLES `GST_VOUCHER` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_CHARGE_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_CHARGE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_CHARGE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` varchar(255) DEFAULT '0',
  `PER_ID` varchar(255) DEFAULT '0',
  `REMARKS` varchar(255) DEFAULT NULL,
  `ON_VALUE` varchar(255) DEFAULT '0.00',
  `AT_VALUE` varchar(255) DEFAULT '0.00',
  `AMOUNT` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_CHARGE_ITEM`
--

LOCK TABLES `GST_VOUCHER_CHARGE_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_CHARGE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GST_VOUCHER_ITEM`
--

DROP TABLE IF EXISTS `GST_VOUCHER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `GST_VOUCHER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VOUCHER_ID` int DEFAULT '0',
  `TAX_ID` int DEFAULT '0',
  `HSN_CODE` varchar(255) DEFAULT NULL,
  `TAXABLE_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_TAX` varchar(255) DEFAULT NULL,
  `NET_AMT` varchar(255) DEFAULT '0.00',
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GST_VOUCHER_ITEM`
--

LOCK TABLES `GST_VOUCHER_ITEM` WRITE;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `GST_VOUCHER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INVOICE_TEMPLATE_CONFIG`
--

DROP TABLE IF EXISTS `INVOICE_TEMPLATE_CONFIG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INVOICE_TEMPLATE_CONFIG` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CONFIG_NAME` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CONFIG_VALUE` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INPUT_TYPE` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISPLAY_STATUS` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SELECT_OPTIONS` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GROUPS` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INVOICE_TEMPLATE_CONFIG`
--

LOCK TABLES `INVOICE_TEMPLATE_CONFIG` WRITE;
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` DISABLE KEYS */;
INSERT INTO `INVOICE_TEMPLATE_CONFIG` VALUES (1,'template_name','Print Invoice','text','Y','','1'),(2,'left_margin','5','text','Y','(%)','1'),(3,'top_margin','2','text','Y','(%)','1'),(4,'top_bar_height','140','text','Y','(px)','1'),(5,'top_address_width','50','text','Y','(%)','2'),(6,'top_center_width','40','text','Y','(%)','2'),(7,'top_right_width','10','text','Y','(%)','2'),(8,'item_section_height','200','text','Y','(px)','1'),(9,'qty','8','text','Y','(%)','3'),(10,'hsn_code','9','text','Y','(%)','3'),(11,'mrp','9','text','Y','(%)','3'),(12,'particular','25','text','Y','(%)','3'),(13,'rate','9','text','Y','(%)','3'),(14,'free','1','text','Y','(%)','3'),(15,'sch_per','1','text','Y','(%)','3'),(16,'sch_amt','9','text','Y','(%)','3'),(17,'sch1_per','10','text','N','(%)','3'),(18,'sch1_amt','10','text','N','(%)','3'),(19,'sch2_per','10','text','N','(%)','3'),(20,'sch2_amt','10','text','N','(%)','3'),(21,'amt','9','text','Y','(%)','3'),(22,'gst_per','2','text','Y','(%)','3'),(23,'gst_amt','9','text','Y','(%)','3'),(24,'net_amt','9','text','Y','(%)','3'),(25,'footer_top_margin','0','text','N','(%)','4'),(26,'footer_height','90','text','N','(%)','4'),(27,'footer_left','24','text','N','(%)','4'),(28,'footer_gross','9','text','Y','(%)','4'),(29,'footer_scheme','9','text','Y','(%)','4'),(30,'footer_discount','9','text','Y','(%)','4'),(31,'footer_display','9','text','Y','(%)','4'),(32,'footer_damage','9','text','Y','(%)','4'),(33,'footer_gst_amt','12','text','Y','(%)','4'),(34,'footer_add','7','text','Y','(%)','4'),(35,'footer_net_amt','26','text','Y','(%)','4');
/*!40000 ALTER TABLE `INVOICE_TEMPLATE_CONFIG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `INV_NO`
--

DROP TABLE IF EXISTS `INV_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `INV_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `START_SEQ` varchar(255) DEFAULT NULL,
  `LAST_USED_SEQ` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(255) DEFAULT NULL,
  `SUFFIX` varchar(255) DEFAULT NULL,
  `MIN_LENGTH` varchar(255) DEFAULT NULL,
  `INV_TYPE` varchar(16) DEFAULT NULL,
  `INV_TEMPLATE` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `INV_NO`
--

LOCK TABLES `INV_NO` WRITE;
/*!40000 ALTER TABLE `INV_NO` DISABLE KEYS */;
INSERT INTO `INV_NO` VALUES (1,'257',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(2,'257',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(3,'257',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(4,'257',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(5,'257',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(6,'257',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(7,'257',NULL,NULL,'1','','S','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(8,'257',NULL,NULL,'1','','TV','','8','TAX_VOUCHER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(9,'257',NULL,NULL,'1','','PC','','8','PURCHASE_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(10,'257',NULL,NULL,'1','','PO','','8','PURCHASE_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(11,'257',NULL,NULL,'1','','SC','','8','SALES_CHALLAN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(12,'257',NULL,NULL,'1','','SO','','8','SALES_ORDER','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(13,'257',NULL,NULL,'1','','SR','','8','SALES_RETURN','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(14,'257',NULL,NULL,'1','','','','8','SALES','DEFAULT',NULL,'','',NULL,0,NULL,NULL),(15,'257',NULL,NULL,'820','','C','','6','SALES','',NULL,'0','0',NULL,0,NULL,NULL),(16,'257',NULL,NULL,'820','','C','','6','SALES','AK',NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `INV_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LEDGER`
--

DROP TABLE IF EXISTS `LEDGER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LEDGER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `MAC_ID` int DEFAULT '0',
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LEDGER`
--

LOCK TABLES `LEDGER` WRITE;
/*!40000 ALTER TABLE `LEDGER` DISABLE KEYS */;
/*!40000 ALTER TABLE `LEDGER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOC`
--

DROP TABLE IF EXISTS `LOC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `LOC_ID` varchar(255) DEFAULT NULL,
  `LOCATION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOC`
--

LOCK TABLES `LOC` WRITE;
/*!40000 ALTER TABLE `LOC` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LOG`
--

DROP TABLE IF EXISTS `LOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` varchar(255) DEFAULT NULL,
  `MODULE` varchar(255) DEFAULT NULL,
  `LEVEL` varchar(255) DEFAULT NULL,
  `MSG` varchar(255) DEFAULT NULL,
  `ADDNL_MSG` varchar(255) DEFAULT NULL,
  `FULL_LOG` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXTRA1` varchar(255) DEFAULT NULL,
  `REFID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LOG`
--

LOCK TABLES `LOG` WRITE;
/*!40000 ALTER TABLE `LOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `LOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MAC`
--

DROP TABLE IF EXISTS `MAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` int DEFAULT '0',
  `AC_LOCATION` varchar(255) DEFAULT NULL,
  `DR_CR` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` int DEFAULT '0',
  `ROOT_PARENT_ID` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(29) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MAC`
--

LOCK TABLES `MAC` WRITE;
/*!40000 ALTER TABLE `MAC` DISABLE KEYS */;
INSERT INTO `MAC` VALUES (1,'1',NULL,'1','CAPITAL_ACCOUNT',1,'','DR',-1,-1,'1','Captial Account','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'1','CURRENT_ASSETS',1,'','DR',-1,-1,'1','Current Assets','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'1','CURRENT_LIABILITIY',1,'','CR',-1,-1,'1','Current Liability','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'1','FIXED_ASSETS',1,'','DR',-1,-1,'1','Fixed Assets','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(5,'1',NULL,'1','SUNDRY_DEBTORS',0,'','DR',2,2,'1','Sundry Debtors','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(6,'1',NULL,'1','INVESTMENTS',1,'','DR',-1,-1,'1','Investments','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(7,'1',NULL,'1','LOANS_LIABILITIES',1,'','CR',-1,-1,'1','LOAN Liabilities','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(8,'1',NULL,'1','PRE_OPERATIVE_EXP',1,'','CR',-1,-1,'1','Pre Operative Expase','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(9,'1',NULL,'1','PROFIT_AND_LOSS',1,'','CR',-1,-1,'1','Proft & Loss','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(10,'1',NULL,'1','REVENUE_ACCOUNT',1,'','CR',-1,-1,'1','Revenue Account','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(11,'1',NULL,'1','SUNDRY_CREDITORS',0,'','CR',3,3,'1','Sundry Creditors','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(12,'1',NULL,'1','BANK',0,'','DR',2,2,'1','Bank Account','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(13,'1',NULL,'1','SUSPENSE_ACCOUNT',1,'','DR',-1,-1,'1','Suspense Account','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(14,'1',NULL,'1','CASH_IN_HAND',0,'','DR',2,2,'1','Cash In Hand','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(15,'1',NULL,'1','BANK_OD_ACCOUNT',0,'','CR',7,7,'1','Bank O/D Account','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(16,'1',NULL,'1','BROKER',0,'','DR',2,2,'1','Broker','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(17,'1',NULL,'1','CUSTOMERS',0,'','DR',5,2,'1','Customers','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(18,'1',NULL,'1','DUTIES_TAXES',0,'','CR',3,3,'1','Duties & Taxes','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(19,'1',NULL,'1','EXPENSES_DIRECT/MFG',0,'','CR',10,10,'1','Expenses(Direct/Mfg)','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(20,'1',NULL,'1','EXPENSES_INDIRECT/ADMIN',0,'','CR',10,10,'1','Expenses(Indirect/Admin)','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(21,'1',NULL,'1','INCOME_DIRECT/OPR',0,'','CR',10,10,'1','Income(Direct/Opr)','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(22,'1',NULL,'1','INCOME_INDIRECT',0,'','CR',10,10,'1','Income(Indirect)','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(23,'1',NULL,'1','LOAN_ADVANCES_ASSET',0,'','DR',2,2,'1','Loan & Advances(Asset)','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(24,'1',NULL,'1','PROVISIONS_EXPENSES_PAYABLE',0,'','CR',3,3,'1','Provision/Expenses Payable','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(25,'1',NULL,'1','PURCHASE',0,'','CR',10,10,'1','Purchase','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(26,'1',NULL,'1','RESERVES_SURPLUS',0,'','CR',1,1,'1','Reserves & Surplus','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(27,'1',NULL,'1','Sales',0,'','CR',10,10,'1','Sales','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(28,'1',NULL,'1','SECURED_LOANS',0,'','CR',7,7,'1','Secured Loans','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(29,'1',NULL,'1','SECURITIES_DEPOSITS_ASSETS',0,'','DR',2,2,'1','Securities & Deposits(Assets)','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(30,'1',NULL,'1','SELF_STOCK',0,'','DR',2,2,'1','Self Stock','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(31,'1',NULL,'1','STOCK_IN_HAND',0,'','DR',2,2,'1','Stock-in-hand','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(32,'1',NULL,'1','SUPPLIERS',0,'','DR',11,3,'1','Suppliers','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(33,'1',NULL,'1','UNSECURED_LOANS',0,'','CR',7,7,'1','Unsecurd Loans','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `MAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_AC_LOCATION`
--

DROP TABLE IF EXISTS `MASTER_AC_LOCATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_AC_LOCATION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_AC_LOCATION`
--

LOCK TABLES `MASTER_AC_LOCATION` WRITE;
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` DISABLE KEYS */;
INSERT INTO `MASTER_AC_LOCATION` VALUES (1,'1',NULL,'1','BL','BalanceSheet-Liability Side','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'1','BA','BalanceSheet-Asset Side','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'1','PE','Profit & Loss-Expenses Side','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'1','PI','Profit & Loss-Income Side','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `MASTER_AC_LOCATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_APPLICATIONS`
--

DROP TABLE IF EXISTS `MASTER_APPLICATIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_APPLICATIONS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_APPLICATIONS`
--

LOCK TABLES `MASTER_APPLICATIONS` WRITE;
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` DISABLE KEYS */;
INSERT INTO `MASTER_APPLICATIONS` VALUES (1,'1',NULL,'1','','Retail/Distribution','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'1','','Mobile','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'1','','Medical','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'1','','Multisize / Multicolor','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(5,'1',NULL,'1','','Milk Center','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(6,'1',NULL,'1','','Multi Location Godown','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(7,'1',NULL,'1','','Menufaturing Unit','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(8,'1',NULL,'1','','Multiple Rate (Firecracker)','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `MASTER_APPLICATIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_COLLECTION_MODE`
--

DROP TABLE IF EXISTS `MASTER_COLLECTION_MODE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_COLLECTION_MODE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MODE` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ACC_FROM` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_COLLECTION_MODE`
--

LOCK TABLES `MASTER_COLLECTION_MODE` WRITE;
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` DISABLE KEYS */;
INSERT INTO `MASTER_COLLECTION_MODE` VALUES (1,'1',NULL,'1','Cheque Issued','CI','bank','1','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'1','Draft Issued','DI','bank','1','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'1','Cheque/Draft/RTGS Received ','CCRR','bank','1','0','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'1','Deposit Cash Into Bank','DCIB','bank','1','0','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(5,'1',NULL,'1','Withdrow Cash From Bank','WCFB','bank','1','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(6,'1',NULL,'1','Bank Expenses','BE','bank','1','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(7,'1',NULL,'1','Online Transfer','OT','bank','1','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(9,'1',NULL,'1','Cash Received','CR','cash','1','0','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(10,'1',NULL,'1','Cash Payment','CP','cash','1','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(11,'1',NULL,'1','Cheque Reversal','CHQ_RET','bank','1','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(12,'1',NULL,'1','Credit','CREDIT','credit','1','0','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(13,'1',NULL,'1','Journal Voucher','JV','voucher','1','0','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `MASTER_COLLECTION_MODE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_CUSTOM_TEMPLATE`
--

DROP TABLE IF EXISTS `MASTER_CUSTOM_TEMPLATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_CUSTOM_TEMPLATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `MASTER_PREF_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `FILE_CONTENT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_CUSTOM_TEMPLATE`
--

LOCK TABLES `MASTER_CUSTOM_TEMPLATE` WRITE;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_CUSTOM_TEMPLATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_GST_LIST`
--

DROP TABLE IF EXISTS `MASTER_GST_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_GST_LIST` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_GST_LIST`
--

LOCK TABLES `MASTER_GST_LIST` WRITE;
/*!40000 ALTER TABLE `MASTER_GST_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_GST_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PARTY_TYPE`
--

DROP TABLE IF EXISTS `MASTER_PARTY_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PARTY_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(18) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PARTY_TYPE`
--

LOCK TABLES `MASTER_PARTY_TYPE` WRITE;
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` DISABLE KEYS */;
INSERT INTO `MASTER_PARTY_TYPE` VALUES (1,'0',NULL,NULL,NULL,'GST Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(2,'0',NULL,NULL,NULL,'VAT Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(3,'0',NULL,NULL,NULL,'Retail Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(4,'0',NULL,NULL,NULL,'TOT Dealer',NULL,NULL,'0','0',NULL,0,NULL,NULL),(5,'0',NULL,NULL,NULL,'Out Of State Party',NULL,NULL,'0','0',NULL,0,NULL,NULL),(6,'0',NULL,NULL,NULL,'Wholesale Party',NULL,NULL,'0','0',NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `MASTER_PARTY_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_POSITION`
--

DROP TABLE IF EXISTS `MASTER_POSITION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_POSITION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_POSITION`
--

LOCK TABLES `MASTER_POSITION` WRITE;
/*!40000 ALTER TABLE `MASTER_POSITION` DISABLE KEYS */;
INSERT INTO `MASTER_POSITION` VALUES (1,'1',NULL,'1','OPERATOR','Operator','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'1','SUPER_USER','Super User','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `MASTER_POSITION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_PREF`
--

DROP TABLE IF EXISTS `MASTER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(29) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `DESC` varchar(31) DEFAULT NULL,
  `PRINT_REF_FILE` varchar(40) DEFAULT NULL,
  `REF_ID_CUSTOM_TEMPLATE` varchar(255) DEFAULT NULL,
  `NEW_FILE_CONTENT` varchar(255) DEFAULT NULL,
  `RESET` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_PREF`
--

LOCK TABLES `MASTER_PREF` WRITE;
/*!40000 ALTER TABLE `MASTER_PREF` DISABLE KEYS */;
INSERT INTO `MASTER_PREF` VALUES (1,'1',NULL,'','PRINT_TAX_INVOICE','1',NULL,'','','Full Page Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'','PRINT_TAX_INVOICE','2',NULL,'','','Half Page Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'','PRINT_TAX_INVOICE','3',NULL,'','','Half Page Invoice(Generic)',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'','PRINT_TAX_INVOICE','4',NULL,'','','Half Page Invoice (4 Decimal)',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(5,'1',NULL,'','PRINT_PUR_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(6,'1',NULL,'','PRINT_PUR_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(7,'1',NULL,'','PRINT_SALES_REGISTER','1',NULL,'','','',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(8,'1',NULL,'','PRINT_SALES_SUMMARY','1',NULL,'','','',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(9,'1',NULL,'','PRINT_OUTSTANDING','1',NULL,'','','',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(10,'1',NULL,'','PRINT_STOCK','1',NULL,'','','',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(11,'1',NULL,'','PRINT_LEDGER','1',NULL,'','','',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(12,'1',NULL,'','PRINT_DAYBOOK','1',NULL,'','','',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(13,'1',NULL,'','PRINT_GST_PUR','1',NULL,'','','',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(14,'1',NULL,'','PRINT_GST_SALES','1',NULL,'','','',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(15,'1',NULL,'','PRINT_TAX_INVOICE','5',NULL,'','','Half Page Invoice(MRP)',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(16,'1',NULL,'','PRINT_TAX_INVOICE','6',NULL,'','','Half Page Invoice(DMART Client)',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(17,'1',NULL,'','PRINT_TAX_INVOICE','7',NULL,'','','Half Page Invoice(BAG)',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(18,'1',NULL,'','PRINT_TAX_INVOICE','8',NULL,'','','Challan Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(19,'1',NULL,'','PRINT_TAX_INVOICE','9',NULL,'','','KG Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(20,'1',NULL,'','PRINT_TAX_INVOICE','10',NULL,'','','GST Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(21,'1',NULL,'','PRINT_TAX_INVOICE','11',NULL,'','','NET Invoice(NET amt)',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(22,'1',NULL,'','PRINT_TAX_INVOICE','12',NULL,'','','CESS Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(23,'1',NULL,'','PRINT_TAX_INVOICE','13',NULL,'','','Disc Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(28,'1',NULL,'','PRINT_TAX_INVOICE','14',NULL,'','','Template 14 Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(29,'1',NULL,'','PRINT_TAX_INVOICE','15',NULL,'','','Template 15 Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(30,'1',NULL,'','PRINT_TAX_INVOICE','16',NULL,'','','Template 16 Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(31,'1',NULL,'','PRINT_TAX_INVOICE','17',NULL,'','','Water Bill Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(32,'1',NULL,'','PRINT_TAX_INVOICE','18',NULL,'','','ORG/DUPL Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(33,'1',NULL,'','PRINT_TAX_INVOICE_RETURN','',NULL,'print-invoice-return-template1-impl','','SR: Credit Note',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(34,'1',NULL,'','PRINT_TAX_INVOICE_ORDER','',NULL,'print-invoice-order-template1-impl','','SO: Sales Order',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(35,'1',NULL,'','PRINT_TAX_INVOICE_CHALLAN','',NULL,'print-invoice-challan-template1-impl','','SC: Sales Challan',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(36,'1',NULL,'','PRINT_TAX_PUR_INVOICE','',NULL,'print-pur-invoice-template1-impl','','PUR: Purchase Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(37,'1',NULL,'','PRINT_TAX_PUR_INVOICE_RETURN','',NULL,'print-pur-invoice-return-template1-impl','','PR: Debit Note',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(38,'1',NULL,'','PRINT_TAX_PUR_INVOICE_ORDER','',NULL,'print-pur-invoice-order-template1-impl','','PO: Purchase Order',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(39,'1',NULL,'','PRINT_TAX_PUR_INVOICE_CHALLAN','',NULL,'print-pur-invoice-challan-template1-impl','','PC: Purchase Challan',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(40,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template19-impl','','Cess Invoice(QTY)',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(41,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template20-impl','','Net Rate Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(42,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template21-impl','','  GST Invoice A5',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(43,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template22-impl','','  APMC Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(44,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template23-impl','','  Medical Invoice',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(45,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template24-impl','','  GST Invoice-2',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(46,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template25-impl','','  Template 16 Invoice-2',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(47,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template26-impl','','  Disc Invoice-2',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(48,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template27-impl','','  Shipping Add',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(49,'1',NULL,'','PRINT_TAX_INVOICE','',NULL,'print-invoice-template28-impl','','  Landscape Template-1',0,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(50,'1',NULL,'','EWAY_BILL_VERSION','1.0.0621',NULL,NULL,NULL,NULL,NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `MASTER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_SETT`
--

DROP TABLE IF EXISTS `MASTER_SETT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_SETT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VALUE` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(30) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_SETT`
--

LOCK TABLES `MASTER_SETT` WRITE;
/*!40000 ALTER TABLE `MASTER_SETT` DISABLE KEYS */;
/*!40000 ALTER TABLE `MASTER_SETT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_STATE`
--

DROP TABLE IF EXISTS `MASTER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_STATE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SHORT_NAME` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT '0',
  `MASTER` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_STATE`
--

LOCK TABLES `MASTER_STATE` WRITE;
/*!40000 ALTER TABLE `MASTER_STATE` DISABLE KEYS */;
INSERT INTO `MASTER_STATE` VALUES (1,'1',NULL,'1','AP','Andhra Pradesh','28','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'1','AN','Andaman and Nicobar Islands','35','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'1','AR','Arunachal Pradesh','12','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'1','AS','Assam','18','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(5,'1',NULL,'1','BR','Bihar','10','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(6,'1',NULL,'1','CH','Chandigarh','4','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(7,'1',NULL,'1','CG','Chhattisgarh','22','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(8,'1',NULL,'1','DH','Dadra and Nagar Haveli','26','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(9,'1',NULL,'1','DD','Daman and Diu','25','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(10,'1',NULL,'1','DL','Delhi','7','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(11,'1',NULL,'1','GA','Goa','30','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(12,'1',NULL,'1','GJ','Gujarat','24','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(13,'1',NULL,'1','HR','Haryana','6','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(14,'1',NULL,'1','HP','Himachal Pradesh','2','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(15,'1',NULL,'1','JK','Jammu & Kashmir','1','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(16,'1',NULL,'1','JH','Jharkhand','20','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(17,'1',NULL,'1','KA','Karnataka','29','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(18,'1',NULL,'1','KL','Kerala','32','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(19,'1',NULL,'1','LD','Lakshadweep','31','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(20,'1',NULL,'1','MP','Madhya Pradesh','23','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(21,'1',NULL,'1','MH','Maharashtra','27','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(22,'1',NULL,'1','MN','Manipur','14','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(23,'1',NULL,'1','ML','Meghalaya','17','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(24,'1',NULL,'1','MZ','Mizoram','15','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(25,'1',NULL,'1','NL','Nagaland','13','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(26,'1',NULL,'1','OR','Orissa','21','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(27,'1',NULL,'1','PY','Pondicherry','34','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(28,'1',NULL,'1','PB','Punjab','3','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(29,'1',NULL,'1','RJ','Rajasthan','8','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(30,'1',NULL,'1','SK','Sikkim','11','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(31,'1',NULL,'1','TN','Tamil Nadu','33','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(32,'1',NULL,'1','TN','Telangana ','36','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(33,'1',NULL,'1','TR','Tripura','16','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(34,'1',NULL,'1','UP','Uttar Pradesh','9','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(35,'1',NULL,'1','UK','Uttarakhand','5','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(36,'1',NULL,'1','WB','West Bengal','19','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `MASTER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MASTER_UNIT`
--

DROP TABLE IF EXISTS `MASTER_UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MASTER_UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UNIT` varchar(255) DEFAULT NULL,
  `DISPLAY` varchar(255) DEFAULT NULL,
  `BASE_FAMILY` varchar(255) DEFAULT NULL,
  `CF_VALUE` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MASTER_UNIT`
--

LOCK TABLES `MASTER_UNIT` WRITE;
/*!40000 ALTER TABLE `MASTER_UNIT` DISABLE KEYS */;
INSERT INTO `MASTER_UNIT` VALUES (1,'1',NULL,'1','MG','Milli-Gram','1',1,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'1','GM','Gram','1',1000,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'1','KG','Killo-Gram','1',1000000,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'1','QNTL','Quintal','1',100000000,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(5,'1',NULL,'1','ML','Milli-Litre','2',1,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(6,'1',NULL,'1','LTR','Litre','2',1000,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(7,'1',NULL,'1','PCS','Pieces','3',1,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(8,'1',NULL,'1','DZN','Dozen','3',12,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(9,'1',NULL,'1','BAG','Bag','0',1,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(10,'1',NULL,'1','BOX','Box','0',1,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(11,'1',NULL,'1','PKT','Packet','0',1,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(12,'1',NULL,'1','MTR','Meter','0',1,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(13,'1',NULL,'1','JAR','Jar','0',1,'1','','1','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `MASTER_UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MIGRATED_DATA`
--

DROP TABLE IF EXISTS `MIGRATED_DATA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MIGRATED_DATA` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `previousId` varchar(255) DEFAULT NULL,
  `currentId` varchar(255) DEFAULT NULL,
  `tableName` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MIGRATED_DATA`
--

LOCK TABLES `MIGRATED_DATA` WRITE;
/*!40000 ALTER TABLE `MIGRATED_DATA` DISABLE KEYS */;
/*!40000 ALTER TABLE `MIGRATED_DATA` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `MOBILE_DASHBOARD`
--

DROP TABLE IF EXISTS `MOBILE_DASHBOARD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `MOBILE_DASHBOARD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `META_TYPE` varchar(255) DEFAULT NULL,
  `META_KEY` varchar(255) DEFAULT NULL,
  `META_VALUE` varchar(255) DEFAULT NULL,
  `META_KEY_2` varchar(255) DEFAULT NULL,
  `META_VALUE_2` varchar(255) DEFAULT NULL,
  `LABEL` text,
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MOBILE_DASHBOARD`
--

LOCK TABLES `MOBILE_DASHBOARD` WRITE;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` DISABLE KEYS */;
/*!40000 ALTER TABLE `MOBILE_DASHBOARD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_BALANCE_IMPORT`
--

DROP TABLE IF EXISTS `OP_BALANCE_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_BALANCE_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `SAC_ID` int NOT NULL DEFAULT '0',
  `REMOTE_ID` int NOT NULL DEFAULT '0',
  `PENDING_AMT` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_BALANCE_IMPORT`
--

LOCK TABLES `OP_BALANCE_IMPORT` WRITE;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `OP_BALANCE_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OP_CL_STOCK`
--

DROP TABLE IF EXISTS `OP_CL_STOCK`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OP_CL_STOCK` (
  `OP_CL_ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `PROD_ID` int NOT NULL DEFAULT '0',
  `PACK` int NOT NULL DEFAULT '0',
  `PROD_BATCH_ID` int NOT NULL DEFAULT '0',
  `PUR_SALE_DATE` date DEFAULT NULL,
  `PUR_QTY` int NOT NULL DEFAULT '0',
  `PUR_RET_QTY` int NOT NULL DEFAULT '0',
  `PUR_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `PUR_TOTAL` int NOT NULL DEFAULT '0',
  `SALE_QTY` int DEFAULT '0',
  `SALE_RET_QTY` int DEFAULT '0',
  `SALE_CHALLAN_QTY` int NOT NULL DEFAULT '0',
  `SALE_TOTAL` int NOT NULL DEFAULT '0',
  `OP_STOCK` int NOT NULL DEFAULT '0',
  `CLOSING_STOCK` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`OP_CL_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OP_CL_STOCK`
--

LOCK TABLES `OP_CL_STOCK` WRITE;
/*!40000 ALTER TABLE `OP_CL_STOCK` DISABLE KEYS */;
INSERT INTO `OP_CL_STOCK` VALUES (1,257,2,0,2,'2026-05-07',0,0,0,0,576,0,0,576,0,-576),(2,257,1,0,1,'2026-06-20',0,0,0,0,2,0,0,2,0,-2);
/*!40000 ALTER TABLE `OP_CL_STOCK` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER_STATUS_MASTER`
--

DROP TABLE IF EXISTS `ORDER_STATUS_MASTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ORDER_STATUS_MASTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ORDER_STATUS` varchar(255) DEFAULT NULL,
  `ORDER_STATUS_ID` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `SORT_ORDER` varchar(255) DEFAULT NULL,
  `STORE_ID` varchar(255) DEFAULT NULL,
  `IS_DEFAULT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ORDER_STATUS_MASTER`
--

LOCK TABLES `ORDER_STATUS_MASTER` WRITE;
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` DISABLE KEYS */;
INSERT INTO `ORDER_STATUS_MASTER` VALUES (1,'1',NULL,'1','Placed','1','1','1','9136','1','',NULL,NULL,'',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'1','Delivered','3','1','3','9136','0','',NULL,NULL,'',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'1','Cancelled','4','1','4','9136','0','',NULL,NULL,'',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `ORDER_STATUS_MASTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OTHER_PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `OTHER_PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OTHER_PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OTHER_PG_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OTHER_PRODUCT_GROUP`
--

LOCK TABLES `OTHER_PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` DISABLE KEYS */;
/*!40000 ALTER TABLE `OTHER_PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PERMISSION`
--

DROP TABLE IF EXISTS `PERMISSION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PERMISSION` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `OPERATION` varchar(255) DEFAULT NULL,
  `USER_TYPE` varchar(255) DEFAULT NULL,
  `ADD_PERMISSION` varchar(255) DEFAULT NULL,
  `EDIT_PERMISSION` varchar(255) DEFAULT NULL,
  `DELETE_PERMISSION` varchar(255) DEFAULT NULL,
  `VIEW_PERMISSION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PERMISSION`
--

LOCK TABLES `PERMISSION` WRITE;
/*!40000 ALTER TABLE `PERMISSION` DISABLE KEYS */;
/*!40000 ALTER TABLE `PERMISSION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PREFERENCES`
--

DROP TABLE IF EXISTS `PREFERENCES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PREFERENCES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `COL_ID` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PREFERENCES`
--

LOCK TABLES `PREFERENCES` WRITE;
/*!40000 ALTER TABLE `PREFERENCES` DISABLE KEYS */;
/*!40000 ALTER TABLE `PREFERENCES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD`
--

DROP TABLE IF EXISTS `PROD`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_BRAND` varchar(255) DEFAULT NULL,
  `PROD_S_NAME` varchar(255) DEFAULT NULL,
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PROD_UNIT` varchar(255) DEFAULT NULL,
  `SERIAL_NO` varchar(255) DEFAULT NULL,
  `PRODM_GROUP` varchar(255) DEFAULT NULL,
  `PROD_COMPANY` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `VAT_TYPE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `PUR_VAT` varchar(255) DEFAULT NULL,
  `APMC` varchar(255) DEFAULT NULL,
  `MIN_QUANTITY` varchar(255) DEFAULT NULL,
  `PROD_LOCK` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `IMG_PATH` varchar(1024) DEFAULT NULL,
  `PUR_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `INNER_PACK` varchar(255) DEFAULT NULL,
  `PACKAGING` varchar(255) DEFAULT NULL,
  `INSURANCE_TAX` varchar(255) DEFAULT NULL,
  `PROD_CATEGORY` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `DELETED_PROD_CODE` varchar(255) DEFAULT NULL,
  `PROD_OTHER_GROUP` varchar(255) DEFAULT NULL,
  `GOOD_SERVICES` varchar(255) DEFAULT NULL,
  `ISMRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD`
--

LOCK TABLES `PROD` WRITE;
/*!40000 ALTER TABLE `PROD` DISABLE KEYS */;
INSERT INTO `PROD` VALUES (1,'257',NULL,NULL,'322','','',NULL,'BN NUTRICA FITNESS 5 LTR','15159040','5','6','0','1','','7','10','4',NULL,NULL,'2','2',NULL,'0',NULL,'1','1','',NULL,NULL,NULL,'7','0','','','','','','0','',NULL,NULL,'','Goods','',NULL,'405','405',NULL,0,'2026-06-10 04:55:03','2026-06-10 04:55:03'),(2,'257',NULL,NULL,'329','','',NULL,'BN NUTRICA IMMUNITY 1 LTR PP','15159040','1','6','0','','','7','10','20',NULL,NULL,'2','2',NULL,'0',NULL,'1','1','',NULL,NULL,NULL,'7','0','','','','','','0','',NULL,NULL,'','Goods','',NULL,'405','405',NULL,0,'2026-06-10 04:55:10','2026-06-10 04:55:10');
/*!40000 ALTER TABLE `PROD` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_BRAND`
--

DROP TABLE IF EXISTS `PRODUCT_BRAND`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_BRAND` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `BRAND_ID` varchar(255) DEFAULT NULL,
  `BRAND_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_BRAND`
--

LOCK TABLES `PRODUCT_BRAND` WRITE;
/*!40000 ALTER TABLE `PRODUCT_BRAND` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_BRAND` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_CATEGORY`
--

DROP TABLE IF EXISTS `PRODUCT_CATEGORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_CATEGORY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PCAT_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_CATEGORY`
--

LOCK TABLES `PRODUCT_CATEGORY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` DISABLE KEYS */;
INSERT INTO `PRODUCT_CATEGORY` VALUES (1,'1',NULL,'1','Fruits & Vegetables','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'1','Milk & Dairy','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'1','Oil & Ghee','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'1','Rice & Atta','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(5,'1',NULL,'1','Dal & Pulses','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(6,'1',NULL,'1','Food & Beverages','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(7,'1',NULL,'1','Salt, Sugar & Masalas','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(8,'1',NULL,'1','Maternity & Baby Care','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(9,'1',NULL,'1','Personal Care','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(10,'1',NULL,'1','Household & Cleaning','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(11,'1',NULL,'1','Sauces & Spreads','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(12,'1',NULL,'1','Snacks & Chocolates','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(13,'1',NULL,'1','Pet Care','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(14,'1',NULL,'1','Noodles, Pasta & Ready Meals','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(15,'1',NULL,'1','Books & Stationery','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(16,'1',NULL,'1','Bakery, Baking & Eggs','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(17,'1',NULL,'1','Meat & Seafood','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(18,'1',NULL,'1','Imported Brands','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(19,'1',NULL,'1','Dry Fruits & Sweets','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(20,'1',NULL,'1','Pooja Needs','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(21,'1',NULL,'1','Electronics','1','','95271',NULL,'','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `PRODUCT_CATEGORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_COMPANY`
--

DROP TABLE IF EXISTS `PRODUCT_COMPANY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_COMPANY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `COMP_ID` varchar(255) DEFAULT NULL,
  `COMPANY_NAME` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_COMPANY`
--

LOCK TABLES `PRODUCT_COMPANY` WRITE;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_COMPANY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_GROUP`
--

DROP TABLE IF EXISTS `PRODUCT_GROUP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_GROUP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PG_NAME` varchar(255) DEFAULT NULL,
  `IS_PRIMARY` varchar(255) DEFAULT NULL,
  `UNDER_GROUP_ID` varchar(255) DEFAULT NULL,
  `ROOT_PARENT_ID` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_GROUP`
--

LOCK TABLES `PRODUCT_GROUP` WRITE;
/*!40000 ALTER TABLE `PRODUCT_GROUP` DISABLE KEYS */;
INSERT INTO `PRODUCT_GROUP` VALUES (1,'257',NULL,NULL,'BN GROUP NUTRICA OIL','1','',NULL,NULL,NULL,NULL,'405','0',NULL,0,'2026-06-09 13:09:21','2026-06-09 13:09:21'),(2,'257',NULL,NULL,'BN GROUP NUTRICA OIL','1','',NULL,NULL,NULL,NULL,'405','0',NULL,0,'2026-06-09 13:09:21','2026-06-09 13:09:21'),(3,'257',NULL,NULL,'BN GROUP NUTRICA OIL','1','',NULL,NULL,NULL,NULL,'405','0',NULL,0,'2026-06-09 13:09:21','2026-06-09 13:09:21'),(4,'257',NULL,NULL,'BN GROUP NUTRICA OIL','1','',NULL,NULL,NULL,NULL,'405','0',NULL,1,'2026-06-09 13:09:21','2026-06-09 13:09:21'),(5,'257',NULL,NULL,'BN GROUP NUTRICA OIL','1','',NULL,NULL,NULL,NULL,'405','0',NULL,1,'2026-06-09 13:09:21','2026-06-09 13:09:21'),(6,'257',NULL,NULL,'BN GROUP NUTRICA OIL','1','',NULL,NULL,NULL,NULL,'405','0',NULL,1,'2026-06-09 13:09:21','2026-06-09 13:09:21'),(7,'257',NULL,NULL,'BN GROUP NUTRICA OIL','1','',NULL,NULL,NULL,NULL,'405','0',NULL,1,'2026-06-09 13:11:00','2026-06-09 13:11:00'),(8,'257',NULL,NULL,'BN GROUP NUTRICA OIL','1','',NULL,NULL,NULL,NULL,'405','0',NULL,1,'2026-06-09 13:09:21','2026-06-09 13:09:21'),(9,'257',NULL,NULL,'BN GROUP NUTRICA OIL','1','',NULL,NULL,NULL,NULL,'405','0',NULL,0,'2026-06-09 13:09:21','2026-06-09 13:09:21');
/*!40000 ALTER TABLE `PRODUCT_GROUP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PRODUCT_TARGET`
--

DROP TABLE IF EXISTS `PRODUCT_TARGET`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PRODUCT_TARGET` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL DEFAULT '0',
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_NAME` varchar(255) DEFAULT NULL,
  `TOTAL_TARGET_SELLING` int NOT NULL DEFAULT '0',
  `CREATED_TS` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DELETED` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PRODUCT_TARGET`
--

LOCK TABLES `PRODUCT_TARGET` WRITE;
/*!40000 ALTER TABLE `PRODUCT_TARGET` DISABLE KEYS */;
/*!40000 ALTER TABLE `PRODUCT_TARGET` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH`
--

DROP TABLE IF EXISTS `PROD_BATCH`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OP_STOCK` varchar(255) DEFAULT '0.00',
  `CUR_STOCK` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `LAST_SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0',
  `LAST_PUR_RATE` varchar(255) DEFAULT '0',
  `MARGIN` varchar(255) DEFAULT '0',
  `BATCH_LOCK` varchar(255) DEFAULT '0',
  `PROD_RACK` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `WEB_SYNC_AT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH`
--

LOCK TABLES `PROD_BATCH` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH` DISABLE KEYS */;
INSERT INTO `PROD_BATCH` VALUES (1,'257',NULL,NULL,'1','67278009','2026-06-10','2026-06-10','322','0','0','-216','1030','788','788','3396.06','0','0','0',NULL,NULL,NULL,NULL,NULL,'undefined','0',NULL,0,'2026-06-10 04:54:40',NULL),(2,'257',NULL,NULL,'2','67392497','2026-06-10','2026-06-10','329','0','0','-360','192','0','158.2667','3165.26','0','0','0',NULL,NULL,NULL,NULL,NULL,'undefined','0',NULL,0,'2026-06-10 04:56:34',NULL);
/*!40000 ALTER TABLE `PROD_BATCH` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROD_BATCH_IMPORT`
--

DROP TABLE IF EXISTS `PROD_BATCH_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PROD_BATCH_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `PRODUCT_CODE` varchar(255) DEFAULT NULL,
  `PRODUCT_DESCRIPTION` varchar(255) DEFAULT NULL,
  `HSN_SAC_CODE` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `WEIGHT_UNIT` varchar(255) DEFAULT NULL,
  `PRODUCT_GROUP` varchar(255) DEFAULT NULL,
  `PRODUCT_COMPANY` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `SALES_UNIT` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `PUR_GST` varchar(255) DEFAULT NULL,
  `SALES_GST` varchar(255) DEFAULT NULL,
  `BARCODE` varchar(255) DEFAULT NULL,
  `BASIC_PRICE` varchar(255) DEFAULT NULL,
  `OPENING_STOCK` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PUR_RATE` varchar(255) DEFAULT NULL,
  `SALES_RATE` varchar(255) DEFAULT NULL,
  `APMC_TAX` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `CESS_ADDL` varchar(255) DEFAULT NULL,
  `CARTON_PACK` varchar(255) DEFAULT NULL,
  `BATCH_NO` varchar(255) DEFAULT NULL,
  `MFG_DATE` varchar(255) DEFAULT NULL,
  `EXP_DATE` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROD_BATCH_IMPORT`
--

LOCK TABLES `PROD_BATCH_IMPORT` WRITE;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROD_BATCH_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE`
--

DROP TABLE IF EXISTS `PURCHASE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `PAID_AMT` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `PAID_AMT1` varchar(255) DEFAULT NULL,
  `PAY_TYPE` varchar(255) DEFAULT NULL,
  `PAY_DATE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `CH_NO` varchar(255) DEFAULT NULL,
  `CH_DATE` varchar(255) DEFAULT NULL,
  `PO_NO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `PO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `BROKER_ID` int DEFAULT '0',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` int DEFAULT '0',
  `M_ROUND_OFF` int DEFAULT '0',
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE`
--

LOCK TABLES `PURCHASE` WRITE;
/*!40000 ALTER TABLE `PURCHASE` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `PUR_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `INV_ARR` text,
  `INV_NO` text,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM`
--

LOCK TABLES `PURCHASE_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `PURCHASE_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ITEM_IMPORT` (
  `ID` bigint unsigned NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` int NOT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT 'mrp_value',
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `PROD_ID` int NOT NULL,
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_CESS_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PACK` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BOX` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DISC_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN_QTY` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `FREE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME1_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_PERCENT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SCHEME2_AMOUNT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_SGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_CGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_IGST` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `CESS_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CESS_AMT_ADDL` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '',
  `WEIGHT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PRICE_PER` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `SALE_UNIT` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_VAT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_APMC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DAMAGE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DIFFERENCE_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `DMG_MRP` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `PUR_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `CLOUD_SYNC` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `INV_ARR` text COLLATE utf8mb4_general_ci COMMENT 'add_amt',
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'less_amt',
  `CREATED_BY` int DEFAULT NULL,
  `UPDATED_BY` int DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_TS` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SUPPLIER_ID` int DEFAULT NULL,
  `PUR_DATE` date DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8mb4_general_ci,
  `GROUP_ID` int DEFAULT NULL,
  `FINAL_AMT` varchar(25) COLLATE utf8mb4_general_ci DEFAULT '0',
  `BATCH_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TCS_TAX` varchar(100) COLLATE utf8mb4_general_ci DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ITEM_IMPORT`
--

LOCK TABLES `PURCHASE_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PUR_DATE` varchar(255) DEFAULT NULL,
  `SUPPLIER_ID` int DEFAULT '0',
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `OCT_FRGHT` varchar(255) DEFAULT '0.00',
  `APMC` varchar(255) DEFAULT '0.00',
  `CREDIT_AMT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `PUR_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `PURCHASE_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `BROKER_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER`
--

LOCK TABLES `PURCHASE_ORDER` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHASE_ORDER_ITEM`
--

DROP TABLE IF EXISTS `PURCHASE_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PURCHASE_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `PUR_ID` int DEFAULT '0',
  `PUR_UNIT` int DEFAULT '0',
  `PUR_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT` varchar(255) DEFAULT '0.00',
  `PUR_VAT_SGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_CGST` varchar(255) DEFAULT '0.00',
  `PUR_VAT_IGST` varchar(255) DEFAULT '0.00',
  `PUR_CESS` varchar(255) DEFAULT '0.00',
  `PUR_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT '0.00',
  `PUR_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `MRP` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'is_challan',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PURCHASE_ORDER_ITEM`
--

LOCK TABLES `PURCHASE_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `PURCHASE_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PUR_SALE_RET_MAPPING`
--

DROP TABLE IF EXISTS `PUR_SALE_RET_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PUR_SALE_RET_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `RETURN_INVOICE_ID` varchar(255) DEFAULT NULL,
  `INVOICE_REF_ID` varchar(255) DEFAULT NULL,
  `REF_TYPE` varchar(255) DEFAULT NULL,
  `ADJ_AMT` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PUR_SALE_RET_MAPPING`
--

LOCK TABLES `PUR_SALE_RET_MAPPING` WRITE;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `PUR_SALE_RET_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REGISTER`
--

DROP TABLE IF EXISTS `REGISTER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REGISTER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `USER_NAME` varchar(255) DEFAULT NULL,
  `USER_NAME_UNIQUE` varchar(255) DEFAULT NULL,
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `ACTIVATION_TOKEN` varchar(255) DEFAULT NULL,
  `ACTIVE_STATUS` varchar(255) DEFAULT 'Yes',
  `POSITION` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `META_DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL COMMENT 'salesman_id',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=407 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REGISTER`
--

LOCK TABLES `REGISTER` WRITE;
/*!40000 ALTER TABLE `REGISTER` DISABLE KEYS */;
INSERT INTO `REGISTER` VALUES (405,'257','0','emYhHb0dYz','AK','emYhHb0dYz','santoshy@yopmail.com','1','v4zICbtFlKU0','Yes','SUPER_USER','$2y$10$VKE2FCYqE1LcwwGVNqO8yOw4kcvpy2TuP1hwOOWZn1IVxU/pOMJCi','','','405','405','',0,'2026-06-09 12:18:12','2026-06-09 12:18:12'),(406,'257',NULL,'emYhHb0dYz','JANARDAN 7506767087','z5C5b3bLx6ht',NULL,'',NULL,'No','SALES_MAN','$2a$10$2I1AHqKd2Z2q7Tdns9vXn.iA472IcpjyaPPUnPAB2NF.iBUJV.GNu','',NULL,'405','405','1',0,'2026-06-10 04:57:58','2026-06-10 04:57:58');
/*!40000 ALTER TABLE `REGISTER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `REMARKS`
--

DROP TABLE IF EXISTS `REMARKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `REMARKS` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `TYPE` int DEFAULT '0',
  `META` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `REMARKS`
--

LOCK TABLES `REMARKS` WRITE;
/*!40000 ALTER TABLE `REMARKS` DISABLE KEYS */;
INSERT INTO `REMARKS` VALUES (1,'1',NULL,'','DEMO',0,'SALES_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'','BEING CHEQUE ISSUED',1,'BANK_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'','BEING CHEQUE RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'','BEING DRAFT ISSUED',1,'BANK_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(5,'1',NULL,'','BEING DRAFT RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(6,'1',NULL,'','BEING DEPOSIT CASH IN BANK',1,'BANK_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(7,'1',NULL,'','BEING CASH RECEIVED IN BANK',1,'BANK_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(8,'1',NULL,'','BEING BANK EXAPANSE',1,'BANK_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(9,'1',NULL,'','BEING ONLINE TRANSFER',1,'BANK_NARRATION','','','','2026-06-09 12:18:07',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(10,'1',NULL,'','BEING RTGS ISSUED',1,'BANK_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(11,'1',NULL,'','BEING RTGS RECEIVED',1,'BANK_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(12,'1',NULL,'','BEING CASH ISSUED',2,'CASH_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(13,'1',NULL,'','BEING CASH RECEIVED',2,'CASH_NARRATION','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `REMARKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC`
--

DROP TABLE IF EXISTS `SAC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `ACC_NAME` text,
  `MAC_ID` int DEFAULT '0',
  `OP_BALANCE` varchar(255) DEFAULT '0.00',
  `DR_CR` varchar(255) DEFAULT NULL,
  `S_ADD1` text,
  `S_ADD2` text,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `PIN_CODE` varchar(255) DEFAULT NULL,
  `PHONE` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `ALT_PER_CONTACT` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `GST_NO` varchar(255) DEFAULT NULL,
  `AADHAAR_NO` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_ACCOUNT_NO` varchar(255) DEFAULT NULL,
  `CHEQUE_PRINT_NAME` varchar(255) DEFAULT NULL,
  `BRANCH` varchar(255) DEFAULT NULL,
  `AREA_ID` varchar(255) DEFAULT '0',
  `DISCOUNT` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `PARTY_TYPE` varchar(255) DEFAULT NULL,
  `VAT_NO` varchar(255) DEFAULT NULL,
  `U_CARD_NO` varchar(255) DEFAULT NULL,
  `CST_NO` varchar(255) DEFAULT NULL,
  `CESS` varchar(255) DEFAULT NULL,
  `DL1` varchar(255) DEFAULT NULL,
  `DL2` varchar(255) DEFAULT NULL,
  `DL3` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `PAN_PI` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `CHECK_ALLOW_LIMIT` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_SALE` varchar(255) DEFAULT NULL,
  `CREDIT_DAYS_PUR` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `DISPLAY` int DEFAULT '0',
  `MASTER` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `PRIMARY_BANK` varchar(255) DEFAULT NULL,
  `IFSC` varchar(255) DEFAULT NULL,
  `BLACKLIST` varchar(255) DEFAULT '0',
  `FSSAI_EXP_DATE` varchar(255) DEFAULT NULL,
  `CUR_OUTSTANDING` varchar(255) DEFAULT '0.00',
  `IS_GST` varchar(255) DEFAULT NULL,
  `CR_AMT` varchar(255) DEFAULT '0',
  `DR_AMT` varchar(255) DEFAULT '0',
  `TCS_PERCENT` varchar(255) DEFAULT NULL,
  `IS_TCS` varchar(255) DEFAULT '0',
  `REMOTE_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC`
--

LOCK TABLES `SAC` WRITE;
/*!40000 ALTER TABLE `SAC` DISABLE KEYS */;
INSERT INTO `SAC` VALUES (1,'257',NULL,NULL,'Cash',14,'19373179.61','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'-3226070',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(2,'257',NULL,NULL,'Additional Tax(GST)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(3,'257',NULL,NULL,'Advertisement & Publicity',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(4,'257',NULL,NULL,'Bad Debts Written Off',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(5,'257',NULL,NULL,'Bank Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(6,'257',NULL,NULL,'Bonus',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(7,'257',NULL,NULL,'Books & Periodicals',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(8,'257',NULL,NULL,'Brokerage',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(9,'257',NULL,NULL,'C Form Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(10,'257',NULL,NULL,'C Form Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(11,'257',NULL,NULL,'Capital Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(12,'257',NULL,NULL,'Central Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(13,'257',NULL,NULL,'CGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(14,'257',NULL,NULL,'Charity & Donations',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'14',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(15,'257',NULL,NULL,'Commissions on Sales',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(16,'257',NULL,NULL,'Computers',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'16',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(17,'257',NULL,NULL,'Conveyance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(18,'257',NULL,NULL,'CST Purchase',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'18',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(19,'257',NULL,NULL,'Development Taxes',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'19',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(20,'257',NULL,NULL,'Edu. Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'20',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(21,'257',NULL,NULL,'Edu. Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(22,'257',NULL,NULL,'Edu. Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(23,'257',NULL,NULL,'Edu. Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'23',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(24,'257',NULL,NULL,'Excise Duties',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'24',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(25,'257',NULL,NULL,'IGST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'25',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(26,'257',NULL,NULL,'SGST',18,'245447.5','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(27,'257',NULL,NULL,'Legal Sales Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(28,'257',NULL,NULL,'Market Fees',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(29,'257',NULL,NULL,'National VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(30,'257',NULL,NULL,'RDF',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(31,'257',NULL,NULL,'Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(32,'257',NULL,NULL,'SHE Cess On Excise',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'32',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(33,'257',NULL,NULL,'SHE Cess On GST',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(34,'257',NULL,NULL,'SHE Cess On Service Tax',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(35,'257',NULL,NULL,'SHE Cess On TDS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(36,'257',NULL,NULL,'Surcharge On VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(37,'257',NULL,NULL,'TDS (Advertisment)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(38,'257',NULL,NULL,'TDS (Commission)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(39,'257',NULL,NULL,'TDS (Contractor)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(40,'257',NULL,NULL,'TDS (Interest)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(41,'257',NULL,NULL,'TDS (Rent)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'41',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(42,'257',NULL,NULL,'TDS (Salery)',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(43,'257',NULL,NULL,'VAT',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'43',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(44,'257',NULL,NULL,'Telephone Expenses',19,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(45,'257',NULL,NULL,'Customer Entertainment Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(46,'257',NULL,NULL,'Depriciation A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(47,'257',NULL,NULL,'Discount',20,'77329.8','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'47',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(48,'257',NULL,NULL,'Freight & Forwarding Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(49,'257',NULL,NULL,'Interest Payable A/c',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'49',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(50,'257',NULL,NULL,'Job Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'50',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(51,'257',NULL,NULL,'Labour',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'51',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(52,'257',NULL,NULL,'Legal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(53,'257',NULL,NULL,'Misc. Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(54,'257',NULL,NULL,'Miscellaneous Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'54',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(55,'257',NULL,NULL,'Office Maintenance Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(56,'257',NULL,NULL,'Office Rent',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'56',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-12000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(57,'257',NULL,NULL,'Office Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'57',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(58,'257',NULL,NULL,'Postal Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'58',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(59,'257',NULL,NULL,'Printing & Stationery',20,'0','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'59',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(60,'257',NULL,NULL,'Rounded Off - Sales',20,'0','CR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'60',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','0',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(61,'257',NULL,NULL,'Salery',20,'20000','DR','DEFAULT',NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,'1','0','0','1',NULL,'61',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,NULL,1,NULL,1,'1','0','0',NULL,'0','-34000',NULL,NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(62,'257',NULL,NULL,'Sales Promotion Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'62',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(63,'257',NULL,NULL,'Sewing Charges',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'63',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(64,'257',NULL,NULL,'Staff Welfare Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'64',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(65,'257',NULL,NULL,'Stitching',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'65',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(66,'257',NULL,NULL,'Travelling Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'66',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(67,'257',NULL,NULL,'Water & Electricity Expenses',20,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'67',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(68,'257',NULL,NULL,'Earnest Money',29,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'68',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(69,'257',NULL,NULL,'Furnituer & Fixture',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'69',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(70,'257',NULL,NULL,'Office Equipments',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'70',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(71,'257',NULL,NULL,'Plants & Machinery',4,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'71',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(72,'257',NULL,NULL,'CST Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'72',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(73,'257',NULL,NULL,'Interstate Retail Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'73',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(74,'257',NULL,NULL,'Local B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'74',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(75,'257',NULL,NULL,'Sales',27,'58302987.77','CR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'75',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(76,'257',NULL,NULL,'Sales Retail 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'76',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(77,'257',NULL,NULL,'Sales Retail 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'77',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(78,'257',NULL,NULL,'Sales VAT 12.5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'78',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(79,'257',NULL,NULL,'Sales VAT 5%',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'79',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(80,'257',NULL,NULL,'Dammi',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'80',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(81,'257',NULL,NULL,'Income From National VAT',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'81',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(82,'257',NULL,NULL,'Interest Receivable A/c',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'82',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(83,'257',NULL,NULL,'Rate Adjustment',22,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'83',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(84,'257',NULL,NULL,'Mall Khata A/c',30,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'84',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(85,'257',NULL,NULL,'Profit & Loss',9,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'85',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(86,'257',NULL,NULL,'Purchase',25,'53645913.6','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'86',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(87,'257',NULL,NULL,'Purchase Retail 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'87',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(88,'257',NULL,NULL,'Purchase Retail 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'88',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(89,'257',NULL,NULL,'Purchase VAT 12.5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'89',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(90,'257',NULL,NULL,'Purchase VAT 5%',25,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'90',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(91,'257',NULL,NULL,'Replacement',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'91',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(92,'257',NULL,NULL,'Stock',31,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'92',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(93,'257',NULL,NULL,'Salery & Bonus Payable',24,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'93',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(94,'257',NULL,NULL,'Interstate B2b Sales',27,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'94',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(95,'257',NULL,NULL,'CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'95',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(96,'257',NULL,NULL,'Additional CESS',18,'0','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'96',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(97,'257',NULL,NULL,'SCHEME-1',20,'35711.8406','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'97',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(98,'257',NULL,NULL,'SCHEME-2',20,'1324.16','DR','DEFAULT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,'98',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,'1',NULL,NULL,NULL,'1',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0','','1','1','',0,'2026-06-09 12:18:09','2026-06-09 12:18:09'),(99,'257',NULL,NULL,'OM SAI ENTERPRISES',5,'0','DR','OPP NAKA NO1 KALYAN AMBERNATH ROAD','SURVEY NO 170/1 SHANTI NAGAR','KALYAN','21','421002','','8308700205','','','27','27BWAPS1142Q1Z5','','','','','','1','','0','1',NULL,'',NULL,'','','','','11522021000090','','','','1','','',0,NULL,0,NULL,NULL,'0','','0','','0.00','GST','0','0','','0','0',NULL,'405','405',NULL,0,'2026-06-09 13:04:50','2026-06-09 13:04:50');
/*!40000 ALTER TABLE `SAC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_IMPORT`
--

DROP TABLE IF EXISTS `SAC_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT NULL,
  `ACCOUNT_NAME` varchar(255) DEFAULT NULL,
  `MAIN_ACCOUNT` varchar(255) DEFAULT NULL,
  `DEBIT_CREDIT` varchar(255) DEFAULT NULL,
  `OPENING_BALANCE` varchar(255) DEFAULT NULL,
  `GST_NUMBER` varchar(255) DEFAULT NULL,
  `AADHAAR_NUMBER` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `AREA_CODE` varchar(255) DEFAULT NULL,
  `AREA_ID` int NOT NULL DEFAULT '0',
  `ADDRESS1` text,
  `ADDRESS2` varchar(255) DEFAULT NULL,
  `CITY` varchar(255) DEFAULT NULL,
  `STATE` varchar(255) DEFAULT NULL,
  `STATE_CODE` varchar(255) DEFAULT NULL,
  `PIN` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `BANK_NAME` varchar(255) DEFAULT NULL,
  `BANK_BRANCH` varchar(255) DEFAULT NULL,
  `CREDIT_LIMIT` varchar(255) DEFAULT NULL,
  `BILL_LIMIT` varchar(255) DEFAULT NULL,
  `PUR_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `SALE_CREDIT_DAYS` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_NO` varchar(255) DEFAULT NULL,
  `FOOD_LICENSE_EXP_DATE` varchar(255) DEFAULT NULL,
  `REMOTE_ID` varchar(255) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_IMPORT`
--

LOCK TABLES `SAC_IMPORT` WRITE;
/*!40000 ALTER TABLE `SAC_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SAC_PG_MAP`
--

DROP TABLE IF EXISTS `SAC_PG_MAP`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SAC_PG_MAP` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SAC_ID` int DEFAULT '0',
  `PG_ID` int DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SAC_PG_MAP`
--

LOCK TABLES `SAC_PG_MAP` WRITE;
/*!40000 ALTER TABLE `SAC_PG_MAP` DISABLE KEYS */;
/*!40000 ALTER TABLE `SAC_PG_MAP` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES`
--

DROP TABLE IF EXISTS `SALES`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `PCS` varchar(255) DEFAULT NULL,
  `REF` varchar(255) DEFAULT NULL,
  `SO_NO` varchar(255) DEFAULT NULL,
  `SO_DATE` varchar(255) DEFAULT NULL,
  `TOTAL_CASH_PAY` varchar(255) DEFAULT NULL,
  `TOTAL_BANK_PAY` varchar(255) DEFAULT NULL,
  `PENDING_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` int DEFAULT '0',
  `RETURN` varchar(255) DEFAULT NULL,
  `RETURN_REF_ID` varchar(255) DEFAULT NULL,
  `SO_REF_ID` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `EWAY_BILL_NO` varchar(255) DEFAULT NULL,
  `SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `SUB_SUPPLY_TYPE` varchar(255) DEFAULT NULL,
  `DOC_TYPE` varchar(255) DEFAULT NULL,
  `TRANS_MODE` varchar(255) DEFAULT NULL,
  `TRANS_DISTANCE` varchar(255) DEFAULT NULL,
  `TRANSPORTER_NAME` varchar(255) DEFAULT NULL,
  `TRANSPORTER_ID` varchar(255) DEFAULT NULL,
  `VEHICLE_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_NO` varchar(255) DEFAULT NULL,
  `TRANS_DOC_DATE` varchar(255) DEFAULT NULL,
  `VEHICLE_TYPE` varchar(255) DEFAULT NULL,
  `EWAY_BILL_INFO` varchar(255) DEFAULT NULL,
  `PO_DATE` varchar(255) DEFAULT NULL,
  `PO_NUMBER` varchar(255) DEFAULT NULL,
  `SCHEME_REVERSE` varchar(255) DEFAULT NULL,
  `RETURN_WITH_REF` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  `GROUP_DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `DELETE_REASON` varchar(255) DEFAULT NULL,
  `M_ROUND_OFF` varchar(255) DEFAULT NULL,
  `INVOICE_STATUS` varchar(255) DEFAULT NULL,
  `TCS_TAX` varchar(255) DEFAULT '0.00',
  `TCS_PERCENT` varchar(255) DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL COMMENT 'Assigned Salesman',
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES`
--

LOCK TABLES `SALES` WRITE;
/*!40000 ALTER TABLE `SALES` DISABLE KEYS */;
INSERT INTO `SALES` VALUES (1,'257',NULL,NULL,'2026-05-07',3,1,'1','',99,'OPP NAKA NO1 KALYAN AMBERNATH ROAD SURVEY NO 170/1 SHANTI NAGAR KALYAN 27BWAPS1142Q1Z5 11522021000090',NULL,'C00820',1,'C','00820','',0,'6','16','240364.110','0','0','0','0','12018.21','6009.105','6009.105','0','0','0','-0.32','252382','252382.32','72/0','1440.00','240364.11','','0.00','0','0',NULL,'0',NULL,NULL,'',NULL,NULL,NULL,NULL,'0',0,0,NULL,NULL,NULL,'0.00','0',0,NULL,0,'0','','O','1','INV','1','33','SELF','','MH04MR0679','C00820','2026-05-07','1',NULL,'2026-05-07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0','0','0',NULL,'N','405','405','1',0,0,'2026-06-10 04:59:54','2026-06-10 04:59:54'),(2,'257','0','0','2026-06-20',3,1,'','',99,'OPP NAKA NO1 KALYAN AMBERNATH ROAD SURVEY NO 170/1 SHANTI NAGAR KALYAN 27BWAPS1142Q1Z5 11522021000090',NULL,'S0000001',2,'S','0000001','',0,'8','7','0.000','0','0','0','0','0','0','0','0','0','0','0','0','1654.80','0','0','0','','0','0','0',NULL,'0',NULL,NULL,'',NULL,'0','0','0','0',0,0,NULL,NULL,NULL,'0','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SHORT IN PACK BOX',NULL,NULL,'0','0','0',NULL,'N','405','405',NULL,0,1,'2026-06-20 08:47:34','2026-06-20 08:47:34'),(3,'257','0','0','2026-06-20',3,1,'','',99,'OPP NAKA NO1 KALYAN AMBERNATH ROAD SURVEY NO 170/1 SHANTI NAGAR KALYAN 27BWAPS1142Q1Z5 11522021000090',NULL,'S0000002',3,'S','0000002','',0,'8','7','0.000','0','0','0','0','0','0','0','0','0','0','0','0','1654.80','0','0','0','','0','0','0',NULL,'0',NULL,NULL,'',NULL,'0','0','0','0',0,0,NULL,NULL,NULL,'0','0',0,NULL,0,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'PREV. BILL NOT PAID',NULL,NULL,'0','0','0',NULL,'N','405','405',NULL,0,1,'2026-06-20 12:26:05','2026-06-20 12:26:05');
/*!40000 ALTER TABLE `SALES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALESMAN_COLLECTION_MAPPING`
--

DROP TABLE IF EXISTS `SALESMAN_COLLECTION_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALESMAN_COLLECTION_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALESMAN_ID` varchar(255) DEFAULT NULL,
  `MAPPING_DATE` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(50) DEFAULT NULL,
  `OUT_REF_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALESMAN_COLLECTION_MAPPING`
--

LOCK TABLES `SALESMAN_COLLECTION_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALESMAN_COLLECTION_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_DISPLAY`
--

DROP TABLE IF EXISTS `SALES_DISPLAY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_DISPLAY` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `DESP_DETAIL` varchar(255) DEFAULT NULL,
  `DESC` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_DISPLAY`
--

LOCK TABLES `SALES_DISPLAY` WRITE;
/*!40000 ALTER TABLE `SALES_DISPLAY` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_DISPLAY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM`
--

DROP TABLE IF EXISTS `SALES_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT '0.00',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT '0',
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `GR_DISC_AMT` varchar(255) DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(255) DEFAULT '0',
  `REMARK` varchar(255) DEFAULT NULL,
  `SALES_INSURANCE` varchar(255) DEFAULT '0.00',
  `TAX_AMT_INSURANCE` varchar(255) DEFAULT '0.00',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `INV_ARR` text,
  `INV_NO` text,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM`
--

LOCK TABLES `SALES_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM` DISABLE KEYS */;
INSERT INTO `SALES_ITEM` VALUES (1,'257',NULL,NULL,2,2,1,7,'166.18',158.2630,0,'5.00','2.5','2.5','0','','',1,NULL,'18.00','360','0','0',NULL,NULL,'0',0,'0','0','0','0','56976.01',0.0000,0.0000,'2848.80','1424.4','1424.4','0',0,'0',0,'0',NULL,NULL,'','',0,'192',NULL,'1',10,'7','158.2667','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'405','405',NULL,0,'2026-06-10 04:59:54','2026-06-10 04:59:54'),(2,'257',NULL,NULL,1,1,1,7,'891.47',849.0150,0,'5.00','2.5','2.5','0','','',1,NULL,'54.00','216','0','0',NULL,NULL,'0',0,'0','0','0','0','183388.10',0.0000,0.0000,'9169.41','4584.705','4584.705','0',0,'0',0,'0',NULL,NULL,'','',0,'1030',NULL,'5',10,'7','849.0190','0','0',0,'0',NULL,'0',NULL,'0','0',NULL,'N',NULL,NULL,'405','405',NULL,0,'2026-06-10 04:59:54','2026-06-10 04:59:54'),(4,'257',NULL,NULL,1,1,3,0,'788',849.0150,0,'5.00','0','0','0','0','0',1,NULL,'0','0','0','0','0','0','0',0,'0','0','0','0','0',0.0000,0.0000,'0','39.4','39.4','0',0,'0',0,'0',NULL,NULL,'0','0',0,'0',NULL,'0',0,'7','0','0','0',0,'0','0','0','0','0','0',NULL,'N',NULL,NULL,'405','405',NULL,0,'2026-06-20 12:26:05','2026-06-20 12:26:05');
/*!40000 ALTER TABLE `SALES_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ITEM_IMPORT`
--

DROP TABLE IF EXISTS `SALES_ITEM_IMPORT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ITEM_IMPORT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `LITE_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `WEB_ID` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_BATCH_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PACK` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DISC_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOX_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `QTY_ORIGINAL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN_QTY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FREE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROFIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_SGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_CGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_IGST` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DAMAGE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REPLACE` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `RETURN` varchar(25) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SR_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `IS_COMBI` tinyint(1) DEFAULT NULL,
  `MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UI_DISP_BAG` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `WEIGHT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PUR_UNIT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PRICE_PER` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TE_RATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_VAT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_APMC` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PW_DISCOUNT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DMG_MRP` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GR_DISC_PERCENT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REMARK` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CLOUD_SYNC` tinyint(1) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_ARR` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INV_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `UPDATED_BY` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SECURITY_KEY` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DELETED` tinyint(1) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `AREA` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `SALES_MAN` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PROD_CODE` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `DESCRIPTION` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `GROUP_ID` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PARTY_CODE` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `FINAL_AMT` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `HSN_SAC_CODE` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BATCH_NO` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `MFG_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `EXP_DATE` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INVOICE_NO` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_AT` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ITEM_IMPORT`
--

LOCK TABLES `SALES_ITEM_IMPORT` WRITE;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ITEM_IMPORT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER`
--

DROP TABLE IF EXISTS `SALES_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` int DEFAULT '0',
  `AREA` int DEFAULT '0',
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` int DEFAULT '0',
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` int DEFAULT '0',
  `PREFIX` varchar(25) DEFAULT NULL,
  `SEQUENCE` varchar(25) DEFAULT '0',
  `SUFFIX` varchar(25) DEFAULT NULL,
  `PREFIXSUFFIX_LENGTH` tinyint NOT NULL DEFAULT '0',
  `MIN_LENGTH` varchar(25) NOT NULL DEFAULT '0',
  `SERIES` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME1_TOTAL` varchar(255) DEFAULT '0.00',
  `SCHEME2_TOTAL` varchar(255) DEFAULT '0.00',
  `DISCOUNT_PERCENT` varchar(255) DEFAULT '0.00',
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT '0.00',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `ADD_AMT` varchar(255) DEFAULT '0.00',
  `LESS_AMT` varchar(255) DEFAULT '0.00',
  `ROUND_OFF` varchar(255) DEFAULT '0.00',
  `FINAL_AMT` varchar(255) DEFAULT '0.00',
  `TEMP_FINAL_AMT` varchar(255) DEFAULT '0',
  `BOX_UNIT` varchar(255) DEFAULT '0',
  `WEIGHT_KG_LTR` varchar(255) DEFAULT '0',
  `SALES_AC_AMT` varchar(255) DEFAULT '0.00',
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `GROSS_REP_AMT` varchar(255) DEFAULT '0.00',
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT '0.00',
  `AFTER_DELIVERY` varchar(255) DEFAULT '0',
  `IS_COMPLETE` int DEFAULT '0',
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` int DEFAULT '0',
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `INV_TEMPLATE_ID` int DEFAULT '0',
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` int DEFAULT '0',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `CHALLAN` int DEFAULT '0',
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` int DEFAULT '0',
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` int DEFAULT '0',
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TCS_TAX` varchar(25) NOT NULL DEFAULT '0',
  `TCS_PERCENT` varchar(25) NOT NULL DEFAULT '0',
  `CREDIT_AMT` varchar(24) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `LOGIN_ID` int NOT NULL DEFAULT '0',
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  `CANCEL_REASON` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER`
--

LOCK TABLES `SALES_ORDER` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALES_ORDER_ITEM`
--

DROP TABLE IF EXISTS `SALES_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALES_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` int DEFAULT '0',
  `PROD_BATCH_ID` int DEFAULT '0',
  `SALES_ID` int DEFAULT '0',
  `SALE_UNIT` int DEFAULT '0',
  `SALE_RATE` varchar(255) DEFAULT '0',
  `PUR_RATE` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROD_PACK` int NOT NULL DEFAULT '0',
  `SALES_VAT` varchar(255) DEFAULT '0',
  `SALES_VAT_SGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_CGST` varchar(255) DEFAULT '0.00',
  `SALES_VAT_IGST` varchar(255) DEFAULT '0.00',
  `SALES_CESS` varchar(255) DEFAULT '0.00',
  `SALES_CESS_ADDL` varchar(255) DEFAULT '0.00',
  `PACK` int DEFAULT '0',
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(25) DEFAULT '0',
  `QTY` varchar(255) DEFAULT '0.00',
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT '0.00',
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` int DEFAULT '0',
  `SCHEME1_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME1_AMOUNT` varchar(255) DEFAULT '0.00',
  `SCHEME2_PERCENT` varchar(255) DEFAULT '0.00',
  `SCHEME2_AMOUNT` varchar(255) DEFAULT '0.00',
  `AMT` varchar(255) DEFAULT '0.00',
  `PUR_AMT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `PROFIT` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `TAX_AMT` varchar(255) DEFAULT '0.00',
  `TAX_AMT_SGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_CGST` varchar(255) DEFAULT '0.00',
  `TAX_AMT_IGST` varchar(255) DEFAULT '0.00',
  `DAMAGE` int DEFAULT '0',
  `DAMAGE_AMT` varchar(255) DEFAULT '0.00',
  `REPLACE` int DEFAULT '0',
  `DIFFERENCE_AMT` varchar(255) DEFAULT '0.00',
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT '0.00',
  `CESS_AMT_ADDL` varchar(255) DEFAULT '0.00',
  `IS_COMBI` int DEFAULT '0',
  `MRP` varchar(255) DEFAULT '0.00',
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` int DEFAULT '0',
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT '0.00',
  `TAX_AMT_APMC` varchar(255) DEFAULT '0.00',
  `PW_DISCOUNT` int DEFAULT '0',
  `DMG_MRP` varchar(255) DEFAULT '0.00',
  `SALES_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `TAX_AMT_INSURANCE` varchar(25) NOT NULL DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `IS_MOBILE_ENTRY` char(4) NOT NULL DEFAULT 'Y',
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALES_ORDER_ITEM`
--

LOCK TABLES `SALES_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALES_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SALE_PUR_MAPPING`
--

DROP TABLE IF EXISTS `SALE_PUR_MAPPING`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SALE_PUR_MAPPING` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `PUR_ID` varchar(255) DEFAULT NULL,
  `SALES_ORDER_ID` varchar(255) DEFAULT NULL,
  `SALES_CHALLAN_ID` int DEFAULT '0',
  `PUR_ORDER_ID` varchar(255) DEFAULT NULL,
  `PUR_CHALLAN_ID` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SALE_PUR_MAPPING`
--

LOCK TABLES `SALE_PUR_MAPPING` WRITE;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` DISABLE KEYS */;
/*!40000 ALTER TABLE `SALE_PUR_MAPPING` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SET_INVOICE_NO`
--

DROP TABLE IF EXISTS `SET_INVOICE_NO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SET_INVOICE_NO` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `HEIGHT` varchar(255) DEFAULT NULL,
  `WIDTH` varchar(255) DEFAULT NULL,
  `CO_NAME` varchar(255) DEFAULT NULL,
  `CO_ADD` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SET_INVOICE_NO`
--

LOCK TABLES `SET_INVOICE_NO` WRITE;
/*!40000 ALTER TABLE `SET_INVOICE_NO` DISABLE KEYS */;
/*!40000 ALTER TABLE `SET_INVOICE_NO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SMAN`
--

DROP TABLE IF EXISTS `SMAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SMAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SM_ID` varchar(255) DEFAULT NULL,
  `SALES_MAN` varchar(255) DEFAULT NULL,
  `AREAS` varchar(255) DEFAULT NULL,
  `MOBILE` varchar(255) DEFAULT NULL,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SMAN`
--

LOCK TABLES `SMAN` WRITE;
/*!40000 ALTER TABLE `SMAN` DISABLE KEYS */;
INSERT INTO `SMAN` VALUES (1,'','emYhHb0dYz','01','JANARDAN 7506767087','','7506767087','257',NULL,'405','0',NULL,0,'2026-06-10 04:58:35','2026-06-10 04:58:35');
/*!40000 ALTER TABLE `SMAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYNC`
--

DROP TABLE IF EXISTS `SYNC`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYNC` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SOURCE` varchar(255) DEFAULT NULL,
  `DESTINATION` varchar(255) DEFAULT NULL,
  `SOURCE_OBJECT_ID` varchar(255) DEFAULT '0',
  `DESTINATION_OBJECT_ID` varchar(255) DEFAULT NULL,
  `ACTION` varchar(255) DEFAULT '0',
  `PREVIOUS_VALUE` text,
  `UPDATED_VALUE` text,
  `STATUS` varchar(255) DEFAULT '0',
  `STORE_ID` varchar(255) DEFAULT NULL,
  `DISTRIBUTOR_ID` varchar(255) DEFAULT NULL,
  `SYNC_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYNC`
--

LOCK TABLES `SYNC` WRITE;
/*!40000 ALTER TABLE `SYNC` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYNC` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SYSINSLOG`
--

DROP TABLE IF EXISTS `SYSINSLOG`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `SYSINSLOG` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SID` text,
  `FULLNAME` varchar(255) DEFAULT NULL,
  `USER_MOBILE` varchar(255) DEFAULT NULL,
  `ACTIVATION_KEY` varchar(255) DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `ARCH` varchar(255) DEFAULT NULL,
  `PLATFORM` varchar(255) DEFAULT NULL,
  `USER_MACID` text,
  `DIACM` text,
  `START_DATE` varchar(255) DEFAULT NULL,
  `END_DATE` varchar(255) DEFAULT NULL,
  `LANMASTER` varchar(255) DEFAULT NULL,
  `DATA` text,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SYSINSLOG`
--

LOCK TABLES `SYSINSLOG` WRITE;
/*!40000 ALTER TABLE `SYSINSLOG` DISABLE KEYS */;
/*!40000 ALTER TABLE `SYSINSLOG` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX`
--

DROP TABLE IF EXISTS `TAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_PERCENT` varchar(255) DEFAULT '0.00',
  `TAX_DETAILS` int DEFAULT '0',
  `SLAB_NAME` varchar(255) DEFAULT NULL,
  `IS_GST` int DEFAULT '0',
  `GST_CATEGORY` varchar(255) DEFAULT NULL,
  `GST_SGST` varchar(255) DEFAULT '0.00',
  `GST_CGST` varchar(255) DEFAULT '0.00',
  `GST_IGST` varchar(255) DEFAULT '0.00',
  `CESS` varchar(255) DEFAULT '0.00',
  `CESS_ADDL` varchar(255) DEFAULT '0.00',
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX`
--

LOCK TABLES `TAX` WRITE;
/*!40000 ALTER TABLE `TAX` DISABLE KEYS */;
INSERT INTO `TAX` VALUES (1,'1',NULL,'','0.00',3,'GST-0',1,'GOODS','0.00','0.00','0.00','0.00','0.00','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'','5.00',3,'GST-5',1,'GOODS','2.50','2.50','5.00','0.00','0.00','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'','12.00',3,'GST-12',1,'GOODS','6.00','6.00','12.00','0.00','0.00','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'','18.00',3,'GST-18',1,'GOODS','9.00','9.00','18.00','0.00','0.00','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(5,'1',NULL,'','28.00',3,'GST-28',1,'GOODS','14.00','14.00','28.00','0.00','0.00','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(6,'1',NULL,'','40.00',3,'GST-40',1,'GOODS','20.00','20.00','40.00','0.00','0.00','1','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `TAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TAX_TYPE`
--

DROP TABLE IF EXISTS `TAX_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TAX_TYPE` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `TAX_TYPE` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `ADD_INFO` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TAX_TYPE`
--

LOCK TABLES `TAX_TYPE` WRITE;
/*!40000 ALTER TABLE `TAX_TYPE` DISABLE KEYS */;
INSERT INTO `TAX_TYPE` VALUES (1,'1',NULL,'','Against VAT','1','','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(2,'1',NULL,'','Against CST','1','','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(3,'1',NULL,'','Against GST','1','Intra State','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07'),(4,'1',NULL,'','Against IGST','1','Inter State','','','','',0,'2026-06-09 12:18:07','2026-06-09 12:18:07');
/*!40000 ALTER TABLE `TAX_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNIT`
--

DROP TABLE IF EXISTS `UNIT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNIT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PIECES` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `KILOGRAMS` varchar(255) DEFAULT NULL,
  `GRAM` varchar(255) DEFAULT NULL,
  `LITER` varchar(255) DEFAULT NULL,
  `MILILITER` varchar(255) DEFAULT NULL,
  `TEN` varchar(255) DEFAULT NULL,
  `HUNDREADS` varchar(255) DEFAULT NULL,
  `THOUSANDS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNIT`
--

LOCK TABLES `UNIT` WRITE;
/*!40000 ALTER TABLE `UNIT` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNIT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `SALES_DATE` varchar(255) DEFAULT NULL,
  `TAX_AGAINST` varchar(255) DEFAULT NULL,
  `AREA` varchar(255) DEFAULT NULL,
  `S_MAN` varchar(255) DEFAULT NULL,
  `VAN` varchar(255) DEFAULT NULL,
  `SUB_AC_DEBTORS` varchar(255) DEFAULT NULL,
  `ACC_ADDRESS` varchar(255) DEFAULT NULL,
  `DEBTORS_ID` varchar(255) DEFAULT NULL,
  `INVOICE_NO` varchar(255) DEFAULT NULL,
  `INVOICE_SEQ` varchar(255) DEFAULT NULL,
  `GROSS_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME1_TOTAL` varchar(255) DEFAULT NULL,
  `SCHEME2_TOTAL` varchar(255) DEFAULT NULL,
  `DISCOUNT_PERCENT` varchar(255) DEFAULT NULL,
  `DISCOUNT_AMOUNT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `ADD_AMT` varchar(255) DEFAULT NULL,
  `LESS_AMT` varchar(255) DEFAULT NULL,
  `ROUND_OFF` varchar(255) DEFAULT NULL,
  `FINAL_AMT` varchar(255) DEFAULT NULL,
  `SALES_AC_AMT` varchar(255) DEFAULT NULL,
  `REMARKS` varchar(255) DEFAULT NULL,
  `SALES_AMT` varchar(255) DEFAULT NULL,
  `GROSS_DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `GROSS_REP_AMT` varchar(255) DEFAULT NULL,
  `DISPLAY_ID` varchar(255) DEFAULT NULL,
  `DISPLAY_AMT` varchar(255) DEFAULT NULL,
  `AFTER_DELIVERY` varchar(255) DEFAULT NULL,
  `IS_COMPLETE` varchar(255) DEFAULT NULL,
  `VERSION` varchar(255) DEFAULT NULL,
  `SALES_REF_ID` varchar(255) DEFAULT NULL,
  `MASTER_QUOTE` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `INV_TEMPLATE_ID` varchar(255) DEFAULT NULL,
  `TAX_INCLUSIVE` varchar(255) DEFAULT NULL,
  `DECIMAL_PRECISION` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `CHALLAN` varchar(255) DEFAULT NULL,
  `ORDER_FROM` varchar(255) DEFAULT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `ORDER_CREATED_APP_FROM` varchar(255) DEFAULT NULL,
  `SAC_DETAIL` varchar(255) DEFAULT NULL,
  `SAC_WEB_ID` varchar(255) DEFAULT NULL,
  `WEB_ACC_NAME` varchar(255) DEFAULT NULL,
  `WEB_AREA` varchar(255) DEFAULT NULL,
  `WEB_MOBILE` varchar(255) DEFAULT NULL,
  `IS_DELIVERY_SUPPORTED` varchar(255) DEFAULT NULL,
  `EMANDI_DELIVERY_TYPE` varchar(255) DEFAULT NULL,
  `DELIVERED_BY` varchar(255) DEFAULT NULL,
  `DELIVERED_TYPE` varchar(255) DEFAULT NULL,
  `EMANDI_STATUS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER`
--

LOCK TABLES `UNMAPPED_ORDER` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UNMAPPED_ORDER_ITEM`
--

DROP TABLE IF EXISTS `UNMAPPED_ORDER_ITEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UNMAPPED_ORDER_ITEM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PROD_ID` varchar(255) DEFAULT NULL,
  `PROD_BATCH_ID` varchar(255) DEFAULT NULL,
  `SALES_ID` varchar(255) DEFAULT NULL,
  `SALE_UNIT` varchar(255) DEFAULT NULL,
  `SALE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT` varchar(255) DEFAULT NULL,
  `SALES_VAT_SGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_CGST` varchar(255) DEFAULT NULL,
  `SALES_VAT_IGST` varchar(255) DEFAULT NULL,
  `SALES_CESS` varchar(255) DEFAULT NULL,
  `SALES_CESS_ADDL` varchar(255) DEFAULT NULL,
  `PACK` varchar(255) DEFAULT NULL,
  `OUTER` varchar(255) DEFAULT NULL,
  `BOX` varchar(255) DEFAULT NULL,
  `QTY` varchar(255) DEFAULT NULL,
  `DISC_PERCENT` varchar(255) DEFAULT '0',
  `DISC_AMOUNT` varchar(255) DEFAULT NULL,
  `BOX_ORIGINAL` varchar(255) DEFAULT NULL,
  `QTY_ORIGINAL` varchar(255) DEFAULT NULL,
  `RETURN_QTY` varchar(255) DEFAULT NULL,
  `FREE` varchar(255) DEFAULT NULL,
  `SCHEME1_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME1_AMOUNT` varchar(255) DEFAULT NULL,
  `SCHEME2_PERCENT` varchar(255) DEFAULT NULL,
  `SCHEME2_AMOUNT` varchar(255) DEFAULT NULL,
  `AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT` varchar(255) DEFAULT NULL,
  `TAX_AMT_SGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_CGST` varchar(255) DEFAULT NULL,
  `TAX_AMT_IGST` varchar(255) DEFAULT NULL,
  `DAMAGE` varchar(255) DEFAULT NULL,
  `DAMAGE_AMT` varchar(255) DEFAULT NULL,
  `REPLACE` varchar(255) DEFAULT NULL,
  `DIFFERENCE_AMT` varchar(255) DEFAULT NULL,
  `RETURN` varchar(255) DEFAULT NULL,
  `SR_NO` varchar(255) DEFAULT NULL,
  `CESS_AMT` varchar(255) DEFAULT NULL,
  `CESS_AMT_ADDL` varchar(255) DEFAULT NULL,
  `IS_COMBI` varchar(255) DEFAULT NULL,
  `MRP` varchar(255) DEFAULT NULL,
  `UI_DISP_BAG` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `PUR_UNIT` varchar(255) DEFAULT NULL,
  `PRICE_PER` varchar(255) DEFAULT NULL,
  `TE_RATE` varchar(255) DEFAULT NULL,
  `SALES_VAT_APMC` varchar(255) DEFAULT NULL,
  `TAX_AMT_APMC` varchar(255) DEFAULT NULL,
  `PW_DISCOUNT` varchar(255) DEFAULT NULL,
  `DMG_MRP` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UNMAPPED_ORDER_ITEM`
--

LOCK TABLES `UNMAPPED_ORDER_ITEM` WRITE;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UNMAPPED_ORDER_ITEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UOM`
--

DROP TABLE IF EXISTS `UOM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UOM` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `UOM_ID` varchar(255) DEFAULT NULL,
  `UOM` varchar(255) DEFAULT NULL,
  `MASTER` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UOM`
--

LOCK TABLES `UOM` WRITE;
/*!40000 ALTER TABLE `UOM` DISABLE KEYS */;
/*!40000 ALTER TABLE `UOM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USER_PREF`
--

DROP TABLE IF EXISTS `USER_PREF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `USER_PREF` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `PREF_NAME` varchar(255) DEFAULT NULL,
  `PREF_VALUE` varchar(255) DEFAULT NULL,
  `USER_ID` int DEFAULT '0',
  `PRINT_REF_FILE` varchar(255) DEFAULT NULL,
  `COMMON_PREFS` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `USER_PREF`
--

LOCK TABLES `USER_PREF` WRITE;
/*!40000 ALTER TABLE `USER_PREF` DISABLE KEYS */;
INSERT INTO `USER_PREF` VALUES (4,'257',NULL,NULL,'SalesReverseCalculation','1',405,NULL,NULL,NULL,'405','405',NULL,0,'2026-06-10 04:57:31','2026-06-10 04:57:31'),(5,'257',NULL,NULL,'SalesZeroStock','1',405,NULL,NULL,NULL,'405','405',NULL,0,'2026-06-10 04:57:31','2026-06-10 04:57:31'),(6,'257',NULL,NULL,'salesTemplateName','6-inch-dot-matrix-gem.hbs',405,NULL,NULL,NULL,'405','405',NULL,0,'2026-06-10 04:57:31','2026-06-10 04:57:31'),(7,'257',NULL,NULL,'SalesPurchaseDecimal4','1',405,NULL,NULL,NULL,'405','405',NULL,0,'2026-06-10 04:57:31','2026-06-10 04:57:31');
/*!40000 ALTER TABLE `USER_PREF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `VAN`
--

DROP TABLE IF EXISTS `VAN`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `VAN` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `COMPANY_ID` varchar(255) DEFAULT '0',
  `LITE_ID` varchar(255) DEFAULT NULL,
  `WEB_ID` varchar(255) DEFAULT NULL,
  `VAN_ID` varchar(255) DEFAULT NULL,
  `VAN_DETAIL` varchar(255) DEFAULT NULL,
  `CLOUD_SYNC` varchar(255) DEFAULT NULL,
  `CREATED_BY` varchar(255) DEFAULT '0',
  `UPDATED_BY` varchar(255) DEFAULT '0',
  `SECURITY_KEY` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `CREATED_TS` varchar(255) DEFAULT NULL,
  `UPDATED_TS` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `VAN`
--

LOCK TABLES `VAN` WRITE;
/*!40000 ALTER TABLE `VAN` DISABLE KEYS */;
/*!40000 ALTER TABLE `VAN` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WEB_COUNT`
--

DROP TABLE IF EXISTS `WEB_COUNT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `WEB_COUNT` (
  `ID` bigint NOT NULL AUTO_INCREMENT,
  `WEB_ID` int NOT NULL DEFAULT '0',
  `MASTER_NAME` varchar(255) DEFAULT NULL,
  `CHILD_NAME` varchar(255) DEFAULT NULL,
  `REGISTER_IDS` varchar(255) DEFAULT NULL,
  `COMPANY_IDS` varchar(255) DEFAULT NULL,
  `DELETED` int DEFAULT '0',
  `DELETED_TS` varchar(255) DEFAULT NULL,
  `CREATED_TS` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WEB_COUNT`
--

LOCK TABLES `WEB_COUNT` WRITE;
/*!40000 ALTER TABLE `WEB_COUNT` DISABLE KEYS */;
INSERT INTO `WEB_COUNT` VALUES (1,1,'master1.db','main1.db',NULL,NULL,0,NULL,'2026-06-09 12:18:12');
/*!40000 ALTER TABLE `WEB_COUNT` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-23  8:00:14
